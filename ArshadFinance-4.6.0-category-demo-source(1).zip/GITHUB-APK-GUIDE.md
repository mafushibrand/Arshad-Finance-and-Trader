# Build a testing APK with GitHub — no local Android Studio required

This workflow is prepared but has not been run in your GitHub account. A successful build produces an APK; this source ZIP is not installable. It builds the current redesign checkpoint, not a finished all-feature release.

## Steps / طریقہ

1. Download `ArshadFinance-GitHub-build.zip` and extract it on your PC.
2. Sign in at https://github.com and create a PRIVATE repository named `arshad-finance-testing`.
3. Choose **Add file → Upload files**. Upload the extracted project CONTENTS, not the ZIP. `app`, `gradle`, `build.gradle.kts`, `settings.gradle.kts` and `gradle.properties` should appear at the repository root. Include `.env.example` (it contains placeholders, not your private API key). No real key or `.env` is required for this offline testing app.
4. Windows may omit the `.github` folder from browser upload. To ensure the workflow is included, choose **Add file → Create new file**, enter `.github/workflows/android-testing.yml` as the filename, and paste the complete contents of that file from the extracted ZIP. Commit it to the default branch.
5. Open **Actions → Build Arshad Finance Testing APK → Run workflow → Run workflow**.
6. When the run is green/successful, open it and scroll to **Artifacts**. Download **ArshadFinance-v4.0-testing-APK**. Extract that downloaded artifact ZIP.
7. Copy `ArshadFinance-v4.0-testing.apk` to your Android phone. Open the APK; if Android requests it, allow **Install unknown apps** for the browser/File Manager you used. Follow the normal installation prompts.

اردو: ZIP کو extract کریں، GitHub کی private repository میں اندر والی files upload کریں۔ `.github/workflows/android-testing.yml` کو لازماً شامل کریں۔ Actions میں workflow چلائیں۔ Green کامیاب build کے بعد Artifacts سے APK والا ZIP download کریں، extract کریں اور APK فون پر کھولیں۔

The phone launcher label is **Arshad Finance Test**. This testing build uses a separate package (`com.aistudio.arshadfinance.v2stock.testing`) so it can install beside your original app. Use dummy business data for this unfinished checkpoint. Minimum Android version from source: Android 7 / API 24. Actual installation/device behavior still needs testing.

## If the build is red

Open the failed run and its failed step. Send the error log; do not send API keys, keystores or passwords. The workflow does not publish an APK if compilation, the safety tests or signature verification fail. Logs identify the issue that must be corrected before retrying. A successful build/signature check is not proof that all workflows or layouts are correct on a phone.

## Signing and updates

The workflow retains the generated Android debug signing key in a GitHub cache for testing. If that cache is removed/evicted, a new key may be generated and upgrades of the previously installed TEST app may fail. Keep durable signing material in protected secrets for stable ongoing distribution. The production app/signing key is not changed by this workflow.

## What this solves and what remains

This provides a build environment with Java, Gradle and Android SDK, bypassing the restricted downloads in this chat. It does not automatically fix compile errors, complete the outstanding business functions, or certify the design. The full custom builder, atomic posting, purchase/return processing, real screenshot approval, correct financial reporting, backup/security and complete bilingual screen review remain pending.
