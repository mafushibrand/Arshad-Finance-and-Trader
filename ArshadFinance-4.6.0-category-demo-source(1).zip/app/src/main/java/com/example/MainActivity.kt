package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import com.example.ui.FinanceTab
import com.example.ui.FinanceViewModel
import com.example.ui.PlannerSubTab
import com.example.ui.components.BottomNavBar
import com.example.ui.components.HeaderBar
import com.example.ui.dialogs.AddAccountDialog
import com.example.ui.dialogs.AddBillDialog
import com.example.ui.dialogs.AddCustomerDialog
import com.example.ui.dialogs.AddEditBudgetDialog
import com.example.ui.dialogs.AddEditInventoryDialog
import com.example.ui.dialogs.AddEditInvoiceDialog
import com.example.ui.dialogs.AddEditRecurringDialog
import com.example.ui.dialogs.AddTransactionDialog
import com.example.ui.dialogs.AuthDialog
import com.example.ui.dialogs.CustomerDetailDialog
import com.example.ui.dialogs.EmployeePermissionsDialog
import com.example.ui.dialogs.FbrTaxReportDialog
import com.example.ui.dialogs.IndustryCatalogDialog
import com.example.ui.dialogs.InvoiceDetailDialog
import com.example.ui.dialogs.PendingScreenshotApprovalsDialog
import com.example.ui.dialogs.ProfileDialog
import com.example.ui.dialogs.QuickStockAdjustDialog
import com.example.ui.dialogs.RoleLoginDialog
import com.example.ui.dialogs.ShopAccountsDialog
import com.example.ui.dialogs.ShopProfileDialog
import com.example.ui.dialogs.StockExportDialog
import com.example.ui.dialogs.StockImportDialog
import com.example.ui.dialogs.TransactionDetailDialog
import com.example.ui.dialogs.TrialLockDialog
import com.example.ui.dialogs.UpgradeProDialog
import com.example.ui.screens.BillingScreen
import com.example.ui.screens.BillsScreen
import com.example.ui.screens.CardsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.BusinessHomeScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ModeSelectionScreen
import com.example.ui.screens.PosCounterScreen
import com.example.ui.screens.ServicesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.theme.LightBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  private val viewModel: FinanceViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        FinanceApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun FinanceApp(
  viewModel: FinanceViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  var selectedCashAccount by remember { mutableStateOf("") }
  var backupDialog by remember { mutableStateOf(false) }
  var businessBuilder by remember { mutableStateOf(false) }
  var featuresOnly by remember { mutableStateOf(false) }
  val layoutDir = if (uiState.appLanguage == AppLanguage.URDU) LayoutDirection.Rtl else LayoutDirection.Ltr
  androidx.lifecycle.compose.LifecycleResumeEffect(Unit) { viewModel.refreshSubscription(); onPauseOrDispose { } }
  if(uiState.userAccount.isLoggedIn && uiState.userAccount.hasSelectedMode &&
    (uiState.appMode==com.example.data.model.AppMode.PERSONAL_KHATA || !uiState.subscriptionState.hasBusinessAccess)) {
    CompositionLocalProvider(LocalLayoutDirection provides layoutDir) {
      com.example.ui.screens.PersonalKhataScreen(uiState,
        {viewModel.openTrialLockDialog()}, {viewModel.toggleLanguage()}, {backupDialog=true},
        {name,phone,done->viewModel.personalContact(name,phone,done)},
        {id,amount,direction,note,done->viewModel.personalEntry(id,amount,direction,note,done)})
      if(uiState.showTrialLockDialog) com.example.ui.dialogs.SubscriptionDialog(uiState.subscriptionState,uiState.appLanguage,
        {viewModel.closeTrialLockDialog()}, {uri,done->viewModel.importEntitlement(uri,done)},
        {viewModel.setAppMode(com.example.data.model.AppMode.PERSONAL_KHATA);viewModel.closeTrialLockDialog()},
        {viewModel.setAppMode(com.example.data.model.AppMode.BUSINESS_RETAIL);viewModel.closeTrialLockDialog()})
      if(backupDialog) com.example.ui.dialogs.BackupDialog(uiState.appLanguage,
        {uri,password,done->viewModel.exportBusinessBackup(uri,password,done)},
        {uri,password,done->viewModel.restoreBusinessBackup(uri,password,done)}, {backupDialog=false})
    }
    return
  }

  CompositionLocalProvider(LocalLayoutDirection provides layoutDir) {
    if (!uiState.userAccount.isLoggedIn) {
      LoginScreen(
        userAccount = uiState.userAccount,
        appLanguage = uiState.appLanguage,
        onToggleLanguage = { viewModel.toggleLanguage() },
        onLoginSuccess = { mobile, shopName, ownerName, city ->
          viewModel.loginUser(mobile, shopName, ownerName, city)
        }
      )
    } else if (!uiState.userAccount.hasSelectedMode) {
      ModeSelectionScreen(
        currentMode = uiState.appMode,
        appLanguage = uiState.appLanguage,
        onModeSelected = { mode ->
          viewModel.confirmAppMode(mode)
        }
      )
    } else {
      Scaffold(
        modifier = modifier
          .fillMaxSize()
          .background(LightBackground),
        topBar = {
          HeaderBar(
            onProfileClick = { viewModel.openProfileDialog() },
            userRole = uiState.userRole,
            appLanguage = uiState.appLanguage,
            appMode = uiState.appMode,
            subscriptionState = uiState.subscriptionState,
            onSwitchRole = { viewModel.openRoleLoginDialog() },
            onToggleLanguage = { viewModel.toggleLanguage() },
            onTrialAlertClick = { viewModel.openTrialLockDialog() },
            onAuthClick = { viewModel.openAuthDialog() },
            businessName = uiState.businessProfile.businessName
          )
        },
      bottomBar = {
        BottomNavBar(
          selectedTab = uiState.selectedTab,
          onTabSelected = { tab -> viewModel.selectTab(tab) },
          cartItemCount = uiState.cartItems.values.sum().toInt(),
          appMode = uiState.appMode,
          appLanguage = uiState.appLanguage,
          features = uiState.features
        )
      },
      containerColor = LightBackground
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        when (uiState.selectedTab) {
          FinanceTab.HOME -> {
            BusinessHomeScreen(
              uiState = uiState,
              onSendClick = { viewModel.openAddTransactionDialog(TransactionType.EXPENSE) },
              onReceiveClick = { viewModel.openAddTransactionDialog(TransactionType.INCOME) },
              onStockClick = { viewModel.selectTab(FinanceTab.PRODUCTS) },
              onServicesClick = { viewModel.selectTab(FinanceTab.SERVICES) },
              onBillingClick = { viewModel.selectTab(FinanceTab.LEDGERS) },
              onBillsClick = { viewModel.selectTab(FinanceTab.PLANNER) },
              onFilterSelected = { filter -> viewModel.setFilter(filter) },
              onSearchQueryChanged = { query -> viewModel.setSearchQuery(query) },
              onTransactionClick = { tx -> viewModel.selectTransaction(tx) },
              onAddNewClick = { viewModel.openAddTransactionDialog(TransactionType.EXPENSE) },
              onOpenFbrTaxReport = { viewModel.openFbrTaxReportDialog() },
              onOpenTrialLock = { viewModel.openTrialLockDialog() },
              onSelectBusinessCategory = { cat -> viewModel.selectBusinessCategory(cat) },
              onPosClick = { viewModel.selectTab(FinanceTab.POS) },
              onReportsClick = { viewModel.selectTab(FinanceTab.REPORTS) },
              onBusinessSetup = { featuresOnly = false; businessBuilder = true }
            )
          }

        FinanceTab.LEDGERS -> {
          BillingScreen(
            uiState = uiState,
            onOpenAddInvoice = { viewModel.openAddInvoiceDialog() },
            onOpenEditInvoice = { inv -> viewModel.openEditInvoiceDialog(inv) },
            onSelectInvoice = { inv -> viewModel.openInvoiceDetailDialog(inv) },
            onOpenAddCustomer = { viewModel.openAddCustomerDialog() },
            onEditCustomer = { cust -> viewModel.openAddCustomerDialog(cust) },
            onSelectCustomer = { cust -> viewModel.openCustomerDetailDialog(cust) },
            onOpenEditProfile = { viewModel.openShopProfileDialog() },
            onOpenShopProfile = { viewModel.openShopProfileDialog() },
            onOpenIndustryCatalog = { viewModel.openIndustryCatalogDialog() },
            onDeleteInvoice = { inv -> viewModel.deleteInvoice(inv) },
            onOpenAddProduct = { viewModel.openAddInventoryDialog() }
          )
        }

        FinanceTab.SERVICES -> {
          ServicesScreen(
            uiState = uiState,
            onAddOrUpdateService = { service -> viewModel.addOrUpdateService(service) },
            onDeleteService = { id -> viewModel.deleteService(id) },
            onToggleServiceDiscount = { id, active, disc -> viewModel.toggleServiceDiscount(id, active, disc) },
            onToggleFeaturedService = { id -> viewModel.toggleFeaturedService(id) },
            onSelectServiceCategory = { cat -> viewModel.selectServiceCategory(cat) },
            onUpdateShopBioData = { bio -> viewModel.updateShopBioData(bio) },
            onAddServiceToCart = { service -> viewModel.addServiceToCart(service) }
          )
        }

        FinanceTab.POS -> {
          PosCounterScreen(
            uiState = uiState,
            onCompleteSale = { invoice, entries, syncStock, onSaved ->
              viewModel.createInvoice(invoice, entries, syncStock, onSaved)
            },
            onAddNewProduct = { viewModel.openAddInventoryDialog() },
            onAddToCart = { item, qty -> viewModel.addToCart(item.id, qty) },
            onUpdateCartQty = { itemId, qty -> viewModel.updateCartQty(itemId, qty) },
            onClearCart = { viewModel.clearCart() },
            onHoldCart={name,done->viewModel.holdCart(name,done)},onResumeCart={id,done->viewModel.resumeCart(id,done)}
          )
        }

        FinanceTab.STOCK -> {
          InventoryScreen(
            uiState = uiState,
            onAddItemClick = { viewModel.openAddInventoryDialog() },
            onEditItemClick = { item -> viewModel.openEditInventoryDialog(item) },
            onQuickAdjustClick = { item -> viewModel.openQuickStockAdjustDialog(item) },
            onDownloadStockClick = { viewModel.openStockExportDialog() },
            onUploadStockClick = { viewModel.openStockImportDialog() },
            onOpenIndustryCatalog = { viewModel.openIndustryCatalogDialog() },
            onDeleteItem = { item -> viewModel.deleteInventoryItem(item) },
            onAddToCart = { item -> viewModel.addToCart(item.id, 1.0) },
            onUpdateCartQty = { itemId, qty -> viewModel.updateCartQty(itemId, qty) },
            onClearCart = { viewModel.clearCart() },
            onGoToPos = { viewModel.selectTab(FinanceTab.POS) }
          )
        }

        FinanceTab.ACCOUNTS -> {
          CardsScreen(
            uiState = uiState,
            onAddAccountClick = { viewModel.openAddAccountDialog() },
            onDeleteAccount = { acc -> viewModel.deleteAccount(acc) },
            onSendClick = { account -> selectedCashAccount = account?.name.orEmpty(); viewModel.openAddTransactionDialog(TransactionType.EXPENSE) },
            onReceiveClick = { account -> selectedCashAccount = account?.name.orEmpty(); viewModel.openAddTransactionDialog(TransactionType.INCOME) },
            onOpenSettings = { viewModel.openShopProfileDialog() }
          )
        }

        FinanceTab.OPERATIONS -> { com.example.ui.screens.BusinessOperationsScreen(uiState, viewModel) }
        FinanceTab.PURCHASES -> { com.example.ui.screens.PurchasesScreen(uiState,onPurchase={ viewModel.openQuickStockAdjustDialog(it) },onDocuments={viewModel.openCommerce()}) }
        FinanceTab.REPORTS -> {
          StatsScreen(uiState = uiState, onTransactionClick = { viewModel.selectTransaction(it) })
        }
        FinanceTab.PLANNER -> {
          BillsScreen(
            uiState = uiState,
            onSubTabSelected = { viewModel.setPlannerSubTab(it) },
            onAddBillClick = { viewModel.openAddBillDialog() },
            onToggleBillPaid = { viewModel.toggleBillPaid(it) },
            onDeleteBill = { viewModel.deleteBill(it) },
            onAddBudgetClick = { viewModel.openAddBudgetDialog() },
            onEditBudgetClick = { viewModel.openEditBudgetDialog(it) },
            onDeleteBudget = { viewModel.deleteBudget(it) },
            onAddRecurringClick = { viewModel.openAddRecurringDialog() },
            onEditRecurringClick = { viewModel.openEditRecurringDialog(it) },
            onToggleRecurringActive = { viewModel.toggleRecurringActive(it) },
            onExecuteRecurringNow = { viewModel.executeRecurringNow(it) },
            onDeleteRecurring = { viewModel.deleteRecurringTransaction(it) },
            onProcessDueRecurring = { viewModel.processDueRecurringTransactions() }
          )
        }

        FinanceTab.SETTINGS -> {
          SettingsScreen(
            uiState = uiState,
            onOpenShopProfile = { viewModel.openShopProfileDialog() },
            onOpenShopAccounts = { viewModel.openShopAccountsDialog() },
            onAddAccountClick = { viewModel.openAddAccountDialog() },
            onOpenIndustryCatalog = { viewModel.openIndustryCatalogDialog() },
            onLoadDemoData = { viewModel.loadPakistaniBusinessDemo() },
            onResetData = { viewModel.resetAllData() },
            onSwitchRole = { viewModel.openRoleLoginDialog() },
            onOpenEmployeePermissions = { viewModel.openEmployeePermissionsDialog() },
            onOpenTrialActivation = { viewModel.openTrialLockDialog() },
            onToggleSimulateLock = { viewModel.toggleSimulateTrialLock() },
            onSelectAppMode = { mode -> viewModel.setAppMode(mode) },
            onToggleLanguage = { viewModel.toggleLanguage() },
            onOpenPendingScreenshots = { viewModel.openPendingScreenshotDialog() },
            onExportStock = { viewModel.openStockExportDialog() },
            onImportStock = { viewModel.openStockImportDialog() },
            onOpenAuthDialog = { viewModel.openAuthDialog() },
            onToggleFbrTaxMode = { viewModel.toggleFbrTaxMode() },
            onOpenFbrTaxReport = { viewModel.openFbrTaxReportDialog() },
            onOpenModeSelection = { viewModel.openModeSelection() },
            onLogout = { viewModel.logoutUser() },
            onSelectBusinessCategory = { cat -> viewModel.selectBusinessCategory(cat) },
            onOpenBackup = { backupDialog = true },
            onOpenBusinessBuilder = { featuresOnly = false; businessBuilder = true },
            onOpenFeatureToggles = { featuresOnly = true; businessBuilder = true }
          )
        }
      }
    }

    if (backupDialog) com.example.ui.dialogs.BackupDialog(uiState.appLanguage,
      { uri, password, done -> viewModel.exportBusinessBackup(uri, password, done) },
      { uri, password, done -> viewModel.restoreBusinessBackup(uri, password, done) }, { backupDialog = false })
    if (businessBuilder) com.example.ui.dialogs.BusinessBuilderDialog(uiState, featuresOnly,
      { profile, features, currency ->
        viewModel.updateBusinessSetup(profile, features, currency)
        if (!featuresOnly && profile.templateId.isNotBlank()) {
          viewModel.seedTemplateDemo(profile.templateId) { error ->
            if (error != null) android.util.Log.w("ArshadFinance", "Sample catalogue not loaded: $error")
          }
        }
        businessBuilder = false
      }, { businessBuilder = false })

    // Modal Dialogs
    if (uiState.showAddTransactionDialog) {
      AddTransactionDialog(
        appLanguage = uiState.appLanguage,
        initialAccount = selectedCashAccount,
        initialType = uiState.initialTransactionType,
        accounts = uiState.accounts,
        currencySymbol = uiState.currencySymbol,
        onDismiss = { selectedCashAccount = ""; viewModel.closeAddTransactionDialog() },
        onSave = { title, amount, type, category, icon, accountName, note, recipientInfo, paymentMethod, receiptUri, txRef ->
          viewModel.addTransaction(
            title = title,
            amount = amount,
            type = type,
            category = category,
            icon = icon,
            accountName = accountName,
            note = note,
            recipientInfo = recipientInfo,
            paymentMethod = paymentMethod,
            receiptImageUri = receiptUri,
            transactionRef = txRef
          )
        }
      )
    }

    if (uiState.showAddEditInventoryDialog) {
      AddEditInventoryDialog(
        appLanguage = uiState.appLanguage,
        templateId = uiState.businessProfile.templateId,
        onSaveFull = { item -> viewModel.saveExpandedItem(item) { error -> if(error != null) android.widget.Toast.makeText(viewModel.getApplication(), error, android.widget.Toast.LENGTH_LONG).show() } },
        item = uiState.editingInventoryItem,
        currencySymbol = uiState.currencySymbol,
        totalExistingProductsCount = uiState.inventoryItems.size,
        isBasicTierRestricted = uiState.isBasicTierRestricted,
        onDismiss = { viewModel.closeAddEditInventoryDialog() },
        onSave = { id, name, category, icon, costPrice, salePrice, stock, unit, threshold, barcode, supplier, note ->
          viewModel.saveInventoryItem(
            id = id,
            name = name,
            category = category,
            icon = icon,
            costPrice = costPrice,
            salePrice = salePrice,
            currentStock = stock,
            unit = unit,
            lowStockThreshold = threshold,
            barcode = barcode,
            supplierName = supplier,
            note = note
          )
        },
        onDelete = { item -> viewModel.deleteInventoryItem(item) }
      )
    }

    if (uiState.showQuickStockAdjustDialog && uiState.adjustingInventoryItem != null) {
      QuickStockAdjustDialog(
        appLanguage = uiState.appLanguage,
        item = uiState.adjustingInventoryItem!!,
        currencySymbol = uiState.currencySymbol,
        onDismiss = { viewModel.closeQuickStockAdjustDialog() },
        onAddStock = { qty, cost ->
          viewModel.addInventoryStock(uiState.adjustingInventoryItem!!, qty, cost)
        },
        onDeductStock = { qty, recordSale ->
          viewModel.deductInventoryStock(uiState.adjustingInventoryItem!!, qty, recordSale)
        }
      )
    }

    if (uiState.showAddAccountDialog) {
      AddAccountDialog(
        appLanguage = uiState.appLanguage,
        currencySymbol = uiState.currencySymbol,
        onDismiss = { viewModel.closeAddAccountDialog() },
        onSave = { name, accountType, balance, cardNumber, colorHex ->
          viewModel.addAccount(name, accountType, balance, cardNumber, colorHex)
        }
      )
    }

    if (uiState.showAddBillDialog) {
      AddBillDialog(
        currencySymbol = uiState.currencySymbol,
        onDismiss = { viewModel.closeAddBillDialog() },
        onSave = { title, amount, dueDate, category, icon ->
          viewModel.addBill(title, amount, dueDate, category, icon)
        }
      )
    }

    if (uiState.showAddRecurringDialog) {
      AddEditRecurringDialog(
        recurring = uiState.editingRecurring,
        accounts = uiState.accounts,
        currencySymbol = uiState.currencySymbol,
        onDismiss = { viewModel.closeRecurringDialog() },
        onSave = { id, title, amount, type, category, icon, accountName, freq, startMillis, endMillis, nextExec, note ->
          viewModel.saveRecurringTransaction(
            id = id,
            title = title,
            amount = amount,
            type = type,
            category = category,
            icon = icon,
            accountName = accountName,
            frequency = freq,
            startDateMillis = startMillis,
            endDateMillis = endMillis,
            nextExecutionDateMillis = nextExec,
            note = note
          )
        },
        onDelete = { rec -> viewModel.deleteRecurringTransaction(rec) }
      )
    }

    if (uiState.showAddEditBudgetDialog) {
      AddEditBudgetDialog(
        budget = uiState.editingBudget,
        currencySymbol = uiState.currencySymbol,
        onDismiss = { viewModel.closeAddEditBudgetDialog() },
        onSave = { id, category, limit, icon, period ->
          viewModel.saveBudget(
            id = id,
            category = category,
            limitAmount = limit,
            icon = icon,
            period = period
          )
        },
        onDelete = { bud -> viewModel.deleteBudget(bud) }
      )
    }

    if (uiState.selectedTransaction != null) {
      val tx = uiState.selectedTransaction!!
      TransactionDetailDialog(
        transaction = tx,
        currencySymbol = uiState.currencySymbol,
        businessProfile = uiState.businessProfile,
        onDismiss = { viewModel.selectTransaction(null) },
        onDelete = { viewModel.deleteTransaction(tx) }
      )
    }

    if (uiState.showProfileDialog) {
      ProfileDialog(
        currentCurrency = uiState.currencySymbol,
        businessProfile = uiState.businessProfile,
        accounts = uiState.accounts,
        transactions = uiState.transactions,
        onCurrencySelected = { cur -> viewModel.setCurrencySymbol(cur) },
        onSaveBusinessProfile = { profile -> viewModel.updateBusinessProfile(profile) },
        onLoadDemoData = { viewModel.loadPakistaniBusinessDemo() },
        onResetAllData = { viewModel.resetAllData() },
        onOpenUpgradePro = { viewModel.openUpgradeDialog() },
        onDismiss = { viewModel.closeProfileDialog() }
      )
    }

    if (uiState.showStockExportDialog) {
      StockExportDialog(
        items = uiState.inventoryItems,
        currencySymbol = uiState.currencySymbol,
        businessProfile = uiState.businessProfile,
        onDismiss = { viewModel.closeStockExportDialog() }
      )
    }

    if (uiState.showStockImportDialog) {
      StockImportDialog(
        currencySymbol = uiState.currencySymbol,
        businessProfile = uiState.businessProfile,
        onDismiss = { viewModel.closeStockImportDialog() },
        onConfirmImport = { items, replaceExisting ->
          viewModel.importStockItems(items, replaceExisting)
        }
      )
    }

    // Billing & Customer Dialogs
    if (uiState.showAddInvoiceDialog) {
      AddEditInvoiceDialog(
        appLanguage = uiState.appLanguage,
        businessProfile = uiState.businessProfile,
        customers = uiState.customers,
        inventoryItems = uiState.inventoryItems,
        editingInvoice = uiState.editingInvoice,
        initialCustomer = uiState.customerForNewBill,
        currencySymbol = uiState.currencySymbol,
        onOpenShopProfile = { viewModel.openShopProfileDialog() },
        onSaveInvoice = { inv, items, syncStock, onSaved ->
          viewModel.createInvoice(inv, items, syncStock, onSaved)
        },
        onAddNewProductToInventory = { item ->
          viewModel.insertInventoryItemDirectly(item)
        },
        onDismiss = { viewModel.closeAddInvoiceDialog() }
      )
    }

    if (uiState.showInvoiceDetailDialog && uiState.selectedInvoice != null) {
      InvoiceDetailDialog(
        invoice = uiState.selectedInvoice!!,
        businessProfile = uiState.businessProfile,
        currencySymbol = uiState.currencySymbol,
        onEditInvoice = { inv -> viewModel.openEditInvoiceDialog(inv) },
        onDeleteInvoice = { inv -> viewModel.deleteInvoice(inv) },
        canEdit = uiState.userRole == com.example.data.model.UserRole.OWNER,
        onDismiss = { viewModel.closeInvoiceDetailDialog() }
      )
    }

    if (uiState.showShopProfileDialog) {
      ShopProfileDialog(
        appLanguage = uiState.appLanguage,
        currentProfile = uiState.businessProfile,
        onSaveProfile = { profile -> viewModel.updateBusinessProfile(profile) },
        onDismiss = { viewModel.closeShopProfileDialog() }
      )
    }

    if (uiState.showAddCustomerDialog) {
      AddCustomerDialog(
        appLanguage = uiState.appLanguage,
        editingCustomer = uiState.selectedCustomer,
        totalExistingCustomersCount = uiState.customers.size,
        isBasicTierRestricted = uiState.isBasicTierRestricted,
        onSaveCustomer = { cust -> viewModel.saveCustomer(cust) },
        onDismiss = { viewModel.closeAddCustomerDialog() }
      )
    }

    if (uiState.showCustomerDetailDialog && uiState.selectedCustomer != null) {
      CustomerDetailDialog(
        appLanguage = uiState.appLanguage,
        onReceiveCash = { amount, note, done -> viewModel.receiveCustomerCash(uiState.selectedCustomer!!, amount, note, done) },
        customer = uiState.selectedCustomer!!,
        invoices = uiState.invoices,
        businessProfile = uiState.businessProfile,
        currencySymbol = uiState.currencySymbol,
        onEditCustomer = { cust -> viewModel.openAddCustomerDialog(cust) },
        onSelectInvoice = { inv -> viewModel.openInvoiceDetailDialog(inv) },
        onNewBillForCustomer = { cust ->
          viewModel.openAddInvoiceDialog(cust)
        },
        onDeleteCustomer = { cust -> viewModel.deleteCustomer(cust) },
        onDismiss = { viewModel.closeCustomerDetailDialog() }
      )
    }

    if (uiState.showIndustryCatalogDialog) {
      IndustryCatalogDialog(
        currentBusinessProfile = uiState.businessProfile,
        onImportCatalog = { industryId, shopType, logoEmoji ->
          viewModel.importIndustryCatalog(industryId, shopType, logoEmoji)
        },
        onDismiss = { viewModel.closeIndustryCatalogDialog() }
      )
    }

    if (uiState.showShopAccountsDialog) {
      ShopAccountsDialog(
        currentProfile = uiState.businessProfile,
        onSave = { updated -> viewModel.updateBusinessProfile(updated) },
        onDismiss = { viewModel.closeShopAccountsDialog() }
      )
    }

    if (uiState.showTrialLockDialog || uiState.showUpgradeDialog) {
      com.example.ui.dialogs.SubscriptionDialog(uiState.subscriptionState,uiState.appLanguage,
        {viewModel.closeTrialLockDialog();viewModel.closeUpgradeDialog()}, {uri,done->viewModel.importEntitlement(uri,done)},
        {viewModel.setAppMode(com.example.data.model.AppMode.PERSONAL_KHATA);viewModel.closeTrialLockDialog();viewModel.closeUpgradeDialog()},
        {viewModel.setAppMode(com.example.data.model.AppMode.BUSINESS_RETAIL);viewModel.closeTrialLockDialog()})
    }

    if (uiState.showRoleLoginDialog || (uiState.userAccount.isLoggedIn && uiState.userAccount.hasSelectedMode && uiState.ownerAuthRequired)) {
      RoleLoginDialog(
        currentRole = uiState.userRole,
        validateOwnerPin = {pin->viewModel.validateOwnerPin(pin)},
        ownerPinConfigured = viewModel.ownerPinConfigured(),
        subscriptionState = uiState.subscriptionState,
        onSelectRole = { role -> viewModel.setUserRole(role) },
        onDismiss = { viewModel.closeRoleLoginDialog() }
      )
    }

    if (uiState.showEmployeePermissionsDialog) {
      EmployeePermissionsDialog(
        currentPermissions = uiState.employeePermissions,
        onSavePermissions = { perms -> viewModel.updateEmployeePermissions(perms) },
        onDismiss = { viewModel.closeEmployeePermissionsDialog() }
      )
    }

    if (uiState.showPendingScreenshotDialog) {
      PendingScreenshotApprovalsDialog(
        pendingInvoices = uiState.pendingScreenshotInvoices,
        currency = uiState.currencySymbol,
        onApprove = { invoice -> viewModel.approveScreenshotInvoice(invoice) },
        onReject = { invoice -> viewModel.rejectScreenshotInvoice(invoice) },
        onDismiss = { viewModel.closePendingScreenshotDialog() }
      )
    }

    if (uiState.showAuthDialog) {
      AuthDialog(
        currentAccount = uiState.userAccount,
        appLanguage = uiState.appLanguage,
        onDismiss = { viewModel.closeAuthDialog() },
        onLoginSuccess = { mob, shop, reg -> viewModel.loginUser(mob, shop, reg) }
      )
    }

    if (uiState.showFbrTaxReportDialog) {
      FbrTaxReportDialog(
        invoices = uiState.invoices,
        shopName = uiState.userAccount.shopName,
        ownerName = uiState.userAccount.ownerName,
        currencySymbol = uiState.currencySymbol,
        appLanguage = uiState.appLanguage,
        onDismiss = { viewModel.closeFbrTaxReportDialog() }
      )
    }
  }
}
}
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
  MyApplicationTheme { Greeting("Android") }
}
