package com.example.util

import android.content.Context
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.widget.Toast
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.example.data.model.Invoice
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/** Wrapped text and measured height keep long item names and Urdu inside the saved receipt. */
object ThermalReceiptImage {
  fun text(invoice: Invoice, profile: BusinessProfile, currency: String): String {
    fun money(n:Double)=String.format(Locale.US,"%s %,.2f",currency,n)
    val date=SimpleDateFormat("yyyy-MM-dd | hh:mm a",Locale.ENGLISH).apply { timeZone=TimeZone.getTimeZone("Asia/Karachi") }.format(Date(invoice.dateMillis))
    return buildString {
      appendLine(invoice.businessName.ifBlank {profile.businessName})
      val address=invoice.businessAddress.ifBlank {profile.address};if(address.isNotBlank())appendLine(address)
      val phone=invoice.businessPhone.ifBlank {profile.phone};if(phone.isNotBlank())appendLine(phone)
      appendLine("────────────────────────")
      appendLine("INVOICE / بل کی تفصیل")
      appendLine("Bill / بل: ${invoice.invoiceNumber}")
      appendLine("Date / تاریخ: $date")
      appendLine("Customer / گاہک: ${invoice.customerName}")
      if(invoice.customerPhone.isNotBlank())appendLine(invoice.customerPhone)
      appendLine("────────────────────────")
      invoice.parseItems().forEachIndexed {i,item->
        appendLine("${i+1}. ${item.itemName}")
        appendLine("   ${item.quantity} ${item.unit} × ${money(item.unitPrice)}")
        appendLine("   ${money(item.total)}")
      }
      appendLine("────────────────────────")
      appendLine("Subtotal / رقم: ${money(invoice.subtotal)}")
      if(invoice.discountAmount!=0.0)appendLine("Discount / رعایت: ${money(invoice.discountAmount)}")
      if(invoice.taxAmount!=0.0)appendLine("Tax / ٹیکس: ${money(invoice.taxAmount)}")
      if(invoice.deliveryOrLabour!=0.0)appendLine("Delivery / Labour: ${money(invoice.deliveryOrLabour)}")
      appendLine("TOTAL BILL / کل بل: ${money(invoice.grandTotal)}")
      val returned=(invoice.grandTotal-invoice.netTotal()).coerceAtLeast(0.0)
      if(returned>0){appendLine("Returned / واپس: ${money(returned)}");appendLine("Net bill / موجودہ بل: ${money(invoice.netTotal())}")}
      appendLine("Received / وصول: ${money(invoice.amountPaid)}")
      appendLine("Due / بقایا: ${money(invoice.remainingBalance)}")
      appendLine("Payment / ادائیگی: ${invoice.paymentMethod}")
      appendLine(if(invoice.remainingBalance<=0.0)"[ PAID / وصول شدہ ]" else "[ DUE / بقایا ]")
      if(invoice.note.isNotBlank())appendLine("Note / نوٹ: ${invoice.note}")
      appendLine("────────────────────────")
      appendLine("Thank you / شکریہ")
    }
  }
  fun bitmap(invoice:Invoice,profile:BusinessProfile,currency:String):Bitmap {
    val paint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply {color=Color.rgb(25,35,30);textSize=27f;typeface=Typeface.MONOSPACE}
    val body=text(invoice,profile,currency)
    val layout=StaticLayout.Builder.obtain(body,0,body.length,paint,632)
      .setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(true).setLineSpacing(7f,1f).build()
    val bmp=Bitmap.createBitmap(720,layout.height+88,Bitmap.Config.ARGB_8888)
    val canvas=Canvas(bmp);canvas.drawColor(Color.WHITE);canvas.save();canvas.translate(44f,44f);layout.draw(canvas);canvas.restore()
    return bmp
  }
  fun file(context:Context,invoice:Invoice,profile:BusinessProfile,currency:String):File {
    val folder=File(context.filesDir,"bill-images").apply {mkdirs()}
    val safe=invoice.invoiceNumber.replace(Regex("[^A-Za-z0-9_-]"),"_").take(70)
    val file=File(folder,"Bill_${invoice.id}_${safe}.png")
    val bmp=bitmap(invoice,profile,currency)
    try {file.outputStream().use {check(bmp.compress(Bitmap.CompressFormat.PNG,100,it))}} finally {bmp.recycle()}
    return file
  }
  fun save(context:Context,destination:Uri,invoice:Invoice,profile:BusinessProfile,currency:String) {
    val file=file(context,invoice,profile,currency)
    context.contentResolver.openOutputStream(destination,"wt").use {out->requireNotNull(out);file.inputStream().use {it.copyTo(out)}}
  }
  /** Creates a JPEG copy of the exact thermal-layout receipt for WhatsApp. */
  internal fun whatsappImageFile(
    context: Context,
    invoice: Invoice,
    profile: BusinessProfile,
    currency: String
  ): File {
    val folder = File(context.cacheDir, "thermal-whatsapp").apply { mkdirs() }
    val safe = invoice.invoiceNumber.replace(Regex("[^A-Za-z0-9_-]"), "_").take(70)
    val imageFile = File(folder, "Thermal_${invoice.id}_${safe}.jpg")
    val receipt = bitmap(invoice, profile, currency)
    try {
      imageFile.outputStream().use { output ->
        check(receipt.compress(Bitmap.CompressFormat.JPEG, 96, output)) {
          "Could not encode thermal receipt image"
        }
      }
    } finally {
      receipt.recycle()
    }
    return imageFile
  }

  /**
   * Shares the thermal receipt as one image/jpeg stream. WhatsApp receives
   * the content URI with explicit read permission; no text-only payload is
   * mixed into the image share.
   */
  fun share(context: Context, invoice: Invoice, profile: BusinessProfile, currency: String) {
    val imageFile = whatsappImageFile(context, invoice, profile, currency)
    val uri = FileProvider.getUriForFile(
      context,
      "${context.packageName}.fileprovider",
      imageFile
    )
    val sendIntent = Intent(Intent.ACTION_SEND).apply {
      type = "image/jpeg"
      putExtra(Intent.EXTRA_STREAM, uri)
      clipData = android.content.ClipData.newUri(
        context.contentResolver,
        "Thermal receipt",
        uri
      )
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    // Prefer WhatsApp; support WhatsApp Business as a fallback.
    val targets = listOf("com.whatsapp", "com.whatsapp.w4b")
    var shared = false
    for (target in targets) {
      try {
        context.startActivity(Intent(sendIntent).setPackage(target))
        shared = true
        break
      } catch (_: ActivityNotFoundException) {
        // Try the next supported destination.
      } catch (_: SecurityException) {
        // Fall back to Android's standard share sheet.
      }
    }
    if (!shared) {
      context.startActivity(
        Intent.createChooser(sendIntent, "Share thermal receipt / تھرمل رسید شیئر کریں")
      )
    }
    Toast.makeText(
      context,
      "Thermal receipt image ready / تھرمل رسید کی تصویر تیار ہے",
      Toast.LENGTH_SHORT
    ).show()
  }
}
