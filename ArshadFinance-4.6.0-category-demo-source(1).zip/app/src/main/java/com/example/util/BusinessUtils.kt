package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BusinessProfile(
  val businessName: String = "Arshad Finance & Traders",
  val ownerName: String = "",
  val phone: String = "",
  val address: String = "",
  val tagline: String = "Wholesale & Retail Management Khata",
  val ntnNumber: String = "",
  val shopType: String = "General Business",
  val templateId: String = "kiryana",
  val sector: String = "Retail",
  val category: String = "Grocery",
  val subcategory: String = "",
  val logoEmoji: String = "🏪",
  val invoicePrefix: String = "AF",
  val bankName: String = "",
  val bankAccountTitle: String = "",
  val bankAccountNumber: String = "",
  val bankIban: String = "",
  val jazzCashNumber: String = "",
  val easyPaisaNumber: String = "",
  val sadaPayNumber: String = "",
  val nayaPayNumber: String = "",
  val raastId: String = "",
  val customPaymentSlots: String = "",
  val isFbrTaxEnabled: Boolean = false,
  val fbrTaxRatePercent: Double = 0.0,
  val fbrPosId: String = ""
)

object BusinessUtils {

  /**
   * Share text directly to WhatsApp or Android share sheet
   */
  fun shareWhatsAppMessage(context: Context, phoneNumber: String, message: String) {
    try {
      val cleanPhone = phoneNumber.replace(Regex("[^0-9+]"), "").removePrefix("+")
      val url = if (cleanPhone.isNotBlank()) {
        "https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}"
      } else {
        "https://api.whatsapp.com/send?text=${Uri.encode(message)}"
      }
      val intent = Intent(Intent.ACTION_VIEW).apply {
        data = Uri.parse(url)
        setPackage("com.whatsapp")
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      // Fallback to generic chooser if WhatsApp is not installed
      try {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
          type = "text/plain"
          putExtra(Intent.EXTRA_TEXT, message)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Khata Message via"))
      } catch (ex: Exception) {
        Toast.makeText(context, "Could not open sharing app", Toast.LENGTH_SHORT).show()
      }
    }
  }

  /**
   * Generate Urdu / English Payment Reminder Message
   */
  fun buildReminderMessage(
    customerName: String,
    amount: Double,
    currency: String,
    businessProfile: BusinessProfile,
    isUrdu: Boolean = true
  ): String {
    val dateStr = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
    return if (isUrdu) {
      """
      *📋 ادھار و کھاتہ یاد دہانی (Payment Reminder)*
      ----------------------------------------
      محترم جناب *${customerName.ifBlank { "محترم کسٹمر" }}*!
      
      آپ کی طرف *${businessProfile.businessName}* کا بقایا واجب الادا ہے:
      💰 *بقایا رقم: $currency ${"%,.2f".format(amount)}*
      📅 تاریخ: $dateStr
      
      برائے مہربانی اپنی جلد از جلد ادائیگی یقینی بنائیں۔
      شکریہ!
      
      🏢 *${businessProfile.businessName}*
      📞 رابطہ: ${businessProfile.phone}
      """.trimIndent()
    } else {
      """
      *📋 Payment Reminder Notice*
      ----------------------------------------
      Dear *${customerName.ifBlank { "Valued Customer" }}*,
      
      This is a gentle payment reminder from *${businessProfile.businessName}*.
      💰 *Outstanding Balance: $currency ${"%,.2f".format(amount)}*
      📅 Date: $dateStr
      
      Please arrange the payment at your earliest convenience.
      Thank you for your business!
      
      🏢 *${businessProfile.businessName}*
      📞 Contact: ${businessProfile.phone}
      """.trimIndent()
    }
  }

  /**
   * Generate and Share Transaction Receipt as PDF
   */
  fun generateAndShareReceiptPdf(
    context: Context,
    transaction: Transaction,
    currencySymbol: String,
    businessProfile: BusinessProfile
  ) {
    try {
      val document = PdfDocument()
      val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // Standard A4 points
      val page = document.startPage(pageInfo)
      val canvas = page.canvas

      val paint = Paint().apply { isAntiAlias = true }
      val isIncome = transaction.type == TransactionType.INCOME
      val dateFormat = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault())
      val dateFormatted = dateFormat.format(Date(transaction.dateMillis))

      // 1. Header Banner
      paint.color = Color.rgb(10, 37, 64) // Deep Navy
      canvas.drawRect(0f, 0f, 595f, 130f, paint)

      // Header Text
      paint.color = Color.WHITE
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 24f
      canvas.drawText(businessProfile.businessName, 36f, 50f, paint)

      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      paint.textSize = 12f
      canvas.drawText(businessProfile.tagline, 36f, 72f, paint)
      canvas.drawText("Phone: ${businessProfile.phone}  |  ${businessProfile.address}", 36f, 92f, paint)
      canvas.drawText("Tax / NTN: ${businessProfile.ntnNumber}", 36f, 110f, paint)

      // Receipt Title
      paint.color = Color.rgb(240, 244, 248)
      canvas.drawRoundRect(36f, 150f, 559f, 210f, 16f, 16f, paint)

      paint.color = Color.rgb(10, 37, 64)
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 16f
      val receiptType = if (isIncome) "CASH INFLOW / RECEIPT VOUCHER" else "PAYMENT / EXPENSE VOUCHER"
      canvas.drawText(receiptType, 50f, 185f, paint)

      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      paint.textSize = 12f
      paint.color = Color.rgb(100, 116, 139)
      val invoiceRef = transaction.transactionRef.ifBlank { "INV-${transaction.id.toString().takeLast(6).uppercase()}" }
      canvas.drawText("Invoice #: $invoiceRef", 380f, 175f, paint)
      canvas.drawText("Date: $dateFormatted", 380f, 195f, paint)

      // Details Table
      var currentY = 240f
      fun drawRow(label: String, value: String, isBold: Boolean = false, valueColor: Int = Color.rgb(30, 41, 59)) {
        paint.color = Color.rgb(100, 116, 139)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 13f
        canvas.drawText(label, 50f, currentY, paint)

        paint.color = valueColor
        paint.typeface = Typeface.create(Typeface.DEFAULT, if (isBold) Typeface.BOLD else Typeface.NORMAL)
        canvas.drawText(value, 200f, currentY, paint)

        paint.color = Color.rgb(226, 232, 240)
        paint.strokeWidth = 1f
        canvas.drawLine(50f, currentY + 12f, 545f, currentY + 12f, paint)
        currentY += 40f
      }

      drawRow("Party / Customer:", transaction.recipientInfo.ifBlank { "Walk-in Customer / Direct" }, isBold = true)
      drawRow("Item / Particulars:", transaction.title, isBold = true)
      drawRow("Category:", "${transaction.icon} ${transaction.category}")
      drawRow("Payment Account:", transaction.accountName)
      drawRow("Payment Method:", transaction.paymentMethod)
      if (transaction.note.isNotBlank()) {
        drawRow("Remarks / Note:", transaction.note)
      }

      // Total Box
      currentY += 15f
      paint.color = if (isIncome) Color.rgb(236, 253, 245) else Color.rgb(254, 242, 242)
      canvas.drawRoundRect(50f, currentY, 545f, currentY + 70f, 12f, 12f, paint)

      paint.color = if (isIncome) Color.rgb(16, 185, 129) else Color.rgb(239, 68, 68)
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 14f
      canvas.drawText("TOTAL AMOUNT PAID:", 70f, currentY + 42f, paint)

      paint.textSize = 22f
      val amountStr = "$currencySymbol ${"%,.2f".format(transaction.amount)}"
      canvas.drawText(amountStr, 340f, currentY + 44f, paint)

      // Signature and Terms
      val footerY = 740f
      paint.color = Color.rgb(148, 163, 184)
      paint.strokeWidth = 1f
      canvas.drawLine(50f, footerY, 220f, footerY, paint)
      canvas.drawLine(375f, footerY, 545f, footerY, paint)

      paint.textSize = 11f
      paint.color = Color.rgb(100, 116, 139)
      canvas.drawText("Customer / Receiver Sign", 65f, footerY + 20f, paint)
      canvas.drawText("Authorized Signature", 405f, footerY + 20f, paint)

      paint.textSize = 9f
      paint.color = Color.rgb(148, 163, 184)
      canvas.drawText("Generated electronically via Arshad Finance Management System. Valid without physical stamp.", 70f, 810f, paint)

      document.finishPage(page)

      // Save to cache directory
      val pdfFile = File(context.cacheDir, "Receipt_${transaction.id.toString().takeLast(6)}.pdf")
      FileOutputStream(pdfFile).use { out ->
        document.writeTo(out)
      }
      document.close()

      // Share PDF File
      val uri: Uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        pdfFile
      )

      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Receipt Voucher - ${transaction.title}")
        putExtra(Intent.EXTRA_TEXT, "Here is your official receipt for $currencySymbol ${"%,.2f".format(transaction.amount)} from ${businessProfile.businessName}.")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      context.startActivity(Intent.createChooser(shareIntent, "Share Receipt PDF via"))
    } catch (e: Exception) {
      e.printStackTrace()
      Toast.makeText(context, "Error generating PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
  }

  /**
   * Generate and Share Full Khata / P&L Statement PDF
   */
  fun generateAndShareStatementPdf(
    context: Context,
    transactions: List<Transaction>,
    totalIncome: Double,
    totalExpense: Double,
    totalBalance: Double,
    currencySymbol: String,
    businessProfile: BusinessProfile
  ) {
    try {
      val document = PdfDocument()
      val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
      val page = document.startPage(pageInfo)
      val canvas = page.canvas
      val paint = Paint().apply { isAntiAlias = true }

      // Header Banner
      paint.color = Color.rgb(10, 37, 64)
      canvas.drawRect(0f, 0f, 595f, 120f, paint)

      paint.color = Color.WHITE
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 22f
      canvas.drawText(businessProfile.businessName, 36f, 45f, paint)

      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      paint.textSize = 11f
      canvas.drawText("ACCOUNT STATEMENT & PROFIT / LOSS SUMMARY", 36f, 68f, paint)
      canvas.drawText("Phone: ${businessProfile.phone}  |  ${businessProfile.address}", 36f, 88f, paint)
      canvas.drawText("Report Generated: ${SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date())}", 36f, 106f, paint)

      // Summary Cards
      val netProfit = totalIncome - totalExpense
      fun drawStatBox(x: Float, label: String, amount: Double, bgColor: Int, textColor: Int) {
        paint.color = bgColor
        canvas.drawRoundRect(x, 135f, x + 160f, 195f, 12f, 12f, paint)

        paint.color = Color.rgb(100, 116, 139)
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(label, x + 14f, 155f, paint)

        paint.color = textColor
        paint.textSize = 15f
        canvas.drawText("$currencySymbol ${"%,.0f".format(amount)}", x + 14f, 180f, paint)
      }

      drawStatBox(36f, "TOTAL INCOME (+)", totalIncome, Color.rgb(236, 253, 245), Color.rgb(16, 185, 129))
      drawStatBox(216f, "TOTAL EXPENSE (-)", totalExpense, Color.rgb(254, 242, 242), Color.rgb(239, 68, 68))
      drawStatBox(396f, "NET BALANCE / PROFIT", netProfit, Color.rgb(240, 249, 255), Color.rgb(2, 132, 199))

      // Table Header
      var curY = 225f
      paint.color = Color.rgb(241, 245, 249)
      canvas.drawRect(36f, curY, 559f, curY + 28f, paint)

      paint.color = Color.rgb(30, 41, 59)
      paint.textSize = 10f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      canvas.drawText("DATE", 45f, curY + 18f, paint)
      canvas.drawText("PARTICULARS / ITEM", 130f, curY + 18f, paint)
      canvas.drawText("PARTY / NOTE", 290f, curY + 18f, paint)
      canvas.drawText("TYPE", 410f, curY + 18f, paint)
      canvas.drawText("AMOUNT", 480f, curY + 18f, paint)

      curY += 28f
      val df = SimpleDateFormat("dd/MM/yy", Locale.getDefault())

      val displayList = transactions.take(15)
      displayList.forEachIndexed { index, tx ->
        val isInc = tx.type == TransactionType.INCOME
        paint.color = if (index % 2 == 0) Color.WHITE else Color.rgb(248, 250, 252)
        canvas.drawRect(36f, curY, 559f, curY + 28f, paint)

        paint.color = Color.rgb(71, 85, 105)
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(df.format(Date(tx.dateMillis)), 45f, curY + 18f, paint)

        val titleTruncated = if (tx.title.length > 20) tx.title.take(18) + ".." else tx.title
        canvas.drawText(titleTruncated, 130f, curY + 18f, paint)

        val partyTruncated = if (tx.recipientInfo.isNotBlank()) tx.recipientInfo.take(18) else tx.category
        canvas.drawText(partyTruncated, 290f, curY + 18f, paint)

        paint.color = if (isInc) Color.rgb(16, 185, 129) else Color.rgb(239, 68, 68)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(if (isInc) "INCOME" else "EXPENSE", 410f, curY + 18f, paint)

        val sign = if (isInc) "+" else "-"
        canvas.drawText("$sign$currencySymbol ${"%,.0f".format(tx.amount)}", 480f, curY + 18f, paint)

        curY += 28f
      }

      // Footer
      paint.color = Color.rgb(148, 163, 184)
      paint.textSize = 9f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      canvas.drawText("Report produced automatically by Arshad Finance App. For accounts queries call ${businessProfile.phone}.", 45f, 810f, paint)

      document.finishPage(page)

      val pdfFile = File(context.cacheDir, "Khata_Statement_${System.currentTimeMillis()}.pdf")
      FileOutputStream(pdfFile).use { out ->
        document.writeTo(out)
      }
      document.close()

      val uri: Uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        pdfFile
      )

      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Business Khata & P&L Statement")
        putExtra(Intent.EXTRA_TEXT, "Attached is the Business Statement from ${businessProfile.businessName}.")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      context.startActivity(Intent.createChooser(shareIntent, "Share Khata Statement PDF via"))
    } catch (e: Exception) {
      e.printStackTrace()
      Toast.makeText(context, "Error generating statement PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
  }

  /**
   * Smart Voice Recognition Parser (Urdu / English)
   * Example spoken: "5000 salary from office", "Ali 1500 sugar", "bijli bill 3500"
   */
  fun parseVoiceQuery(text: String): VoiceParsedResult {
    val clean = text.trim()
    val words = clean.split(" ")
    
    // Find numeric amount
    var detectedAmount: Double? = null
    val remainingWords = mutableListOf<String>()
    
    for (word in words) {
      val numStr = word.replace(",", "")
      val parsedNum = numStr.toDoubleOrNull()
      if (parsedNum != null && detectedAmount == null && parsedNum > 0) {
        detectedAmount = parsedNum
      } else {
        remainingWords.add(word)
      }
    }

    val title = remainingWords.joinToString(" ").ifBlank { "Voice Entry" }
    val lower = clean.lowercase()

    // Determine type and category
    val isIncome = lower.contains("salary") || lower.contains("kamai") || lower.contains("wasool") ||
        lower.contains("receive") || lower.contains("sale") || lower.contains("becha") || lower.contains("income")

    val type = if (isIncome) TransactionType.INCOME else TransactionType.EXPENSE
    
    val category = when {
      lower.contains("food") || lower.contains("khana") || lower.contains("sabzi") || lower.contains("rashan") || lower.contains("doodh") -> "Food" to "🍔"
      lower.contains("bill") || lower.contains("bijli") || lower.contains("gas") || lower.contains("water") -> "Bills" to "💡"
      lower.contains("rent") || lower.contains("kiraya") -> "Bills" to "🏠"
      lower.contains("salary") || lower.contains("tankha") || lower.contains("payment") -> "Salary" to "💼"
      lower.contains("shop") || lower.contains("saman") || lower.contains("mal") -> "Shopping" to "🛍️"
      lower.contains("petrol") || lower.contains("diesel") || lower.contains("fare") || lower.contains("kiraya gaari") -> "Transport" to "🚗"
      else -> "General" to "📝"
    }

    return VoiceParsedResult(
      title = title.replaceFirstChar { it.uppercase() },
      amount = detectedAmount ?: 0.0,
      type = type,
      category = category.first,
      icon = category.second,
      rawQuery = text
    )
  }
}

data class VoiceParsedResult(
  val title: String,
  val amount: Double,
  val type: TransactionType,
  val category: String,
  val icon: String,
  val rawQuery: String
)
