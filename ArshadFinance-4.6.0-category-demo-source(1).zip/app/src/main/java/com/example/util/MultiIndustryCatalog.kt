package com.example.util

import com.example.data.model.InventoryItem

object MultiIndustryCatalog {

  data class IndustryInfo(
    val id: String,
    val name: String,
    val urduName: String,
    val emoji: String,
    val description: String,
    val sampleBusinessName: String
  )

  val industries = listOf(
    IndustryInfo(
      id = "BEAUTY_PARLOUR",
      name = "Beauty Parlour & Salon",
      urduName = "بیوٹی پارلر و سیلون",
      emoji = "💅",
      description = "Facials, Bridal Makeup, Hair Styling, Waxing & Skin Care",
      sampleBusinessName = "Glamour Beauty Parlour & Spa"
    ),
    IndustryInfo(
      id = "CLOTH_BOUTIQUE",
      name = "Cloth Shop & Boutique",
      urduName = "کپڑے کی دکان و بوتیک",
      emoji = "👗",
      description = "Suits, Fabrics, Ready-to-wear, Tailoring & Stitching Services",
      sampleBusinessName = "Arshad Fashion & Cloth House"
    ),
    IndustryInfo(
      id = "MEDICAL_PHARMACY",
      name = "Medical Store & Pharmacy",
      urduName = "میڈیکل سٹور و فارمیسی",
      emoji = "💊",
      description = "Medicines, Tablets, Syrups, Health Monitors & First Aid",
      sampleBusinessName = "Al-Shifa Pharmacy & Medical Store"
    ),
    IndustryInfo(
      id = "GROCERY_KIRYANA",
      name = "Grocery & General Store",
      urduName = "کریانہ و جنرل سٹور",
      emoji = "🛒",
      description = "Rice, Flour, Ghee, Sugar, Tea & Daily Essentials",
      sampleBusinessName = "Bismillah Kiryana & Wholesale"
    ),
    IndustryInfo(
      id = "MOBILE_ELECTRONICS",
      name = "Mobile & Electronics",
      urduName = "موبائل و الیکٹرانکس",
      emoji = "📱",
      description = "Accessories, Chargers, Screen Protectors & Repairing Services",
      sampleBusinessName = "City Mobile & Repairing Lab"
    ),
    IndustryInfo(
      id = "SERVICES_GENERAL",
      name = "Services & Other Shops",
      urduName = "جنرل سروسز و ہارڈویئر",
      emoji = "🛠️",
      description = "Labour, Hardware, Auto Care & Professional Services",
      sampleBusinessName = "Arshad Master Services"
    ),
    IndustryInfo(
      id = "CASH_AND_CARRY",
      name = "Cash & Carry & Mart",
      urduName = "کیش اینڈ کیری و مارٹ",
      emoji = "🛒",
      description = "Bulk & Retail: Sugar, Daal, Ghee in kg, 40kg maund & 50kg bags",
      sampleBusinessName = "Arshad Cash & Carry"
    ),
    IndustryInfo(
      id = "FAST_FOOD",
      name = "Fast Food & Pizza",
      urduName = "فاسٹ فوڈ و پیزا",
      emoji = "🍔",
      description = "Pizza, Burgers, Shawarma, Broast, Deals & Cold Drinks",
      sampleBusinessName = "Pizza Crust & Fast Food"
    ),
    IndustryInfo(
      id = "SHOES_STORE",
      name = "Shoes & Footwear",
      urduName = "شوز و جوتے کی دکان",
      emoji = "👟",
      description = "Leather Shoes, Joggers, Peshawari Chappal & Sandals",
      sampleBusinessName = "Star Shoes Collection"
    ),
    IndustryInfo(
      id = "BAKERY_SWEETS",
      name = "Bakery & Sweets",
      urduName = "بیکری اینڈ سویٹس",
      emoji = "🧁",
      description = "Fresh Cakes, Mithai, Bread, Biscuits & Pastries",
      sampleBusinessName = "Al-Madina Sweets & Bakers"
    ),
    IndustryInfo(
      id = "BOOK_STATIONERY",
      name = "Book & Stationery",
      urduName = "بک اینڈ سٹیشنری",
      emoji = "📖",
      description = "Registers, Photocopy Paper, Pens, School Supplies",
      sampleBusinessName = "Iqbal Book & Stationery"
    ),
    IndustryInfo(
      id = "FARM_DAIRY",
      name = "Farm & Dairy",
      urduName = "فارم اینڈ ڈیری ڈسٹری بیوٹرز",
      emoji = "🐄",
      description = "Pure Milk, Yogurt, Desi Butter & Fresh Eggs",
      sampleBusinessName = "Punjab Pure Dairy Farm"
    ),
    IndustryInfo(
      id = "ELECTRONICS_ELECTRIC",
      name = "Electronics & Electric",
      urduName = "الیکٹرانکس اینڈ الیکٹرک",
      emoji = "🔌",
      description = "LED Bulbs, Fans, Wires, Switch Boards & Electronics",
      sampleBusinessName = "Royal Electric & Lighting"
    ),
    IndustryInfo(
      id = "GYM_FITNESS",
      name = "Gym & Fitness Club",
      urduName = "جم و فٹنس سنٹر",
      emoji = "🏋️‍♂️",
      description = "Monthly Memberships, Protein Powders, Fitness Coaching",
      sampleBusinessName = "Gold Fitness & Gym"
    ),
    IndustryInfo(
      id = "LAPTOP_REPAIR",
      name = "Laptop & Computer Repair",
      urduName = "لیپ ٹاپ شاپ و ریپیئرنگ",
      emoji = "💻",
      description = "Motherboard Chip Repair, Windows Setup, SSD Upgrades",
      sampleBusinessName = "TechExpert Laptop Lab"
    ),
    IndustryInfo(
      id = "CROCKERY_STORE",
      name = "Crockery & Utensils",
      urduName = "کراکری و برتن سٹور",
      emoji = "🍽️",
      description = "Dinner Sets, Tea Sets, Non-stick Cookware, Glassware",
      sampleBusinessName = "Crown Crockery Mart"
    ),
    IndustryInfo(
      id = "AUTO_SHOWROOM",
      name = "Showroom & Auto Parts",
      urduName = "کار شو روم و آٹو پارٹس",
      emoji = "🚗",
      description = "Car Sales, Booking Advance, Engine Oils & Filters",
      sampleBusinessName = "Arshad Motors & Spare Parts"
    )
  )

  fun getCatalogForIndustry(industryId: String): List<InventoryItem> {
    val now = System.currentTimeMillis()
    return when (industryId) {
      "BEAUTY_PARLOUR" -> listOf(
        InventoryItem(
          id = 0L,
          name = "Bridal Makeup Special Package (برائیڈل میک اپ)",
          category = "Beauty Parlour / سیلون",
          icon = "👰",
          costPrice = 8000.0,
          salePrice = 25000.0,
          currentStock = 50.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "PARL-BRIDAL",
          supplierName = "In-House Salon Service",
          note = "Includes HD Makeup, Hairstyling, Lashes & Dupatta Setting",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Party Makeup & Hair Styling (پارٹی میک اپ)",
          category = "Beauty Parlour / سیلون",
          icon = "💄",
          costPrice = 1000.0,
          salePrice = 3500.0,
          currentStock = 100.0,
          unit = "Service",
          lowStockThreshold = 10.0,
          barcode = "PARL-PARTY",
          supplierName = "In-House Salon Service",
          note = "Glam party look with curls or hair updo",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Whitening Hydra Facial (وائٹننگ ہائیڈرا فیشل)",
          category = "Beauty Parlour / سیلون",
          icon = "✨",
          costPrice = 1200.0,
          salePrice = 4500.0,
          currentStock = 80.0,
          unit = "Service",
          lowStockThreshold = 10.0,
          barcode = "PARL-HYDRA",
          supplierName = "Imported Salon Kit",
          note = "Deep pore cleansing, serum infusion & glow mask",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Herbal Skin Polish & Cleansing (سکن پالش)",
          category = "Beauty Parlour / سیلون",
          icon = "💆‍♀️",
          costPrice = 500.0,
          salePrice = 1800.0,
          currentStock = 90.0,
          unit = "Service",
          lowStockThreshold = 15.0,
          barcode = "PARL-POLISH",
          supplierName = "Dermacos Polish",
          note = "Fruit herbal bleach and exfoliating polish",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Hair Cut & Blow Dry (ہیر کٹ)",
          category = "Beauty Parlour / سیلون",
          icon = "✂️",
          costPrice = 200.0,
          salePrice = 1200.0,
          currentStock = 120.0,
          unit = "Service",
          lowStockThreshold = 10.0,
          barcode = "PARL-CUT",
          supplierName = "Salon Tools",
          note = "Layers, Step, or Bob Cut with professional blowdry",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Hair Rebonding / Keratin (ری بونڈنگ و کیراٹین)",
          category = "Beauty Parlour / سیلون",
          icon = "💇‍♀️",
          costPrice = 4500.0,
          salePrice = 14000.0,
          currentStock = 40.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "PARL-REBOND",
          supplierName = "L'Oreal / Keune Professional",
          note = "Silk smooth permanent straightening treatment",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Deluxe Manicure & Pedicure (مینی کیور پیڈی کیور)",
          category = "Beauty Parlour / سیلون",
          icon = "💅",
          costPrice = 600.0,
          salePrice = 2500.0,
          currentStock = 60.0,
          unit = "Service",
          lowStockThreshold = 10.0,
          barcode = "PARL-MANIPEDI",
          supplierName = "Spa Care Kit",
          note = "Dead skin removal, scrub, massage & nail paint",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Full Face Threading & Waxing (تھریڈنگ و ویکسنگ)",
          category = "Beauty Parlour / سیلون",
          icon = "🌸",
          costPrice = 150.0,
          salePrice = 800.0,
          currentStock = 150.0,
          unit = "Service",
          lowStockThreshold = 20.0,
          barcode = "PARL-THREAD",
          supplierName = "Rica Wax",
          note = "Eyebrows, upper lips and full face smooth waxing",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Bridal Mehndi Both Hands & Feet (مہندی ڈیزائن)",
          category = "Beauty Parlour / سیلون",
          icon = "🌿",
          costPrice = 800.0,
          salePrice = 5000.0,
          currentStock = 30.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "PARL-MEHNDI",
          supplierName = "Organic Henna",
          note = "Fine Arabic / Rajasthani intricate bridal design",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Keune Keratin Shampoo 400ml (شیمپو)",
          category = "Beauty Products / پراڈکٹس",
          icon = "🧴",
          costPrice = 1650.0,
          salePrice = 2200.0,
          currentStock = 24.0,
          unit = "Bottle",
          lowStockThreshold = 6.0,
          barcode = "PARL-SHAMP-400",
          supplierName = "Keune Official Distribution",
          note = "Post treatment sulfate free shampoo",
          lastUpdatedMillis = now
        )
      )

      "CLOTH_BOUTIQUE" -> listOf(
        InventoryItem(
          id = 0L,
          name = "Lawn 3-Piece Designer Printed Suit (لان تھری پیس سوٹ)",
          category = "Cloth & Fabric / کپڑے",
          icon = "👗",
          costPrice = 2800.0,
          salePrice = 3800.0,
          currentStock = 45.0,
          unit = "Suit",
          lowStockThreshold = 10.0,
          barcode = "CLOTH-LAWN-3PC",
          supplierName = "Sapphire / Gul Ahmed Wholesale",
          note = "Shirt, Trouser and Chiffon/Voile Dupatta",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Gents Premium Cotton Unstitched (جنٹس کاٹن سوٹ)",
          category = "Cloth & Fabric / کپڑے",
          icon = "👔",
          costPrice = 1900.0,
          salePrice = 2900.0,
          currentStock = 60.0,
          unit = "Suit",
          lowStockThreshold = 12.0,
          barcode = "CLOTH-GENTS-COT",
          supplierName = "Pasha / Grace Fabrics",
          note = "4.5 Metres soft wash and wear cotton fabric",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Embroidered Silk Party Wear (سلک کڑھائی سوٹ)",
          category = "Cloth & Fabric / کپڑے",
          icon = "✨",
          costPrice = 5200.0,
          salePrice = 7500.0,
          currentStock = 22.0,
          unit = "Suit",
          lowStockThreshold = 5.0,
          barcode = "CLOTH-SILK-PARTY",
          supplierName = "Raw Silk Faisalabad",
          note = "Zari and sequin embroidered wedding collection",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Ladies Ready-to-Wear Stitched Kurti (ریڈی میڈ کرتی)",
          category = "Ready to Wear / کرتیاں",
          icon = "👚",
          costPrice = 1400.0,
          salePrice = 2200.0,
          currentStock = 38.0,
          unit = "Piece",
          lowStockThreshold = 8.0,
          barcode = "CLOTH-KURTI-RTW",
          supplierName = "Boutique Collection",
          note = "Sizes: Small, Medium, Large available",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Gents Boski Silk Luxury Suit (بوسکی سوٹ)",
          category = "Cloth & Fabric / کپڑے",
          icon = "🎩",
          costPrice = 4800.0,
          salePrice = 6500.0,
          currentStock = 18.0,
          unit = "Suit",
          lowStockThreshold = 4.0,
          barcode = "CLOTH-BOSKI-LUX",
          supplierName = "China Boski Import",
          note = "Traditional white & cream festive wear",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Ladies Suit Stitching Service (سلائی چارجز لیڈیز)",
          category = "Tailoring / سلائی",
          icon = "🧵",
          costPrice = 800.0,
          salePrice = 1800.0,
          currentStock = 999.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "TAILOR-LADIES",
          supplierName = "Master Tailor Khursheed",
          note = "Custom tailoring with pipen, laces & neck design",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Gents Shalwar Kameez Stitching (سلائی چارجز جنٹس)",
          category = "Tailoring / سلائی",
          icon = "🪡",
          costPrice = 600.0,
          salePrice = 1400.0,
          currentStock = 999.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "TAILOR-GENTS",
          supplierName = "Gents Tailor Unit",
          note = "Sherwani collar, double pocket, cuffs finishing",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Chiffon Embroidered Dupatta (فینسی دوپٹہ)",
          category = "Accessories / لیس و دوپٹہ",
          icon = "🧣",
          costPrice = 750.0,
          salePrice = 1200.0,
          currentStock = 50.0,
          unit = "Piece",
          lowStockThreshold = 10.0,
          barcode = "CLOTH-DUPATTA",
          supplierName = "Rawalpindi Fabric Market",
          note = "Four sided kiran / pico border finish",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Winter Pashmina Woolen Shawl (پشمینہ شال)",
          category = "Cloth & Fabric / کپڑے",
          icon = "🧤",
          costPrice = 2400.0,
          salePrice = 3600.0,
          currentStock = 25.0,
          unit = "Piece",
          lowStockThreshold = 6.0,
          barcode = "CLOTH-SHAWL",
          supplierName = "Kashmir Shawl House",
          note = "Pure warm woolen unisex winter shawl",
          lastUpdatedMillis = now
        )
      )

      "MEDICAL_PHARMACY" -> listOf(
        InventoryItem(
          id = 0L,
          name = "Panadol 500mg (Box of 200 Tablets) (پیناڈول)",
          category = "Medicines / ادویات",
          icon = "💊",
          costPrice = 580.0,
          salePrice = 680.0,
          currentStock = 50.0,
          unit = "Box",
          lowStockThreshold = 10.0,
          barcode = "MED-PANADOL-500",
          supplierName = "GSK Pakistan Ltd",
          note = "Paracetamol 500mg for fever and pain relief",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Disprin Effervescent Tablets 100s (ڈسپرین)",
          category = "Medicines / ادویات",
          icon = "💧",
          costPrice = 260.0,
          salePrice = 320.0,
          currentStock = 40.0,
          unit = "Box",
          lowStockThreshold = 8.0,
          barcode = "MED-DISPRIN-100",
          supplierName = "Reckitt Benckiser",
          note = "Aspirin 300mg soluble headache relief",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Brufen 120ml Suspension (بروفین سیرپ)",
          category = "Syrups / سیرپ",
          icon = "🧪",
          costPrice = 115.0,
          salePrice = 145.0,
          currentStock = 60.0,
          unit = "Bottle",
          lowStockThreshold = 12.0,
          barcode = "MED-BRUFEN-SYR",
          supplierName = "Abbott Laboratories",
          note = "Ibuprofen 100mg/5ml anti-inflammatory",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Augmentin 625mg Tablets (Strip of 10) (اگمنٹن)",
          category = "Antibiotics / اینٹی بائیوٹک",
          icon = "🛡️",
          costPrice = 380.0,
          salePrice = 450.0,
          currentStock = 35.0,
          unit = "Strip",
          lowStockThreshold = 10.0,
          barcode = "MED-AUGM-625",
          supplierName = "GSK Distribution",
          note = "Amoxicillin + Clavulanic acid antibiotic",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Surbex-Z Multivitamin Zinc 30s (سربیکس زی)",
          category = "Vitamins / وٹامنز",
          icon = "⚡",
          costPrice = 490.0,
          salePrice = 580.0,
          currentStock = 45.0,
          unit = "Bottle",
          lowStockThreshold = 10.0,
          barcode = "MED-SURBEX-Z",
          supplierName = "Abbott Distribution",
          note = "High potency Vitamin B-Complex with Zinc & Vit C",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Digital Blood Pressure Monitor (بی پی مانیٹر)",
          category = "Medical Devices / آلات",
          icon = "🩺",
          costPrice = 3300.0,
          salePrice = 4200.0,
          currentStock = 12.0,
          unit = "Piece",
          lowStockThreshold = 3.0,
          barcode = "MED-BP-DIGITAL",
          supplierName = "Certeza Medical Germany",
          note = "Automatic upper arm BP tester with warranty",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Glucometer Sugar Test Kit + 25 Strips (شوگر میٹر)",
          category = "Medical Devices / آلات",
          icon = "🩸",
          costPrice = 2400.0,
          salePrice = 3200.0,
          currentStock = 15.0,
          unit = "Kit",
          lowStockThreshold = 4.0,
          barcode = "MED-GLUCO-KIT",
          supplierName = "Accu-Chek Roche",
          note = "Accu-Chek Instant Blood Glucose Meter",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Dettol Antiseptic 250ml + Bandages (ڈیٹول و پٹی)",
          category = "First Aid / فرسٹ ایڈ",
          icon = "🩹",
          costPrice = 320.0,
          salePrice = 420.0,
          currentStock = 50.0,
          unit = "Pack",
          lowStockThreshold = 12.0,
          barcode = "MED-DETTOL-250",
          supplierName = "Reckitt Pharmacy Supply",
          note = "Hospital grade antiseptic and sterile dressings",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Surgical 3-Ply Face Masks (Box of 50) (ماسک ڈبہ)",
          category = "First Aid / فرسٹ ایڈ",
          icon = "😷",
          costPrice = 300.0,
          salePrice = 450.0,
          currentStock = 80.0,
          unit = "Box",
          lowStockThreshold = 20.0,
          barcode = "MED-MASKS-50",
          supplierName = "Surgical City Sialkot",
          note = "High filtration medical grade face masks",
          lastUpdatedMillis = now
        )
      )

      "MOBILE_ELECTRONICS" -> listOf(
        InventoryItem(
          id = 0L,
          name = "9D Curved Tempered Glass Protector (گلاس پروٹیکٹر)",
          category = "Accessories / موبائل اشیاء",
          icon = "📱",
          costPrice = 120.0,
          salePrice = 350.0,
          currentStock = 150.0,
          unit = "Piece",
          lowStockThreshold = 30.0,
          barcode = "MOB-GLASS-9D",
          supplierName = "Hafeez Centre Wholesaler",
          note = "Unbreakable edge-to-edge screen protection",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Fast USB Type-C Fast Charger 33W (فاسٹ چارجر)",
          category = "Accessories / موبائل اشیاء",
          icon = "🔌",
          costPrice = 750.0,
          salePrice = 1250.0,
          currentStock = 40.0,
          unit = "Piece",
          lowStockThreshold = 10.0,
          barcode = "MOB-CHARGER-33W",
          supplierName = "Dany / Ronin Distribution",
          note = "Super fast charging adapter with warranty",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Wireless Bluetooth Earbuds Pro (ایئربڈز)",
          category = "Accessories / موبائل اشیاء",
          icon = "🎧",
          costPrice = 1600.0,
          salePrice = 2600.0,
          currentStock = 30.0,
          unit = "Piece",
          lowStockThreshold = 6.0,
          barcode = "MOB-EARBUDS-PRO",
          supplierName = "Faster Tech",
          note = "ENC noise reduction with 24 hours battery playback",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Mobile Display / LCD Replacement (ڈسپلے اسکرین)",
          category = "Repair Services / مرمت",
          icon = "📲",
          costPrice = 2200.0,
          salePrice = 3800.0,
          currentStock = 99.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "MOB-SRV-SCREEN",
          supplierName = "Lab Repair Service",
          note = "Original AMOLED / IPS display fitting with warranty",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Charging Port & Mic Repair Service (چارجنگ جیک مرمت)",
          category = "Repair Services / مرمت",
          icon = "🔧",
          costPrice = 250.0,
          salePrice = 850.0,
          currentStock = 99.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "MOB-SRV-PORT",
          supplierName = "Technician Lab",
          note = "Micro-soldering USB port replacement",
          lastUpdatedMillis = now
        )
      )

      "GROCERY_KIRYANA" -> listOf(
        InventoryItem(
          id = 0L,
          name = "Super Basmati Rice (سپر باسمتی چاول)",
          category = "Grocery / اناج",
          icon = "🌾",
          costPrice = 320.0,
          salePrice = 380.0,
          currentStock = 120.0,
          unit = "Kg",
          lowStockThreshold = 25.0,
          barcode = "RICE-BAS-01",
          supplierName = "Al-Rehman Rice Mills",
          note = "Premium export quality 50kg bags",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Dal Chana Special (دال چنا)",
          category = "Grocery / اناج",
          icon = "🍲",
          costPrice = 240.0,
          salePrice = 280.0,
          currentStock = 85.0,
          unit = "Kg",
          lowStockThreshold = 15.0,
          barcode = "DAL-CHANA-02",
          supplierName = "Ghalla Mandi Wholesaler",
          note = "Cleaned and sorted",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Cooking Oil 5 Litre (کوکنگ آئل)",
          category = "Oils & Ghee",
          icon = "🛢️",
          costPrice = 2450.0,
          salePrice = 2750.0,
          currentStock = 45.0,
          unit = "Can",
          lowStockThreshold = 10.0,
          barcode = "OIL-5L-CAN",
          supplierName = "Habib Oil Mills",
          note = "5 Litre tin container",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Sugar Premium White (چینی)",
          category = "Grocery / اناج",
          icon = "🧂",
          costPrice = 135.0,
          salePrice = 155.0,
          currentStock = 350.0,
          unit = "Kg",
          lowStockThreshold = 50.0,
          barcode = "SUGAR-WHITE-1KG",
          supplierName = "JDW Sugar Mills",
          note = "Grade-A refined white sugar",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Tapal Danedar Tea 900g (چائے پتی)",
          category = "Beverages",
          icon = "☕",
          costPrice = 1650.0,
          salePrice = 1850.0,
          currentStock = 28.0,
          unit = "Packet",
          lowStockThreshold = 8.0,
          barcode = "TAPAL-900G",
          supplierName = "Tapal Tea Distribution",
          note = "Family pack",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Chakki Atta Flour 10Kg Bag (چکی آٹا)",
          category = "Grocery / اناج",
          icon = "🌾",
          costPrice = 1220.0,
          salePrice = 1400.0,
          currentStock = 80.0,
          unit = "Bag",
          lowStockThreshold = 20.0,
          barcode = "ATTA-CHAKKI-10KG",
          supplierName = "Punjab Flour Mills",
          note = "Whole wheat wholemeal chakki fresh atta",
          lastUpdatedMillis = now
        )
      )

      else -> listOf(
        InventoryItem(
          id = 0L,
          name = "General Service & Labour Charge (سروس چارجز)",
          category = "Services / سروسز",
          icon = "🛠️",
          costPrice = 300.0,
          salePrice = 1200.0,
          currentStock = 999.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "SRV-GENERAL",
          supplierName = "In-House Service",
          note = "Standard technical or consulting service fee",
          lastUpdatedMillis = now
        ),
        InventoryItem(
          id = 0L,
          name = "Fitting / Delivery Service (ڈلیوری و فٹنگ)",
          category = "Services / سروسز",
          icon = "🚚",
          costPrice = 200.0,
          salePrice = 600.0,
          currentStock = 999.0,
          unit = "Trip",
          lowStockThreshold = 5.0,
          barcode = "SRV-DELIVERY",
          supplierName = "Logistics Unit",
          note = "Doorstep delivery and installation service",
          lastUpdatedMillis = now
        )
      )
    }
  }
}
