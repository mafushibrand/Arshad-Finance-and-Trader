package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.InventoryItem
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object StockExportImportUtils {

  private const val DEVELOPER_FOOTER = "Developed by Muhammad Arshad, 0302-7761415"

  /**
   * 1. Export Stock List as High-Quality Multi-Page PDF Document
   */
  fun exportStockToPdf(
    context: Context,
    items: List<InventoryItem>,
    currencySymbol: String,
    businessProfile: BusinessProfile
  ) {
    if (items.isEmpty()) {
      Toast.makeText(context, "No inventory items to export", Toast.LENGTH_SHORT).show()
      return
    }

    try {
      val document = PdfDocument()
      val pageWidth = 595
      val pageHeight = 842
      val rowsPerPage = 18

      val calendar = Calendar.getInstance()
      val fullDateFormat = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault())
      val dayName = SimpleDateFormat("EEEE", Locale.getDefault()).format(calendar.time)
      val yearStr = SimpleDateFormat("yyyy", Locale.getDefault()).format(calendar.time)
      val dateFormatted = fullDateFormat.format(calendar.time)
      val timeFormatted = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(calendar.time)
      val rowDateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

      val totalStockQty = items.sumOf { it.currentStock }
      val totalCostValue = items.sumOf { it.currentStock * it.costPrice }
      val totalSaleValue = items.sumOf { it.currentStock * it.salePrice }
      val totalProfit = (totalSaleValue - totalCostValue).coerceAtLeast(0.0)

      val totalPages = ((items.size + rowsPerPage - 1) / rowsPerPage).coerceAtLeast(1)

      for (pageNum in 1..totalPages) {
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint().apply { isAntiAlias = true }

        // --- TOP HEADER (Shop Name, Date, Day, Year) ---
        paint.color = Color.rgb(10, 37, 64) // Navy Blue
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 115f, paint)

        // Shop Name
        paint.color = Color.WHITE
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 20f
        canvas.drawText(businessProfile.businessName, 32f, 40f, paint)

        // Subtitles & Contact
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 10f
        paint.color = Color.rgb(226, 232, 240)
        canvas.drawText("INVENTORY & STOCK LIST REPORT  |  ${businessProfile.tagline}", 32f, 58f, paint)
        canvas.drawText("Phone: ${businessProfile.phone}  |  Address: ${businessProfile.address}", 32f, 74f, paint)

        // Date, Day, Year Banner info
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.color = Color.rgb(250, 204, 21) // Gold accent
        canvas.drawText("📅 Date: $dateFormatted ($dayName, $yearStr) • $timeFormatted", 32f, 96f, paint)

        // --- Page 1 Summary Metrics Cards ---
        var curY = 125f
        if (pageNum == 1) {
          fun drawMetricCard(x: Float, label: String, value: String, bgColor: Int, textColor: Int) {
            paint.color = bgColor
            canvas.drawRoundRect(x, curY, x + 125f, curY + 46f, 8f, 8f, paint)

            paint.color = Color.rgb(100, 116, 139)
            paint.textSize = 8f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText(label, x + 8f, curY + 16f, paint)

            paint.color = textColor
            paint.textSize = 11f
            canvas.drawText(value, x + 8f, curY + 34f, paint)
          }

          drawMetricCard(32f, "TOTAL PRODUCTS", "${items.size} Items", Color.rgb(241, 245, 249), Color.rgb(30, 41, 59))
          drawMetricCard(165f, "TOTAL QUANTITY", String.format("%,.0f Units", totalStockQty), Color.rgb(240, 249, 255), Color.rgb(2, 132, 199))
          drawMetricCard(298f, "TOTAL STOCK WORTH", "$currencySymbol ${String.format("%,.0f", totalSaleValue)}", Color.rgb(236, 253, 245), Color.rgb(16, 185, 129))
          drawMetricCard(431f, "PROJECTED PROFIT", "$currencySymbol ${String.format("%,.0f", totalProfit)}", Color.rgb(254, 243, 199), Color.rgb(180, 83, 9))

          curY += 56f
        }

        // --- Table Header ---
        paint.color = Color.rgb(226, 232, 240)
        canvas.drawRect(32f, curY, pageWidth - 32f, curY + 24f, paint)

        paint.color = Color.rgb(15, 23, 42)
        paint.textSize = 8.5f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

        canvas.drawText("SR#", 36f, curY + 16f, paint)
        canvas.drawText("DATE", 64f, curY + 16f, paint)
        canvas.drawText("ITEM NAME / تفصیل", 130f, curY + 16f, paint)
        canvas.drawText("CATEGORY", 260f, curY + 16f, paint)
        canvas.drawText("QTY", 335f, curY + 16f, paint)
        canvas.drawText("COST", 380f, curY + 16f, paint)
        canvas.drawText("SALE", 435f, curY + 16f, paint)
        canvas.drawText("TOTAL", 490f, curY + 16f, paint)

        curY += 24f

        // Table Rows for this page
        val startIndex = (pageNum - 1) * rowsPerPage
        val endIndex = (startIndex + rowsPerPage).coerceAtMost(items.size)
        val pageItems = items.subList(startIndex, endIndex)

        pageItems.forEachIndexed { idx, item ->
          val srNumber = startIndex + idx + 1
          val itemDate = rowDateFormat.format(Date(item.lastUpdatedMillis))
          val isLowStock = item.currentStock <= item.lowStockThreshold
          val totalItemVal = item.currentStock * item.salePrice

          // Zebra background
          paint.color = if (idx % 2 == 0) Color.WHITE else Color.rgb(248, 250, 252)
          canvas.drawRect(32f, curY, pageWidth - 32f, curY + 26f, paint)

          // Border bottom
          paint.color = Color.rgb(241, 245, 249)
          paint.strokeWidth = 0.8f
          canvas.drawLine(32f, curY + 26f, pageWidth - 32f, curY + 26f, paint)

          // Row Content
          paint.textSize = 8.5f
          paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
          paint.color = Color.rgb(51, 65, 85)

          // Sr#
          canvas.drawText("$srNumber", 36f, curY + 17f, paint)

          // Date
          canvas.drawText(itemDate, 64f, curY + 17f, paint)

          // Item Name
          paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
          val truncName = if (item.name.length > 22) item.name.take(20) + ".." else item.name
          canvas.drawText(truncName, 130f, curY + 17f, paint)

          // Category
          paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
          val truncCat = if (item.category.length > 12) item.category.take(10) + ".." else item.category
          canvas.drawText(truncCat, 260f, curY + 17f, paint)

          // Qty & Unit
          paint.color = if (isLowStock) Color.rgb(220, 38, 38) else Color.rgb(15, 23, 42)
          paint.typeface = Typeface.create(Typeface.DEFAULT, if (isLowStock) Typeface.BOLD else Typeface.NORMAL)
          val qtyStr = "${String.format("%.0f", item.currentStock)} ${item.unit}"
          canvas.drawText(qtyStr, 335f, curY + 17f, paint)

          // Cost Price
          paint.color = Color.rgb(100, 116, 139)
          paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
          canvas.drawText(String.format("%,.0f", item.costPrice), 380f, curY + 17f, paint)

          // Sale Price
          paint.color = Color.rgb(15, 23, 42)
          canvas.drawText(String.format("%,.0f", item.salePrice), 435f, curY + 17f, paint)

          // Total Value
          paint.color = Color.rgb(16, 185, 129)
          paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
          canvas.drawText(String.format("%,.0f", totalItemVal), 490f, curY + 17f, paint)

          curY += 26f
        }

        // --- FOOTER (Developed by Muhammad Arshad, 0302-7761415) ---
        val footerY = pageHeight - 45f
        paint.color = Color.rgb(10, 37, 64)
        paint.strokeWidth = 1.2f
        canvas.drawLine(32f, footerY, pageWidth - 32f, footerY, paint)

        // Mandatory Developer Credit in Footer
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 10f
        paint.color = Color.rgb(10, 37, 64)
        canvas.drawText(DEVELOPER_FOOTER, 32f, footerY + 18f, paint)

        // Page info & App branding
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 8.5f
        paint.color = Color.rgb(100, 116, 139)
        canvas.drawText("Page $pageNum of $totalPages  •  Arshad Finance & Stock Manager", 330f, footerY + 18f, paint)

        document.finishPage(page)
      }

      // Save PDF file
      val fileName = "Stock_Report_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())}.pdf"
      val pdfFile = File(context.cacheDir, fileName)
      FileOutputStream(pdfFile).use { out ->
        document.writeTo(out)
      }
      document.close()

      // Share PDF
      val uri: Uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        pdfFile
      )

      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Stock List Report - ${businessProfile.businessName}")
        putExtra(Intent.EXTRA_TEXT, "Stock List Report (${items.size} Products) from ${businessProfile.businessName}.\n\n$DEVELOPER_FOOTER")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      context.startActivity(Intent.createChooser(shareIntent, "Share Stock PDF via"))

    } catch (e: Exception) {
      e.printStackTrace()
      Toast.makeText(context, "Error generating PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
  }

  /**
   * 2. Export Stock List as Excel-Compatible CSV / TSV with UTF-8 BOM
   */
  fun exportStockToExcelCsv(
    context: Context,
    items: List<InventoryItem>,
    currencySymbol: String,
    businessProfile: BusinessProfile,
    isTsv: Boolean = false
  ) {
    if (items.isEmpty()) {
      Toast.makeText(context, "No inventory items to export", Toast.LENGTH_SHORT).show()
      return
    }

    try {
      val sep = if (isTsv) "\t" else ","
      val ext = if (isTsv) "tsv" else "csv"
      val calendar = Calendar.getInstance()
      val dayName = SimpleDateFormat("EEEE", Locale.getDefault()).format(calendar.time)
      val yearStr = SimpleDateFormat("yyyy", Locale.getDefault()).format(calendar.time)
      val dateFormatted = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(calendar.time)
      val rowDateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

      val totalQty = items.sumOf { it.currentStock }
      val totalCost = items.sumOf { it.currentStock * it.costPrice }
      val totalSale = items.sumOf { it.currentStock * it.salePrice }
      val totalProfit = totalSale - totalCost

      val sb = StringBuilder()

      // UTF-8 BOM for Microsoft Excel compatibility
      sb.append("\uFEFF")

      // Header info (Shop Name, Date, Day, Year)
      sb.append("SHOP NAME$sep\"${businessProfile.businessName}\"$sep$sep$sep$sep$sep$sep$sep$sep$sep$sep$sep\n")
      sb.append("REPORT TITLE$sep\"INVENTORY & STOCK LIST REPORT\"$sep$sep$sep$sep$sep$sep$sep$sep$sep$sep$sep\n")
      sb.append("DATE$sep\"$dateFormatted\"$sep\"DAY\"$sep\"$dayName\"$sep\"YEAR\"$sep\"$yearStr\"$sep$sep$sep$sep$sep$sep\n")
      sb.append("PHONE$sep\"${businessProfile.phone}\"$sep\"ADDRESS\"$sep\"${businessProfile.address}\"$sep$sep$sep$sep$sep$sep$sep$sep\n")
      sb.append("\n")

      // Columns Header
      sb.append("Sr#$sep Date$sep Day$sep Year$sep Item Name$sep Category$sep Quantity$sep Unit$sep Cost Price ($currencySymbol)$sep Sale Price ($currencySymbol)$sep Total Cost Value$sep Total Sale Value$sep Projected Profit$sep Supplier$sep Barcode$sep Status\n")

      // Data Rows
      items.forEachIndexed { index, item ->
        val sr = index + 1
        val itemDate = rowDateFormat.format(Date(item.lastUpdatedMillis))
        val rowTotalCost = item.currentStock * item.costPrice
        val rowTotalSale = item.currentStock * item.salePrice
        val rowProfit = rowTotalSale - rowTotalCost
        val status = if (item.currentStock <= item.lowStockThreshold) "LOW STOCK" else "IN STOCK"

        fun escape(s: String) = "\"${s.replace("\"", "\"\"")}\""

        sb.append("$sr$sep$itemDate$sep$dayName$sep$yearStr$sep${escape(item.name)}$sep${escape(item.category)}$sep${item.currentStock}$sep${escape(item.unit)}$sep${item.costPrice}$sep${item.salePrice}$sep$rowTotalCost$sep$rowTotalSale$sep$rowProfit$sep${escape(item.supplierName)}$sep${escape(item.barcode)}$sep$status\n")
      }

      // Summary Row
      sb.append("\n")
      sb.append("TOTALS$sep$sep$sep$sep\"${items.size} Products\"$sep$sep$totalQty$sep\"Units\"$sep$sep$sep$totalCost$sep$totalSale$sep$totalProfit$sep$sep$sep\n")
      sb.append("\n")

      // Footer Developer Credit
      sb.append("DEVELOPED BY$sep\"$DEVELOPER_FOOTER\"$sep$sep$sep$sep$sep$sep$sep$sep$sep$sep$sep\n")

      val fileName = "Stock_List_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())}.$ext"
      val file = File(context.cacheDir, fileName)
      file.writeText(sb.toString(), Charsets.UTF_8)

      val uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
      )

      val mimeType = if (isTsv) "text/tab-separated-values" else "text/csv"
      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Stock List Excel/CSV - ${businessProfile.businessName}")
        putExtra(Intent.EXTRA_TEXT, "Stock List (${items.size} items) for ${businessProfile.businessName}.\n\n$DEVELOPER_FOOTER")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      context.startActivity(Intent.createChooser(shareIntent, "Open / Share Stock Sheet via"))

    } catch (e: Exception) {
      e.printStackTrace()
      Toast.makeText(context, "Error exporting CSV: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
  }

  /**
   * 3. Export Stock List as Graphic Image (PNG / JPEG)
   */
  fun exportStockToImage(
    context: Context,
    items: List<InventoryItem>,
    currencySymbol: String,
    businessProfile: BusinessProfile,
    format: Bitmap.CompressFormat = Bitmap.CompressFormat.PNG
  ) {
    if (items.isEmpty()) {
      Toast.makeText(context, "No inventory items to export", Toast.LENGTH_SHORT).show()
      return
    }

    try {
      val displayItems = items.take(25) // Up to 25 items for visual fidelity
      val imgWidth = 1080
      val rowHeight = 60
      val headerHeight = 260
      val footerHeight = 140
      val imgHeight = headerHeight + (displayItems.size * rowHeight) + footerHeight + 100

      val bitmap = Bitmap.createBitmap(imgWidth, imgHeight, Bitmap.Config.ARGB_8888)
      val canvas = Canvas(bitmap)
      val paint = Paint().apply { isAntiAlias = true }

      val calendar = Calendar.getInstance()
      val dayName = SimpleDateFormat("EEEE", Locale.getDefault()).format(calendar.time)
      val yearStr = SimpleDateFormat("yyyy", Locale.getDefault()).format(calendar.time)
      val dateFormatted = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(calendar.time)
      val timeFormatted = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(calendar.time)
      val rowDateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

      val totalStockQty = items.sumOf { it.currentStock }
      val totalSaleValue = items.sumOf { it.currentStock * it.salePrice }
      val totalProfit = items.sumOf { it.currentStock * (it.salePrice - it.costPrice) }.coerceAtLeast(0.0)

      // Background Canvas
      paint.color = Color.WHITE
      canvas.drawRect(0f, 0f, imgWidth.toFloat(), imgHeight.toFloat(), paint)

      // Top Header Banner
      paint.color = Color.rgb(10, 37, 64) // Deep Navy
      canvas.drawRect(0f, 0f, imgWidth.toFloat(), 180f, paint)

      // Shop Name
      paint.color = Color.WHITE
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 40f
      canvas.drawText(businessProfile.businessName, 50f, 65f, paint)

      paint.textSize = 22f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      paint.color = Color.rgb(203, 213, 225)
      canvas.drawText("📦 STOCK & INVENTORY SUMMARY REPORT", 50f, 105f, paint)

      // Date, Day, Year Header
      paint.color = Color.rgb(250, 204, 21) // Gold
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 20f
      canvas.drawText("📅 Date: $dateFormatted ($dayName, $yearStr) • $timeFormatted", 50f, 145f, paint)

      // 3 Stat Metric Cards
      var curY = 200f
      val cardW = 310f
      val cardH = 80f

      fun drawStatCard(x: Float, label: String, value: String, bgColor: Int, textColor: Int) {
        paint.color = bgColor
        canvas.drawRoundRect(RectF(x, curY, x + cardW, curY + cardH), 16f, 16f, paint)

        paint.color = Color.rgb(100, 116, 139)
        paint.textSize = 16f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(label, x + 20f, curY + 30f, paint)

        paint.color = textColor
        paint.textSize = 24f
        canvas.drawText(value, x + 20f, curY + 62f, paint)
      }

      drawStatCard(50f, "TOTAL ITEMS", "${items.size} Products", Color.rgb(241, 245, 249), Color.rgb(30, 41, 59))
      drawStatCard(385f, "TOTAL QUANTITY", String.format("%,.0f Units", totalStockQty), Color.rgb(240, 249, 255), Color.rgb(2, 132, 199))
      drawStatCard(720f, "STOCK VALUATION", "$currencySymbol ${String.format("%,.0f", totalSaleValue)}", Color.rgb(236, 253, 245), Color.rgb(16, 185, 129))

      curY += cardH + 30f

      // Table Header
      paint.color = Color.rgb(15, 23, 42)
      canvas.drawRoundRect(RectF(50f, curY, imgWidth - 50f, curY + 48f), 12f, 12f, paint)

      paint.color = Color.WHITE
      paint.textSize = 18f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      canvas.drawText("SR#", 65f, curY + 32f, paint)
      canvas.drawText("DATE", 130f, curY + 32f, paint)
      canvas.drawText("ITEM NAME", 260f, curY + 32f, paint)
      canvas.drawText("QTY", 560f, curY + 32f, paint)
      canvas.drawText("COST", 670f, curY + 32f, paint)
      canvas.drawText("SALE", 790f, curY + 32f, paint)
      canvas.drawText("TOTAL", 920f, curY + 32f, paint)

      curY += 48f

      // Table Rows
      displayItems.forEachIndexed { index, item ->
        val sr = index + 1
        val itemDate = rowDateFormat.format(Date(item.lastUpdatedMillis))
        val isLow = item.currentStock <= item.lowStockThreshold
        val rowTotal = item.currentStock * item.salePrice

        // Background
        paint.color = if (index % 2 == 0) Color.rgb(255, 255, 255) else Color.rgb(248, 250, 252)
        canvas.drawRect(50f, curY, imgWidth - 50f, curY + rowHeight, paint)

        // Divider
        paint.color = Color.rgb(226, 232, 240)
        paint.strokeWidth = 1f
        canvas.drawLine(50f, curY + rowHeight, imgWidth - 50f, curY + rowHeight, paint)

        // Text
        paint.textSize = 18f
        paint.color = Color.rgb(51, 65, 85)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("$sr", 65f, curY + 38f, paint)
        canvas.drawText(itemDate, 130f, curY + 38f, paint)

        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val truncName = if (item.name.length > 20) item.name.take(18) + ".." else item.name
        canvas.drawText(truncName, 260f, curY + 38f, paint)

        paint.color = if (isLow) Color.rgb(220, 38, 38) else Color.rgb(15, 23, 42)
        canvas.drawText("${String.format("%.0f", item.currentStock)} ${item.unit}", 560f, curY + 38f, paint)

        paint.color = Color.rgb(100, 116, 139)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(String.format("%,.0f", item.costPrice), 670f, curY + 38f, paint)

        paint.color = Color.rgb(15, 23, 42)
        canvas.drawText(String.format("%,.0f", item.salePrice), 790f, curY + 38f, paint)

        paint.color = Color.rgb(16, 185, 129)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(String.format("%,.0f", rowTotal), 920f, curY + 38f, paint)

        curY += rowHeight
      }

      // Truncation Notice if more items exist
      if (items.size > 25) {
        paint.color = Color.rgb(100, 116, 139)
        paint.textSize = 16f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        canvas.drawText("... and ${items.size - 25} more items. Export PDF or Excel for full list.", 50f, curY + 30f, paint)
        curY += 40f
      }

      // Bottom Footer Card
      val footerY = imgHeight - 110f
      paint.color = Color.rgb(10, 37, 64)
      canvas.drawRoundRect(RectF(50f, footerY, imgWidth - 50f, footerY + 80f), 16f, 16f, paint)

      // Mandatory Developer Credit
      paint.color = Color.WHITE
      paint.textSize = 22f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      canvas.drawText(DEVELOPER_FOOTER, 75f, footerY + 46f, paint)

      paint.color = Color.rgb(203, 213, 225)
      paint.textSize = 15f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      canvas.drawText("Shop: ${businessProfile.businessName} • Phone: ${businessProfile.phone}", 620f, footerY + 46f, paint)

      // Save file
      val isPng = format == Bitmap.CompressFormat.PNG
      val ext = if (isPng) "png" else "jpeg"
      val fileName = "Stock_Summary_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())}.$ext"
      val file = File(context.cacheDir, fileName)

      FileOutputStream(file).use { out ->
        bitmap.compress(format, 95, out)
      }

      val uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
      )

      val mimeType = if (isPng) "image/png" else "image/jpeg"
      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Stock Report Image - ${businessProfile.businessName}")
        putExtra(Intent.EXTRA_TEXT, "Stock Report Image from ${businessProfile.businessName}.\n\n$DEVELOPER_FOOTER")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      context.startActivity(Intent.createChooser(shareIntent, "Share Stock Image via"))

    } catch (e: Exception) {
      e.printStackTrace()
      Toast.makeText(context, "Error creating stock image: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
  }

  /**
   * 4. Export Stock List as Formatted Text for WhatsApp / Telegram
   */
  fun exportStockToWhatsAppText(
    context: Context,
    items: List<InventoryItem>,
    currencySymbol: String,
    businessProfile: BusinessProfile
  ) {
    if (items.isEmpty()) {
      Toast.makeText(context, "No inventory items to export", Toast.LENGTH_SHORT).show()
      return
    }

    val calendar = Calendar.getInstance()
    val dayName = SimpleDateFormat("EEEE", Locale.getDefault()).format(calendar.time)
    val yearStr = SimpleDateFormat("yyyy", Locale.getDefault()).format(calendar.time)
    val dateFormatted = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(calendar.time)

    val totalQty = items.sumOf { it.currentStock }
    val totalSaleValue = items.sumOf { it.currentStock * it.salePrice }

    val sb = StringBuilder()
    sb.append("🏬 *${businessProfile.businessName}*\n")
    sb.append("📋 *اسٹاک و انوینٹری رپورٹ (Stock List Report)*\n")
    sb.append("📅 تاریخ: $dateFormatted ($dayName, $yearStr)\n")
    sb.append("📞 رابطہ: ${businessProfile.phone}\n")
    sb.append("------------------------------------\n\n")

    items.forEachIndexed { index, item ->
      val sr = index + 1
      val statusIcon = if (item.currentStock <= item.lowStockThreshold) "⚠️" else "✅"
      val itemTotal = item.currentStock * item.salePrice
      sb.append("$sr. *$statusIcon ${item.name}*\n")
      sb.append("   📦 مقدار: ${item.currentStock} ${item.unit}\n")
      sb.append("   💰 خرید: $currencySymbol ${String.format("%,.0f", item.costPrice)} | فروخت: $currencySymbol ${String.format("%,.0f", item.salePrice)}\n")
      sb.append("   💵 کل مالیت: $currencySymbol ${String.format("%,.0f", itemTotal)}\n\n")
    }

    sb.append("------------------------------------\n")
    sb.append("📊 *خلاصہ (Stock Summary):*\n")
    sb.append("🔹 کل پراڈکٹس: ${items.size} Items\n")
    sb.append("🔹 کل تعداد: ${String.format("%,.0f", totalQty)} Units\n")
    sb.append("💰 *کل اسٹاک ویلیو: $currencySymbol ${String.format("%,.0f", totalSaleValue)}*\n\n")
    sb.append("🌟 *$DEVELOPER_FOOTER*\n")

    val message = sb.toString()
    BusinessUtils.shareWhatsAppMessage(context, businessProfile.phone, message)
  }

  /**
   * 5. Export Stock List as JSON Data File for Backup / Transfer
   */
  fun exportStockToJson(
    context: Context,
    items: List<InventoryItem>,
    businessProfile: BusinessProfile
  ) {
    if (items.isEmpty()) {
      Toast.makeText(context, "No inventory items to export", Toast.LENGTH_SHORT).show()
      return
    }

    try {
      val root = JSONObject()
      root.put("shopName", businessProfile.businessName)
      root.put("exportDate", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
      root.put("developer", DEVELOPER_FOOTER)

      val array = JSONArray()
      items.forEachIndexed { index, item ->
        val obj = JSONObject()
        obj.put("sr", index + 1)
        obj.put("name", item.name)
        obj.put("category", item.category)
        obj.put("icon", item.icon)
        obj.put("costPrice", item.costPrice)
        obj.put("salePrice", item.salePrice)
        obj.put("currentStock", item.currentStock)
        obj.put("unit", item.unit)
        obj.put("lowStockThreshold", item.lowStockThreshold)
        obj.put("barcode", item.barcode)
        obj.put("supplierName", item.supplierName)
        obj.put("note", item.note)
        array.put(obj)
      }
      root.put("inventory", array)

      val fileName = "Stock_Backup_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())}.json"
      val file = File(context.cacheDir, fileName)
      file.writeText(root.toString(2), Charsets.UTF_8)

      val uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
      )

      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/json"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Stock Backup JSON - ${businessProfile.businessName}")
        putExtra(Intent.EXTRA_TEXT, "Stock Backup (${items.size} products) for ${businessProfile.businessName}.\n\n$DEVELOPER_FOOTER")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      context.startActivity(Intent.createChooser(shareIntent, "Export Stock JSON File via"))

    } catch (e: Exception) {
      e.printStackTrace()
      Toast.makeText(context, "Error exporting JSON: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
  }

  /**
   * 6. Generate Sample CSV Template content for users
   */
  fun getSampleCsvTemplate(): String {
    return """
    Sr#,Date,Day,Year,Item Name,Category,Quantity,Unit,Cost Price,Sale Price,Supplier,Barcode,Low Stock Limit
    1,28/08/2026,Friday,2026,Super Basmati Rice (50kg),Grocery,150,Bags,4500,5200,Punjab Mills,892301,15
    2,28/08/2026,Friday,2026,Cooking Oil (16 Liter Tin),Grocery,80,Tins,7800,8500,Habib Mills,892302,10
    3,28/08/2026,Friday,2026,Fine White Sugar (50kg),Grocery,120,Bags,6200,6800,Al-Moiz Sugar,892303,20
    4,28/08/2026,Friday,2026,Chakki Wheat Flour (20kg),Grocery,200,Bags,2200,2450,Local Flour Mills,892304,25
    5,28/08/2026,Friday,2026,Tapal Danedar Tea (950g),Beverages,90,Packs,1350,1550,Tapal Tea Ltd,892305,15
    """.trimIndent()
  }

  /**
   * 7. Smart Parser for uploaded Stock CSV, TSV, or JSON
   */
  fun parseStockFile(content: String): ParseResult {
    val clean = content.trim()
    if (clean.isBlank()) {
      return ParseResult(emptyList(), "The file or text is empty.")
    }

    // Try parsing as JSON first
    if (clean.startsWith("{") && clean.contains("inventory")) {
      try {
        val root = JSONObject(clean)
        val array = root.getJSONArray("inventory")
        val parsedItems = mutableListOf<InventoryItem>()
        for (i in 0 until array.length()) {
          val obj = array.getJSONObject(i)
          parsedItems.add(
            InventoryItem(
              id = 0L,
              name = obj.optString("name", "Product ${i + 1}"),
              category = obj.optString("category", "General"),
              icon = obj.optString("icon", "📦"),
              costPrice = obj.optDouble("costPrice", 0.0),
              salePrice = obj.optDouble("salePrice", 0.0),
              currentStock = obj.optDouble("currentStock", 0.0),
              unit = obj.optString("unit", "Pcs"),
              lowStockThreshold = obj.optDouble("lowStockThreshold", 5.0),
              barcode = obj.optString("barcode", ""),
              supplierName = obj.optString("supplierName", ""),
              lastUpdatedMillis = System.currentTimeMillis(),
              note = obj.optString("note", "")
            )
          )
        }
        return ParseResult(parsedItems, null)
      } catch (e: Exception) {
        // Fallback to CSV parsing
      }
    }

    // Parse as Delimited Text (CSV / TSV / Semicolon)
    val lines = clean.lines().filter { it.isNotBlank() }
    if (lines.isEmpty()) {
      return ParseResult(emptyList(), "No data lines found in file.")
    }

    // Detect separator
    val firstLine = lines.firstOrNull { it.contains("Item") || it.contains("Name") || it.contains(",") || it.contains("\t") || it.contains(";") } ?: lines[0]
    val separator = when {
      firstLine.count { it == '\t' } >= 2 -> "\t"
      firstLine.count { it == ';' } >= 2 -> ";"
      firstLine.count { it == '|' } >= 2 -> "|"
      else -> ","
    }

    val parsedItems = mutableListOf<InventoryItem>()
    var headerFound = false
    var nameIdx = -1
    var qtyIdx = -1
    var unitIdx = -1
    var costIdx = -1
    var saleIdx = -1
    var catIdx = -1
    var suppIdx = -1
    var barIdx = -1
    var threshIdx = -1

    for (line in lines) {
      val cols = parseLineColumns(line, separator)
      if (cols.isEmpty()) continue

      val lowerCols = cols.map { it.trim().lowercase() }

      // Check if this line is header
      if (!headerFound && (lowerCols.any { it.contains("item") || it.contains("name") || it.contains("product") })) {
        headerFound = true
        lowerCols.forEachIndexed { i, col ->
          when {
            col.contains("item") || col.contains("name") || col.contains("product") || col.contains("تفصیل") || col.contains("نام") -> if (nameIdx == -1) nameIdx = i
            col.contains("qty") || col.contains("quant") || col.contains("stock") || col.contains("مقدار") -> if (qtyIdx == -1) qtyIdx = i
            col.contains("unit") || col.contains("یونٹ") -> if (unitIdx == -1) unitIdx = i
            col.contains("cost") || col.contains("buy") || col.contains("خرید") -> if (costIdx == -1) costIdx = i
            col.contains("sale") || col.contains("price") || col.contains("فروخت") -> if (saleIdx == -1) saleIdx = i
            col.contains("cat") || col.contains("type") -> if (catIdx == -1) catIdx = i
            col.contains("supp") || col.contains("vendor") -> if (suppIdx == -1) suppIdx = i
            col.contains("bar") || col.contains("code") || col.contains("sku") -> if (barIdx == -1) barIdx = i
            col.contains("thresh") || col.contains("low") || col.contains("limit") -> if (threshIdx == -1) threshIdx = i
          }
        }
        continue
      }

      // Skip metadata or developer lines
      if (lowerCols.any { it.contains("developed by") || it.contains("shop name") || it.contains("report title") || it.contains("totals") }) {
        continue
      }

      // If header wasn't standard, assign fallback default column positions:
      // Expected: Sr#, Date, Day, Year, Item Name, Category, Qty, Unit, Cost, Sale
      val actualNameIdx = if (nameIdx != -1) nameIdx else if (cols.size >= 5 && cols[0].toIntOrNull() != null) 4 else 0
      val actualCatIdx = if (catIdx != -1) catIdx else if (cols.size >= 6 && cols[0].toIntOrNull() != null) 5 else 1
      val actualQtyIdx = if (qtyIdx != -1) qtyIdx else if (cols.size >= 7 && cols[0].toIntOrNull() != null) 6 else 2
      val actualUnitIdx = if (unitIdx != -1) unitIdx else if (cols.size >= 8 && cols[0].toIntOrNull() != null) 7 else 3
      val actualCostIdx = if (costIdx != -1) costIdx else if (cols.size >= 9 && cols[0].toIntOrNull() != null) 8 else 4
      val actualSaleIdx = if (saleIdx != -1) saleIdx else if (cols.size >= 10 && cols[0].toIntOrNull() != null) 9 else 5

      val name = cols.getOrNull(actualNameIdx)?.trim() ?: ""
      if (name.isBlank() || name.equals("Sr#", ignoreCase = true) || name.equals("Item Name", ignoreCase = true)) {
        continue
      }

      val cat = cols.getOrNull(actualCatIdx)?.trim()?.ifBlank { "General" } ?: "General"
      val qty = cols.getOrNull(actualQtyIdx)?.replace(",", "")?.toDoubleOrNull() ?: 0.0
      val unit = cols.getOrNull(actualUnitIdx)?.trim()?.ifBlank { "Pcs" } ?: "Pcs"
      val cost = cols.getOrNull(actualCostIdx)?.replace(",", "")?.toDoubleOrNull() ?: 0.0
      val sale = cols.getOrNull(actualSaleIdx)?.replace(",", "")?.toDoubleOrNull() ?: cost
      val supp = if (suppIdx != -1) cols.getOrNull(suppIdx)?.trim() ?: "" else ""
      val barcode = if (barIdx != -1) cols.getOrNull(barIdx)?.trim() ?: "" else ""
      val threshold = if (threshIdx != -1) cols.getOrNull(threshIdx)?.toDoubleOrNull() ?: 5.0 else 5.0

      val icon = when {
        cat.contains("Grocery", ignoreCase = true) || name.contains("Rice", ignoreCase = true) || name.contains("Sugar", ignoreCase = true) -> "🌾"
        cat.contains("Oil", ignoreCase = true) || name.contains("Oil", ignoreCase = true) || name.contains("Ghee", ignoreCase = true) -> "🛢️"
        cat.contains("Tea", ignoreCase = true) || cat.contains("Beverage", ignoreCase = true) -> "☕"
        cat.contains("Dairy", ignoreCase = true) || name.contains("Milk", ignoreCase = true) -> "🥛"
        cat.contains("Flour", ignoreCase = true) || name.contains("Atta", ignoreCase = true) -> "🍞"
        cat.contains("Spices", ignoreCase = true) || name.contains("Mirch", ignoreCase = true) -> "🌶️"
        cat.contains("Pulse", ignoreCase = true) || name.contains("Daal", ignoreCase = true) -> "🫘"
        else -> "📦"
      }

      parsedItems.add(
        InventoryItem(
          id = 0L,
          name = name,
          category = cat,
          icon = icon,
          costPrice = cost,
          salePrice = sale,
          currentStock = qty,
          unit = unit,
          lowStockThreshold = threshold,
          barcode = barcode,
          supplierName = supp,
          lastUpdatedMillis = System.currentTimeMillis(),
          note = "Imported from file"
        )
      )
    }

    return if (parsedItems.isEmpty()) {
      ParseResult(emptyList(), "Could not parse any valid product rows. Please verify your format.")
    } else {
      ParseResult(parsedItems, null)
    }
  }

  private fun parseLineColumns(line: String, separator: String): List<String> {
    val result = mutableListOf<String>()
    var cur = StringBuilder()
    var inQuotes = false

    var i = 0
    while (i < line.length) {
      val c = line[i]
      if (c == '"') {
        if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
          cur.append('"')
          i++
        } else {
          inQuotes = !inQuotes
        }
      } else if (!inQuotes && line.startsWith(separator, i)) {
        result.add(cur.toString().trim())
        cur = StringBuilder()
        i += separator.length - 1
      } else {
        cur.append(c)
      }
      i++
    }
    result.add(cur.toString().trim())
    return result
  }

  /**
   * Read Uri content as text safely
   */
  fun readTextFromUri(context: Context, uri: Uri): String? {
    return try {
      context.contentResolver.openInputStream(uri)?.use { stream ->
        BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
          reader.readText()
        }
      }
    } catch (e: Exception) {
      e.printStackTrace()
      null
    }
  }
}

data class ParseResult(
  val items: List<InventoryItem>,
  val errorMessage: String?
)
