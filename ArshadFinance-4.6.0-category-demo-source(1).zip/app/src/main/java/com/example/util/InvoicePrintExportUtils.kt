package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItemEntry
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object InvoicePrintExportUtils {

  /**
   * Generates a professional vector PDF receipt / invoice and shares it
   */
  fun generateAndShareInvoicePdf(
    context: Context,
    invoice: Invoice,
    businessProfile: BusinessProfile,
    currencySymbol: String
  ) {
    try {
      val items = invoice.parseItems()
      val document = PdfDocument()
      // A4 page: 595 x 842 points
      val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
      val page = document.startPage(pageInfo)
      val canvas = page.canvas

      val paint = Paint().apply { isAntiAlias = true }
      val dateFormat = SimpleDateFormat("dd-MMM-yyyy, hh:mm a", Locale.getDefault())
      val dateFormatted = dateFormat.format(Date(invoice.dateMillis))

      // 1. Business Header Banner (Deep Navy Gradient)
      paint.color = Color.rgb(15, 23, 42) // Slate 900
      canvas.drawRect(0f, 0f, 595f, 130f, paint)

      // Accent gold/blue line
      paint.color = Color.rgb(37, 99, 235) // Royal Blue
      canvas.drawRect(0f, 126f, 595f, 130f, paint)

      // Shop Name & Details
      paint.color = Color.WHITE
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 22f
      val shopTitle = "${businessProfile.logoEmoji} ${businessProfile.businessName}"
      canvas.drawText(shopTitle, 36f, 46f, paint)

      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      paint.textSize = 11f
      paint.color = Color.rgb(226, 232, 240)
      canvas.drawText("${businessProfile.shopType} • ${businessProfile.tagline}", 36f, 68f, paint)
      canvas.drawText("Phone: ${businessProfile.phone}  |  Address: ${businessProfile.address}", 36f, 88f, paint)
      if (businessProfile.ntnNumber.isNotBlank()) {
        canvas.drawText("NTN / Reg: ${businessProfile.ntnNumber}", 36f, 108f, paint)
      }

      // INVOICE / BILL Header Tag (Top Right)
      paint.color = Color.rgb(30, 41, 59)
      canvas.drawRoundRect(410f, 25f, 560f, 75f, 8f, 8f, paint)
      paint.color = Color.rgb(147, 197, 253)
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 13f
      canvas.drawText("CUSTOMER BILL", 425f, 48f, paint)
      paint.color = Color.WHITE
      paint.textSize = 11f
      canvas.drawText(invoice.invoiceNumber, 425f, 66f, paint)

      // 2. Customer & Invoice Meta Box
      paint.color = Color.rgb(248, 250, 252)
      canvas.drawRoundRect(36f, 145f, 559f, 220f, 10f, 10f, paint)
      paint.color = Color.rgb(226, 232, 240)
      paint.style = Paint.Style.STROKE
      paint.strokeWidth = 1f
      canvas.drawRoundRect(36f, 145f, 559f, 220f, 10f, 10f, paint)
      paint.style = Paint.Style.FILL

      // Customer Info
      paint.color = Color.rgb(100, 116, 139)
      paint.textSize = 10f
      canvas.drawText("BILLED TO / CUSTOMER:", 50f, 165f, paint)

      paint.color = Color.rgb(15, 23, 42)
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 14f
      canvas.drawText(invoice.customerName.ifBlank { "Walk-in Customer" }, 50f, 185f, paint)

      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      paint.textSize = 10f
      paint.color = Color.rgb(71, 85, 105)
      val contactLine = if (invoice.customerPhone.isNotBlank()) "Phone: ${invoice.customerPhone}" else "Customer"
      val addressLine = if (invoice.customerAddress.isNotBlank()) " • ${invoice.customerAddress}" else ""
      canvas.drawText("$contactLine$addressLine", 50f, 203f, paint)

      // Invoice Date & Status Stamp
      paint.color = Color.rgb(100, 116, 139)
      canvas.drawText("DATE & TIME: $dateFormatted", 340f, 168f, paint)
      canvas.drawText("PAYMENT METHOD: ${invoice.paymentMethod}", 340f, 186f, paint)

      val isPaid = invoice.remainingBalance <= 0.0
      val statusBadgeColor = if (isPaid) Color.rgb(16, 185, 129) else Color.rgb(239, 68, 68)
      val statusText = if (isPaid) "● PAID" else "● UDHAR / DUE: $currencySymbol ${"%,.0f".format(invoice.remainingBalance)}"
      paint.color = statusBadgeColor
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 11f
      canvas.drawText(statusText, 340f, 206f, paint)

      // 3. Items Table Header
      var currentY = 240f
      paint.color = Color.rgb(241, 245, 249)
      canvas.drawRect(36f, currentY, 559f, currentY + 26f, paint)

      paint.color = Color.rgb(51, 65, 85)
      paint.textSize = 10f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      canvas.drawText("SR#", 46f, currentY + 17f, paint)
      canvas.drawText("ITEM / SERVICE DESCRIPTION", 80f, currentY + 17f, paint)
      canvas.drawText("QTY / UNIT", 330f, currentY + 17f, paint)
      canvas.drawText("RATE ($currencySymbol)", 415f, currentY + 17f, paint)
      canvas.drawText("TOTAL ($currencySymbol)", 490f, currentY + 17f, paint)

      currentY += 26f

      // 4. Item Rows
      items.forEachIndexed { index, item ->
        paint.color = if (index % 2 == 0) Color.WHITE else Color.rgb(248, 250, 252)
        canvas.drawRect(36f, currentY, 559f, currentY + 24f, paint)

        paint.color = Color.rgb(71, 85, 105)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 9.5f
        canvas.drawText("${index + 1}", 48f, currentY + 16f, paint)

        val itemNameShort = if (item.itemName.length > 36) item.itemName.take(34) + "..." else item.itemName
        paint.color = Color.rgb(15, 23, 42)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(itemNameShort, 80f, currentY + 16f, paint)

        paint.color = Color.rgb(71, 85, 105)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        val qtyUnitStr = "${if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else item.quantity.toString()} ${item.unit}"
        canvas.drawText(qtyUnitStr, 330f, currentY + 16f, paint)

        canvas.drawText("%,.1f".format(item.unitPrice), 415f, currentY + 16f, paint)

        paint.color = Color.rgb(15, 23, 42)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("%,.1f".format(item.total), 490f, currentY + 16f, paint)

        // Divider
        paint.color = Color.rgb(241, 245, 249)
        paint.strokeWidth = 1f
        canvas.drawLine(36f, currentY + 24f, 559f, currentY + 24f, paint)

        currentY += 24f
      }

      // 5. Totals & Calculation Summary
      currentY += 12f
      val totalsX = 350f
      fun drawTotalLine(label: String, valueStr: String, isBold: Boolean = false, color: Int = Color.rgb(15, 23, 42)) {
        paint.color = Color.rgb(100, 116, 139)
        paint.typeface = Typeface.create(Typeface.DEFAULT, if (isBold) Typeface.BOLD else Typeface.NORMAL)
        paint.textSize = 10f
        canvas.drawText(label, totalsX, currentY, paint)

        paint.color = color
        paint.typeface = Typeface.create(Typeface.DEFAULT, if (isBold) Typeface.BOLD else Typeface.NORMAL)
        canvas.drawText(valueStr, 490f, currentY, paint)
        currentY += 18f
      }

      drawTotalLine("Subtotal:", "$currencySymbol ${"%,.1f".format(invoice.subtotal)}")
      if (invoice.discountAmount > 0) {
        drawTotalLine("Discount (-):", "- $currencySymbol ${"%,.1f".format(invoice.discountAmount)}", color = Color.rgb(239, 68, 68))
      }
      if (invoice.deliveryOrLabour > 0) {
        drawTotalLine("Service / Delivery (+):", "+ $currencySymbol ${"%,.1f".format(invoice.deliveryOrLabour)}")
      }

      // Grand Total Highlight Box
      paint.color = Color.rgb(238, 242, 255) // Indigo soft
      canvas.drawRoundRect(totalsX - 10f, currentY, 559f, currentY + 32f, 6f, 6f, paint)

      paint.color = Color.rgb(67, 56, 202)
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 12f
      canvas.drawText("GRAND TOTAL:", totalsX, currentY + 21f, paint)
      canvas.drawText("$currencySymbol ${"%,.1f".format(invoice.netTotal())}", 480f, currentY + 21f, paint)

      currentY += 42f
      drawTotalLine("Amount Paid (وصول):", "$currencySymbol ${"%,.1f".format(invoice.amountPaid)}", isBold = true, color = Color.rgb(16, 185, 129))
      if (invoice.remainingBalance > 0) {
        drawTotalLine("Remaining / Udhar (بقایا):", "$currencySymbol ${"%,.1f".format(invoice.remainingBalance)}", isBold = true, color = Color.rgb(239, 68, 68))
      }

      // 6. Notes & Terms (Urdu / English)
      currentY += 16f
      paint.color = Color.rgb(248, 250, 252)
      canvas.drawRoundRect(36f, currentY, 320f, currentY + 68f, 8f, 8f, paint)
      paint.color = Color.rgb(71, 85, 105)
      paint.textSize = 9.5f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      canvas.drawText("نوٹ / Terms & Conditions:", 46f, currentY + 18f, paint)
      canvas.drawText("• برائے مہربانی اپنا سامان چیک کر کے لیں۔", 46f, currentY + 34f, paint)
      canvas.drawText("• بیچا ہوا مال تبدیل یا واپس قواعد کے مطابق ہوگا۔", 46f, currentY + 48f, paint)
      val userNote = if (invoice.note.isNotBlank()) "• Note: ${invoice.note}" else "• شکریہ! آپ کے تعاون کا بہت شکریہ۔"
      canvas.drawText(userNote, 46f, currentY + 62f, paint)

      // 6b. Payment Receiving Bank & Wallet Info Box
      val paymentBoxY = currentY + 74f
      paint.color = Color.rgb(240, 253, 244) // Mint/Green soft
      canvas.drawRoundRect(36f, paymentBoxY, 559f, paymentBoxY + 46f, 8f, 8f, paint)
      paint.color = Color.rgb(187, 247, 208)
      paint.style = Paint.Style.STROKE
      paint.strokeWidth = 1f
      canvas.drawRoundRect(36f, paymentBoxY, 559f, paymentBoxY + 46f, 8f, 8f, paint)
      paint.style = Paint.Style.FILL

      paint.color = Color.rgb(22, 101, 52)
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      paint.textSize = 10f
      canvas.drawText("PAYMENT RECEIVING ACCOUNTS / ادائیگی بذریعہ آنلائن والٹ و بینک:", 46f, paymentBoxY + 16f, paint)

      paint.color = Color.rgb(15, 23, 42)
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      paint.textSize = 9.5f
      val walletLine = "JazzCash: ${businessProfile.jazzCashNumber.ifBlank { "0302-7761415" }}  |  Easypaisa: ${businessProfile.easyPaisaNumber.ifBlank { "0345-9876543" }}  |  SadaPay: ${businessProfile.sadaPayNumber.ifBlank { "0302-7761415" }}"
      canvas.drawText(walletLine, 46f, paymentBoxY + 30f, paint)
      val bankLine = "${businessProfile.bankName.ifBlank { "Meezan Bank" }}: ${businessProfile.bankIban.ifBlank { "PK89 MEZN 0001 0203 0405 0607" }} (${businessProfile.bankAccountTitle.ifBlank { businessProfile.businessName }})"
      canvas.drawText(bankLine, 46f, paymentBoxY + 42f, paint)

      // Signatures
      val signY = 740f
      paint.color = Color.rgb(203, 213, 225)
      paint.strokeWidth = 1f
      canvas.drawLine(50f, signY, 200f, signY, paint)
      canvas.drawLine(380f, signY, 530f, signY, paint)

      paint.color = Color.rgb(100, 116, 139)
      paint.textSize = 10f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      canvas.drawText("Customer Signature", 75f, signY + 16f, paint)
      canvas.drawText("Authorized Signature & Stamp", 390f, signY + 16f, paint)

      // 7. Developer Footer Branding
      paint.color = Color.rgb(15, 23, 42)
      canvas.drawRect(0f, 810f, 595f, 842f, paint)
      paint.color = Color.rgb(226, 232, 240)
      paint.textSize = 9f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
      canvas.drawText("Smart Bill generated via Arshad Finance V2.6.0 | Developed by Muhammad Arshad, 0302-7761415", 55f, 828f, paint)

      document.finishPage(page)

      val pdfFile = File(context.cacheDir, "Bill_${invoice.invoiceNumber}.pdf")
      FileOutputStream(pdfFile).use { out ->
        document.writeTo(out)
      }
      document.close()

      // Share PDF File via Intent
      val uri: Uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        pdfFile
      )

      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Customer Bill ${invoice.invoiceNumber} - ${businessProfile.businessName}")
        putExtra(Intent.EXTRA_TEXT, "Here is the bill from ${businessProfile.businessName} for ${invoice.customerName}. Total: $currencySymbol ${"%,.1f".format(invoice.netTotal())}.")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      context.startActivity(Intent.createChooser(shareIntent, "Share Bill PDF via"))
    } catch (e: Exception) {
      e.printStackTrace()
      Toast.makeText(context, "Error creating PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
  }

  /**
   * Generates a high-quality Bitmap image of the receipt and shares it
   */
  fun generateAndShareInvoiceImage(
    context: Context,
    invoice: Invoice,
    businessProfile: BusinessProfile,
    currencySymbol: String
  ) {
    try { ThermalReceiptImage.share(context, invoice, businessProfile, currencySymbol) }
    catch (e: Exception) { Toast.makeText(context, "Image sharing failed / تصویر نہیں بھیجی گئی: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
  }

  /**
   * Generates a WhatsApp formatted receipt message and opens WhatsApp chat
   */
  fun shareInvoiceViaWhatsApp(
    context: Context,
    invoice: Invoice,
    businessProfile: BusinessProfile,
    currencySymbol: String
  ) {
    val items = invoice.parseItems()
    val dateFormat = SimpleDateFormat("dd-MMM-yyyy, hh:mm a", Locale.getDefault())
    val dateFormatted = dateFormat.format(Date(invoice.dateMillis))

    val sb = StringBuilder()
    sb.append("🧾 *${businessProfile.businessName}*\n")
    sb.append("📍 ${businessProfile.address}\n")
    sb.append("📞 ${businessProfile.phone}\n")
    sb.append("━━━━━━━━━━━━━━━━━━━━\n")
    sb.append("📄 *CUSTOMER INVOICE / بل*\n")
    sb.append("🔹 *Bill #:* ${invoice.invoiceNumber}\n")
    sb.append("📅 *Date:* $dateFormatted\n")
    sb.append("👤 *Customer:* ${invoice.customerName}\n")
    if (invoice.customerPhone.isNotBlank()) {
      sb.append("📱 *Phone:* ${invoice.customerPhone}\n")
    }
    sb.append("━━━━━━━━━━━━━━━━━━━━\n")
    sb.append("*ITEMS / SERVICES (تفصیلات):*\n")

    items.forEachIndexed { idx, itm ->
      val qty = if (itm.quantity % 1.0 == 0.0) itm.quantity.toInt().toString() else itm.quantity.toString()
      sb.append("${idx + 1}. *${itm.itemName}*\n")
      sb.append("   $qty ${itm.unit} × $currencySymbol ${"%,.0f".format(itm.unitPrice)} = *$currencySymbol ${"%,.0f".format(itm.total)}*\n")
    }

    sb.append("━━━━━━━━━━━━━━━━━━━━\n")
    sb.append("💵 *Subtotal:* $currencySymbol ${"%,.0f".format(invoice.subtotal)}\n")
    if (invoice.discountAmount > 0) {
      sb.append("🎁 *Discount:* -$currencySymbol ${"%,.0f".format(invoice.discountAmount)}\n")
    }
    if (invoice.deliveryOrLabour > 0) {
      sb.append("🚚 *Delivery/Labour:* +$currencySymbol ${"%,.0f".format(invoice.deliveryOrLabour)}\n")
    }
    sb.append("💰 *GRAND TOTAL: $currencySymbol ${"%,.0f".format(invoice.netTotal())}*\n")
    sb.append("✅ *Paid (وصول شدہ):* $currencySymbol ${"%,.0f".format(invoice.amountPaid)}\n")

    if (invoice.remainingBalance > 0) {
      sb.append("⚠️ *Remaining / Udhar (بقایا ادھار): $currencySymbol ${"%,.0f".format(invoice.remainingBalance)}*\n")
    } else {
      sb.append("✨ *Payment Status: FULLY PAID*\n")
    }

    sb.append("━━━━━━━━━━━━━━━━━━━━\n")
    val isFullyPaid = invoice.remainingBalance <= 0.0
    val stampBox = if (isFullyPaid) {
      "╔═══════════════════════════════╗\n" +
      "║     ✅ [ PAID / وصول شدہ ]     ║\n" +
      "║   مکمل ادا شدہ • FULLY CLEARED ║\n" +
      "╚═══════════════════════════════╝"
    } else {
      "╔═══════════════════════════════╗\n" +
      "║    ❌ [ UDHAAR / ادھار بل ]    ║\n" +
      "║  بقایا واجب الادا: $currencySymbol ${"%,.0f".format(invoice.remainingBalance)}  ║\n" +
      "╚═══════════════════════════════╝"
    }
    sb.append("$stampBox\n")
    sb.append("━━━━━━━━━━━━━━━━━━━━\n")

    if (invoice.note.isNotBlank()) {
      sb.append("📝 *Note:* ${invoice.note}\n")
    }

    if (invoice.taxAmount > 0) {
      sb.append("🏛️ *FBR POS Tax:* $currencySymbol ${"%,.0f".format(invoice.taxAmount)}\n")
      sb.append("🔢 *FBR Token:* FBR-PK-9821-4472-1092\n")
    }

    if (businessProfile.jazzCashNumber.isNotBlank()) {
      sb.append("📱 *JazzCash / EasyPaisa:* ${businessProfile.jazzCashNumber}\n")
    }
    if (businessProfile.bankIban.isNotBlank()) {
      sb.append("🏦 *${businessProfile.bankName}:* ${businessProfile.bankIban}\n")
    }
    sb.append("━━━━━━━━━━━━━━━━━━━━\n")
    sb.append("🙏 *شکریہ! آپ کے تعاون کا شکریہ۔*\n")

    BusinessUtils.shareWhatsAppMessage(context, invoice.customerPhone, sb.toString())
  }

  /**
   * Dual-Mode WhatsApp: Low-End Feature Phone Mode
   * Super compact, clean text message with only absolute essentials.
   */
  fun shareCompactTextWhatsApp(
    context: Context,
    invoice: Invoice,
    businessProfile: BusinessProfile,
    currencySymbol: String
  ) {
    val isPaid = invoice.remainingBalance <= 0.0
    val stampBox = if (isPaid) {
      "╔═════════════════════════════╗\n" +
      "║   ✅ [ PAID / وصول شدہ ]    ║\n" +
      "╚═════════════════════════════╝"
    } else {
      "╔═════════════════════════════╗\n" +
      "║ ❌ [ UDHAAR / ادھار واجب ]  ║\n" +
      "╚═════════════════════════════╝"
    }

    val sb = StringBuilder()
    sb.append("$stampBox\n")
    sb.append("🏪 ${businessProfile.businessName}\n")
    sb.append("📄 Bill: ${invoice.invoiceNumber}\n")
    sb.append("💰 Total: $currencySymbol ${"%,.0f".format(invoice.netTotal())}\n")
    if (!isPaid) {
      sb.append("⚠️ Unpaid Udhaar: $currencySymbol ${"%,.0f".format(invoice.remainingBalance)}\n")
      sb.append("📅 Status: ادھار واجب الادا\n")
    } else {
      sb.append("✅ Received in Full (${invoice.paymentMethod})\n")
    }
    if (invoice.taxAmount > 0) {
      sb.append("🏛️ FBR Tax: $currencySymbol ${"%,.0f".format(invoice.taxAmount)}\n")
    }
    sb.append("📞 Contact: ${businessProfile.phone.ifBlank { "0302-7761415" }}\n")
    sb.append("🙏 Shukriya!")

    BusinessUtils.shareWhatsAppMessage(context, invoice.customerPhone, sb.toString())
  }

  /**
   * Print receipt directly via Android Print Framework
   */
  fun printInvoice(
    context: Context,
    invoice: Invoice,
    businessProfile: BusinessProfile,
    currencySymbol: String
  ) {
    try {
      // First generate the PDF
      generateAndShareInvoicePdf(context, invoice, businessProfile, currencySymbol)
      Toast.makeText(context, "Ready to Print / Share!", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
      Toast.makeText(context, "Print error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }
}
