package com.example.business

import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.FinanceDatabase
import com.example.data.model.*
import com.example.data.model.Transaction
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject
import java.util.UUID

@Entity(tableName = "business_records")
data class BusinessRecord(@PrimaryKey val id: String = UUID.randomUUID().toString(), val kind: String,
  val title: String, val party: String = "", val amount: Double = 0.0, val status: String = "OPEN",
  val payload: String = "{}", val createdAt: Long = System.currentTimeMillis(), val updatedAt: Long = System.currentTimeMillis(),
  val createdBy: String = "owner", val branchId: String = "main", val warehouseId: String = "main", val archived: Boolean = false)
@Entity(tableName = "stock_movements")
data class StockMovement(@PrimaryKey val id: String, val itemId: Long, val quantity: Double,
  val reason: String, val createdAt: Long, val createdBy: String = "local", val branchId: String = "main", val warehouseId: String = "main",
  @ColumnInfo(defaultValue = "''") val documentId: String = "")
@Dao
interface BusinessDao {
  @Query("SELECT * FROM business_records ORDER BY createdAt DESC") fun records(): Flow<List<BusinessRecord>>
  @Query("SELECT * FROM business_records ORDER BY createdAt DESC") suspend fun allRecords(): List<BusinessRecord>
  @Query("SELECT * FROM business_records WHERE id=:id") suspend fun record(id: String): BusinessRecord?
  @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(record: BusinessRecord)
  @Update suspend fun update(record: BusinessRecord)
  @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertRecords(records: List<BusinessRecord>)
  @Query("SELECT * FROM stock_movements ORDER BY createdAt DESC") fun movements(): Flow<List<StockMovement>>
  @Query("SELECT * FROM stock_movements") suspend fun allMovements(): List<StockMovement>
  @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertMovements(records: List<StockMovement>)
  @Query("SELECT COALESCE(SUM(quantity),0) FROM stock_movements WHERE itemId=:id") suspend fun derivedStock(id: Long): Double
  @Query("SELECT COALESCE(SUM(quantity),0) FROM stock_movements WHERE itemId=:id AND branchId=:branch AND warehouseId=:warehouse") suspend fun locationStock(id: Long, branch: String, warehouse: String): Double
  @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun context(context: StockContext)
  @Query("SELECT * FROM stock_context WHERE id=1") suspend fun context(): StockContext?
  @Query("DELETE FROM business_records") suspend fun clearRecords()
  @Query("DELETE FROM stock_movements") suspend fun clearMovements()
}
object BusinessSchema {
  fun install(db: SupportSQLiteDatabase) {
    db.execSQL("""CREATE TABLE IF NOT EXISTS business_records (id TEXT NOT NULL PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL, party TEXT NOT NULL, amount REAL NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, createdBy TEXT NOT NULL, branchId TEXT NOT NULL, warehouseId TEXT NOT NULL, archived INTEGER NOT NULL)""")
    db.execSQL("""CREATE TABLE IF NOT EXISTS stock_movements (id TEXT NOT NULL PRIMARY KEY, itemId INTEGER NOT NULL, quantity REAL NOT NULL, reason TEXT NOT NULL, createdAt INTEGER NOT NULL, createdBy TEXT NOT NULL, branchId TEXT NOT NULL, warehouseId TEXT NOT NULL)""")
    // Capture every legacy inventory write as well as new workflows, in the same SQLite transaction.
    db.execSQL("""CREATE TRIGGER IF NOT EXISTS stock_insert AFTER INSERT ON inventory_items BEGIN INSERT INTO stock_movements (id,itemId,quantity,reason,createdAt,createdBy,branchId,warehouseId) VALUES(lower(hex(randomblob(16))),NEW.id,NEW.currentStock-COALESCE((SELECT SUM(quantity) FROM stock_movements WHERE itemId=NEW.id),0),'OPENING',NEW.lastUpdatedMillis,'local','main','main'); END""")
    db.execSQL("""CREATE TRIGGER IF NOT EXISTS stock_update AFTER UPDATE OF currentStock ON inventory_items WHEN NEW.currentStock != OLD.currentStock BEGIN INSERT INTO stock_movements (id,itemId,quantity,reason,createdAt,createdBy,branchId,warehouseId) VALUES(lower(hex(randomblob(16))),NEW.id,NEW.currentStock-OLD.currentStock,'STOCK_CHANGE',NEW.lastUpdatedMillis,'local','main','main'); END""")
    db.execSQL("""CREATE TRIGGER IF NOT EXISTS stock_delete AFTER DELETE ON inventory_items BEGIN INSERT INTO stock_movements (id,itemId,quantity,reason,createdAt,createdBy,branchId,warehouseId) VALUES(lower(hex(randomblob(16))),OLD.id,-OLD.currentStock,'REMOVED',OLD.lastUpdatedMillis,'local','main','main'); END""")
  }
  val callback = object: RoomDatabase.Callback() { override fun onCreate(db: SupportSQLiteDatabase) { install(db); WorkflowSchema.install(db) } }
  val migration = object: androidx.room.migration.Migration(6,7) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL("ALTER TABLE inventory_items ADD COLUMN detailsJson TEXT NOT NULL DEFAULT '{}'")
      install(db)
      db.execSQL("INSERT INTO stock_movements SELECT lower(hex(randomblob(16))),id,currentStock,'MIGRATED_OPENING',lastUpdatedMillis,'local','main','main' FROM inventory_items")
    }
  }
}
class BusinessCore(private val db: FinanceDatabase) {
  val records = db.businessDao().records()
  val movements = db.businessDao().movements()
  private fun validMoney(amount: Double) = require(amount.isFinite() && amount >= 0) { "Enter a valid amount / درست رقم درج کریں" }
  suspend fun create(kind: String, title: String, party: String, amount: Double, payload: String = "{}", actor: String = "owner") = db.withTransaction {
    require(kind in listOf("JOB","APPOINTMENT","PROJECT","BOM","SUPPLIER","QUOTATION","ORDER","CHALLAN","RENTAL","SUBSCRIPTION","BRANCH","WAREHOUSE"))
    require(title.isNotBlank()) { "Enter a name / نام درج کریں" }; validMoney(amount); JSONObject(payload)
    val records = db.businessDao().allRecords()
    require(records.none { !it.archived && it.kind == kind && it.title.equals(title.trim(),true) && it.party.equals(party.trim(),true) }) { "This record already exists / یہ ریکارڈ پہلے سے موجود ہے" }
    val data=JSONObject(payload)
    val record = BusinessRecord(kind=kind,title=title.trim(),party=party.trim(),amount=amount,payload=payload,createdBy=actor,branchId=data.optString("branch","main").ifBlank { "main" },warehouseId=data.optString("warehouse","main").ifBlank { "main" })
    db.businessDao().insert(record); audit("CREATE",record.id,actor); record
  }
  private suspend fun audit(action: String, id: String, actor: String) { db.businessDao().insert(BusinessRecord(kind="AUDIT",title=action,party=id,createdBy=actor,status="RECORDED")) }
  suspend fun complete(id: String, actor: String) = db.withTransaction {
    val record = db.businessDao().record(id) ?: error("Record no longer exists")
    require(record.kind !in listOf("AUDIT","SUPPLIER_DEBIT","SUPPLIER_CREDIT","PRODUCTION","PRODUCTION_ORDER","RENTAL_CONTRACT","RENTAL_DEPOSIT","RENTAL_DEPOSIT_APPLIED","RENTAL_DEPOSIT_REFUND","RAW_MATERIAL_ISSUE"))
    require(record.status != "COMPLETED") { "Already completed / پہلے مکمل ہو چکا ہے" }
    db.businessDao().update(record.copy(status="COMPLETED",updatedAt=System.currentTimeMillis())); audit("COMPLETE",id,actor)
  }
  // Supplier balance is derived from signed entries. Cash and payable changes are atomic.
  suspend fun supplierEntry(supplier: String, amount: Double, payment: Boolean, note: String, actor: String) = db.withTransaction {
    validMoney(amount); require(amount > 0 && supplier.isNotBlank())
    val dao = db.businessDao(); val name = supplier.trim()
    if (payment) {
      val due = dao.allRecords().filter { it.party == name }.sumOf { if(it.kind=="SUPPLIER_DEBIT") it.amount else if(it.kind=="SUPPLIER_CREDIT") -it.amount else 0.0 }
      require(amount <= due + 0.000001) { "Payment exceeds supplier balance / ادائیگی سپلائر کے بقایا سے زیادہ ہے" }
      val account = db.financeDao().getAllAccountsList().firstOrNull { it.accountType.contains("Cash",true) } ?: error("Create a cash account first / پہلے کیش اکاؤنٹ بنائیں")
      var allocation=amount
      dao.allRecords().filter {it.kind=="PURCHASE_BILL"&&it.party==name}.sortedBy {it.createdAt}.forEach {bill -> val data=JSONObject(bill.payload);val paid=data.optDouble("paid");val returnedCredits=dao.allRecords().filter {it.kind=="PURCHASE_RETURN"&&JSONObject(it.payload).optString("sourceId")==bill.id}.sumOf {JSONObject(it.payload).optDouble("dueCredit")};val part=minOf(allocation,(bill.amount-paid-returnedCredits).coerceAtLeast(0.0));if(part>0){dao.update(bill.copy(payload=data.put("paid",paid+part).toString(),updatedAt=System.currentTimeMillis()));allocation-=part}}
      db.financeDao().changeAccountBalance(account.id,-amount)
      db.financeDao().insertTransaction(Transaction(title="Supplier payment: $name",amount=amount,type=TransactionType.EXPENSE,category="Supplier payment",icon="💵",accountName=account.name,note=note,transactionRef="SUPPLIER/${UUID.randomUUID()}"))
    }
    val record=BusinessRecord(kind=if(payment) "SUPPLIER_CREDIT" else "SUPPLIER_DEBIT",title=note.ifBlank { if(payment) "Payment" else "Supplier bill / opening balance" },party=name,amount=amount,createdBy=actor,status="POSTED")
    dao.insert(record); audit("SUPPLIER_ENTRY",record.id,actor)
  }
  suspend fun produce(bomId: String, outputQuantity: Double, wastage: Double, actor: String) = db.withTransaction {
    require(outputQuantity.isFinite() && outputQuantity > 0 && wastage.isFinite() && wastage >= 0) { "Enter valid output/wastage / پیداوار اور ضیاع درست درج کریں" }
    val bom=db.businessDao().record(bomId) ?: error("Select a recipe / BOM")
    require(bom.kind=="BOM")
    val data=JSONObject(bom.payload); val outputId=data.getLong("outputId"); val ingredients=data.getJSONArray("ingredients")
    val output=db.financeDao().getInventoryItemById(outputId) ?: error("Output product missing")
    val usage=mutableMapOf<Long,Double>(); val batchQuantity=outputQuantity+wastage
    for(i in 0 until ingredients.length()) { val line=ingredients.getJSONObject(i); val qty=line.getDouble("quantity")*batchQuantity; val id=line.getLong("itemId"); require(qty.isFinite() && qty > 0 && id != outputId); usage[id]=(usage[id] ?: 0.0)+qty }
    require(usage.isNotEmpty()); var cost=0.0
    usage.forEach { (id,qty) -> val item=db.financeDao().getInventoryItemById(id) ?: error("Ingredient missing"); require(item.currentStock+0.000001>=qty) { "Insufficient stock: ${item.name} / اسٹاک کم ہے" }; cost+=qty*item.costPrice }
    require(cost.isFinite())
    usage.forEach { (id,qty) -> db.financeDao().deductInventoryStock(id,qty) }
    val average = (output.currentStock*output.costPrice+cost)/(output.currentStock+outputQuantity)
    db.financeDao().updateInventoryItem(output.copy(currentStock=output.currentStock+outputQuantity,costPrice=average,lastUpdatedMillis=System.currentTimeMillis()))
    val record=BusinessRecord(kind="PRODUCTION",title=bom.title,amount=cost,payload=JSONObject().put("bomId",bomId).put("outputId",outputId).put("outputQuantity",outputQuantity).put("wastage",wastage).toString(),status="POSTED",createdBy=actor)
    db.businessDao().insert(record); audit("PRODUCE",record.id,actor)
  }
}
