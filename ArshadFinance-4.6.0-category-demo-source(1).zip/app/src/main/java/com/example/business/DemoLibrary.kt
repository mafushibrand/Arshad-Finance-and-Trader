package com.example.business

import com.example.data.model.InventoryItem
import com.example.data.model.ServiceItem
import org.json.JSONObject
import kotlinx.coroutines.flow.first

/**
 * Category-aware starter catalogue. All entries are clearly marked as samples;
 * callers merge by name so importing a demo never replaces a customer's records.
 */
object DemoLibrary {
  private data class Sample(
    val name: String, val category: String, val unit: String,
    val cost: Double, val price: Double, val stock: Double, val emoji: String,
    val type: String = "Product"
  )

  private val catalog = mapOf(
    "kiryana" to listOf(
      Sample("🌾 Basmati Rice / باسمتی چاول","Grocery","kg",250.0,310.0,80.0,"🌾"),
      Sample("🛢️ Cooking Oil / کوکنگ آئل","Grocery","litre",480.0,550.0,42.0,"🛢️"),
      Sample("🥣 Sugar / چینی","Grocery","kg",145.0,175.0,100.0,"🥣"),
      Sample("🧼 Detergent / واشنگ پاؤڈر","Household","pack",180.0,220.0,35.0,"🧼")
    ),
    "supermarket" to listOf(
      Sample("🥛 Fresh Milk / تازہ دودھ","Dairy","litre",180.0,220.0,30.0,"🥛"),
      Sample("🥤 Mineral Water / منرل واٹر","Beverages","bottle",35.0,50.0,96.0,"🥤"),
      Sample("🍪 Family Biscuits / بسکٹ","Snacks","pack",65.0,90.0,60.0,"🍪")
    ),
    "produce" to listOf(
      Sample("🍎 Fresh Apples / سیب","Fruit","kg",220.0,280.0,45.0,"🍎"),
      Sample("🥔 Potatoes / آلو","Vegetables","kg",70.0,95.0,90.0,"🥔"),
      Sample("🍌 Bananas / کیلے","Fruit","dozen",100.0,140.0,25.0,"🍌")
    ),
    "meat" to listOf(
      Sample("🍗 Chicken / مرغی","Meat","kg",520.0,620.0,35.0,"🍗"),
      Sample("🥩 Beef / گائے کا گوشت","Meat","kg",900.0,1080.0,18.0,"🥩"),
      Sample("🐟 Fresh Fish / تازہ مچھلی","Seafood","kg",700.0,850.0,12.0,"🐟")
    ),
    "bakery" to listOf(
      Sample("🍞 Milk Bread / دودھ والی ڈبل روٹی","Bakery","piece",90.0,130.0,24.0,"🍞"),
      Sample("🎂 Chocolate Cake / چاکلیٹ کیک","Cakes","kg",900.0,1350.0,8.0,"🎂"),
      Sample("🥐 Croissant / کروساں","Bakery","piece",80.0,120.0,20.0,"🥐")
    ),
    "restaurant" to listOf(
      Sample("🌾 Rice & Spices / چاول اور مصالحہ","Raw Material","kg",180.0,0.0,80.0,"🌾","Raw Material"),
      Sample("🍛 Chicken Biryani / چکن بریانی","Menu","plate",180.0,320.0,0.0,"🍛","Finished Good"),
      Sample("🍔 Zinger Burger / زنگر برگر","Menu","piece",220.0,420.0,0.0,"🍔","Finished Good"),
      Sample("🥤 Soft Drink / کولڈ ڈرنک","Beverages","bottle",65.0,100.0,48.0,"🥤")
    ),
    "dairy" to listOf(
      Sample("🥛 Fresh Milk / تازہ دودھ","Dairy","litre",170.0,210.0,60.0,"🥛"),
      Sample("🧈 Desi Ghee / دیسی گھی","Dairy","kg",1800.0,2200.0,12.0,"🧈"),
      Sample("🍶 Yogurt / دہی","Dairy","kg",160.0,210.0,30.0,"🍶")
    ),
    "pharmacy" to listOf(
      Sample("💊 Paracetamol / پیراسیٹامول","Medicine","pack",40.0,60.0,50.0,"💊"),
      Sample("🩹 First Aid Bandage / پٹی","Medical","box",90.0,130.0,25.0,"🩹"),
      Sample("🧴 Hand Sanitizer / سینیٹائزر","Personal Care","bottle",120.0,170.0,30.0,"🧴")
    ),
    "garments" to listOf(
      Sample("👕 Cotton Shirt / کاٹن شرٹ","Clothing","piece",650.0,1100.0,18.0,"👕"),
      Sample("🧣 Lawn Suit / لان سوٹ","Clothing","suit",1400.0,2200.0,12.0,"🧣"),
      Sample("👖 Denim Jeans / جینز","Clothing","piece",900.0,1500.0,14.0,"👖")
    ),
    "shoes" to listOf(
      Sample("👟 Sports Joggers / اسپورٹس جوتے","Footwear","pair",1500.0,2300.0,16.0,"👟"),
      Sample("🩴 Casual Sandals / سینڈل","Footwear","pair",650.0,1000.0,20.0,"🩴"),
      Sample("🥾 Leather Shoes / لیدر شوز","Footwear","pair",2100.0,3200.0,9.0,"🥾")
    ),
    "cosmetics" to listOf(
      Sample("💄 Lipstick / لپ اسٹک","Beauty","piece",350.0,550.0,25.0,"💄"),
      Sample("🧴 Face Wash / فیس واش","Skincare","bottle",280.0,420.0,30.0,"🧴"),
      Sample("🧴 Sunscreen / سن اسکرین","Skincare","tube",450.0,650.0,18.0,"🧴")
    ),
    "jewellery" to listOf(
      Sample("💍 Gold Ring / سونے کی انگوٹھی","Jewellery","gram",18000.0,20500.0,2.0,"💍"),
      Sample("📿 Silver Bracelet / چاندی کا بریسلٹ","Jewellery","piece",2500.0,3400.0,5.0,"📿"),
      Sample("✨ Gem Pendant / نگینے کا لاکٹ","Jewellery","piece",3200.0,4500.0,3.0,"✨")
    ),
    "mobile" to listOf(
      Sample("📱 Android Smartphone / اسمارٹ فون","Electronics","piece",42000.0,47999.0,8.0,"📱"),
      Sample("🎧 Wireless Earbuds / وائرلیس ایئربڈز","Accessories","piece",1800.0,2600.0,20.0,"🎧"),
      Sample("🔌 Fast Charger / فاسٹ چارجر","Accessories","piece",650.0,950.0,30.0,"🔌")
    ),
    "computer" to listOf(
      Sample("💻 Business Laptop / لیپ ٹاپ","Computers","piece",95000.0,112000.0,5.0,"💻"),
      Sample("🖱️ Wireless Mouse / وائرلیس ماؤس","Accessories","piece",900.0,1400.0,20.0,"🖱️"),
      Sample("⌨️ Mechanical Keyboard / کی بورڈ","Accessories","piece",2800.0,3900.0,12.0,"⌨️")
    ),
    "electronics" to listOf(
      Sample("🌀 Pedestal Fan / پیڈسٹل پنکھا","Appliances","piece",6500.0,8200.0,8.0,"🌀"),
      Sample("🧊 Refrigerator / فریج","Appliances","piece",85000.0,99000.0,3.0,"🧊"),
      Sample("📺 LED Television / ایل ای ڈی","Appliances","piece",62000.0,73500.0,4.0,"📺")
    ),
    "electrical" to listOf(
      Sample("💡 LED Bulb / ایل ای ڈی بلب","Electrical","piece",180.0,260.0,50.0,"💡"),
      Sample("🔌 Power Socket / پاور ساکٹ","Electrical","piece",220.0,320.0,40.0,"🔌"),
      Sample("🧵 Copper Wire / تانبے کی تار","Electrical","meter",95.0,130.0,200.0,"🧵")
    ),
    "hardware" to listOf(
      Sample("🔧 Tool Set / اوزار سیٹ","Tools","set",1800.0,2500.0,10.0,"🔧"),
      Sample("🚰 Brass Tap / پیتل کا نل","Sanitary","piece",950.0,1350.0,18.0,"🚰"),
      Sample("🪛 Screw Pack / پیچ","Hardware","pack",80.0,120.0,60.0,"🪛")
    ),
    "paint" to listOf(
      Sample("🎨 Interior Emulsion / اندرونی پینٹ","Paint","litre",650.0,850.0,35.0,"🎨"),
      Sample("🖌️ Paint Brush / پینٹ برش","Tools","piece",120.0,180.0,25.0,"🖌️"),
      Sample("🪣 Weather Shield / ویدر شیلڈ","Paint","bucket",4200.0,5100.0,8.0,"🪣")
    ),
    "auto_parts" to listOf(
      Sample("🛢️ Engine Oil / انجن آئل","Auto Parts","litre",850.0,1100.0,24.0,"🛢️"),
      Sample("🔋 Car Battery / گاڑی کی بیٹری","Auto Parts","piece",14500.0,16900.0,6.0,"🔋"),
      Sample("🧰 Oil Filter / آئل فلٹر","Auto Parts","piece",450.0,650.0,20.0,"🧰")
    ),
    "tyres" to listOf(
      Sample("🛞 Car Tyre / گاڑی کا ٹائر","Tyres","piece",14500.0,17200.0,12.0,"🛞"),
      Sample("🔋 Dry Battery / ڈرائی بیٹری","Batteries","piece",8200.0,9900.0,8.0,"🔋"),
      Sample("🧰 Puncture Kit / پنکچر کٹ","Accessories","set",350.0,550.0,15.0,"🧰")
    ),
    "fuel" to listOf(
      Sample("⛽ Petrol / پیٹرول","Fuel","litre",250.0,257.0,1000.0,"⛽"),
      Sample("🛢️ Diesel / ڈیزل","Fuel","litre",255.0,265.0,900.0,"🛢️"),
      Sample("🧴 Lubricant / لبریکینٹ","Lubricants","litre",650.0,820.0,40.0,"🧴")
    ),
    "books" to listOf(
      Sample("📓 School Notebook / کاپی","Stationery","piece",90.0,130.0,50.0,"📓"),
      Sample("🖊️ Pen Pack / پین","Stationery","pack",100.0,150.0,35.0,"🖊️"),
      Sample("📚 Urdu Reader / اردو کتاب","Books","piece",280.0,380.0,18.0,"📚")
    ),
    "printing" to listOf(
      Sample("🖨️ Colour Print / کلر پرنٹ","Print Service","page",0.0,50.0,0.0,"🖨️","Service"),
      Sample("🪧 Flex Banner / فلیکس بینر","Print Service","sq ft",0.0,90.0,0.0,"🪧","Service"),
      Sample("📇 Business Cards / وزٹنگ کارڈ","Print Service","box",0.0,1200.0,0.0,"📇","Service")
    ),
    "furniture" to listOf(
      Sample("🪑 Office Chair / آفس کرسی","Furniture","piece",6500.0,8500.0,6.0,"🪑"),
      Sample("🛏️ Bed Set / بیڈ سیٹ","Furniture","set",28000.0,36000.0,2.0,"🛏️"),
      Sample("🗄️ Office Desk / آفس میز","Furniture","piece",12000.0,15800.0,4.0,"🗄️")
    ),
    "building" to listOf(
      Sample("🧱 Cement Bag / سیمنٹ بوری","Building","bag",1250.0,1390.0,100.0,"🧱"),
      Sample("🏖️ Sand / ریت","Building","cft",75.0,100.0,500.0,"🏖️"),
      Sample("🔩 Steel Bar / سریا","Building","kg",260.0,290.0,800.0,"🔩")
    ),
    "tiles" to listOf(
      Sample("◻️ Ceramic Tile / سرامک ٹائل","Tiles","sq ft",180.0,260.0,200.0,"◻️"),
      Sample("⬜ Marble Slab / ماربل","Stone","sq ft",450.0,650.0,80.0,"⬜"),
      Sample("🧱 Tile Adhesive / ٹائل گوند","Materials","bag",650.0,850.0,30.0,"🧱")
    ),
    "mobile_repair" to listOf(
      Sample("🔧 Screen Replacement / اسکرین تبدیلی","Repair Service","job",0.0,6500.0,0.0,"📱","Service"),
      Sample("🔋 Battery Replacement / بیٹری تبدیلی","Repair Service","job",0.0,2800.0,0.0,"🔋","Service"),
      Sample("🧰 Charging Port Repair / چارجنگ پورٹ مرمت","Repair Service","job",0.0,1800.0,0.0,"🧰","Service")
    ),
    "workshop" to listOf(
      Sample("🛢️ Engine Oil / انجن آئل","Parts","litre",500.0,700.0,20.0,"🛢️"),
      Sample("🔍 Vehicle Inspection / گاڑی معائنہ","Labour","job",0.0,800.0,0.0,"🔍","Service"),
      Sample("🧰 Brake Service / بریک سروس","Labour","job",0.0,2500.0,0.0,"🧰","Service")
    ),
    "salon" to listOf(
      Sample("💇 Hair Cut / بال کٹنگ","Salon Service","session",0.0,500.0,0.0,"💇","Service"),
      Sample("✨ Hydra Facial / ہائیڈرا فیشل","Salon Service","session",0.0,2800.0,0.0,"✨","Service"),
      Sample("🧔 Beard Styling / داڑھی اسٹائلنگ","Salon Service","session",0.0,400.0,0.0,"🧔","Service")
    ),
    "tailor" to listOf(
      Sample("🧵 Suit Stitching / سوٹ سلائی","Tailoring","suit",0.0,1800.0,0.0,"🧵","Service"),
      Sample("✂️ Alteration / کپڑوں کی تراش خراش","Tailoring","job",0.0,500.0,0.0,"✂️","Service"),
      Sample("👔 Waistcoat Stitching / واسکٹ سلائی","Tailoring","piece",0.0,1200.0,0.0,"👔","Service")
    ),
    "laundry" to listOf(
      Sample("👔 Shirt Wash & Press / شرٹ دھلائی","Laundry","piece",0.0,180.0,0.0,"👔","Service"),
      Sample("🧥 Dry Cleaning / ڈرائی کلیننگ","Laundry","piece",0.0,450.0,0.0,"🧥","Service"),
      Sample("🛏️ Bedding Service / بیڈنگ دھلائی","Laundry","set",0.0,700.0,0.0,"🛏️","Service")
    ),
    "clinic" to listOf(
      Sample("🩺 General Consultation / معائنہ","Clinic Service","visit",0.0,1000.0,0.0,"🩺","Service"),
      Sample("🧪 CBC Test / سی بی سی ٹیسٹ","Lab Service","test",0.0,900.0,0.0,"🧪","Service"),
      Sample("🩸 Blood Sugar Test / شوگر ٹیسٹ","Lab Service","test",0.0,250.0,0.0,"🩸","Service")
    ),
    "school" to listOf(
      Sample("📚 Monthly Tuition / ماہانہ ٹیوشن","Education","month",0.0,3500.0,0.0,"📚","Service"),
      Sample("📝 Admission Fee / داخلہ فیس","Education","student",0.0,2000.0,0.0,"📝","Service"),
      Sample("🧮 Computer Course / کمپیوٹر کورس","Education","course",0.0,6500.0,0.0,"🧮","Service")
    ),
    "property" to listOf(
      Sample("🏠 Property Listing / پراپرٹی لسٹنگ","Property Service","listing",0.0,5000.0,0.0,"🏠","Service"),
      Sample("📄 Documentation / دستاویزات","Property Service","job",0.0,3500.0,0.0,"📄","Service"),
      Sample("🤝 Rental Deal / کرایہ معاہدہ","Property Service","deal",0.0,12000.0,0.0,"🤝","Service")
    ),
    "travel" to listOf(
      Sample("✈️ Air Ticket / ہوائی ٹکٹ","Travel Service","booking",0.0,2500.0,0.0,"✈️","Service"),
      Sample("🛂 Visa Assistance / ویزا معاونت","Travel Service","case",0.0,8500.0,0.0,"🛂","Service"),
      Sample("🏨 Hotel Booking / ہوٹل بکنگ","Travel Service","booking",0.0,1800.0,0.0,"🏨","Service")
    ),
    "courier" to listOf(
      Sample("📦 Local Parcel / مقامی پارسل","Courier Service","shipment",0.0,250.0,0.0,"📦","Service"),
      Sample("🚚 Same Day Delivery / اسی دن ترسیل","Courier Service","shipment",0.0,450.0,0.0,"🚚","Service"),
      Sample("✉️ Document Delivery / دستاویز ترسیل","Courier Service","shipment",0.0,180.0,0.0,"✉️","Service")
    ),
    "transport" to listOf(
      Sample("🚕 City Ride / شہر کے اندر سفر","Transport Service","trip",0.0,1200.0,0.0,"🚕","Service"),
      Sample("🚐 Airport Transfer / ایئرپورٹ ٹرانسفر","Transport Service","trip",0.0,3500.0,0.0,"🚐","Service"),
      Sample("🚘 Daily Car Rental / روزانہ گاڑی کرایہ","Transport Service","day",0.0,6500.0,0.0,"🚘","Service")
    ),
    "hotel" to listOf(
      Sample("🛏️ Standard Room / معیاری کمرہ","Hospitality","room-night",0.0,4500.0,0.0,"🛏️","Service"),
      Sample("🍳 Breakfast / ناشتہ","Hospitality","meal",0.0,650.0,0.0,"🍳","Service"),
      Sample("🧹 Room Service / کمرہ سروس","Hospitality","service",0.0,350.0,0.0,"🧹","Service")
    ),
    "gym" to listOf(
      Sample("🏋️ Monthly Membership / ماہانہ ممبرشپ","Fitness","month",0.0,3500.0,0.0,"🏋️","Service"),
      Sample("💪 Personal Training / ذاتی تربیت","Fitness","session",0.0,900.0,0.0,"💪","Service"),
      Sample("🧘 Yoga Class / یوگا کلاس","Fitness","session",0.0,600.0,0.0,"🧘","Service")
    ),
    "farm" to listOf(
      Sample("🥚 Farm Eggs / فارم انڈے","Farm Produce","dozen",250.0,320.0,40.0,"🥚"),
      Sample("🌽 Animal Feed / جانوروں کی خوراک","Feed","bag",1800.0,2200.0,20.0,"🌽"),
      Sample("🥛 Fresh Milk / تازہ دودھ","Dairy","litre",170.0,210.0,60.0,"🥛")
    ),
    "agri" to listOf(
      Sample("🌱 Hybrid Seeds / ہائبرڈ بیج","Agriculture","bag",1200.0,1550.0,25.0,"🌱"),
      Sample("🌾 Fertilizer / کھاد","Agriculture","bag",4200.0,4800.0,18.0,"🌾"),
      Sample("🧴 Crop Spray / فصل اسپرے","Agriculture","litre",850.0,1100.0,16.0,"🧴")
    ),
    "mill" to listOf(
      Sample("🌾 Wheat Grain / گندم","Raw Material","kg",95.0,0.0,500.0,"🌾","Raw Material"),
      Sample("🥣 Flour / آٹا","Finished Goods","kg",0.0,125.0,0.0,"🥣","Finished Good"),
      Sample("🍚 Rice / چاول","Finished Goods","kg",0.0,280.0,0.0,"🍚","Finished Good")
    ),
    "textile" to listOf(
      Sample("🧵 Cotton Yarn / سوتی دھاگہ","Raw Material","kg",650.0,0.0,200.0,"🧵","Raw Material"),
      Sample("🧶 Dyed Fabric / رنگین کپڑا","Finished Goods","meter",0.0,480.0,0.0,"🧶","Finished Good"),
      Sample("👕 Stitched Shirt / سلی ہوئی شرٹ","Finished Goods","piece",0.0,1200.0,0.0,"👕","Finished Good")
    ),
    "leather" to listOf(
      Sample("🦬 Raw Leather / خام چمڑا","Raw Material","sq ft",180.0,0.0,300.0,"🦬","Raw Material"),
      Sample("👞 Leather Shoes / لیدر جوتے","Finished Goods","pair",0.0,4200.0,0.0,"👞","Finished Good"),
      Sample("👜 Leather Bag / چمڑے کا بیگ","Finished Goods","piece",0.0,3500.0,0.0,"👜","Finished Good")
    ),
    "plastic" to listOf(
      Sample("🧪 Polymer Granules / پلاسٹک دانہ","Raw Material","kg",320.0,0.0,400.0,"🧪","Raw Material"),
      Sample("🧴 Plastic Bottle / پلاسٹک بوتل","Finished Goods","piece",0.0,18.0,0.0,"🧴","Finished Good"),
      Sample("📦 Packaging Box / پیکنگ ڈبہ","Finished Goods","piece",0.0,35.0,0.0,"📦","Finished Good")
    ),
    "food_factory" to listOf(
      Sample("🌶️ Spice Raw Material / مصالحہ خام مال","Raw Material","kg",400.0,0.0,100.0,"🌶️","Raw Material"),
      Sample("🫙 Masala Pack / مصالحہ پیک","Finished Goods","pack",0.0,150.0,0.0,"🫙","Finished Good"),
      Sample("🥫 Sauce Bottle / ساس بوتل","Finished Goods","bottle",0.0,220.0,0.0,"🥫","Finished Good")
    ),
    "chemical" to listOf(
      Sample("🧪 Chemical Base / کیمیکل خام مال","Raw Material","kg",280.0,0.0,150.0,"🧪","Raw Material"),
      Sample("🧼 Detergent Pack / ڈٹرجنٹ پیک","Finished Goods","pack",0.0,180.0,0.0,"🧼","Finished Good"),
      Sample("🧴 Liquid Soap / لیکوئڈ صابن","Finished Goods","litre",0.0,260.0,0.0,"🧴","Finished Good")
    ),
    "pharma_factory" to listOf(
      Sample("🧪 Active Ingredient / خام دوا","Raw Material","kg",2500.0,0.0,40.0,"🧪","Raw Material"),
      Sample("💊 Tablet Pack / گولیوں کا پیک","Finished Goods","pack",0.0,450.0,0.0,"💊","Finished Good"),
      Sample("🧴 Syrup Bottle / سیرپ بوتل","Finished Goods","bottle",0.0,280.0,0.0,"🧴","Finished Good")
    ),
    "contractor" to listOf(
      Sample("🏗️ Site Supervision / سائٹ نگرانی","Construction Service","project",0.0,25000.0,0.0,"🏗️","Service"),
      Sample("👷 Labour Contract / مزدوری ٹھیکہ","Construction Service","day",0.0,4500.0,0.0,"👷","Service"),
      Sample("📐 Measurement & Estimate / پیمائش و تخمینہ","Construction Service","job",0.0,3500.0,0.0,"📐","Service")
    ),
    "solar" to listOf(
      Sample("☀️ Solar Installation / سولر تنصیب","Solar Service","project",0.0,45000.0,0.0,"☀️","Service"),
      Sample("🔋 Inverter Setup / انورٹر سیٹ اپ","Solar Service","job",0.0,12000.0,0.0,"🔋","Service"),
      Sample("🧰 Maintenance Visit / مرمت وزٹ","Solar Service","visit",0.0,2500.0,0.0,"🧰","Service")
    ),
    "security" to listOf(
      Sample("🛡️ Security Guard Shift / سکیورٹی گارڈ شفٹ","Security Service","shift",0.0,1800.0,0.0,"🛡️","Service"),
      Sample("📹 CCTV Monitoring / سی سی ٹی وی نگرانی","Security Service","month",0.0,6500.0,0.0,"📹","Service"),
      Sample("🚨 Site Security Audit / سکیورٹی آڈٹ","Security Service","visit",0.0,3500.0,0.0,"🚨","Service")
    ),
    "software" to listOf(
      Sample("💻 Website Development / ویب سائٹ بنانا","IT Service","project",0.0,45000.0,0.0,"💻","Service"),
      Sample("☁️ Cloud Setup / کلاؤڈ سیٹ اپ","IT Service","job",0.0,12000.0,0.0,"☁️","Service"),
      Sample("🧑‍💻 IT Support / آئی ٹی معاونت","IT Service","hour",0.0,1800.0,0.0,"🧑‍💻","Service")
    ),
    "wholesale" to listOf(
      Sample("📦 Rice Carton / چاول کارٹن","Wholesale","carton",4200.0,4650.0,30.0,"📦"),
      Sample("🛢️ Oil Carton / آئل کارٹن","Wholesale","carton",10500.0,11400.0,18.0,"🛢️"),
      Sample("🧼 Detergent Case / ڈٹرجنٹ کیس","Wholesale","case",1800.0,2100.0,25.0,"🧼")
    ),
    "custom" to listOf(
      Sample("📦 Sample Product / نمونہ پروڈکٹ","General","piece",500.0,750.0,20.0,"📦"),
      Sample("🛠️ Sample Service / نمونہ سروس","General","job",0.0,1200.0,0.0,"🛠️","Service"),
      Sample("🧾 Consultation / مشاورت","General","hour",0.0,900.0,0.0,"🧾","Service")
    )
  )

  fun items(template: String): List<InventoryItem> {
    val samples = catalog[template] ?: catalog.getValue("custom")
    return samples.map { sample ->
      item(sample.name, sample.category, sample.unit, sample.cost, sample.price, sample.stock,
        sample.type, JSONObject().put("demoImageEmoji", sample.emoji).put("demoSample", true))
    }
  }

  /** Category-matched service menu used by salon, repair, clinic, travel and other service firms. */
  fun services(template: String): List<ServiceItem> {
    val samples = catalog[template] ?: return emptyList()
    return samples.filter { it.type == "Service" }.mapIndexed { index, sample ->
      ServiceItem(
        id = ("demo_${template}_${index}").hashCode().toLong().let { kotlin.math.abs(it) + 10_000L },
        name = sample.name.substringAfter(" ").substringBefore(" / "),
        urduName = sample.name.substringAfter(" / ", sample.name),
        businessCategory = template.uppercase(),
        serviceType = sample.category,
        price = sample.price,
        unit = sample.unit,
        stockOrSlots = 25.0,
        icon = sample.emoji,
        description = if (sample.name.contains(" / ")) sample.name.substringAfter(" / ") else sample.name,
        isFeatured = index == 0
      )
    }
  }

  suspend fun workflows(db: com.example.data.local.FinanceDatabase, template: String) {
    val dao = db.financeDao()
    val items = dao.getAllInventoryItems().first()
    val customer = dao.insertCustomer(com.example.data.model.Customer(name = "Demo customer / ڈیمو گاہک"))
    val core = BusinessCore(db)
    val engine = AdvancedWorkflowEngine(db)
    core.create("SUPPLIER", "Demo supplier / ڈیمو سپلائر", "", 0.0)
    when (template) {
      "restaurant", "food_factory", "mill", "textile", "leather", "plastic", "chemical", "pharma_factory" -> {
        val raw = items.firstOrNull { JSONObject(it.detailsJson).optString("itemType") == "Raw Material" }
        val output = items.firstOrNull { JSONObject(it.detailsJson).optString("itemType") == "Finished Good" }
        if (raw != null && output != null) {
          val bom = core.create("BOM", "Demo recipe / ڈیمو ریسپی", "", 0.0,
            JSONObject().put("outputId", output.id).put("ingredients",
              org.json.JSONArray().put(JSONObject().put("itemId", raw.id).put("quantity", 0.1))).toString())
          engine.planProduction("DEMO-PRODUCTION", bom.id, 10.0, batch = "DEMO-BATCH")
        }
      }
      "workshop", "mobile_repair", "solar", "contractor", "security", "software" ->
        core.create("JOB", "Demo service / ڈیمو سروس", "Demo customer / ڈیمو گاہک", 800.0,
          JSONObject().put("customerId", customer).put("technician", "Demo technician")
            .put("notes", "Sample job; replace with your real customer details").toString())
      else -> {
        val first = items.firstOrNull()
        if (first != null) TradeEngine(db).salesDocument("QUOTATION", "DEMO-QUOTE", customer,
          listOf(TradeLine(first.id, 1.0, first.salePrice)), "main", "main")
      }
    }
  }

  private fun item(
    name: String, category: String, unit: String, cost: Double, price: Double, stock: Double,
    type: String = "Product", details: JSONObject = JSONObject()
  ) = InventoryItem(
    name = name, category = category, unit = unit, costPrice = cost, salePrice = price,
    currentStock = stock, barcode = if (type == "Service") "SRV-DEMO-${name.hashCode()}" else "",
    detailsJson = details.put("itemType", type).put("conversion", details.optString("conversion", "1"))
      .put("saleConversion", "1").toString()
  )
}
