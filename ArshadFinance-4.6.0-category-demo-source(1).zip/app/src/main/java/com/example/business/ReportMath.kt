package com.example.business

import com.example.data.model.Invoice
import com.example.data.model.InvoiceItemEntry
import org.json.JSONObject

data class NetInvoiceLine(val line:InvoiceItemEntry,val quantity:Double,val revenue:Double,val cost:Double)
/** Returns target the original line index, including when an item appears more than once. */
fun netInvoiceLines(invoice:Invoice,records:List<BusinessRecord>,currentCost:(Long)->Double):List<NetInvoiceLine> {
  val returns=records.filter {it.kind=="SALES_RETURN"&&JSONObject(it.payload).optLong("invoiceId")==invoice.id}
  val costs=JSONObject(invoice.detailsJson).optJSONArray("lineCosts")
  return invoice.parseItems().mapIndexed {index,line->
    val returned=returns.sumOf {JSONObject(it.payload).optJSONObject("quantities")?.optDouble(index.toString(),0.0) ?: 0.0}
    val restocked=returns.filter {JSONObject(it.payload).optBoolean("restock")}.sumOf {JSONObject(it.payload).optJSONObject("quantities")?.optDouble(index.toString(),0.0) ?: 0.0}
    val remaining=(line.quantity-returned).coerceAtLeast(0.0)
    val unitCost=if(line.isService)0.0 else if(costs!=null&&index<costs.length())costs.optDouble(index,0.0) else line.itemId?.let(currentCost) ?: 0.0
    NetInvoiceLine(line,remaining,line.unitPrice*remaining,unitCost*(line.quantity-restocked).coerceAtLeast(0.0))
  }
}
