package com.example.business

import java.math.BigDecimal
import java.math.MathContext
import org.json.JSONObject

data class BusinessTemplate(val id: String, val name: String, val urdu: String, val sector: String,
  val category: String, val samples: String, val unit: String, val fields: List<String>, val mode: String) {
  fun label(urduMode: Boolean) = if (urduMode) urdu else name
}
object BusinessLibrary {
  private fun t(id: String, en: String, ur: String, sector: String, category: String, samples: String,
    unit: String = "piece", fields: String = "", mode: String = "stock") = BusinessTemplate(id,en,ur,sector,category,samples,unit,fields.split(',').filter { it.isNotBlank() },mode)
  val templates = listOf(
    t("kiryana","Kiryana / General Store","کریانہ / جنرل سٹور","Retail","Grocery","Rice, flour, oil","kg"),
    t("supermarket","Supermarket","سپر مارکیٹ","Retail","Grocery","Household, food, beverages"),
    t("produce","Fruit & Vegetable","پھل اور سبزی","Retail","Fresh food","Fruit, vegetables","kg"),
    t("meat","Meat / Chicken / Fish","گوشت / مرغی / مچھلی","Retail","Fresh food","Meat, poultry, fish","kg", "batch,expiry"),
    t("bakery","Bakery / Sweets","بیکری / مٹھائی","Food","Bakery","Bread, cakes, sweets","kg","batch,expiry","recipe"),
    t("restaurant","Restaurant / Cafe / Fast Food","ریسٹورنٹ / کیفے / فاسٹ فوڈ","Food","Dining","Meals, drinks","plate","batch,expiry","recipe"),
    t("dairy","Dairy","ڈیری","Retail","Fresh food","Milk, yoghurt","litre","batch,expiry"),
    t("pharmacy","Pharmacy / Medical Store","فارمیسی / میڈیکل سٹور","Retail","Healthcare","Medicines, medical supplies","pack","batch,mfg,expiry"),
    t("garments","Garments","کپڑے","Retail","Fashion","Shirts, suits","piece","size,color,brand"),
    t("shoes","Shoes","جوتے","Retail","Fashion","Shoes, sandals","pair","size,color,brand"),
    t("cosmetics","Cosmetics","کاسمیٹکس","Retail","Beauty","Skincare, makeup","piece","brand,batch,expiry"),
    t("jewellery","Jewellery / Gold","زیورات / سونا","Retail","Jewellery","Gold, silver, gems","gram","purity,grade,makingCharges"),
    t("mobile","Mobile Shop","موبائل شاپ","Retail","Technology","Phones, accessories","piece","serial,imei,warranty,brand,model"),
    t("computer","Computer / IT Shop","کمپیوٹر / آئی ٹی شاپ","Retail","Technology","Computers, components","piece","serial,warranty,brand,model"),
    t("electronics","Electronics / Appliances","الیکٹرانکس / گھریلو آلات","Retail","Technology","Fans, refrigerators","piece","serial,warranty,brand,model"),
    t("electrical","Electrical","الیکٹریکل","Retail","Hardware","Wires, switches","meter","brand,model"),
    t("hardware","Hardware / Sanitary","ہارڈویئر / سینیٹری","Retail","Hardware","Fittings, tools","piece","brand,grade"),
    t("paint","Paint","پینٹ","Retail","Hardware","Paints, coatings","litre","color,brand,batch"),
    t("auto_parts","Auto Parts","آٹو پارٹس","Retail","Automotive","Parts, oils","piece","brand,model"),
    t("tyres","Tyre / Battery","ٹائر / بیٹری","Retail","Automotive","Tyres, batteries","piece","serial,warranty,brand,model"),
    t("fuel","Petrol Pump","پیٹرول پمپ","Retail","Fuel","Fuel, lubricants","litre"),
    t("books","Books / Stationery","کتابیں / سٹیشنری","Retail","Stationery","Books, paper","piece"),
    t("printing","Printing / Flex","پرنٹنگ / فلیکس","Services","Printing","Print, signage","sq ft","size,color","job"),
    t("furniture","Furniture","فرنیچر","Retail","Home","Furniture","piece","size,color,model"),
    t("building","Building Material","تعمیراتی سامان","Retail","Construction","Cement, sand","bag","grade"),
    t("tiles","Tiles / Marble","ٹائل / ماربل","Retail","Construction","Tiles, stone","sq ft","size,color,grade"),
    t("mobile_repair","Mobile Repair","موبائل مرمت","Services","Repair","Device repair","job","serial,imei,model,warranty","job"),
    t("workshop","Auto Workshop","آٹو ورکشاپ","Services","Repair","Vehicle repair","job","model","job"),
    t("salon","Salon / Beauty Parlour","سیلون / بیوٹی پارلر","Services","Personal care","Hair, beauty","session","","appointment"),
    t("tailor","Tailor / Boutique","درزی / بوتیک","Services","Fashion","Stitching, alterations","job","size,color","job"),
    t("laundry","Laundry / Dry Cleaning","لانڈری / ڈرائی کلیننگ","Services","Personal care","Cleaning","piece","","job"),
    t("clinic","Clinic / Lab","کلینک / لیب","Services","Healthcare","Consultations, tests","visit","","appointment"),
    t("school","School / Academy","سکول / اکیڈمی","Services","Education","Classes, courses","month","","subscription"),
    t("property","Real Estate","رئیل اسٹیٹ","Services","Property","Property services","project","","project"),
    t("travel","Travel / Ticketing","ٹریول / ٹکٹنگ","Services","Travel","Tickets, bookings","booking","","booking"),
    t("courier","Courier / Logistics","کورئیر / لاجسٹکس","Services","Logistics","Parcels, shipments","shipment","","job"),
    t("transport","Transport / Rent-a-Car","ٹرانسپورٹ / رینٹ اے کار","Services","Travel","Vehicle hire","trip","model","rental"),
    t("hotel","Hotel / Guest House","ہوٹل / گیسٹ ہاؤس","Services","Hospitality","Rooms","room-night","","booking"),
    t("gym","Gym","جم","Services","Fitness","Membership, training","month","","subscription"),
    t("farm","Poultry / Livestock / Dairy Farm","پولٹری / مویشی / ڈیری فارم","Agriculture","Farm","Eggs, milk, feed","kg","batch,expiry"),
    t("agri","Agriculture Inputs","زرعی سامان","Agriculture","Inputs","Seed, fertilizer","bag","batch,expiry"),
    t("mill","Flour / Rice / Oil Mill","آٹا / چاول / آئل مل","Manufacturing","Milling","Flour, rice, oil","kg","batch,grade","production"),
    t("textile","Textile / Garment Factory","ٹیکسٹائل / گارمنٹ فیکٹری","Manufacturing","Textile","Fabric, garments","meter","size,color,grade","production"),
    t("leather","Leather / Shoes / Bags Factory","چمڑا / جوتے / بیگ فیکٹری","Manufacturing","Leather","Shoes, bags","piece","size,color,grade","production"),
    t("plastic","Plastic / Packaging Factory","پلاسٹک / پیکنگ فیکٹری","Manufacturing","Packaging","Containers, packaging","piece","size,grade","production"),
    t("food_factory","Food / Spice Factory","خوراک / مصالحہ فیکٹری","Manufacturing","Food","Spices, food packs","kg","batch,mfg,expiry","production"),
    t("chemical","Chemical / Soap / Detergent","کیمیکل / صابن / ڈٹرجنٹ","Manufacturing","Chemical","Soap, chemicals","kg","batch,mfg,expiry","production"),
    t("pharma_factory","Pharma / Medical Manufacturing","ادویات / میڈیکل فیکٹری","Manufacturing","Healthcare","Medical products","pack","batch,mfg,expiry","production"),
    t("contractor","Construction Contractor","تعمیراتی ٹھیکیدار","Services","Construction","Materials, labour","project","grade","project"),
    t("solar","Solar Installer","سولر انسٹالر","Services","Energy","Panels, installation","project","serial,warranty,brand","job"),
    t("security","Security Company","سیکیورٹی کمپنی","Services","Security","Guard deployment","shift","","job"),
    t("software","Software / IT / Freelancer","سافٹ ویئر / آئی ٹی / فری لانسر","Services","Technology","Software, consulting","project","","job"),
    t("wholesale","Wholesale / Distributor","ہول سیل / ڈسٹری بیوٹر","Wholesale","Distribution","Bulk items","carton"),
    t("custom","Custom Business","اپنا کاروبار","Custom","General","Your products and services")
  )
  fun find(id: String) = templates.firstOrNull { it.id == id } ?: templates.first()
  val itemTypes = listOf("Product","Service","Raw Material","Finished Good","Semi-Finished / WIP","Expense Item","Asset","Rental Item","Combo / Bundle","Recipe / BOM Item")
  val units = linkedMapOf(
    "Count" to "piece,pcs,unit,item,pair,set,dozen,gross,bundle,packet,pack,box,carton,case,tray,bag",
    "Weight" to "mg,gram,g,kg,maund,quintal,ton,tonne,tola,ratti,carat",
    "Volume" to "ml,litre,L,gallon,bottle,can,tin,drum,bucket",
    "Length" to "mm,cm,inch,foot,ft,yard,meter,m,running foot,running meter,coil,roll",
    "Area" to "sq inch,sq ft,sq yard,sq meter,marla,kanal,acre",
    "Construction" to "cubic foot,cft,cubic meter,truck,load",
    "Time" to "minute,hour,day,week,month,quarter,year,shift",
    "Service" to "job,service,visit,session,appointment,test,procedure,project,milestone,package,trip,booking,parcel,shipment",
    "Hospitality" to "plate,serving,cup,glass,meal,room-night,guest-night",
    "Digital" to "license,user,device,GB,TB,domain,mailbox,subscription/month",
    "Paper" to "page,sheet,ream"
  ).mapValues { it.value.split(',') }
  val allUnits = units.values.flatten().distinct()
  fun convert(quantity: String, factor: String): BigDecimal {
    val q = quantity.toBigDecimalOrNull() ?: error("Invalid quantity / مقدار درست نہیں")
    val f = factor.toBigDecimalOrNull() ?: error("Invalid conversion / تبدیلی درست نہیں")
    require(q >= BigDecimal.ZERO && f > BigDecimal.ZERO) { "Quantity must be non-negative and conversion positive / درست مقدار اور تبدیلی درج کریں" }
    return q.multiply(f, MathContext.DECIMAL128)
  }
  fun details(itemJson: String) = runCatching { JSONObject(itemJson) }.getOrDefault(JSONObject())
}

fun com.example.data.model.InventoryItem.saleFactor(): Double = BusinessLibrary.details(detailsJson).optString("saleConversion","1").toDoubleOrNull()?.takeIf { it.isFinite() && it > 0 } ?: 1.0
fun com.example.data.model.InventoryItem.saleUnit(): String = BusinessLibrary.details(detailsJson).optString("saleUnit").ifBlank { unit }
fun com.example.data.model.InventoryItem.isServiceItem(): Boolean = barcode.startsWith("SRV-") || BusinessLibrary.details(detailsJson).optString("itemType") == "Service"
