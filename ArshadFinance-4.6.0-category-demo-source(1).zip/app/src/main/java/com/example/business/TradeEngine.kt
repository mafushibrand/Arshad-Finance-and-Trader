package com.example.business

import androidx.room.withTransaction
import com.example.data.local.FinanceDatabase
import com.example.data.repository.FinanceRepository
import com.example.data.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

data class TradeLine(val itemId:Long,val quantity:Double,val price:Double) {
  fun json()=JSONObject().put("itemId",itemId).put("quantity",quantity).put("price",price)
}
fun tradeLines(payload:String):List<TradeLine> {
  val a=JSONObject(payload).optJSONArray("lines") ?: JSONArray()
  return (0 until a.length()).map {a.getJSONObject(it).let {o->TradeLine(o.getLong("itemId"),o.getDouble("quantity"),o.getDouble("price"))}}
}
fun moneyRound(amount:Double):Double {require(amount.isFinite());return BigDecimal.valueOf(amount).setScale(2,RoundingMode.HALF_UP).toDouble()}

class TradeEngine(private val db:FinanceDatabase) {
  private val dao=db.financeDao();private val records=db.businessDao()
  private suspend fun audit(action:String,id:String,actor:String)=records.insert(BusinessRecord(kind="AUDIT",title=action,party=id,status="RECORDED",createdBy=actor))
  private suspend fun location(branch:String,warehouse:String) {
    require(branch.isNotBlank() && warehouse.isNotBlank()) {"Select branch and warehouse / برانچ اور گودام منتخب کریں"}
    val all=records.allRecords()
    require(branch=="main" || all.any {it.kind=="BRANCH"&&it.title==branch&&!it.archived})
    require(warehouse=="main" || all.any {it.kind=="WAREHOUSE"&&it.title==warehouse&&!it.archived})
  }
  private suspend fun validate(lines:List<TradeLine>) {
    require(lines.isNotEmpty()) {"Add at least one item / سامان شامل کریں"}
    lines.forEach {require(it.quantity.isFinite()&&it.quantity>0&&it.price.isFinite()&&it.price>=0);require(dao.getInventoryItemById(it.itemId)!=null) {"Item no longer exists / سامان موجود نہیں"}}
  }
  private fun payload(lines:List<TradeLine>,paid:Double=0.0)=JSONObject().put("lines",JSONArray().apply {lines.forEach {put(it.json())}}).put("paid",paid)
  suspend fun purchase(kind:String,supplier:String,reference:String,lines:List<TradeLine>,paid:Double,accountId:Long,branch:String="main",warehouse:String="main",sourceId:String="",actor:String="owner"):BusinessRecord=db.withTransaction {
    require(kind in listOf("PURCHASE_ORDER","PURCHASE_BILL"));validate(lines);location(branch,warehouse)
    require(supplier.isNotBlank()&&reference.isNotBlank())
    val all=records.allRecords()
    require(all.none {it.kind==kind&&it.title.equals(reference.trim(),true)}) {"Duplicate purchase reference / خریداری حوالہ پہلے موجود ہے"}
    val total=moneyRound(lines.sumOf {it.quantity*it.price});require(paid.isFinite()&&paid>=0&&paid<=total)
    if(sourceId.isNotBlank()) {val source=records.record(sourceId) ?: error("Purchase order missing");require(source.kind=="PURCHASE_ORDER"&&source.status=="OPEN"&&source.party==supplier);require(tradeLines(source.payload)==lines) {"Receipt must match the selected order / وصولی منتخب آرڈر کے مطابق ہو"}}
    val r=BusinessRecord(kind=kind,title=reference.trim(),party=supplier.trim(),amount=total,status=if(kind=="PURCHASE_ORDER")"OPEN" else "POSTED",payload=payload(lines,paid).put("sourceId",sourceId).toString(),branchId=branch,warehouseId=warehouse,createdBy=actor)
    if(kind=="PURCHASE_BILL") {
      val oldContext=records.context() ?: StockContext()
      records.context(StockContext(reason="PURCHASE_RECEIPT",documentId=r.id,createdBy=actor,branchId=branch,warehouseId=warehouse))
      try {lines.forEach {line->val item=dao.getInventoryItemById(line.itemId)!!;val stock=item.currentStock+line.quantity;val average=(item.currentStock*item.costPrice+line.quantity*line.price)/stock;require(stock.isFinite()&&average.isFinite());dao.updateInventoryItem(item.copy(currentStock=stock,costPrice=average,lastUpdatedMillis=System.currentTimeMillis()))}} finally {records.context(oldContext)}
      if(all.none {it.kind=="SUPPLIER"&&it.title==supplier.trim()}) records.insert(BusinessRecord(kind="SUPPLIER",title=supplier.trim(),createdBy=actor))
      records.insert(BusinessRecord(kind="SUPPLIER_DEBIT",title=reference,party=supplier.trim(),amount=total,status="POSTED",payload=JSONObject().put("documentId",r.id).toString(),createdBy=actor))
      if(paid>0) {accountPost(accountId,paid,false,"Purchase $reference",r.id,actor);records.insert(BusinessRecord(kind="SUPPLIER_CREDIT",title="Payment $reference",party=supplier.trim(),amount=paid,status="POSTED",payload=JSONObject().put("documentId",r.id).toString(),createdBy=actor))}
      if(sourceId.isNotBlank()) {val source=records.record(sourceId)!!;records.update(source.copy(status="RECEIVED",updatedAt=System.currentTimeMillis()));records.insert(BusinessRecord(kind="GRN",title="GRN-$reference",party=supplier,amount=total,payload=JSONObject(r.payload).put("purchaseBillId",r.id).toString(),status="POSTED",branchId=branch,warehouseId=warehouse,createdBy=actor))}
    }
    records.insert(r);audit(kind,r.id,actor);r
  }
  private suspend fun accountPost(accountId:Long,amount:Double,income:Boolean,title:String,documentId:String,actor:String) {
    require(amount.isFinite()&&amount>=0);if(amount==0.0)return
    val account=dao.getAllAccountsList().find {it.id==accountId} ?: error("Select a payment account / ادائیگی اکاؤنٹ منتخب کریں")
    dao.changeAccountBalance(accountId,if(income)amount else -amount)
    dao.insertTransaction(Transaction(title=title,amount=amount,type=if(income)TransactionType.INCOME else TransactionType.EXPENSE,category=if(income)"Document receipt" else "Document payment",icon="🧾",accountName=account.name,transactionRef="DOC/$documentId",createdBy=actor,updatedAt=System.currentTimeMillis()))
  }
  suspend fun returnPurchase(purchaseId:String,quantities:Map<Int,Double>,accountId:Long,actor:String="owner")=db.withTransaction {
    val purchase=records.record(purchaseId) ?: error("Purchase missing");require(purchase.kind=="PURCHASE_BILL")
    val lines=tradeLines(purchase.payload);require(quantities.isNotEmpty());val previous=records.allRecords().filter {it.kind=="PURCHASE_RETURN"&&JSONObject(it.payload).optString("sourceId")==purchaseId}
    var value=0.0;val chosen=quantities.map { (index,q)->
      require(index in lines.indices&&q.isFinite()&&q>0);val line=lines[index]
      val prior=previous.sumOf {JSONObject(it.payload).optJSONObject("quantities")?.optDouble(index.toString(),0.0) ?: 0.0}
      require(prior+q<=line.quantity+0.000001) {"Return exceeds purchased quantity / واپسی خرید مقدار سے زیادہ ہے"}
      require(records.locationStock(line.itemId,purchase.branchId,purchase.warehouseId)+0.000001>=q) {"Insufficient stock in purchase warehouse / خرید گودام میں اسٹاک ناکافی ہے"}
      value+=q*line.price;TradeLine(line.itemId,q,line.price)
    }
    chosen.groupBy {it.itemId}.forEach {(itemId,group)->val quantity=group.sumOf {it.quantity};require(records.locationStock(itemId,purchase.branchId,purchase.warehouseId)+0.000001>=quantity && (dao.getInventoryItemById(itemId)?.currentStock ?: 0.0)+0.000001>=quantity) {"Insufficient combined return stock / مجموعی واپسی کے لیے اسٹاک ناکافی ہے"}}
    value=minOf(moneyRound(value),(purchase.amount-previous.sumOf {it.amount}).coerceAtLeast(0.0))
    val remaining=purchase.amount-JSONObject(purchase.payload).optDouble("paid",0.0)
    val previousCredits=previous.sumOf {JSONObject(it.payload).optDouble("dueCredit")}
    val dueCredit=minOf(value,(remaining-previousCredits).coerceAtLeast(0.0));val refund=moneyRound(value-dueCredit)
    val id=UUID.randomUUID().toString();val context=records.context() ?: StockContext()
    records.context(StockContext(reason="PURCHASE_RETURN",documentId=id,createdBy=actor,branchId=purchase.branchId,warehouseId=purchase.warehouseId))
    try {chosen.forEach {dao.deductInventoryStock(it.itemId,it.quantity)}}finally {records.context(context)}
    records.insert(BusinessRecord(kind="SUPPLIER_CREDIT",title="Purchase return "+purchase.title,party=purchase.party,amount=value,status="POSTED",createdBy=actor))
    if(refund>0) {accountPost(accountId,refund,true,"Supplier refund "+purchase.title,id,actor);records.insert(BusinessRecord(kind="SUPPLIER_DEBIT",title="Supplier refund "+purchase.title,party=purchase.party,amount=refund,status="POSTED",createdBy=actor))}
    records.insert(BusinessRecord(id=id,kind="PURCHASE_RETURN",title="Return "+purchase.title,party=purchase.party,amount=value,status="POSTED",payload=payload(chosen).put("sourceId",purchaseId).put("quantities",JSONObject().apply {quantities.forEach {(i,q)->put(i.toString(),q)}}).put("dueCredit",dueCredit).put("refund",refund).toString(),branchId=purchase.branchId,warehouseId=purchase.warehouseId,createdBy=actor));audit("PURCHASE_RETURN",id,actor)
  }
  suspend fun returnSale(invoiceId:Long,quantities:Map<Int,Double>,accountId:Long,restock:Boolean=true,actor:String="owner")=db.withTransaction {
    val invoice=dao.getInvoiceById(invoiceId) ?: error("Invoice missing");require(invoice.paymentStatus!="PENDING_APPROVAL") {"Review pending payment before return / پہلے ادائیگی کی تصدیق کریں"}
    val lines=invoice.parseItems();val previous=records.allRecords().filter {it.kind=="SALES_RETURN"&&JSONObject(it.payload).optLong("invoiceId")==invoiceId}
    require(quantities.isNotEmpty());var gross=0.0
    quantities.forEach { (index,q)->require(index in lines.indices&&q.isFinite()&&q>0);val line=lines[index];val returned=previous.sumOf {JSONObject(it.payload).optJSONObject("quantities")?.optDouble(index.toString(),0.0) ?: 0.0};require(q+returned<=line.quantity+0.000001) {"Quantity already returned / مقدار پہلے واپس ہو چکی ہے"};gross+=line.unitPrice*q}
    val previously=previous.sumOf {it.amount};val base=lines.sumOf {it.total};require(base>0)
    val value=minOf(moneyRound(gross/base*invoice.grandTotal),(invoice.grandTotal-previously).coerceAtLeast(0.0))
    val dueCredit=minOf(value,invoice.remainingBalance);val refund=moneyRound(value-dueCredit);val id=UUID.randomUUID().toString()
    if(restock&&invoice.syncWithInventory) {
      val meta=JSONObject(invoice.detailsJson);val context=records.context() ?: StockContext()
      records.context(StockContext(reason="SALES_RETURN",documentId=id,createdBy=actor,branchId=meta.optString("branch","main"),warehouseId=meta.optString("warehouse","main")))
      try {quantities.forEach {(index,q)->val line=lines[index];if(!line.isService) {val itemId=line.itemId ?: error("Original stock item missing");val item=dao.getInventoryItemById(itemId) ?: error("Original stock item missing");val costs=JSONObject(invoice.detailsJson).optJSONArray("lineCosts");val cost=if(costs!=null&&index<costs.length())costs.optDouble(index,item.costPrice) else item.costPrice;val average=(item.currentStock*item.costPrice+q*cost)/(item.currentStock+q);dao.updateInventoryItem(item.copy(currentStock=item.currentStock+q,costPrice=average,lastUpdatedMillis=System.currentTimeMillis()))}}}finally{records.context(context)}
    }
    if(refund>0)accountPost(accountId,refund,false,"Sales refund "+invoice.invoiceNumber,id,actor)
    if(invoice.customerId>0) {dao.updateCustomerFinancials(invoice.customerId,-value,-refund,-dueCredit);CustomerLedger.post(db,invoice.customerId,-dueCredit,"Sales return "+invoice.invoiceNumber,actor)}
    val meta=JSONObject(invoice.detailsJson).put("returnedTotal",previously+value)
    dao.updateInvoice(invoice.copy(amountPaid=(invoice.amountPaid-refund).coerceAtLeast(0.0),remainingBalance=(invoice.remainingBalance-dueCredit).coerceAtLeast(0.0),paymentStatus=if(previously+value>=invoice.grandTotal-0.000001)"RETURNED" else "PARTIAL_RETURN",detailsJson=meta.toString()))
    records.insert(BusinessRecord(id=id,kind="SALES_RETURN",title="Return "+invoice.invoiceNumber,party=invoice.customerName,amount=value,status="POSTED",createdBy=actor,payload=JSONObject().put("invoiceId",invoiceId).put("quantities",JSONObject().apply {quantities.forEach {(i,q)->put(i.toString(),q)}}).put("dueCredit",dueCredit).put("refund",refund).put("restock",restock).toString()));audit("SALES_RETURN",id,actor)
  }
  suspend fun complaintReturn(invoiceId:Long,reason:String,actor:String="owner")=db.withTransaction {
    val invoice=dao.getInvoiceById(invoiceId) ?: error("Invoice missing")
    require(reason.trim().isNotBlank()) {"Enter complaint details / شکایت کی تفصیل درج کریں"}
    val r=BusinessRecord(kind="COMPLAINT_RETURN",title="Complaint "+invoice.invoiceNumber,party=invoice.customerName,
      payload=JSONObject().put("invoiceId",invoiceId).put("reason",reason.trim()).toString(),createdBy=actor)
    records.insert(r);audit("COMPLAINT_OPENED",r.id,actor);r
  }
  suspend fun settleComplaint(id:String,quantities:Map<Int,Double>,accountId:Long,restock:Boolean,actor:String="owner")=db.withTransaction {
    val r=records.record(id) ?: error("Complaint missing")
    require(r.kind=="COMPLAINT_RETURN" && r.status=="OPEN") {"Complaint already settled / شکایت پہلے مکمل ہو چکی ہے"}
    val data=JSONObject(r.payload)
    returnSale(data.getLong("invoiceId"),quantities,accountId,restock,actor)
    records.update(r.copy(status="REFUNDED",updatedAt=System.currentTimeMillis(),payload=data.put("resolvedAt",System.currentTimeMillis()).put("restock",restock).put("quantities",JSONObject().apply {quantities.forEach {(i,q)->put(i.toString(),q)}}).toString()))
    audit("COMPLAINT_REFUNDED",id,actor)
  }
  suspend fun closeComplaint(id:String,note:String,actor:String="owner")=db.withTransaction {
    val r=records.record(id) ?: error("Complaint missing");require(r.kind=="COMPLAINT_RETURN" && r.status=="OPEN")
    require(note.isNotBlank());records.update(r.copy(status="RESOLVED_NO_REFUND",updatedAt=System.currentTimeMillis(),payload=JSONObject(r.payload).put("resolution",note).toString()));audit("COMPLAINT_RESOLVED",id,actor)
  }
  suspend fun transfer(itemId:Long,quantity:Double,fromBranch:String,fromWarehouse:String,toBranch:String,toWarehouse:String,actor:String="owner")=db.withTransaction {
    require(quantity.isFinite()&&quantity>0);require(fromBranch!=toBranch||fromWarehouse!=toWarehouse)
    location(fromBranch,fromWarehouse);location(toBranch,toWarehouse);require(dao.getInventoryItemById(itemId)!=null)
    require(records.locationStock(itemId,fromBranch,fromWarehouse)+0.000001>=quantity) {"Not enough stock at source / متعلقہ گودام میں اسٹاک کم ہے"}
    val id=UUID.randomUUID().toString();val now=System.currentTimeMillis()
    records.insertMovements(listOf(StockMovement(UUID.randomUUID().toString(),itemId,-quantity,"TRANSFER_OUT",now,actor,fromBranch,fromWarehouse,id),StockMovement(UUID.randomUUID().toString(),itemId,quantity,"TRANSFER_IN",now,actor,toBranch,toWarehouse,id)))
    records.insert(BusinessRecord(id=id,kind="TRANSFER",title="Stock transfer",payload=JSONObject().put("itemId",itemId).put("quantity",quantity).put("fromBranch",fromBranch).put("fromWarehouse",fromWarehouse).put("toBranch",toBranch).put("toWarehouse",toWarehouse).toString(),status="POSTED",createdBy=actor,branchId=toBranch,warehouseId=toWarehouse));audit("TRANSFER",id,actor)
  }
  suspend fun stockCount(itemId:Long,counted:Double,branch:String,warehouse:String,actor:String="owner")=db.withTransaction {
    require(counted.isFinite()&&counted>=0);location(branch,warehouse);val item=dao.getInventoryItemById(itemId) ?: error("Item missing")
    val expected=records.locationStock(itemId,branch,warehouse);val delta=counted-expected;require(item.currentStock+delta>=0)
    val id=UUID.randomUUID().toString();val ctx=records.context() ?: StockContext();records.context(StockContext(reason="STOCK_COUNT",documentId=id,createdBy=actor,branchId=branch,warehouseId=warehouse))
    try {dao.updateInventoryItem(item.copy(currentStock=item.currentStock+delta,lastUpdatedMillis=System.currentTimeMillis()))}finally{records.context(ctx)}
    records.insert(BusinessRecord(id=id,kind="STOCK_COUNT",title="Stock count",payload=JSONObject().put("itemId",itemId).put("expected",expected).put("counted",counted).put("delta",delta).toString(),status="POSTED",createdBy=actor,branchId=branch,warehouseId=warehouse));audit("STOCK_COUNT",id,actor)
  }
  suspend fun salesDocument(kind:String,reference:String,customerId:Long,lines:List<TradeLine>,branch:String,warehouse:String,actor:String="owner")=db.withTransaction {
    require(kind in listOf("QUOTATION","ORDER","CHALLAN"));validate(lines);location(branch,warehouse)
    val customer=dao.getCustomerById(customerId) ?: error("Select a customer / گاہک منتخب کریں")
    require(reference.isNotBlank() && records.allRecords().none {it.kind==kind&&it.title.equals(reference,true)})
    val r=BusinessRecord(kind=kind,title=reference,party=customer.name,amount=moneyRound(lines.sumOf {it.price*it.quantity}),payload=payload(lines).put("customerId",customerId).toString(),branchId=branch,warehouseId=warehouse,createdBy=actor)
    records.insert(r);audit(kind,r.id,actor);r
  }
  suspend fun convertSales(id:String,target:String,actor:String="owner")=db.withTransaction {
    val source=records.record(id) ?: error("Document missing");require(source.status=="OPEN")
    require((source.kind=="QUOTATION"&&target=="ORDER") || (source.kind=="ORDER"&&target in listOf("CHALLAN","INVOICE")) || (source.kind=="CHALLAN"&&target=="INVOICE"))
    if(target!="INVOICE") {val next=source.copy(id=UUID.randomUUID().toString(),kind=target,title=target+"-"+source.title,createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis());records.insert(next);records.update(source.copy(status="CONVERTED",updatedAt=System.currentTimeMillis()));audit("CONVERT_"+target,source.id,actor)}
    else {
      val customer=dao.getCustomerById(JSONObject(source.payload).getLong("customerId")) ?: error("Customer missing")
      val items=tradeLines(source.payload).map {l->val item=dao.getInventoryItemById(l.itemId)!!;InvoiceItemEntry(itemId=item.id,itemName=item.name,category=item.category,quantity=l.quantity,unit=item.unit,unitPrice=l.price,total=l.price*l.quantity,isService=item.isServiceItem())}
      val invoice=Invoice(invoiceNumber="INV-"+UUID.randomUUID().toString().take(8).uppercase(),customerId=customer.id,customerName=customer.name,grandTotal=source.amount,subtotal=source.amount,amountPaid=0.0,remainingBalance=source.amount,paymentMethod="Khata",detailsJson=JSONObject().put("sourceId",source.id).put("branch",source.branchId).put("warehouse",source.warehouseId).toString())
      val saved=FinanceRepository(dao,db).saveInvoiceAtomically(invoice,items,true)
      records.update(source.copy(status="INVOICED",payload=JSONObject(source.payload).put("invoiceId",saved.id).toString(),updatedAt=System.currentTimeMillis()));audit("CONVERT_INVOICE",source.id,actor)
    }
  }
  suspend fun billWork(id:String,customerId:Long,parts:List<TradeLine>,labour:Double,period:String="",actor:String="owner")=db.withTransaction {
    val work=records.record(id) ?: error("Job missing")
    require(work.kind in listOf("JOB","APPOINTMENT","PROJECT","SUBSCRIPTION"))
    require(labour.isFinite()&&labour>=0)
    val customer=dao.getCustomerById(customerId) ?: error("Select customer / گاہک منتخب کریں")
    if(work.kind=="SUBSCRIPTION") {
      require(period.matches(Regex("[0-9]{4}-(0[1-9]|1[0-2])"))) {"Use YYYY-MM period / سال-مہینہ درج کریں"}
      require(records.allRecords().none {it.kind=="DUES_POSTING"&&JSONObject(it.payload).optString("sourceId")==id&&JSONObject(it.payload).optString("period")==period}) {"Dues already posted for this month / اس مہینے کا بل پہلے درج ہے"}
    } else require(work.status !in listOf("INVOICED","CANCELLED")) {"Already invoiced / بل پہلے بن چکا ہے"}
    if(parts.isNotEmpty())validate(parts)
    val entries=parts.map {line->val item=dao.getInventoryItemById(line.itemId)!!;InvoiceItemEntry(itemId=item.id,itemName=item.name,quantity=line.quantity,unitPrice=line.price,total=line.quantity*line.price,unit=item.unit,isService=item.isServiceItem())}.toMutableList()
    if(labour>0)entries.add(InvoiceItemEntry(itemName=work.title,quantity=1.0,unitPrice=labour,total=labour,isService=true,unit="service"))
    require(entries.isNotEmpty()) {"Add labour or parts / محنت یا سامان شامل کریں"}
    val total=moneyRound(entries.sumOf {it.total})
    val invoice=FinanceRepository(dao,db).saveInvoiceAtomically(Invoice(invoiceNumber="WORK-"+UUID.randomUUID().toString().take(8).uppercase(),customerId=customer.id,customerName=customer.name,subtotal=total,grandTotal=total,amountPaid=0.0,remainingBalance=total,paymentMethod="Khata",detailsJson=JSONObject().put("sourceId",id).put("branch",work.branchId).put("warehouse",work.warehouseId).toString()),entries,true)
    val metadata=JSONObject(work.payload).put("invoiceId",invoice.id).put("customerId",customerId)
    records.update(work.copy(status=if(work.kind=="SUBSCRIPTION")"ACTIVE" else "INVOICED",payload=metadata.toString(),updatedAt=System.currentTimeMillis()))
    records.insert(BusinessRecord(kind=if(work.kind=="SUBSCRIPTION")"DUES_POSTING" else "JOB_BILLING",title=invoice.invoiceNumber,party=customer.name,amount=total,status="POSTED",payload=JSONObject().put("sourceId",id).put("period",period).put("invoiceId",invoice.id).toString(),createdBy=actor,branchId=work.branchId,warehouseId=work.warehouseId));audit("WORK_INVOICE",id,actor)
  }

}
