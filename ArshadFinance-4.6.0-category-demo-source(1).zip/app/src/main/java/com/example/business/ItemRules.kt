package com.example.business

import com.example.data.model.InventoryItem
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

object ItemRules {
  fun validateSale(item:InventoryItem,quantity:Double) {
    val d=JSONObject(item.detailsJson)
    require(!d.optBoolean("archived")) {"Item is archived / سامان آرکائیو ہے"}
    val expiry=d.optString("expiry")
    if(expiry.isNotBlank()) {
      val fmt=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply {isLenient=false;timeZone=TimeZone.getTimeZone("Asia/Karachi")}
      val date=runCatching {fmt.parse(expiry)}.getOrNull() ?: error("Expiry must use yyyy-MM-dd / ایکسپائری کی تاریخ درست درج کریں")
      val today=fmt.parse(fmt.format(java.util.Date()))!!
      require(!date!!.before(today)) {"Expired item cannot be sold / زائد المعیاد سامان فروخت نہیں ہو سکتا"}
    }
    if(d.optString("serial").isNotBlank()||d.optString("imei").isNotBlank())require(quantity==1.0&&item.currentStock<=1.000001) {"Use one stock item per serial/IMEI / ہر سیریل یا آئی ایم ای آئی کے لیے الگ سامان درج کریں"}
  }
  fun price(item:InventoryItem,wholesale:Boolean=false):Double {
    val d=JSONObject(item.detailsJson)
    if(d.optString("purity").isNotBlank() && d.optDouble("metalRate",0.0)>0) return moneyRound(d.optDouble("weight",1.0)*d.optDouble("metalRate")*d.optDouble("purity",100.0)/100.0+d.optDouble("makingCharges",0.0))
    return if(wholesale)d.optDouble("wholesale",item.salePrice).takeIf {it>0} ?: item.salePrice else item.salePrice
  }
}
