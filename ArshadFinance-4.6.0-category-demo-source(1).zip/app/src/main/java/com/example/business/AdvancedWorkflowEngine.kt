package com.example.business

import androidx.room.withTransaction
import com.example.data.local.FinanceDatabase
import com.example.data.model.*
import com.example.data.model.Transaction
import com.example.data.repository.FinanceRepository
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ceil

/** Stateful workflows use the same atomic Room transaction, stock triggers and customer ledger. */
class AdvancedWorkflowEngine(private val db: FinanceDatabase) {
  private val records get()=db.businessDao()
  private val dao get()=db.financeDao()
  private fun number(value:Double,positive:Boolean=false) {require(value.isFinite() && if(positive)value>0 else value>=0){"Enter a valid amount / درست مقدار درج کریں"}}
  private suspend fun location(branch:String,warehouse:String) {
    val all=records.allRecords()
    require(branch=="main" || all.any {it.kind=="BRANCH"&&it.title==branch&&!it.archived}){"Select a branch / برانچ منتخب کریں"}
    require(warehouse=="main" || all.any {it.kind=="WAREHOUSE"&&it.title==warehouse&&!it.archived}){"Select a warehouse / گودام منتخب کریں"}
  }
  private suspend fun audit(action:String,id:String,actor:String) {records.insert(BusinessRecord(kind="AUDIT",title=action,party=id,status="RECORDED",createdBy=actor))}
  private suspend fun unique(kind:String,title:String) {require(title.isNotBlank());require(records.allRecords().none {it.kind==kind&&it.title.equals(title.trim(),true)}){"Reference already exists / حوالہ پہلے موجود ہے"}}
  private suspend fun stock(record:BusinessRecord,reason:String,actor:String,action:suspend ()->Unit) {
    val previous=records.context() ?: StockContext()
    records.context(StockContext(reason=reason,documentId=record.id,createdBy=actor,branchId=record.branchId,warehouseId=record.warehouseId))
    try {action()} finally {records.context(previous)}
  }
  private suspend fun available(id:Long,quantity:Double,record:BusinessRecord) {
    val item=dao.getInventoryItemById(id) ?: error("Item missing / سامان موجود نہیں")
    require(!item.isServiceItem() && !JSONObject(item.detailsJson).optBoolean("archived") && item.currentStock+0.000001>=quantity && records.locationStock(id,record.branchId,record.warehouseId)+0.000001>=quantity){"Insufficient stock: ${item.name} / اسٹاک کم ہے"}
  }
  private suspend fun cash(id:Long,amount:Double,income:Boolean,title:String,record:BusinessRecord) {
    if(amount==0.0)return
    val account=dao.getAllAccountsList().find {it.id==id} ?: error("Select an account / اکاؤنٹ منتخب کریں")
    dao.changeAccountBalance(id,if(income)amount else -amount)
    dao.insertTransaction(Transaction(title=title,amount=amount,type=if(income)TransactionType.INCOME else TransactionType.EXPENSE,category=record.kind,icon="💵",accountName=account.name,transactionRef="DOC/${record.id}/${java.util.UUID.randomUUID()}"))
  }
  private suspend fun returnMaterial(line:JSONObject,quantity:Double) {
    if(quantity<=0)return
    val item=dao.getInventoryItemById(line.getLong("itemId")) ?: error("Raw material missing / خام مال موجود نہیں")
    val average=(item.currentStock*item.costPrice+quantity*line.getDouble("unitCost"))/(item.currentStock+quantity)
    number(average);dao.updateInventoryItem(item.copy(currentStock=item.currentStock+quantity,costPrice=average,lastUpdatedMillis=System.currentTimeMillis()))
  }
  suspend fun planProduction(reference:String,bomId:String,quantity:Double,branch:String="main",warehouse:String="main",batch:String="",actor:String="owner"):BusinessRecord=db.withTransaction {
    number(quantity,true);unique("PRODUCTION_ORDER",reference);location(branch,warehouse)
    val bom=records.record(bomId) ?: error("Select a recipe / ریسپی منتخب کریں");require(bom.kind=="BOM"&&!bom.archived)
    val source=JSONObject(bom.payload);val output=source.getLong("outputId");require(dao.getInventoryItemById(output)?.let {!it.isServiceItem()&&!JSONObject(it.detailsJson).optBoolean("archived")}==true)
    val ingredients=source.getJSONArray("ingredients");require(ingredients.length()>0)
    for(i in 0 until ingredients.length()){val line=ingredients.getJSONObject(i);number(line.getDouble("quantity"),true);require(line.getLong("itemId")!=output)}
    val order=BusinessRecord(kind="PRODUCTION_ORDER",title=reference.trim(),party=bom.title,status="PLANNED",branchId=branch,warehouseId=warehouse,createdBy=actor,payload=source.put("bomId",bomId).put("plannedQuantity",quantity).put("batch",batch).toString())
    records.insert(order);audit("PRODUCTION_PLANNED",order.id,actor);order
  }
  suspend fun issueProduction(id:String,actor:String="owner")=db.withTransaction {
    val order=records.record(id) ?: error("Order missing");require(order.kind=="PRODUCTION_ORDER"&&order.status=="PLANNED"){"Only planned orders can be issued / صرف منصوبہ شدہ آرڈر جاری ہو سکتا ہے"}
    val data=JSONObject(order.payload);val lines=data.getJSONArray("ingredients");val usage=mutableMapOf<Long,Double>()
    for(i in 0 until lines.length()){val line=lines.getJSONObject(i);val item=line.getLong("itemId");usage[item]=(usage[item] ?: 0.0)+line.getDouble("quantity")*data.getDouble("plannedQuantity")}
    val issued=JSONArray();var cost=0.0
    usage.forEach {(item,qty)->number(qty,true);available(item,qty,order);val unitCost=dao.getInventoryItemById(item)!!.costPrice;number(unitCost);cost+=qty*unitCost;issued.put(JSONObject().put("itemId",item).put("quantity",qty).put("unitCost",unitCost))};number(cost)
    stock(order,"PRODUCTION_ISSUE",actor){usage.forEach {(item,qty)->dao.deductInventoryStock(item,qty)}}
    records.update(order.copy(status="WIP",amount=cost,payload=data.put("issued",issued).put("issuedCost",cost).toString(),updatedAt=System.currentTimeMillis()))
    records.insert(BusinessRecord(kind="RAW_MATERIAL_ISSUE",title=order.title,party=id,amount=cost,status="POSTED",payload=JSONObject().put("lines",issued).toString(),branchId=order.branchId,warehouseId=order.warehouseId,createdBy=actor));audit("PRODUCTION_ISSUED",id,actor)
  }
  suspend fun finishProduction(id:String,output:Double,wastage:Double,additionalCost:Double=0.0,accountId:Long=0,actor:String="owner")=db.withTransaction {
    number(output,true);number(wastage);number(additionalCost)
    val order=records.record(id) ?: error("Order missing");require(order.kind=="PRODUCTION_ORDER"&&order.status=="WIP"){"Issue raw materials first / پہلے خام مال جاری کریں"}
    val data=JSONObject(order.payload);val planned=data.getDouble("plannedQuantity");require(output+wastage<=planned+0.000001){"Output plus wastage exceeds planned quantity / پیداوار اور ضیاع منصوبہ سے زیادہ ہیں"}
    val used=(output+wastage)/planned;val cost=data.getDouble("issuedCost")*used+additionalCost;number(cost)
    val item=dao.getInventoryItemById(data.getLong("outputId")) ?: error("Output item missing")
    val average=(item.currentStock*item.costPrice+cost)/(item.currentStock+output);number(average)
    cash(accountId,additionalCost,false,"Production labour / overhead",order)
    stock(order,"PRODUCTION_OUTPUT",actor){val lines=data.getJSONArray("issued");for(i in 0 until lines.length()){val line=lines.getJSONObject(i);val returned=line.getDouble("quantity")*(1-used);returnMaterial(line,returned)};dao.updateInventoryItem(item.copy(currentStock=item.currentStock+output,costPrice=average,lastUpdatedMillis=System.currentTimeMillis()))}
    val posting=data.put("outputQuantity",output).put("wastage",wastage).put("additionalCost",additionalCost).put("orderId",id)
    records.insert(BusinessRecord(kind="PRODUCTION",title=order.title,party=id,amount=cost,status="POSTED",payload=posting.toString(),branchId=order.branchId,warehouseId=order.warehouseId,createdBy=actor))
    records.update(order.copy(status="COMPLETED",amount=cost,payload=posting.toString(),updatedAt=System.currentTimeMillis()));audit("PRODUCTION_FINISHED",id,actor)
  }
  suspend fun cancelProduction(id:String,actor:String="owner")=db.withTransaction {
    val order=records.record(id) ?: error("Order missing");require(order.kind=="PRODUCTION_ORDER"&&order.status in listOf("PLANNED","WIP"))
    if(order.status=="WIP")stock(order,"PRODUCTION_CANCEL",actor){val lines=JSONObject(order.payload).getJSONArray("issued");for(i in 0 until lines.length()){val line=lines.getJSONObject(i);returnMaterial(line,line.getDouble("quantity"))}}
    records.update(order.copy(status="CANCELLED",updatedAt=System.currentTimeMillis()));audit("PRODUCTION_CANCELLED",id,actor)
  }
  suspend fun bookAppointment(title:String,customerId:Long,staff:String,start:Long,end:Long,fee:Double,branch:String="main",notes:String="",id:String="",actor:String="owner"):BusinessRecord=db.withTransaction {
    require(title.isNotBlank()&&staff.isNotBlank()&&start>0&&end>start){"Enter service, staff and a valid time range / سروس، عملہ اور درست وقت درج کریں"};number(fee);location(branch,"main");val customer=dao.getCustomerById(customerId) ?: error("Select a customer / گاہک منتخب کریں")
    val previous=if(id.isBlank())null else records.record(id) ?: error("Appointment missing")
    if(previous!=null)require(previous.kind=="APPOINTMENT"&&previous.status in listOf("OPEN","BOOKED")){"This appointment can no longer be changed / اپائنٹمنٹ تبدیل نہیں ہو سکتی"}
    require(records.allRecords().none {record->if(record.id==id||record.kind!="APPOINTMENT"||record.status in listOf("CANCELLED","COMPLETED")||record.archived||record.branchId!=branch)false else {val d=JSONObject(record.payload);d.optString("staff").equals(staff.trim(),true)&&start<d.optLong("end")&&end>d.optLong("start")}}){"Staff already booked at this time / اس وقت عملہ پہلے سے بک ہے"}
    val data=JSONObject().put("customerId",customerId).put("staff",staff.trim()).put("start",start).put("end",end).put("notes",notes).put("technician",staff.trim())
    val record=(previous ?: BusinessRecord(kind="APPOINTMENT",title=title.trim())).copy(title=title.trim(),party=customer.name,amount=fee,status="BOOKED",payload=data.toString(),branchId=branch,createdBy=previous?.createdBy ?: actor,updatedAt=System.currentTimeMillis())
    if(previous==null)records.insert(record) else records.update(record);audit(if(previous==null)"APPOINTMENT_BOOKED" else "APPOINTMENT_RESCHEDULED",record.id,actor);record
  }
  suspend fun cancelAppointment(id:String,actor:String="owner")=db.withTransaction {val record=records.record(id) ?: error("Appointment missing");require(record.kind=="APPOINTMENT"&&record.status in listOf("OPEN","BOOKED"));records.update(record.copy(status="CANCELLED",updatedAt=System.currentTimeMillis()));audit("APPOINTMENT_CANCELLED",id,actor)}
  suspend fun issueRental(reference:String,itemId:Long,quantity:Double,customerId:Long,start:Long,due:Long,rate:Double,lateRate:Double,deposit:Double,accountId:Long,branch:String="main",warehouse:String="main",actor:String="owner"):BusinessRecord=db.withTransaction {
    number(quantity,true);number(rate);number(lateRate);number(deposit);require(start>0&&due>start);unique("RENTAL_CONTRACT",reference);location(branch,warehouse)
    val customer=dao.getCustomerById(customerId) ?: error("Select a customer / گاہک منتخب کریں")
    val record=BusinessRecord(kind="RENTAL_CONTRACT",title=reference.trim(),party=customer.name,amount=deposit,status="ACTIVE",branchId=branch,warehouseId=warehouse,createdBy=actor,payload=JSONObject().put("itemId",itemId).put("quantity",quantity).put("customerId",customerId).put("start",start).put("due",due).put("rate",rate).put("lateRate",lateRate).put("deposit",deposit).toString())
    available(itemId,quantity,record);cash(accountId,deposit,true,"Refundable rental deposit",record);stock(record,"RENTAL_ISSUE",actor){dao.deductInventoryStock(itemId,quantity)};records.insert(record)
    records.insert(BusinessRecord(kind="RENTAL_DEPOSIT",title=reference.trim(),party=record.id,amount=deposit,status="POSTED",createdBy=actor));audit("RENTAL_ISSUED",record.id,actor);record
  }
  suspend fun returnRental(id:String,usableQuantity:Double,damageCharge:Double,accountId:Long,returnedAt:Long=System.currentTimeMillis(),actor:String="owner")=db.withTransaction {
    number(usableQuantity);number(damageCharge);val record=records.record(id) ?: error("Rental missing");require(record.kind=="RENTAL_CONTRACT"&&record.status=="ACTIVE"){"Rental already returned / کرایہ پہلے واپس ہو چکا ہے"}
    val d=JSONObject(record.payload);val qty=d.getDouble("quantity");require(usableQuantity<=qty&&returnedAt>=d.getLong("start"))
    val days=ceil((d.getLong("due")-d.getLong("start"))/86400000.0).coerceAtLeast(1.0);val late=ceil((returnedAt-d.getLong("due")).coerceAtLeast(0)/86400000.0)
    val fee=moneyRound(qty*(days*d.getDouble("rate")+late*d.getDouble("lateRate"))+damageCharge);number(fee)
    val deposit=d.getDouble("deposit");val applied=minOf(deposit,fee);val refund=moneyRound(deposit-applied);val customer=dao.getCustomerById(d.getLong("customerId")) ?: error("Customer missing")
    val invoice=FinanceRepository(dao,db).saveInvoiceAtomically(Invoice(invoiceNumber="RENT-${record.id}",customerId=customer.id,customerName=customer.name,subtotal=fee,grandTotal=fee,amountPaid=applied,paymentMethod="Rental deposit",detailsJson=JSONObject().put("rentalId",id).put("branch",record.branchId).put("warehouse",record.warehouseId).toString()),listOf(InvoiceItemEntry(itemName="Rental: ${record.title}",quantity=1.0,unit="job",unitPrice=fee,total=fee,isService=true)),false,existingRentalDepositId=id)
    cash(accountId,refund,false,"Rental deposit refund",record);stock(record,"RENTAL_RETURN",actor){if(usableQuantity>0)dao.addInventoryStock(d.getLong("itemId"),usableQuantity)}
    records.insert(BusinessRecord(kind="RENTAL_DEPOSIT_REFUND",title=record.title,party=id,amount=refund,status="POSTED",createdBy=actor))
    records.update(record.copy(status="CLOSED",amount=fee,payload=d.put("returnedAt",returnedAt).put("usableQuantity",usableQuantity).put("damagedQuantity",qty-usableQuantity).put("damageCharge",damageCharge).put("lateDays",late).put("invoiceId",invoice.id).put("refund",refund).toString(),updatedAt=System.currentTimeMillis()));audit("RENTAL_RETURNED",id,actor)
  }
}
