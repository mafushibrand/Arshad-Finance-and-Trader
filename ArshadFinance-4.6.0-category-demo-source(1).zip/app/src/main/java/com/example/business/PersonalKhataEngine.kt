package com.example.business

import androidx.room.withTransaction
import com.example.data.local.FinanceDatabase
import org.json.JSONObject

/** Separate personal journal: never creates shop invoices, changes stock or business customer balances. */
class PersonalKhataEngine(private val db: FinanceDatabase) {
  suspend fun contact(name: String, phone: String): BusinessRecord = db.withTransaction {
    require(name.trim().isNotEmpty()) { "Enter a name / نام درج کریں" }
    require(db.businessDao().allRecords().none {it.kind=="PERSONAL_CONTACT" && !it.archived && it.title.equals(name.trim(),true)}) { "Name already exists / یہ نام پہلے موجود ہے" }
    val r=BusinessRecord(kind="PERSONAL_CONTACT",title=name.trim(),payload=JSONObject().put("phone",phone.trim()).toString(),branchId="personal",warehouseId="personal")
    db.businessDao().insert(r); r
  }
  suspend fun entry(contactId: String, amount: Double, direction: String, note: String) = db.withTransaction {
    require(amount.isFinite() && amount>0 && amount<=1e12) { "Enter a valid amount / درست رقم درج کریں" }
    require(direction in listOf("GAVE","RECEIVED"))
    val contact=db.businessDao().record(contactId) ?: error("Choose a person / نام منتخب کریں")
    require(contact.kind=="PERSONAL_CONTACT" && !contact.archived)
    val r=BusinessRecord(kind="PERSONAL_ENTRY",title=note.trim().ifBlank {direction},party=contactId,amount=amount,status="POSTED",payload=JSONObject().put("direction",direction).toString(),branchId="personal",warehouseId="personal")
    db.businessDao().insert(r)
    db.businessDao().insert(BusinessRecord(kind="AUDIT",title="PERSONAL_ENTRY",party=r.id,status="RECORDED",branchId="personal",warehouseId="personal"))
  }
  companion object {
    fun balance(records:List<BusinessRecord>,id:String):Double=records.filter {it.kind=="PERSONAL_ENTRY" && it.party==id && !it.archived}.sumOf {if(JSONObject(it.payload).optString("direction")=="GAVE")it.amount else -it.amount}
  }
}
