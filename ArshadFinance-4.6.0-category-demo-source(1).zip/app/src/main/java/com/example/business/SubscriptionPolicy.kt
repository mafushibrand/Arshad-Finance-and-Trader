package com.example.business

import android.util.Base64
import com.example.data.model.SubscriptionState
import org.json.JSONObject
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/** Offline signed entitlement. Online authoritative billing is required for reinstall/root-proof enforcement. */
object SubscriptionPolicy {
  const val DAY = 86_400_000L
  const val MONTHLY = 300
  const val YEARLY = 3000
  const val YEAR_SAVING = 600
  const val YEAR_DISCOUNT = "16.67%"
  private const val PUBLIC_KEY = "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAxURvFpR++2yLLrtm12gmFHpOmG+Xzc2HthW/yKso59OjAVootDVNRs9v+UaL65d1wlu4Hyfi6Q5ofzF41inLENVjD5xJNPohtFEdZ4HxLHTHKRHjjFWxIDshGdmtYMPO9mho0M0P33A9KzOxB1R6eGf1NV+NTwtF/kJMnjW4X3lUi+aqOAWKxMoAeB6J90HJ7ovo32X89dZ80593jF9IdYORzGFURcPLW3kWdg4K5JiRkeTMUY3Bipl7N3oKzvdTgrMDp8d8do5CgQeME476gNhpBcHUFE/1OSEz3n4qbMwo1997SNZcPMyo3FUJICjTQ51Dpa/gYOrmcVtB/v9XFfHJWM48xrU0TH9xa8qKBnOlsOK4zlipyp3mPwKYBjHUrQ507PShr9Lw/nxBf2kqX9Gd26HH0v1cTvrIZKAassfOBeBbiUcKsrj6icqdK2tWRXpFELFj5/vSik2QNwKgjeWrvW2FWJWMye+f5w4ZBONwY8hTBy60ebEQQK2x69sFAgMBAAE="
  fun allowed(s: SubscriptionState, now: Long): Boolean {
    if (s.isSimulatedLocked || s.clockBlocked || now + 300_000L < s.lastSeenMillis) return false
    if (s.isActivated && s.expiryDateMillis > now) return true
    if(s.hasPaidBefore) return false
    return s.trialStartedMillis > 0 && now >= s.trialStartedMillis && now < s.trialStartedMillis + 30 * DAY
  }
  fun remainingDays(s: SubscriptionState, now: Long): Long {
    if(s.hasPaidBefore && !s.isActivated) return 0
    val end = if (s.isActivated) s.expiryDateMillis else if (s.trialStartedMillis > 0) s.trialStartedMillis + 30 * DAY else 0L
    return if (end <= now) 0 else (end - now + DAY - 1) / DAY
  }
  fun signedPayload(token: String): JSONObject {
    val parts = token.trim().split('.')
    require(parts.size == 3 && parts[0] == "AF1" && token.length <= 16000) { "Invalid activation file / ایکٹیویشن فائل درست نہیں" }
    val body = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    val signature = Base64.decode(parts[2], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    val key = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(Base64.decode(PUBLIC_KEY, Base64.DEFAULT)))
    val verifier = Signature.getInstance("SHA256withRSA"); verifier.initVerify(key); verifier.update(body)
    require(verifier.verify(signature)) { "Activation not verified / ایکٹیویشن تصدیق شدہ نہیں" }
    val payload = JSONObject(body.toString(Charsets.UTF_8))
    require(payload.getInt("version") == 1 && payload.getString("app") == "ArshadFinance")
    return payload
  }
  fun activate(s: SubscriptionState, token: String, now: Long): SubscriptionState {
    val p = signedPayload(token)
    require(p.getString("type") == "license" && p.getString("deviceId") == s.deviceId) { "Activation belongs to another device / یہ ایکٹیویشن دوسرے فون کے لیے ہے" }
    val plan = p.getString("plan"); require(plan in listOf("MONTHLY", "YEARLY"))
    require(p.getInt("amount")==if(plan=="YEARLY")YEARLY else MONTHLY)
    val issued = p.getLong("issuedAt"); val expiry = p.getLong("expiresAt")
    require(issued <= now + 300_000L && expiry > now && expiry > issued && expiry - issued <= (if(plan=="MONTHLY")32 else 367) * DAY) { "Activation expired or phone date incorrect / ایکٹیویشن ختم یا فون کی تاریخ غلط ہے" }
    require(now + 300_000L >= s.lastSeenMillis) { "Correct phone date first / پہلے فون کی تاریخ درست کریں" }
    return s.copy(hasPaidBefore = true, isActivated = true, activationCode = token.trim(), expiryDateMillis = expiry, plan = plan, isSimulatedLocked = false, clockBlocked = false, lastSeenMillis = maxOf(now,s.lastSeenMillis))
  }
  fun refresh(s: SubscriptionState, now: Long): SubscriptionState {
    val verified = if (s.activationCode.startsWith("AF1.")) runCatching { activate(s,s.activationCode,now) }.getOrNull() else null
    val retained=runCatching {val p=signedPayload(s.activationCode);require(p.getString("type")=="license" && p.getString("deviceId")==s.deviceId);s.copy(isActivated=false,hasPaidBefore=true,plan=p.getString("plan"),expiryDateMillis=p.getLong("expiresAt"))}.getOrNull()
    return (verified ?: retained ?: s.copy(isActivated=false,activationCode="",plan="",expiryDateMillis=0)).copy(
      policyVersion=2, clockBlocked=now + 300_000L < s.lastSeenMillis, lastSeenMillis=maxOf(now,s.lastSeenMillis))
  }
  fun merchant(token: String): JSONObject {
    val p = signedPayload(token); require(p.getString("type") == "merchant")
    require(p.optString("title").isNotBlank() && p.optString("contact").matches(Regex("[+]?[0-9]{10,15}")))
    require(p.optString("jazzcash").matches(Regex("[+]?[0-9]{10,15}")) || p.optString("meezanIban").matches(Regex("PK[0-9A-Z]{22}"))) { "Receiving account is missing" }
    return p
  }
}
