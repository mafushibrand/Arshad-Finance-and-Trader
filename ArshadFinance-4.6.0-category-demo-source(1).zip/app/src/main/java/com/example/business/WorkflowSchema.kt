package com.example.business

import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.FinanceDatabase
import org.json.JSONObject
import java.util.UUID

@Entity(tableName="stock_context")
data class StockContext(@PrimaryKey val id:Int=1, val reason:String="STOCK_CHANGE",val documentId:String="",val createdBy:String="local",val branchId:String="main",val warehouseId:String="main")

object WorkflowSchema {
  fun install(db:SupportSQLiteDatabase) {
    db.execSQL("CREATE TABLE IF NOT EXISTS stock_context (id INTEGER NOT NULL PRIMARY KEY,reason TEXT NOT NULL,documentId TEXT NOT NULL,createdBy TEXT NOT NULL,branchId TEXT NOT NULL,warehouseId TEXT NOT NULL)")
    db.execSQL("INSERT OR IGNORE INTO stock_context VALUES(1,'STOCK_CHANGE','','local','main','main')")
    listOf("stock_insert","stock_update","stock_delete").forEach {db.execSQL("DROP TRIGGER IF EXISTS $it")}
    fun trigger(name:String,event:String,quantity:String,time:String,item:String,condition:String="") {
      db.execSQL("""CREATE TRIGGER $name AFTER $event ON inventory_items $condition BEGIN
        INSERT INTO stock_movements(id,itemId,quantity,reason,createdAt,createdBy,branchId,warehouseId,documentId)
        VALUES(lower(hex(randomblob(16))),$item,$quantity,
        COALESCE((SELECT reason FROM stock_context WHERE id=1),'STOCK_CHANGE'),$time,
        COALESCE((SELECT createdBy FROM stock_context WHERE id=1),'local'),
        COALESCE((SELECT branchId FROM stock_context WHERE id=1),'main'),
        COALESCE((SELECT warehouseId FROM stock_context WHERE id=1),'main'),
        COALESCE((SELECT documentId FROM stock_context WHERE id=1),'')); END""")
    }
    trigger("stock_insert","INSERT","NEW.currentStock-COALESCE((SELECT SUM(quantity) FROM stock_movements WHERE itemId=NEW.id),0)","NEW.lastUpdatedMillis","NEW.id")
    trigger("stock_update","UPDATE OF currentStock","NEW.currentStock-OLD.currentStock","NEW.lastUpdatedMillis","NEW.id","WHEN NEW.currentStock != OLD.currentStock")
    trigger("stock_delete","DELETE","-OLD.currentStock","CAST(strftime('%s','now') AS INTEGER)*1000","OLD.id")
  }
  val migration=object:androidx.room.migration.Migration(7,8) {
    override fun migrate(db:SupportSQLiteDatabase) {
      db.execSQL("ALTER TABLE stock_movements ADD COLUMN documentId TEXT NOT NULL DEFAULT ''")
      db.execSQL("ALTER TABLE customers ADD COLUMN detailsJson TEXT NOT NULL DEFAULT '{}'")
      db.execSQL("ALTER TABLE invoices ADD COLUMN detailsJson TEXT NOT NULL DEFAULT '{}'")
      db.execSQL("ALTER TABLE transactions ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
      db.execSQL("ALTER TABLE transactions ADD COLUMN createdBy TEXT NOT NULL DEFAULT 'local'")
      db.execSQL("ALTER TABLE transactions ADD COLUMN branchId TEXT NOT NULL DEFAULT 'main'")
      install(db)
      // Preserve balances while establishing an immutable opening and invoice ledger.
      val cols="(id,kind,title,party,amount,status,payload,createdAt,updatedAt,createdBy,branchId,warehouseId,archived)"
      db.execSQL("""INSERT INTO business_records $cols SELECT 'MIG-INVOICE-DEBIT-'||id,'CUSTOMER_DEBIT','Migrated invoice',CAST(customerId AS TEXT),grandTotal,'POSTED','{"source":"migration"}',dateMillis,dateMillis,'migration','main','main',0 FROM invoices WHERE customerId>0 AND grandTotal>0""")
      db.execSQL("""INSERT INTO business_records $cols SELECT 'MIG-INVOICE-CREDIT-'||id,'CUSTOMER_CREDIT','Migrated payment',CAST(customerId AS TEXT),amountPaid,'POSTED','{"source":"migration"}',dateMillis,dateMillis,'migration','main','main',0 FROM invoices WHERE customerId>0 AND amountPaid>0""")
      db.execSQL("""INSERT INTO business_records $cols SELECT 'MIG-OPENING-'||id,CASE WHEN delta>=0 THEN 'CUSTOMER_DEBIT' ELSE 'CUSTOMER_CREDIT' END,'Migrated opening',CAST(id AS TEXT),abs(delta),'POSTED','{"source":"migration"}',createdDateMillis,createdDateMillis,'migration','main','main',0 FROM (SELECT c.*,currentBalance-COALESCE((SELECT SUM(grandTotal-amountPaid) FROM invoices WHERE customerId=c.id),0) AS delta FROM customers c) WHERE abs(delta)>0.000001""")
    }
  }
}

object CustomerLedger {
  suspend fun post(db:FinanceDatabase,customerId:Long,delta:Double,source:String,actor:String="owner") {
    require(delta.isFinite()); if(customerId<=0 || kotlin.math.abs(delta)<0.000001)return
    db.businessDao().insert(BusinessRecord(kind=if(delta>0)"CUSTOMER_DEBIT" else "CUSTOMER_CREDIT",title=source,party=customerId.toString(),amount=kotlin.math.abs(delta),status="POSTED",payload=JSONObject().put("source",source).toString(),createdBy=actor))
  }
  suspend fun balance(db:FinanceDatabase,id:Long)=db.businessDao().allRecords().filter {it.party==id.toString()}.sumOf {if(it.kind=="CUSTOMER_DEBIT")it.amount else if(it.kind=="CUSTOMER_CREDIT")-it.amount else 0.0}
}
