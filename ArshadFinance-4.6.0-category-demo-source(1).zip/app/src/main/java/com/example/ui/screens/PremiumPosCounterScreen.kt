package com.example.ui.screens

import com.example.business.isServiceItem
import com.example.business.saleUnit

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun PosCounterScreen(
  uiState: FinanceUiState,
  onCompleteSale: (Invoice, List<InvoiceItemEntry>, Boolean, (Invoice?) -> Unit) -> Unit,
  onAddNewProduct: () -> Unit,
  onAddToCart: (InventoryItem, Double) -> Unit = { _, _ -> },
  onUpdateCartQty: (Long, Double) -> Unit = { _, _ -> },
  onClearCart: () -> Unit = {},
  modifier: Modifier = Modifier,
  onHoldCart: ((String,(String?)->Unit)->Unit)? = null,
  onResumeCart: ((String,(String?)->Unit)->Unit)? = null
) {
  var advanced by rememberSaveable { mutableStateOf(false) }
  if (advanced) {
    BackHandler { advanced = false }
    Column(modifier.fillMaxSize().background(Cream)) {
      TextButton(onClick = { advanced = false }, modifier = Modifier.padding(horizontal = 16.dp)) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(8.dp)); Text(uiState.word("Back to overview", "خلاصے پر واپس")) }
      LegacyPosCounterScreen(uiState = uiState, onCompleteSale = onCompleteSale, onAddNewProduct = onAddNewProduct, onAddToCart = onAddToCart, onUpdateCartQty = onUpdateCartQty, onClearCart = onClearCart, modifier = Modifier.weight(1f))
    }
    return
  }
  var search by rememberSaveable { mutableStateOf("") }
  var editingQty by remember { mutableStateOf<Pair<Long,String>?>(null) }
  var draftMessage by remember {mutableStateOf("")}
  var draftName by remember {mutableStateOf("")}
  var holdDialog by remember {mutableStateOf(false)}
  var checkout by remember { mutableStateOf(false) }
  var saving by remember { mutableStateOf(false) }
  var saved by remember { mutableStateOf<Invoice?>(null) }
  var tab by rememberSaveable { mutableIntStateOf(0) }
  val catalog = uiState.inventoryItems.filter { (search.isBlank() || it.name.contains(search, true) || it.barcode.contains(search, true)) && (tab != 1 || uiState.cartItems.containsKey(it.id)) }
  PremiumPage(uiState.word("New Sale", "نئی فروخت"), uiState.word("Add items, review and complete your bill", "سامان شامل کریں اور بل مکمل کریں"), Icons.Default.PointOfSale,
    modifier, uiState.word("Add product", "نیا سامان"), onAddNewProduct,
    footer = { Surface(color = Color.White, shadowElevation = 8.dp) { Column(Modifier.padding(16.dp)) {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(uiState.word("Total amount", "کل رقم"), fontWeight = FontWeight.SemiBold); Text(uiState.money(uiState.cartSubtotal), fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Forest) }
      Spacer(Modifier.height(10.dp))
      Button(onClick = { checkout = true }, enabled = uiState.cartItemCount > 0 && !saving, modifier = Modifier.fillMaxWidth().height(54.dp).testTag("pos_checkout_button"), shape = RoundedCornerShape(18.dp)) {
        Icon(Icons.Default.CheckCircleOutline, null); Spacer(Modifier.width(10.dp)); Text(if (saving) uiState.word("Saving…", "محفوظ ہو رہا ہے…") else uiState.word("Complete Sale • ${uiState.cartItemCount} items", "فروخت مکمل کریں • ${uiState.cartItemCount} اشیاء"))
      }
    } } }) {
    item { SearchBox(search, uiState.word("Search product or barcode…", "سامان یا بارکوڈ تلاش کریں…")) { search = it } }
    if(onHoldCart!=null && uiState.cartItems.isNotEmpty()) item { TextButton(onClick={holdDialog=true}) {Text(uiState.word("Hold bill", "بل محفوظ رکھیں"))} }
    if(draftMessage.isNotBlank()) item {Text(draftMessage)}
    if(onResumeCart!=null) items(uiState.businessRecords.filter {it.kind=="POS_DRAFT"&&it.status=="OPEN"},key={it.id}) {draft-> ListTile(draft.title,uiState.word("Held bill • resume at current prices", "محفوظ بل • موجودہ قیمت پر کھولیں"),Icons.Default.PauseCircle,click={onResumeCart(draft.id){draftMessage=it ?: uiState.word("Bill resumed", "بل کھول دیا گیا")}}) }
    item { FilterRow(listOf(uiState.word("Products", "سامان"), uiState.word("Your bill", "آپ کا بل")), tab) { tab = it } }
    if (catalog.isEmpty()) item { EmptyList(uiState.word("No items yet", "ابھی کوئی سامان نہیں"), uiState.word("Add products or add services from your catalog.", "سامان شامل کریں یا کیٹلاگ سے سروس شامل کریں۔"), Icons.Default.ShoppingBasket) }
    items(catalog, key = { it.id }) { product ->
      val qty = uiState.cartItems[product.id] ?: 0.0
      ListTile(product.name, if (product.isServiceItem()) uiState.word("Service", "سروس") else "${product.currentStock} ${product.unit} • ${product.category}", Icons.Default.ShoppingBasket, uiState.money(product.salePrice), click = { if (product.currentStock > 0 || product.isServiceItem()) onAddToCart(product, 1.0) }) {
        if (qty > 0) {
          IconButton(onClick = { onUpdateCartQty(product.id, qty - 1.0) }) { Icon(Icons.Default.RemoveCircleOutline, uiState.word("Reduce quantity", "مقدار کم کریں")) }
          TextButton(onClick={editingQty=product.id to qty.toString()}) { Text("$qty ${product.saleUnit()}", fontWeight = FontWeight.Bold) }
          IconButton(onClick = { onUpdateCartQty(product.id, qty + 1.0) }) { Icon(Icons.Default.AddCircleOutline, uiState.word("Increase quantity", "مقدار بڑھائیں")) }
          Text(uiState.money(product.salePrice * qty), fontWeight = FontWeight.SemiBold)
        } else TextButton(onClick = { onAddToCart(product, 1.0) }, enabled = product.currentStock > 0 || product.isServiceItem()) { Icon(Icons.Default.Add, null); Text(uiState.word("Add", "شامل کریں")) }
      }
    }
    if (uiState.cartItemCount > 0) item { TextButton(onClick = onClearCart, modifier = Modifier.fillMaxWidth()) { Text(uiState.word("Clear bill", "بل خالی کریں")) } }
    item { AdvancedButton(uiState) { advanced = true } }
  }
  if(holdDialog) AlertDialog(onDismissRequest={holdDialog=false},title={Text(uiState.word("Hold bill","بل محفوظ رکھیں"))},text={com.example.ui.dialogs.BusinessField(draftName,uiState.word("Bill name / customer","بل نام / گاہک")){draftName=it}},confirmButton={TextButton(onClick={onHoldCart?.invoke(draftName){draftMessage=it ?: uiState.word("Bill held","بل محفوظ ہے");if(it==null)holdDialog=false}}){Text(uiState.word("Hold","محفوظ"))}},dismissButton={TextButton(onClick={holdDialog=false}){Text(uiState.word("Cancel","منسوخ"))}})
  editingQty?.let { (id,value) -> AlertDialog(onDismissRequest={editingQty=null},title={Text(uiState.word("Quantity / weight", "مقدار / وزن"))},text={com.example.ui.dialogs.BusinessField(value,uiState.word("Decimal quantities allowed","اعشاریہ مقدار درج کر سکتے ہیں"),true){editingQty=id to it}},confirmButton={TextButton(onClick={val q=value.toDoubleOrNull(); if(q!=null&&q.isFinite()&&q>=0){onUpdateCartQty(id,q);editingQty=null}}){Text(uiState.word("Apply","محفوظ"))}},dismissButton={TextButton(onClick={editingQty=null}){Text(uiState.word("Cancel","منسوخ"))}}) }
  if (checkout) PremiumCheckout(uiState,
    { invoice, entries, sync -> checkout = false; saving = true; onCompleteSale(invoice, entries, sync) { result -> saving = false; if (result != null) { onClearCart(); saved = result } } }, { checkout = false })
  saved?.let { ThermalSlipDialog(it, uiState.businessProfile, uiState.currencySymbol, { saved = null }) }
}
