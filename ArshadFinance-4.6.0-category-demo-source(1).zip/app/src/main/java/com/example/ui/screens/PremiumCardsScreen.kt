package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun CardsScreen(
  uiState: FinanceUiState,
  onAddAccountClick: () -> Unit,
  onDeleteAccount: (Account) -> Unit,
  onSendClick: (Account?) -> Unit = {},
  onReceiveClick: (Account?) -> Unit = {},
  onOpenSettings: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  var advanced by rememberSaveable { mutableStateOf(false) }
  if (advanced) {
    BackHandler { advanced = false }
    Column(modifier.fillMaxSize().background(Cream)) {
      TextButton(onClick = { advanced = false }, modifier = Modifier.padding(horizontal = 16.dp)) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(8.dp)); Text(uiState.word("Back to overview", "خلاصے پر واپس")) }
      LegacyCardsScreen(uiState = uiState, onAddAccountClick = onAddAccountClick, onDeleteAccount = onDeleteAccount, onSendClick = onSendClick, onReceiveClick = onReceiveClick, onOpenSettings = onOpenSettings, modifier = Modifier.weight(1f))
    }
    return
  }
  PremiumPage(uiState.word("Cash & accounts", "کیش اور اکاؤنٹس"), uiState.word("Keep every payment in one place", "ہر ادائیگی کا حساب ایک جگہ"), Icons.Default.AccountBalanceWallet,
    modifier, uiState.word("Add account", "نیا اکاؤنٹ"), onAddAccountClick, footer = {
      Column(Modifier.padding(16.dp)) { PremiumButton(uiState.word("Add account", "نیا اکاؤنٹ شامل کریں"), onAddAccountClick) }
    }) {
    item { Metric(uiState.word("Available balance", "دستیاب بیلنس"), uiState.money(uiState.totalBalance)) }
    items(uiState.accounts, key = { it.id }) { account -> ListTile(account.name, account.accountType, Icons.Default.AccountBalanceWallet, uiState.money(account.balance), Mint, onOpenSettings) {
      TextButton(onClick = { onReceiveClick(account) }) { Icon(Icons.Default.SouthWest, null); Text(uiState.word("Receive", "وصول کریں")) }
      if (uiState.features.expenses) TextButton(onClick = { onSendClick(account) }) { Icon(Icons.Default.NorthEast, null); Text(uiState.word("Pay / expense", "ادائیگی / خرچ")) }
    } }
    item { AdvancedButton(uiState) { advanced = true } }
  }
}
