package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun SettingsScreen(
  uiState: FinanceUiState,
  onOpenShopProfile: () -> Unit,
  onOpenShopAccounts: () -> Unit,
  onAddAccountClick: () -> Unit = {},
  onOpenIndustryCatalog: () -> Unit,
  onLoadDemoData: () -> Unit,
  onResetData: () -> Unit,
  onSwitchRole: () -> Unit = {},
  onOpenEmployeePermissions: () -> Unit = {},
  onOpenTrialActivation: () -> Unit = {},
  onToggleSimulateLock: () -> Unit = {},
  onSelectAppMode: (AppMode) -> Unit = {},
  onToggleLanguage: () -> Unit = {},
  onOpenPendingScreenshots: () -> Unit = {},
  onExportStock: () -> Unit = {},
  onImportStock: () -> Unit = {},
  onOpenAuthDialog: () -> Unit = {},
  onToggleFbrTaxMode: () -> Unit = {},
  onOpenFbrTaxReport: () -> Unit = {},
  onOpenModeSelection: () -> Unit = {},
  onLogout: () -> Unit = {},
  onSelectBusinessCategory: (com.example.ui.components.BusinessCategoryItem) -> Unit = {},
  onOpenBackup: () -> Unit = {},
  onOpenBusinessBuilder: () -> Unit = {},
  onOpenFeatureToggles: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  var advanced by rememberSaveable { mutableStateOf(false) }
  if (advanced) {
    BackHandler { advanced = false }
    Column(modifier.fillMaxSize()) {
      TextButton(onClick = { advanced = false }) { Text(uiState.word("Back to Settings", "سیٹنگز پر واپس")) }
      LegacySettingsScreen(uiState = uiState, onOpenShopProfile = onOpenShopProfile, onOpenShopAccounts = onOpenShopAccounts, onAddAccountClick = onAddAccountClick, onOpenIndustryCatalog = onOpenIndustryCatalog, onLoadDemoData = onLoadDemoData, onResetData = onResetData, onSwitchRole = onSwitchRole, onOpenEmployeePermissions = onOpenEmployeePermissions, onOpenTrialActivation = onOpenTrialActivation, onToggleSimulateLock = onToggleSimulateLock, onSelectAppMode = onSelectAppMode, onToggleLanguage = onToggleLanguage, onOpenPendingScreenshots = onOpenPendingScreenshots, onExportStock = onExportStock, onImportStock = onImportStock, onOpenAuthDialog = onOpenAuthDialog, onToggleFbrTaxMode = onToggleFbrTaxMode, onOpenFbrTaxReport = onOpenFbrTaxReport, onOpenModeSelection = onOpenModeSelection, onLogout = onLogout, onSelectBusinessCategory = onSelectBusinessCategory, modifier = Modifier.weight(1f))
    }
    return
  }
  PremiumPage(uiState.word("Settings", "ترتیبات"), uiState.word("Make this business truly yours", "اپنا کاروبار اپنی ضرورت کے مطابق بنائیں"), Icons.Default.Settings, modifier) {
    item { com.example.ui.components.SubscriptionAccessCard(uiState.subscriptionState, uiState.appLanguage, onOpenTrialActivation) }
    item { Metric(uiState.businessProfile.businessName, uiState.word("Your business workspace", "آپ کا کاروباری مرکز")) }
    item { ListTile(uiState.word("Business Builder", "اپنا کاروبار بنائیں"), uiState.word("Name, industry, currency & modules", "نام، کاروبار، کرنسی اور فیچرز"), Icons.Default.Storefront, click = onOpenBusinessBuilder) }
    item { ListTile(uiState.word("Business profile", "کاروبار کی تفصیل"), uiState.word("Logo, contact, invoice & payment details", "لوگو، رابطہ، بل اور ادائیگی کی تفصیل"), Icons.Default.Badge, click = onOpenShopProfile) }
    item { ListTile(uiState.word("Currency & language", "کرنسی اور زبان"), uiState.currencySymbol + " • " + if (uiState.appLanguage == AppLanguage.URDU) "اردو → English" else "English → اردو", Icons.Default.Language, click = onToggleLanguage) }
    item { ListTile(uiState.word("Enable / Disable Features", "فیچرز منتخب کریں"), uiState.word("Show only what your business needs", "اپنے کاروبار کے ضروری فیچرز منتخب کریں"), Icons.Default.ToggleOn, click = onOpenFeatureToggles) }
    if (uiState.features.onlinePayments) item { ListTile(uiState.word("Online payment receipts", "آن لائن ادائیگی کی رسیدیں"), uiState.word("${uiState.pendingScreenshotInvoices.size} awaiting review", "${uiState.pendingScreenshotInvoices.size} منظوری کی منتظر"), Icons.Default.Image, tint = Color(0xFFE7F2FC), click = onOpenPendingScreenshots) }
    item { ListTile(uiState.word("Cash & payment accounts", "کیش اور ادائیگی کے اکاؤنٹس"), uiState.word("Manage your wallets and bank accounts", "اپنے والٹ اور بینک اکاؤنٹس کا انتظام"), Icons.Default.AccountBalanceWallet, click = onOpenShopAccounts) }
    item { Text(uiState.word("Data & team", "ڈیٹا اور ٹیم"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
    item { ListTile(uiState.word("Backup & Data", "بیک اپ اور ڈیٹا"), uiState.word("Encrypted full backup & restore", "مکمل بیک اپ اور بحالی"), Icons.Default.Backup, click = onOpenBackup) }
    item { ListTile(uiState.word("Export stock", "اسٹاک ایکسپورٹ"), uiState.word("Save your inventory file", "اسٹاک کی فائل محفوظ کریں"), Icons.Default.FileDownload, click = onExportStock) }
    item { ListTile(uiState.word("Import stock", "اسٹاک امپورٹ"), uiState.word("Review and import your inventory", "اسٹاک کی فائل امپورٹ کریں"), Icons.Default.FileUpload, click = onImportStock) }
    item { ListTile(uiState.word("Staff & permissions", "اسٹاف اور اختیارات"), uiState.word("Control employee access", "ملازمین کی رسائی کا انتظام"), Icons.Default.AdminPanelSettings, tint = Color(0xFFECE8FF), click = onOpenEmployeePermissions) }
    item { ListTile(uiState.word("Business type", "کاروبار کی قسم"), uiState.word("Retail, services or personal khata", "دکان، سروسز یا ذاتی کھاتہ"), Icons.Default.Category, click = onOpenModeSelection) }
    item { ListTile(uiState.word("Detailed settings", "تفصیلی ترتیبات"), uiState.word("Tax, printer, catalog & existing tools", "ٹیکس، پرنٹر، کیٹلاگ اور موجودہ ٹولز"), Icons.Default.Tune, tint = Peach, click = { advanced = true }) }
    item { OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Logout, null); Spacer(Modifier.width(8.dp)); Text(uiState.word("Sign out", "لاگ آؤٹ")) } }
  }
}
