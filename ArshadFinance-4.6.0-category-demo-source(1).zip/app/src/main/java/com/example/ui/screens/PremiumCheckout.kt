package com.example.ui.screens

import com.example.business.saleFactor
import com.example.business.isServiceItem

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.BusinessPreferences
import com.example.data.model.*
import com.example.ui.FinanceUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PremiumCheckout(state: FinanceUiState, confirm: (Invoice, List<InvoiceItemEntry>, Boolean) -> Unit, dismiss: () -> Unit) {
  val context = androidx.compose.ui.platform.LocalContext.current
  var customer by remember { mutableStateOf<Customer?>(null) }
  var name by remember { mutableStateOf("") }
  var phone by remember { mutableStateOf("") }
  var dropdown by remember { mutableStateOf(false) }
  var mode by remember { mutableStateOf("Cash") }
  var method by remember { mutableStateOf("JazzCash") }
  var cash by remember { mutableStateOf("") }
  var online by remember { mutableStateOf("") }
  var discount by remember { mutableStateOf("0") }
  var tax by remember { mutableStateOf(state.isFbrTaxMode) }
  var receipt by remember { mutableStateOf("") }
  var copying by remember { mutableStateOf(false) }
  var branch by remember {mutableStateOf("main")};var warehouse by remember {mutableStateOf("main")}
  var error by remember { mutableStateOf("") }
  val scope = rememberCoroutineScope()
  val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
    if (uri != null) scope.launch {
      copying = true
      try {
        receipt = withContext(Dispatchers.IO) {
          val folder = File(context.filesDir, "payment-receipts").apply { mkdirs() }
          val file = File(folder, "receipt-${java.util.UUID.randomUUID()}.image")
          try {
            context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { output ->
              val buffer = ByteArray(8192); var size = 0
              while (true) { val read = input.read(buffer); if (read < 0) break; size += read; require(size <= 10 * 1024 * 1024) { "Image must be under 10 MB" }; output.write(buffer, 0, read) }
              require(size > 0)
            } } ?: error("Could not open image")
            require(android.graphics.BitmapFactory.decodeFile(file.absolutePath) != null) { "Invalid image" }
            android.net.Uri.fromFile(file).toString()
          } catch (e: Exception) { file.delete(); throw e }
        }
      } catch (e: Exception) { error = state.word("Could not save screenshot", "اسکرین شاٹ محفوظ نہیں ہوا") }
      finally { copying = false }
    }
  }
  val cut = discount.toDoubleOrNull() ?: 0.0
  val subtotal = state.cartSubtotal
  val taxRate = state.businessProfile.fbrTaxRatePercent / 100.0
  val taxAmount = if (tax) (subtotal - cut).coerceAtLeast(0.0) * taxRate else 0.0
  val total = (subtotal - cut).coerceAtLeast(0.0) + taxAmount
  val cashPaid = if (mode == "Cash") total else if (mode == "Split") cash.toDoubleOrNull() ?: 0.0 else 0.0
  val onlinePaid = if (mode == "Online") total else if (mode == "Split") online.toDoubleOrNull() ?: 0.0 else 0.0
  val paid = cashPaid + onlinePaid
  androidx.compose.ui.window.Dialog(onDismissRequest = dismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
    Scaffold(topBar = { TopAppBar(title = { Text(state.word("Complete Sale", "فروخت مکمل کریں")) }, navigationIcon = { IconButton(onClick = dismiss) { Icon(Icons.Default.Close, state.word("Close", "بند کریں")) } }) },
      bottomBar = { Surface { Column(Modifier.padding(16.dp)) {
        Text(state.word("Total: ", "کل رقم: ") + state.money(total), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        Button(enabled = !copying && state.cartItems.isNotEmpty(), onClick = {
          val valid = cut.isFinite() && cut >= 0 && cut <= subtotal && cashPaid.isFinite() && cashPaid >= 0 && onlinePaid.isFinite() && onlinePaid >= 0 && paid <= total + 0.001
          if (!valid) { error = state.word("Check discount and payment amounts", "رعایت اور ادائیگی کی رقم درست کریں"); return@Button }
          if (paid < total && name.isBlank() && customer == null) { error = state.word("Select a customer for khata", "کھاتے کے لیے گاہک منتخب کریں"); return@Button }
          val number = "${state.businessProfile.invoicePrefix}-${System.currentTimeMillis()}"
          val entries = state.cartItems.mapNotNull { (id, qty) -> state.inventoryItems.find { it.id == id }?.let { item -> InvoiceItemEntry(itemId = id, itemName = item.name, category = item.category, quantity = qty * item.saleFactor(), unit = item.unit, unitPrice = item.salePrice / item.saleFactor(), total = item.salePrice * qty, isService = item.isServiceItem()) } }
          val pending = onlinePaid > 0 && receipt.isNotBlank()
          if (pending) {
            val preferences = BusinessPreferences(context)
            preferences.write("receipt/$number", receipt)
            preferences.write("pendingAmount/$number", paid)
            preferences.write("pendingCash/$number", cashPaid)
          }
          confirm(Invoice(invoiceNumber = number, customerId = customer?.id ?: 0, customerName = customer?.name ?: name.ifBlank { "Walk-in Customer" }, customerPhone = customer?.phone ?: phone,
            customerAddress = customer?.address ?: "", subtotal = subtotal, discountAmount = cut, taxAmount = taxAmount, grandTotal = total,
            amountPaid = paid, remainingBalance = (total - paid).coerceAtLeast(0.0),
            paymentMethod = when (mode) { "Split" -> "Split [Cash=$cashPaid;$method=$onlinePaid]"; "Online" -> method; "Udhar" -> "Udhar"; else -> "Cash" },
            paymentStatus = if (pending) "PENDING_APPROVAL" else if (paid >= total) "PAID" else if (paid > 0) "PARTIAL" else "UNPAID / UDHAR",
            itemsJson = InvoiceItemEntry.toJsonString(entries), businessName = state.businessProfile.businessName, businessPhone = state.businessProfile.phone, businessAddress = state.businessProfile.address,
            detailsJson=org.json.JSONObject().put("branch",branch).put("warehouse",warehouse).toString(),
            note = if (pending) "Online screenshot awaiting owner verification" else "POS sale"), entries, true)
        }, modifier = Modifier.fillMaxWidth().height(54.dp)) { Icon(Icons.Default.CheckCircleOutline, null); Spacer(Modifier.width(8.dp)); Text(state.word("Save & open receipt", "محفوظ کریں اور رسید کھولیں")) }
      } } }) { padding ->
      Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        LocationChoices(state,branch,warehouse,{branch=it},{warehouse=it})
        Metric(state.word("Bill amount", "بل کی رقم"), state.money(subtotal))
        Text(state.word("Customer", "گاہک"), style = MaterialTheme.typography.titleMedium)
        Box {
          OutlinedButton(onClick = { dropdown = true }, modifier = Modifier.fillMaxWidth()) { Text(customer?.name ?: state.word("Walk-in / Select customer", "عام گاہک / گاہک منتخب کریں")); Icon(Icons.Default.ExpandMore, null) }
          DropdownMenu(expanded = dropdown, onDismissRequest = { dropdown = false }) {
            DropdownMenuItem(text = { Text(state.word("Walk-in customer", "عام گاہک")) }, onClick = { customer = null; name = ""; phone = ""; dropdown = false })
            state.customers.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { customer = c; name = c.name; phone = c.phone; dropdown = false }) }
          }
        }
        if (customer == null) {
          OutlinedTextField(name, { name = it }, label = { Text(state.word("Customer name (required for khata)", "گاہک کا نام (کھاتے کے لیے ضروری)")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          OutlinedTextField(phone, { phone = it }, label = { Text(state.word("Phone (optional)", "فون (اختیاری)")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        Text(state.word("Payment", "ادائیگی"), style = MaterialTheme.typography.titleMedium)
        val modes = if (state.features.onlinePayments) listOf("Cash", "Online", "Udhar", "Split") else listOf("Cash", "Udhar")
        FilterRow(modes.map { when (it) { "Cash" -> state.word("Cash", "نقد"); "Online" -> state.word("Online", "آن لائن"); "Udhar" -> state.word("Khata", "کھاتہ"); else -> state.word("Split", "مکس") } }, modes.indexOf(mode).coerceAtLeast(0)) { mode = modes[it] }
        if (mode == "Online" || mode == "Split") {
          FilterRow(listOf("JazzCash", "EasyPaisa", "Bank", "Raast"), listOf("JazzCash", "EasyPaisa", "Bank", "Raast").indexOf(method)) { method = listOf("JazzCash", "EasyPaisa", "Bank", "Raast")[it] }
          if (mode == "Split") {
            OutlinedTextField(cash, { cash = it }, label = { Text(state.word("Cash received", "وصول شدہ نقد")) }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            OutlinedTextField(online, { online = it }, label = { Text(state.word("Online amount", "آن لائن رقم")) }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
          }
          OutlinedButton(onClick = { picker.launch("image/*") }, enabled = !copying, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text(state.word("Upload Payment Screenshot", "ادائیگی کا اسکرین شاٹ اپلوڈ کریں")) }
          if (receipt.isNotBlank()) {
            AsyncImage(receipt, state.word("Payment screenshot", "ادائیگی کی تصویر"), Modifier.fillMaxWidth().height(180.dp))
            TextButton(onClick = { receipt = "" }) { Text(state.word("Remove screenshot", "تصویر ہٹائیں")) }
            Text(state.word("Screenshot payments stay pending until the owner approves them.", "اسکرین شاٹ والی ادائیگی مالک کی تصدیق تک زیرِ منظوری رہے گی۔"), style = MaterialTheme.typography.bodySmall)
          }
        }
        OutlinedTextField(discount, { discount = it }, label = { Text(state.word("Discount amount", "رعایت کی رقم")) }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Row { Text(state.word("Sales tax (${state.businessProfile.fbrTaxRatePercent}%)", "سیلز ٹیکس (${state.businessProfile.fbrTaxRatePercent}%)"), Modifier.weight(1f)); Switch(tax, { tax = it }) }
        if (tax) Text(state.word("Tax amount: ", "ٹیکس کی رقم: ") + state.money(taxAmount))
        Text(state.word("Remaining khata: ", "کھاتے کی بقایا رقم: ") + state.money((total - paid).coerceAtLeast(0.0)))
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
      }
    }
  }
}
