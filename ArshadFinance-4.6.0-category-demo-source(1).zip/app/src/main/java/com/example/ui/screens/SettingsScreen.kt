package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.AppMode
import com.example.data.model.UserRole
import com.example.ui.FinanceUiState
import com.example.ui.theme.ExpenseRed

@Composable
fun LegacySettingsScreen(
  uiState: FinanceUiState,
  onOpenShopProfile: () -> Unit,
  onOpenShopAccounts: () -> Unit,
  onAddAccountClick: () -> Unit = {},
  onOpenIndustryCatalog: () -> Unit,
  onLoadDemoData: () -> Unit,
  onResetData: () -> Unit,
  onSwitchRole: () -> Unit = {},
  onOpenEmployeePermissions: () -> Unit = {},
  onOpenTrialActivation: () -> Unit = {},
  onToggleSimulateLock: () -> Unit = {},
  onSelectAppMode: (AppMode) -> Unit = {},
  onToggleLanguage: () -> Unit = {},
  onOpenPendingScreenshots: () -> Unit = {},
  onExportStock: () -> Unit = {},
  onImportStock: () -> Unit = {},
  onOpenAuthDialog: () -> Unit = {},
  onToggleFbrTaxMode: () -> Unit = {},
  onOpenFbrTaxReport: () -> Unit = {},
  onOpenModeSelection: () -> Unit = {},
  onLogout: () -> Unit = {},
  onSelectBusinessCategory: (com.example.ui.components.BusinessCategoryItem) -> Unit = {},
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val isUrdu = uiState.appLanguage == AppLanguage.URDU
  val profile = uiState.businessProfile
  val subscription = uiState.subscriptionState
  var showResetDialog by remember { mutableStateOf(false) }
  var showApkDownloadGuideDialog by remember { mutableStateOf(false) }

  if (showApkDownloadGuideDialog) {
    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
    AlertDialog(
      onDismissRequest = { showApkDownloadGuideDialog = false },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text("📥", fontSize = 22.sp)
          Spacer(modifier = Modifier.width(8.dp))
          Text(if (isUrdu) "تازہ ترین APK ڈاؤنلوڈ (ورژن 3.3.0)" else "Download Latest Version APK (v3.3.0)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
      },
      text = {
        Column {
          Text(
            text = "تازہ ترین APK ڈاؤنلوڈ کرنے کے 2 آسان طریقے:",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = Color(0xFF0F172A)
          )
          Spacer(modifier = Modifier.height(8.dp))
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFE5F3EA),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBEDBC8)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = "طریقہ نمبر 1 (براہ راست AI Studio مینیو سے):",
                fontWeight = FontWeight.Bold,
                fontSize = 11.5.sp,
                color = Color(0xFF006C45)
              )
              Text(
                text = "اسکرین کے اوپر دائیں کونے میں تھری ڈاٹس (⋮) یا Settings مینیو دبائیں، اور 'Download APK' یا 'Export ZIP' منتخب کریں۔",
                fontSize = 11.sp,
                color = Color(0xFF006C45),
                lineHeight = 15.sp
              )
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF0FDF4),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = "طریقہ نمبر 2 (لائیو کلاؤڈ ویب لنک):",
                fontWeight = FontWeight.Bold,
                fontSize = 11.5.sp,
                color = Color(0xFF166534)
              )
              Text(
                text = "https://ais-pre-7sa2hnvnrl37a37rlup4rw-584336949178.asia-east1.run.app",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF15803D)
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val clip = android.content.ClipData.newPlainText("App URL", "https://ais-pre-7sa2hnvnrl37a37rlup4rw-584336949178.asia-east1.run.app")
            clipboard?.setPrimaryClip(clip)
            Toast.makeText(context, "لائیو ایپ لنک کاپی ہو گیا! ✓", Toast.LENGTH_SHORT).show()
            showApkDownloadGuideDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D))
        ) {
          Text("کاپی لنک (Copy Link)")
        }
      },
      dismissButton = {
        TextButton(onClick = { showApkDownloadGuideDialog = false }) {
          Text("بند کریں (Close)")
        }
      }
    )
  }

  if (showResetDialog) {
    AlertDialog(
      onDismissRequest = { showResetDialog = false },
      title = { Text("Factory Reset All App Data?") },
      text = { Text("Are you sure you want to permanently clear all transactions, bills, accounts, and inventory boxes? This cannot be undone.") },
      confirmButton = {
        Button(
          onClick = {
            showResetDialog = false
            onResetData()
            Toast.makeText(context, "All local data wiped successfully!", Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
        ) {
          Text("Yes, Wipe All Data")
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
      }
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFFF5F7F2))
      .padding(horizontal = 16.dp),
    contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 6.dp, bottom = 100.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item { Spacer(modifier = Modifier.height(6.dp)) }

    // 0. User Account, Cloud Sync & Device Recovery Card
    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onOpenAuthDialog() }
          .testTag("auth_account_settings_card")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Box(
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Color(0xFF086B4D)),
              contentAlignment = Alignment.Center
            ) {
              Text(text = "☁️", fontSize = 22.sp)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Cloud Sync & Recovery",
                  fontSize = 14.5.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = Color(0xFF10B981)
                ) {
                  Text(
                    text = "ACTIVE",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                  )
                }
              }
              Text(
                text = "Mobile: ${uiState.userAccount.mobileNumber} • Region: ${uiState.userAccount.lastLoginRegion}",
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
              )
              Text(
                text = "موبائل تبدیل یا گم ہونے پر 100% کلاؤڈ ڈیٹا بحال کریں",
                fontSize = 10.5.sp,
                color = Color(0xFF818CF8)
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF086B4D)
          ) {
            Text(
              text = "LOGIN / SYNC",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )
          }
        }
      }
    }

    // 1. Shop Profile Summary Card
    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF086B4D)),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onOpenShopProfile() }
          .testTag("shop_profile_summary_card")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
          ) {
            Box(
              modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(Color.White),
              contentAlignment = Alignment.Center
            ) {
              Text(text = profile.logoEmoji.ifBlank { "🏪" }, fontSize = 28.sp)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = profile.businessName.ifBlank { "Arshad Finance & Traders" },
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = "Owner: ${profile.ownerName.ifBlank { "Muhammad Arshad" }}",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.9f)
              )
              if (profile.phone.isNotBlank()) {
                Text(
                  text = "📞 ${profile.phone}",
                  fontSize = 11.sp,
                  color = Color.White.copy(alpha = 0.8f)
                )
              }
            }
          }

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.White.copy(alpha = 0.2f)
          ) {
            Text(
              text = "EDIT",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }
        }
      }
    }

    // 2. CRITICAL SECTION: Shop Payment Accounts & Digital Wallets (JazzCash, EasyPaisa, Bank)
    item {
      Text(
        text = "SHOP PAYMENT & BANK ACCOUNTS (دکان کے بینک و والٹ اکاؤنٹس)",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF64748B),
        letterSpacing = 0.8.sp
      )
    }

    // Direct Prominent Action: "+ Add New Shop Account / Wallet"
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(
            Brush.horizontalGradient(
              colors = listOf(
                Color(0xFF086B4D),
                Color(0xFF13865F),
                Color(0xFF059669)
              )
            )
          )
          .clickable { onAddAccountClick() }
          .testTag("btn_add_shop_account_settings")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = Color.White,
              modifier = Modifier.size(38.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.Add,
                  contentDescription = null,
                  tint = Color(0xFF086B4D),
                  modifier = Modifier.size(22.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "+ Add New Shop Account / Wallet",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = "نیا بینک، والٹ یا کیش دراز اکاؤنٹ شامل کریں",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.9f)
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.White.copy(alpha = 0.25f)
          ) {
            Text(
              text = "+ نیا کھاتہ",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }
    }

    // Carousel of Configured Accounts
    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(uiState.accounts) { acc ->
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.width(190.dp)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = Color(acc.colorHex).copy(alpha = 0.12f)
                ) {
                  Text(
                    text = acc.accountType,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(acc.colorHex),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
                Text(text = "💳", fontSize = 14.sp)
              }

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = acc.name,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A),
                maxLines = 1
              )

              Text(
                text = "${uiState.currencySymbol} ${"%,.0f".format(acc.balance)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF059669)
              )

              Spacer(modifier = Modifier.height(2.dp))

              Text(
                text = acc.accountNumber,
                fontSize = 10.sp,
                color = Color(0xFF94A3B8)
              )
            }
          }
        }

        item {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFFE5F3EA),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF99C9AB)),
            modifier = Modifier
              .width(120.dp)
              .height(98.dp)
              .clickable { onAddAccountClick() }
          ) {
            Column(
              modifier = Modifier.fillMaxSize().padding(10.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center
            ) {
              Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color(0xFF086B4D), modifier = Modifier.size(22.dp))
              Spacer(modifier = Modifier.height(4.dp))
              Text(text = "+ نیا اکاؤنٹ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF086B4D))
            }
          }
        }
      }
    }

    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF10B981).copy(alpha = 0.12f),
                modifier = Modifier.size(38.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.AccountBalance,
                    contentDescription = null,
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "Receiving Bank & Wallets",
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = Color(0xFF0F172A)
                )
                Text(
                  text = "جاز کیش، ایزی پیسہ و بینک کی تفصیلات",
                  fontSize = 11.sp,
                  color = Color(0xFF64748B)
                )
              }
            }

            Button(
              onClick = onOpenShopAccounts,
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D))
            ) {
              Text(text = "Change (تبدیل کریں)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Display Current Configured Accounts
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFFF5F7F2),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              // JazzCash Row
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(text = "🔴", fontSize = 12.sp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = "JazzCash:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF334155))
                }
                Text(
                  text = profile.jazzCashNumber.ifBlank { "0302-7761415" },
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF0F172A)
                )
              }

              Spacer(modifier = Modifier.height(6.dp))

              // Easypaisa Row
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(text = "🟢", fontSize = 12.sp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = "Easypaisa:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF334155))
                }
                Text(
                  text = profile.easyPaisaNumber.ifBlank { "0345-9876543" },
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF0F172A)
                )
              }

              Spacer(modifier = Modifier.height(6.dp))

              // SadaPay / NayaPay Row
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(text = "📱", fontSize = 12.sp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = "SadaPay / Raast:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF334155))
                }
                Text(
                  text = profile.sadaPayNumber.ifBlank { "0302-7761415" },
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF0F172A)
                )
              }

              Spacer(modifier = Modifier.height(6.dp))

              // Bank Account Row
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(text = "🏦", fontSize = 12.sp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = profile.bankName.ifBlank { "Meezan Bank" } + ":", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF334155))
                }
                Text(
                  text = profile.bankAccountNumber.ifBlank { "01020304050607" },
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF0F172A)
                )
              }
            }
          }
        }
      }
    }

    // 3. STEP 1: Local Auth & Owner/Employee Multi-Role Access Control
    item {
      Text(
        text = "ROLES & EMPLOYEE ACCESS CONTROL (مالک و ملازم کنٹرول)",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF64748B),
        letterSpacing = 0.8.sp
      )
    }

    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          SettingsMenuItem(
            icon = Icons.Default.SwitchAccount,
            iconTint = Color(0xFF086B4D),
            title = "Active User Role: ${if (uiState.userRole == UserRole.OWNER) "OWNER (مالک)" else "EMPLOYEE (ملازم)"}",
            subtitle = if (uiState.userRole == UserRole.OWNER) "Full access to profits, reset, and controls" else "Restricted to Billing Cart & POS only",
            onClick = onSwitchRole
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.AdminPanelSettings,
            iconTint = Color(0xFF8B5CF6),
            title = "Employee Master Toggle Panel",
            subtitle = "Control permissions: Add Products, Discounts, Profits visibility",
            onClick = onOpenEmployeePermissions
          )
        }
      }
    }

    // Best For All Businesses Showcase in Settings
    item {
      com.example.ui.components.BestForBusinessShowcase(
        appLanguage = uiState.appLanguage,
        selectedCategory = profile.shopType,
        onSelectCategory = { cat ->
          onSelectBusinessCategory(cat)
          android.widget.Toast.makeText(context, if (isUrdu) "کاروبار کی قسم: ${cat.urduTitle} منتخب ہو گئی!" else "Shop type set to ${cat.englishTitle}!", android.widget.Toast.LENGTH_SHORT).show()
        }
      )
    }

    // 4. STEP 2: Trial & Offline Activation System
    item {
      Text(
        text = if (isUrdu) "لائسنس و آف لائن ایکٹیویشن (TRIAL & LICENSE)" else "TRIAL & OFFLINE ACTIVATION",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF64748B),
        letterSpacing = 0.8.sp
      )
    }

    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (subscription.isActivated) Color(0xFF10B981).copy(alpha = 0.12f) else Color(0xFFD97706).copy(alpha = 0.12f),
                modifier = Modifier.size(38.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = if (subscription.isActivated) Icons.Default.Key else Icons.Default.Lock,
                    contentDescription = null,
                    tint = if (subscription.isActivated) Color(0xFF10B981) else Color(0xFFD97706),
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (subscription.isActivated) {
                    if (isUrdu) "ادا شدہ کاروباری رسائی ✓" else "Paid business access ✓"
                  } else if (subscription.remainingDays > 0) {
                    if (isUrdu) "${subscription.remainingDays} دن کا مفت ٹرائل باقی ہے" else "${subscription.remainingDays} Days Free Trial"
                  } else {
                    if (isUrdu) "ٹرائل ختم ہو چکا ہے (ایکٹیویٹ کریں)" else "Trial Expired (Please Activate)"
                  },
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = Color(0xFF0F172A)
                )
                Text(
                  text = if (subscription.isActivated) {
                    "${subscription.plan} • ${subscription.remainingDays} days remaining"
                  } else if (subscription.remainingDays > 0) {
                    if (isUrdu) "تمام فیچرز بغیر کسی پابندی کے فعال ہیں" else "${subscription.remainingDays} days remaining with full access"
                  } else {
                    if (isUrdu) "براہ کرم کوڈ درج کر کے ایکٹیویٹ کریں" else "0 days remaining - Enter key to unlock"
                  },
                  fontSize = 11.sp,
                  color = if (subscription.isActivated) Color(0xFF10B981) else Color(0xFFD97706)
                )
              }
            }

            Button(
              onClick = onOpenTrialActivation,
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
            ) {
              Text(text = if (isUrdu) "پلان اور ادائیگی" else "Plans & payment", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))


        }
      }
    }

    // 5. STEP 3: General App Mode Selector (Three-in-One)
    item {
      Text(
        text = "APP MODE SELECTOR (تھری ان ون موڈ سلیکٹر)",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF64748B),
        letterSpacing = 0.8.sp
      )
    }

    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(text = "Select Application Workflow Mode:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Mode 1: Retail Shop POS
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (uiState.appMode == AppMode.BUSINESS_RETAIL) Color(0xFF086B4D) else Color(0xFFF7F9F3),
              modifier = Modifier.weight(1f).clickable { onSelectAppMode(AppMode.BUSINESS_RETAIL) }
            ) {
              Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "🏪", fontSize = 18.sp)
                Text(text = "Retail Shop", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (uiState.appMode == AppMode.BUSINESS_RETAIL) Color.White else Color(0xFF0F172A))
                Text(text = "POS & Stock", fontSize = 9.sp, color = if (uiState.appMode == AppMode.BUSINESS_RETAIL) Color.White.copy(alpha = 0.8f) else Color(0xFF64748B))
              }
            }

            // Mode 2: Service Mode
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (uiState.appMode == AppMode.SERVICE_BASED) Color(0xFF8B5CF6) else Color(0xFFF7F9F3),
              modifier = Modifier.weight(1f).clickable { onSelectAppMode(AppMode.SERVICE_BASED) }
            ) {
              Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "🛠️", fontSize = 18.sp)
                Text(text = "Service Mode", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (uiState.appMode == AppMode.SERVICE_BASED) Color.White else Color(0xFF0F172A))
                Text(text = "Labor & Time", fontSize = 9.sp, color = if (uiState.appMode == AppMode.SERVICE_BASED) Color.White.copy(alpha = 0.8f) else Color(0xFF64748B))
              }
            }

            // Mode 3: Personal Khata
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (uiState.appMode == AppMode.PERSONAL_KHATA) Color(0xFF10B981) else Color(0xFFF7F9F3),
              modifier = Modifier.weight(1f).clickable { onSelectAppMode(AppMode.PERSONAL_KHATA) }
            ) {
              Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "👤", fontSize = 18.sp)
                Text(text = "Personal", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (uiState.appMode == AppMode.PERSONAL_KHATA) Color.White else Color(0xFF0F172A))
                Text(text = "Income & Log", fontSize = 9.sp, color = if (uiState.appMode == AppMode.PERSONAL_KHATA) Color.White.copy(alpha = 0.8f) else Color(0xFF64748B))
              }
            }
          }
        }
      }
    }

    // 6. STEP 4: Bilingual UI & Regional Settings
    item {
      Text(
        text = "LANGUAGE & LOCALIZATION (زبان کی ترتیبات)",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF64748B),
        letterSpacing = 0.8.sp
      )
    }

    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          SettingsMenuItem(
            icon = Icons.Default.Language,
            iconTint = Color(0xFF13865F),
            title = "App Language: ${if (uiState.appLanguage == AppLanguage.URDU) "اردو (Urdu RTL)" else "English (LTR)"}",
            subtitle = "Tap to toggle between Urdu and English anytime",
            onClick = onToggleLanguage
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.Store,
            iconTint = Color(0xFF6366F1),
            title = when (uiState.appMode) {
              AppMode.BUSINESS_RETAIL -> "Usage Mode: Shop, Mart & Retail POS (دکان موڈ)"
              AppMode.SERVICE_BASED -> "Usage Mode: Services & Repairing (سروس موڈ)"
              AppMode.PERSONAL_KHATA -> "Usage Mode: Personal Khata & Finance (ذاتی کھاتہ)"
            },
            subtitle = "Tap to switch usage mode (Shop / Service / Personal)",
            onClick = onOpenModeSelection
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.Lock,
            iconTint = Color(0xFFDC2626),
            title = "Account Logout (لاگ آؤٹ اور نیا اکاؤنٹ)",
            subtitle = "Logged in as ${uiState.userAccount.ownerName} (${uiState.userAccount.mobileNumber})",
            onClick = onLogout
          )
        }
      }
    }

    // 7. STEP 5 & 6: POS, FBR Tax & Pending Screenshot Approvals
    item {
      Text(
        text = "POS, TAX & PAYMENT APPROVALS",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF64748B),
        letterSpacing = 0.8.sp
      )
    }

    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          // FBR Sales Tax Toggle
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onToggleFbrTaxMode() }
              .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFFEF3C7), modifier = Modifier.size(36.dp)) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
                }
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("FBR Tax Deduction (ایف بی آر ٹیکس موڈ)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0F172A))
                Text(
                  if (uiState.isFbrTaxMode) "ON: Calculates FBR Tax with 12-digit mock verification token" else "OFF: Standard non-tax receipt mode",
                  fontSize = 10.5.sp,
                  color = Color(0xFF64748B)
                )
              }
            }
            Switch(
              checked = uiState.isFbrTaxMode,
              onCheckedChange = { onToggleFbrTaxMode() }
            )
          }
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.ReceiptLong,
            iconTint = Color(0xFF047857),
            title = "FBR Tax Statement & Deduction Audit (ایف بی آر رپورٹ)",
            subtitle = "Daily, Weekly, Monthly, Yearly tax audit & product breakdown download",
            onClick = onOpenFbrTaxReport
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.ReceiptLong,
            iconTint = Color(0xFF13865F),
            title = "Pending Screenshot Approvals",
            subtitle = "Review customer JazzCash / EasyPaisa receipts (${uiState.pendingScreenshotInvoices.size} pending)",
            onClick = onOpenPendingScreenshots
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.Print,
            iconTint = Color(0xFF10B981),
            title = "Thermal Printer Setup (58mm / 80mm)",
            subtitle = "Configure ESC/POS Bluetooth and Network slip printer",
            onClick = {
              Toast.makeText(context, "Thermal Printer (58mm/80mm) ready!", Toast.LENGTH_SHORT).show()
            }
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.RocketLaunch,
            iconTint = Color(0xFF8B5CF6),
            title = "Load Pakistani Shop Catalog",
            subtitle = "Food, Grocery, Pharmacy, Cloth & Boutique items",
            onClick = onOpenIndustryCatalog
          )
        }
      }
    }

    // 8. Reports & Bulk Inventory Utilities
    item {
      Text(
        text = "DATA BACKUP & INVENTORY CSV/TEXT",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF64748B),
        letterSpacing = 0.8.sp
      )
    }

    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          SettingsMenuItem(
            icon = Icons.Default.PictureAsPdf,
            iconTint = Color(0xFFE11D48),
            title = "Export Full Khata Statement (PDF/Text)",
            subtitle = "Download complete customer and sales ledger report",
            onClick = {
              Toast.makeText(context, "Exporting Ledger Report... ✓", Toast.LENGTH_SHORT).show()
            }
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.Download,
            iconTint = Color(0xFF086B4D),
            title = "Download Inventory / Export Report",
            subtitle = "Export local stock items into CSV / Text file",
            onClick = onExportStock
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.Upload,
            iconTint = Color(0xFF0D9488),
            title = "Upload Bulk Inventory (Mock 10 Items)",
            subtitle = "Simulate reading structured text to seed stock items",
            onClick = onImportStock
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.Refresh,
            iconTint = Color(0xFF13865F),
            title = "1-Click Pakistani Demo Data",
            subtitle = "Preload customers, stock items, and daily sales",
            onClick = {
              onLoadDemoData()
              Toast.makeText(context, "Demo Data Loaded! ✓", Toast.LENGTH_SHORT).show()
            }
          )
          HorizontalDivider(color = Color(0xFFF7F9F3))
          SettingsMenuItem(
            icon = Icons.Default.CleaningServices,
            iconTint = Color(0xFFDC2626),
            title = "Factory Reset All Local Data",
            subtitle = "Wipe all local boxes and start fresh",
            onClick = { showResetDialog = true }
          )
        }
      }
    }

    // 9. Version & APK Update Guide
    item {
      Text(
        text = "APP VERSION & APK UPDATE (ورژن 2.7.0)",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF64748B),
        letterSpacing = 0.8.sp
      )
    }

    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF10B981).copy(alpha = 0.12f),
                modifier = Modifier.size(42.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "APK Download",
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(24.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "Arshad Finance V3.2.0",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF0F172A)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFF10B981)
                  ) {
                    Text(
                      text = "LATEST ✓",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                  }
                }
                Text(
                  text = "Build 33 • Login, Mode Switcher, FBR Statements & Plans",
                  fontSize = 11.sp,
                  color = Color(0xFF64748B)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = "تازہ ترین اپ ڈیٹ (What's New in V3.2.0):",
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
          )
          Text(
            text = "• مکمل لاگ ان اور سائن اپ سسٹم (سوشل / بین الاقوامی فون سپورٹ)\n• بزنس موڈ سلیکشن (Personal Khata, Shop & Mart, Service Mode)\n• ایف بی آر ٹیکس کٹوتی (Daily, Weekly, Monthly, Yearly) اور اسٹیٹمنٹ ڈاؤنلوڈ\n• ٹرائل ورژن اور قیمت کے پیکجز (300 روپے/ماہ، 3000 روپے/سال)\n• ٹیکسٹ کنٹراسٹ اور ہائی وزیبلٹی ڈسپلے میں اضافہ",
            fontSize = 11.sp,
            color = Color(0xFF475569),
            modifier = Modifier.padding(vertical = 4.dp)
          )

          Spacer(modifier = Modifier.height(8.dp))

          Button(
            onClick = {
              showApkDownloadGuideDialog = true
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Download APK / Update Guide (تازہ ترین APK ڈاؤنلوڈ کریں)",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }
        }
      }
    }

    // 10. Developer Footer
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "Arshad Finance & Traders V2.7.0",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF0F172A)
        )
        Text(
          text = "All-in-One POS, Billing, Multi-Role & Subscription Khata",
          fontSize = 10.5.sp,
          color = Color(0xFF64748B)
        )
        Text(
          text = "Lead Developer: Muhammad Arshad (0302-7761415)",
          fontSize = 10.sp,
          color = Color(0xFF086B4D),
          fontWeight = FontWeight.SemiBold
        )
      }
    }

    item { Spacer(modifier = Modifier.height(70.dp)) }
  }
}

@Composable
private fun SettingsMenuItem(
  icon: ImageVector,
  iconTint: Color,
  title: String,
  subtitle: String,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(horizontal = 16.dp, vertical = 13.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = iconTint.copy(alpha = 0.1f),
        modifier = Modifier.size(38.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(imageVector = icon, contentDescription = title, tint = iconTint, modifier = Modifier.size(20.dp))
        }
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(text = title, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
        Text(text = subtitle, fontSize = 11.sp, color = Color(0xFF64748B))
      }
    }

    Icon(
      imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
      contentDescription = null,
      tint = Color(0xFFCBD5E1),
      modifier = Modifier.size(14.dp)
    )
  }
}
