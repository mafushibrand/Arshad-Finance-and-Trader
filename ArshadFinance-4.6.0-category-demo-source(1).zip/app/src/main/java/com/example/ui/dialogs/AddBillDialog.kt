package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AddBillDialog(
  currencySymbol: String,
  onDismiss: () -> Unit,
  onSave: (title: String, amount: Double, dueDate: String, category: String, icon: String) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var amountText by remember { mutableStateOf("") }
  var dueDate by remember { mutableStateOf("Aug 31, 2026") }
  var selectedCategory by remember { mutableStateOf("Utilities") }
  var selectedIcon by remember { mutableStateOf("⚡") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val categories = listOf(
    Pair("Utilities", "⚡"),
    Pair("Internet & Phone", "🌐"),
    Pair("Rent & Housing", "🏠"),
    Pair("Subscriptions", "📺"),
    Pair("Health & Gym", "🏋️"),
    Pair("Insurance", "🛡️")
  )

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(28.dp))
        .testTag("add_bill_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(24.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Schedule Bill",
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Bill / Provider Name") },
          placeholder = { Text("e.g. Electric Co, Netflix, Rent") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_bill_title")
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("Amount ($currencySymbol)") },
          placeholder = { Text("0.00") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_bill_amount")
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = dueDate,
          onValueChange = { dueDate = it },
          label = { Text("Due Date") },
          placeholder = { Text("e.g. Aug 30, 2026") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_bill_due_date")
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = "Category",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
        )

        Spacer(modifier = Modifier.height(6.dp))

        val catScroll = rememberScrollState()
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(catScroll),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          categories.forEach { (catName, icon) ->
            val isSelected = selectedCategory == catName
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable {
                  selectedCategory = catName
                  selectedIcon = icon
                }
                .padding(horizontal = 12.dp, vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "$icon $catName",
                style = MaterialTheme.typography.bodySmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        if (errorMessage != null) {
          Text(
            text = errorMessage ?: "",
            color = ExpenseRed,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 8.dp)
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically
        ) {
          TextButton(onClick = onDismiss) {
            Text(text = "Cancel", color = TextSecondary)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              val parsedAmount = amountText.toDoubleOrNull()
              if (title.isBlank()) {
                errorMessage = "Please enter a bill title"
              } else if (parsedAmount == null || parsedAmount <= 0) {
                errorMessage = "Please enter a valid amount"
              } else {
                onSave(title.trim(), parsedAmount, dueDate.trim(), selectedCategory, selectedIcon)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.testTag("save_bill_button")
          ) {
            Text(text = "Save Bill")
          }
        }
      }
    }
  }
}
