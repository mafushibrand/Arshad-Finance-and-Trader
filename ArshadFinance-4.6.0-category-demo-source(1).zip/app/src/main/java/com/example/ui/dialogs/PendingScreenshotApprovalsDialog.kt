package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HighlightOff
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Invoice
import com.example.data.local.BusinessPreferences
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PendingScreenshotApprovalsDialog(
  pendingInvoices: List<Invoice>,
  currency: String,
  onApprove: (Invoice) -> Unit,
  onReject: (Invoice) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(24.dp))
        .testTag("pending_screenshots_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFF13865F).copy(alpha = 0.12f),
              modifier = Modifier.size(38.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.ReceiptLong,
                  contentDescription = null,
                  tint = Color(0xFF13865F),
                  modifier = Modifier.size(22.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Pending Screenshot Approvals",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
              )
              Text(
                text = "آن لائن پیمنٹ رسید کی تصدیق",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (pendingInvoices.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 32.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(text = "🎉", fontSize = 36.sp)
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "No Pending Screenshot Approvals",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
              )
              Text(
                text = "تمام آن لائن ادائیگیاں تصدیق شدہ ہیں",
                fontSize = 11.5.sp,
                color = Color(0xFF64748B)
              )
            }
          }
        } else {
          Text(
            text = "گاہک کی آن لائن رسید چیک کریں، تصدیق ہونے پر [منظور] کریں ورنہ [مسترد] کر کے ادھار کھاتہ میں ڈالیں۔",
            fontSize = 11.5.sp,
            color = Color(0xFF475569)
          )

          Spacer(modifier = Modifier.height(12.dp))

          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .height(380.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(pendingInvoices, key = { it.id }) { invoice ->
              Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7F2)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column {
                      Text(
                        text = invoice.customerName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF0F172A)
                      )
                      Text(
                        text = "Bill: #${invoice.invoiceNumber} • ${dateFormat.format(Date(invoice.dateMillis))}",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                      )
                    }

                    Text(
                      text = "$currency ${String.format(Locale.US, "%,.0f", invoice.grandTotal)}",
                      fontWeight = FontWeight.Bold,
                      fontSize = 15.sp,
                      color = Color(0xFF086B4D)
                    )
                  }

                  Spacer(modifier = Modifier.height(8.dp))

                  val receipt = remember(invoice.invoiceNumber) { BusinessPreferences(context).read("receipt/${invoice.invoiceNumber}", "") }
                  if (receipt.isNotBlank()) AsyncImage(model = receipt,
                    contentDescription = "Payment receipt / ادائیگی کی رسید",
                    modifier = Modifier.fillMaxWidth().height(220.dp))
                  // Receipt remains pending until the owner confirms it.
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Row(
                      modifier = Modifier.padding(8.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Box(
                        modifier = Modifier
                          .size(36.dp)
                          .clip(RoundedCornerShape(6.dp))
                          .background(Color(0xFFE0F2FE)),
                        contentAlignment = Alignment.Center
                      ) {
                        Icon(
                          imageVector = Icons.Default.Image,
                          contentDescription = null,
                          tint = Color(0xFF13865F),
                          modifier = Modifier.size(20.dp)
                        )
                      }
                      Spacer(modifier = Modifier.width(10.dp))
                      Column {
                        Text(
                          text = if (receipt.isNotBlank()) "Screenshot attached (${invoice.paymentMethod})" else "No receipt image / رسید موجود نہیں",
                          fontSize = 11.5.sp,
                          fontWeight = FontWeight.SemiBold,
                          color = Color(0xFF0F172A)
                        )
                        Text(
                          text = "Awaiting owner verification / تصدیق درکار ہے",
                          fontSize = 10.sp,
                          color = Color(0xFF10B981)
                        )
                      }
                    }
                  }

                  Spacer(modifier = Modifier.height(10.dp))

                  // Two Action Buttons: Approve and Reject
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    Button(
                      onClick = {
                        onApprove(invoice)
                        Toast.makeText(context, "Payment Approved & Finalized! ✓", Toast.LENGTH_SHORT).show()
                      },
                      shape = RoundedCornerShape(10.dp),
                      colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                      modifier = Modifier.weight(1f).height(40.dp)
                    ) {
                      Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(text = "Approve (منظور)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                      onClick = {
                        onReject(invoice)
                        Toast.makeText(context, "Payment Rejected -> Added to Khata Udhar!", Toast.LENGTH_SHORT).show()
                      },
                      shape = RoundedCornerShape(10.dp),
                      colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                      modifier = Modifier.weight(1f).height(40.dp)
                    ) {
                      Icon(Icons.Default.HighlightOff, contentDescription = null, modifier = Modifier.size(16.dp))
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(text = "Reject (ادھار کھاتہ)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
