package com.example.ui.dialogs

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.*
import com.example.business.SubscriptionPolicy

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionDialog(state:SubscriptionState,language:AppLanguage,onDismiss:()->Unit,
  importFile:(Uri,(String?)->Unit)->Unit,onUsePersonal:()->Unit={},onStartBusiness:()->Unit={}) {
  val ur=language==AppLanguage.URDU
  fun t(en:String,u:String)=if(ur)u else en
  val context=LocalContext.current;val clipboard=LocalClipboardManager.current
  var plan by remember {mutableStateOf("YEARLY")};var method by remember {mutableStateOf("JazzCash")}
  var proof by remember {mutableStateOf<Uri?>(null)};var reference by remember {mutableStateOf("")};var message by remember {mutableStateOf("")}
  val merchant=remember(state.merchantConfig){runCatching {SubscriptionPolicy.merchant(state.merchantConfig)}.getOrNull()}
  val filePicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)importFile(uri){error->message=error ?: t("Verified file applied. You can continue.","تصدیق شدہ فائل لگ گئی۔ آپ جاری رکھ سکتے ہیں۔")}}
  val proofPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->proof=uri}
  fun share(addon:String="") {
    if(merchant==null){message=t("Receiving account setup is pending. Do not pay yet.","وصولی اکاؤنٹ کا سیٹ اپ باقی ہے۔ ابھی ادائیگی نہ کریں۔");return}
    if(addon.isEmpty() && (proof==null||reference.isBlank())) {message=t("Choose payment screenshot and enter transaction reference.","ادائیگی کی تصویر منتخب کریں اور ٹرانزیکشن نمبر درج کریں۔");return}
    val text="Arshad Finance • "+(if(addon.isEmpty())"Payment verification" else "Add-on request: $addon")+"\nContact: "+merchant.optString("contact")+"\nPhone ID: "+state.deviceId+"\nPlan: "+plan+"\nAmount: Rs. "+(if(plan=="YEARLY")3000 else 300)+"\nMethod: "+method+"\nReference: "+reference
    runCatching {
      val intent=Intent(Intent.ACTION_SEND).apply {type=if(proof!=null&&addon.isEmpty())"image/*" else "text/plain";putExtra(Intent.EXTRA_TEXT,text);if(proof!=null&&addon.isEmpty()){putExtra(Intent.EXTRA_STREAM,proof);clipData=android.content.ClipData.newRawUri("Payment proof",proof);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}}
      context.startActivity(Intent.createChooser(intent,t("Send to ","یہاں بھیجیں: ")+merchant.optString("contact")))
    }.onFailure {message=t("No sharing app available","بھیجنے کی ایپ دستیاب نہیں")}
  }
  Dialog(onDismissRequest=onDismiss,properties=DialogProperties(usePlatformDefaultWidth=false)) {
    Scaffold(containerColor=MaterialTheme.colorScheme.background,topBar={TopAppBar(title={Text(t("Simple pricing","آسان قیمتیں"),fontWeight=FontWeight.Bold)},navigationIcon={IconButton(onClick=onDismiss){Icon(Icons.Default.Close,null)}})}) {padding->
      Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp).testTag("subscription_screen"),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)) {Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
          Icon(Icons.Default.Storefront,null,Modifier.size(36.dp))
          Text(if(state.isActivated&&state.hasBusinessAccess)t("Paid access • "+state.plan,"ادا شدہ رسائی • "+state.plan) else if(state.hasBusinessAccess)t("Free trial • ${state.remainingDays} days left","مفت ٹرائل • ${state.remainingDays} دن باقی") else if(state.trialStartedMillis==0L&&!state.hasPaidBefore)t("30-day free business trial","کاروبار کا ۳۰ دن مفت ٹرائل") else t("Business access needs renewal","کاروباری رسائی کی تجدید کریں"),style=MaterialTheme.typography.titleLarge)
          Text(t("Personal Khata is always free. Products, services and shop billing need active business access.","ذاتی کھاتہ ہمیشہ مفت ہے۔ پروڈکٹس، سروسز اور دکان کے بل کے لیے کاروباری رسائی ضروری ہے۔"))
          if(state.trialStartedMillis==0L || state.hasBusinessAccess)Button(onClick=onStartBusiness,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp)){Text(if(state.hasBusinessAccess)t("Open business","کاروبار کھولیں") else t("Start 30-day free trial","۳۰ دن کا مفت ٹرائل شروع کریں"))}
        }}
        PriceOption(t("Monthly plan","ماہانہ پلان"),"Rs. 300 / "+t("month","ماہ"),t("Pay every month","ہر ماہ ادائیگی"),plan=="MONTHLY"){plan="MONTHLY"}
        PriceOption(t("Yearly plan","سالانہ پلان"),"Rs. 3,000 / "+t("year","سال"),t("Save Rs. 600 • 16.67% discount • Rs. 250/month equivalent","۶۰۰ روپے بچت • ۱۶.۶۷٪ رعایت • تقریباً ۲۵۰ روپے ماہانہ"),plan=="YEARLY"){plan="YEARLY"}
        Text(t("1 • Pay securely","۱ • محفوظ ادائیگی کریں"),style=MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {FilterChip(method=="JazzCash",{method="JazzCash"},label={Text("JazzCash")});FilterChip(method=="Meezan Bank",{method="Meezan Bank"},label={Text("Meezan Bank")})}
        if(merchant==null)Text(t("Payment receiving details are not configured yet. Please wait for verified account details.","ادائیگی وصول کرنے کی تفصیل ابھی درج نہیں۔ تصدیق شدہ اکاؤنٹ تفصیل کا انتظار کریں۔"),color=MaterialTheme.colorScheme.error)
        else {
          val account=if(method=="JazzCash")merchant.optString("jazzcash") else merchant.optString("meezanIban")
          Text(merchant.optString("title"),style=MaterialTheme.typography.titleMedium)
          Text(if(account.isBlank())t("This payment method is not configured","اس ادائیگی کا اکاؤنٹ درج نہیں") else account)
          if(account.isNotBlank())OutlinedButton(onClick={clipboard.setText(AnnotatedString(account));message=t("Account copied","اکاؤنٹ کاپی ہو گیا")},modifier=Modifier.fillMaxWidth().heightIn(min=52.dp)){Icon(Icons.Default.ContentCopy,null);Text(t("Copy account number","اکاؤنٹ نمبر کاپی کریں"))}
          Text(t("Only pay to this verified account. Review the name and amount in your banking app.","صرف اس تصدیق شدہ اکاؤنٹ میں ادائیگی کریں۔ بینک ایپ میں نام اور رقم دیکھیں۔"))
        }
        Text(t("2 • Send payment proof","۲ • ادائیگی کی تصویر بھیجیں"),style=MaterialTheme.typography.titleLarge)
        BusinessField(reference,t("Transaction reference","ٹرانزیکشن نمبر")){reference=it}
        OutlinedButton(onClick={proofPicker.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth().heightIn(min=54.dp)){Icon(Icons.Default.AddPhotoAlternate,null);Text(if(proof==null)t("Choose screenshot","ادائیگی کی تصویر منتخب کریں") else t("Screenshot selected ✓","تصویر منتخب ہو گئی ✓"))}
        Button(onClick={share()},enabled=merchant!=null,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp)){Icon(Icons.Default.Share,null);Text(t("Send proof for verification","تصدیق کے لیے تصویر بھیجیں"))}
        Text(t("Screenshots do not unlock the app. Access starts after payment is checked and signed activation is issued.","صرف تصویر سے ایپ نہیں کھلتی۔ ادائیگی کی تصدیق کے بعد ایکٹیویشن فائل ملے گی۔"))
        Text(t("3 • Open activation file","۳ • ایکٹیویشن فائل کھولیں"),style=MaterialTheme.typography.titleLarge)
        Button(onClick={filePicker.launch(arrayOf("*/*"))},modifier=Modifier.fillMaxWidth().heightIn(min=54.dp).testTag("import_signed_activation")){Icon(Icons.Default.VerifiedUser,null);Text(t("Choose activation / setup file","ایکٹیویشن / سیٹ اپ فائل منتخب کریں"))}
        OutlinedButton(onClick={clipboard.setText(AnnotatedString(state.deviceId));message=t("Phone ID copied","فون آئی ڈی کاپی ہو گئی")},modifier=Modifier.fillMaxWidth()){Text(t("Copy phone ID","فون آئی ڈی کاپی کریں"))}
        Text(t("Optional add-ons • priced separately","اختیاری اضافے • الگ قیمت"),style=MaterialTheme.typography.titleMedium)
        listOf("Installment plan" to "قسطوں کا پلان","Multi-branch / Multi-outlet" to "کئی برانچیں / دکانیں","Custom reports" to "حسب ضرورت رپورٹس").forEach {(en,u)->OutlinedButton(onClick={share(en)},enabled=merchant!=null,modifier=Modifier.fillMaxWidth().heightIn(min=52.dp)){Text(t(en,u))}}
        Text(t("Existing multi-branch workflows remain available during active business access; managed add-ons require an agreed quote.","فعال کاروباری رسائی میں موجود برانچ فیچرز دستیاب ہیں؛ اضافی سیٹ اپ کی قیمت الگ طے ہوگی۔"))
        if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.primary)
        TextButton(onClick=onUsePersonal,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp)){Text(t("Continue with free personal Khata","مفت ذاتی کھاتہ جاری رکھیں"))}
      }
    }
  }
}
@Composable
private fun PriceOption(title:String,price:String,subtitle:String,selected:Boolean,click:()->Unit) {
  Card(onClick=click,shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=if(selected)MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)) {
    Row(Modifier.fillMaxWidth().padding(18.dp)) {RadioButton(selected,click);Column(Modifier.weight(1f)){Text(title,style=MaterialTheme.typography.titleMedium);Text(price,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text(subtitle,style=MaterialTheme.typography.bodyMedium)}}
  }
}
