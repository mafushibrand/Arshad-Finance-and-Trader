package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun BillingScreen(
  uiState: FinanceUiState,
  onOpenAddInvoice: () -> Unit,
  onOpenEditInvoice: (Invoice) -> Unit,
  onSelectInvoice: (Invoice) -> Unit,
  onOpenAddCustomer: () -> Unit,
  onEditCustomer: (Customer) -> Unit,
  onSelectCustomer: (Customer) -> Unit,
  onOpenEditProfile: () -> Unit,
  onOpenShopProfile: () -> Unit,
  onOpenIndustryCatalog: () -> Unit,
  onDeleteInvoice: (Invoice) -> Unit,
  onOpenAddProduct: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  var advanced by rememberSaveable { mutableStateOf(false) }
  if (advanced) {
    BackHandler { advanced = false }
    Column(modifier.fillMaxSize().background(Cream)) {
      TextButton(onClick = { advanced = false }, modifier = Modifier.padding(horizontal = 16.dp)) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(8.dp)); Text(uiState.word("Back to overview", "خلاصے پر واپس")) }
      LegacyBillingScreen(uiState = uiState, onOpenAddInvoice = onOpenAddInvoice, onOpenEditInvoice = onOpenEditInvoice, onSelectInvoice = onSelectInvoice, onOpenAddCustomer = onOpenAddCustomer, onEditCustomer = onEditCustomer, onSelectCustomer = onSelectCustomer, onOpenEditProfile = onOpenEditProfile, onOpenShopProfile = onOpenShopProfile, onOpenIndustryCatalog = onOpenIndustryCatalog, onDeleteInvoice = onDeleteInvoice, onOpenAddProduct = onOpenAddProduct, modifier = Modifier.weight(1f))
    }
    return
  }
  var search by rememberSaveable { mutableStateOf("") }
  var filter by rememberSaveable { mutableIntStateOf(0) }
  val customers = uiState.customers.filter { search.isBlank() || it.name.contains(search, true) || it.phone.contains(search, true) }
  val bills = uiState.invoices.filter { (search.isBlank() || it.customerName.contains(search, true) || it.invoiceNumber.contains(search, true)) && (filter != 2 || it.remainingBalance > 0.0) }
  PremiumPage(uiState.word("Khata & customers", "کھاتہ اور گاہک"), uiState.word("Clear balances. Better relationships.", "صاف حساب، بہتر تعلقات"), Icons.Default.ReceiptLong,
    modifier, uiState.word("Add customer", "نیا گاہک"), onOpenAddCustomer,
    footer = { Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      PremiumButton(uiState.word("New customer", "نیا گاہک"), onOpenAddCustomer, modifier = Modifier.weight(1f))
      PremiumButton(uiState.word("New bill", "نیا بل"), onOpenAddInvoice, modifier = Modifier.weight(1f))
    } }) {
    item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      Metric(uiState.word("To collect", "وصول طلب"), uiState.money(uiState.totalActiveUdhar), Peach, Modifier.weight(1f))
      Metric(uiState.word("Customers", "گاہک"), uiState.customers.size.toString(), modifier = Modifier.weight(1f))
    } }
    item { SearchBox(search, uiState.word("Search customer, phone or invoice", "گاہک، فون یا بل تلاش کریں")) { search = it } }
    item { FilterRow(listOf(uiState.word("Customers", "گاہک"), uiState.word("All bills", "تمام بل"), uiState.word("Due bills", "بقایہ بل")), filter) { filter = it } }
    if (filter == 0) {
      if (customers.isEmpty()) item { EmptyList(uiState.word("Your khata starts here", "آپ کا کھاتہ یہاں سے شروع ہوتا ہے"), uiState.word("Add a customer to track their balance.", "حساب رکھنے کے لیے نیا گاہک شامل کریں۔"), Icons.Default.PeopleAlt) }
      items(customers, key = { it.id }) { customer -> ListTile(customer.name, customer.phone.ifBlank { customer.customerType }, Icons.Default.Person, uiState.money(customer.currentBalance), Peach, { onSelectCustomer(customer) }) {
        TextButton(onClick = { onEditCustomer(customer) }) { Text(uiState.word("Edit", "ترمیم")) }
        TextButton(onClick = { onSelectCustomer(customer) }) { Text(uiState.word("Open statement", "تفصیل کھولیں")) }
      } }
    } else {
      if (bills.isEmpty()) item { EmptyList(uiState.word("No bills found", "کوئی بل نہیں ملا"), uiState.word("Saved bills will appear here.", "محفوظ بل یہاں نظر آئیں گے۔"), Icons.Default.ReceiptLong) }
      items(bills, key = { it.id }) { bill -> ListTile(bill.customerName, "${bill.invoiceNumber} • ${SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(Date(bill.dateMillis))}", Icons.Default.ReceiptLong, uiState.money(bill.netTotal()), click = { onSelectInvoice(bill) }) {
        Text(if (bill.paymentStatus == "PENDING_APPROVAL") uiState.word("Receipt awaiting review", "رسید کی منظوری باقی") else uiState.word("Due: ", "بقایہ: ") + uiState.money(bill.remainingBalance), color = if (bill.remainingBalance > 0) Color(0xFFAF4C26) else Forest, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        if(uiState.userRole==UserRole.OWNER) TextButton(enabled = bill.paymentStatus !in listOf("RETURNED","PARTIAL_RETURN"),onClick = { onOpenEditInvoice(bill) }) { Text(uiState.word("Edit", "ترمیم")) }
      } }
    }
    item { AdvancedButton(uiState) { advanced = true } }
  }
}
