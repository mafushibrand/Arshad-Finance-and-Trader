package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LegacyAddAccountDialog(
  currencySymbol: String,
  onDismiss: () -> Unit,
  onSave: (name: String, accountType: String, balance: Double, cardNumber: String, colorHex: Long) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var accountType by remember { mutableStateOf("Checking") }
  var balanceText by remember { mutableStateOf("") }
  var cardNumber by remember { mutableStateOf("•••• " + (1000..9999).random().toString()) }
  var selectedColorHex by remember { mutableLongStateOf(0xFF006C45) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val accountTypes = listOf("Checking", "Savings", "Credit Card", "Investment")
  val cardColors = listOf(
    0xFF006C45, // Executive Blue
    0xFF136D00, // Emerald Green
    0xFF535F70, // Slate Graphite
    0xFF6750A4, // Regal Violet
    0xFF9C4146, // Burgundy
    0xFFB26200  // Amber Gold
  )

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(28.dp))
        .testTag("add_account_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(24.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Add Account / Card",
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Account Name") },
          placeholder = { Text("e.g. Chase Premier, Robinhood") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_account_name")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Account Type
        Text(
          text = "Account Type",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
        )

        Spacer(modifier = Modifier.height(6.dp))

        val typeScroll = rememberScrollState()
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(typeScroll),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          accountTypes.forEach { type ->
            val isSelected = accountType == type
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable { accountType = type }
                .padding(horizontal = 12.dp, vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = type,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = balanceText,
          onValueChange = { balanceText = it },
          label = { Text("Current Balance ($currencySymbol)") },
          placeholder = { Text("0.00") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_account_balance")
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = cardNumber,
          onValueChange = { cardNumber = it },
          label = { Text("Masked Card Number") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_account_card_number")
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Theme Color Palette
        Text(
          text = "Card Theme Color",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          cardColors.forEach { colorVal ->
            val isSelected = selectedColorHex == colorVal
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(colorVal))
                .clickable { selectedColorHex = colorVal }
                .then(
                  if (isSelected) Modifier.padding(4.dp).clip(CircleShape).background(Color.White)
                  else Modifier
                )
            )
          }
        }

        if (errorMessage != null) {
          Text(
            text = errorMessage ?: "",
            color = ExpenseRed,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 8.dp)
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically
        ) {
          TextButton(onClick = onDismiss) {
            Text(text = "Cancel", color = TextSecondary)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              val parsedBalance = balanceText.toDoubleOrNull()
              if (name.isBlank()) {
                errorMessage = "Please enter an account name"
              } else if (parsedBalance == null) {
                errorMessage = "Please enter a valid balance"
              } else {
                onSave(name.trim(), accountType, parsedBalance, cardNumber.trim(), selectedColorHex)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.testTag("save_account_button")
          ) {
            Text(text = "Create Account")
          }
        }
      }
    }
  }
}
