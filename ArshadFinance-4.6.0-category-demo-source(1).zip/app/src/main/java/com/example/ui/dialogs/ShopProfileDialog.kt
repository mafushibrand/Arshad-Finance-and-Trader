package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.DeepNavyText
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.InputFieldStyles
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BusinessProfile

@Composable
fun LegacyShopProfileDialog(
  currentProfile: BusinessProfile,
  onSaveProfile: (BusinessProfile) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current

  var businessName by remember { mutableStateOf(currentProfile.businessName) }
  var ownerName by remember { mutableStateOf(currentProfile.ownerName) }
  var phone by remember { mutableStateOf(currentProfile.phone) }
  var address by remember { mutableStateOf(currentProfile.address) }
  var shopType by remember { mutableStateOf(currentProfile.shopType) }
  var logoEmoji by remember { mutableStateOf(currentProfile.logoEmoji.ifBlank { "🏪" }) }
  var tagline by remember { mutableStateOf(currentProfile.tagline) }
  var invoicePrefix by remember { mutableStateOf(currentProfile.invoicePrefix.ifBlank { "AF" }) }
  var ntnNumber by remember { mutableStateOf(currentProfile.ntnNumber) }
  var bankName by remember { mutableStateOf(currentProfile.bankName) }
  var bankAccountTitle by remember { mutableStateOf(currentProfile.bankAccountTitle) }
  var bankAccountNumber by remember { mutableStateOf(currentProfile.bankAccountNumber) }
  var bankIban by remember { mutableStateOf(currentProfile.bankIban) }
  var jazzCashNumber by remember { mutableStateOf(currentProfile.jazzCashNumber) }
  var easyPaisaNumber by remember { mutableStateOf(currentProfile.easyPaisaNumber) }
  var sadaPayNumber by remember { mutableStateOf(currentProfile.sadaPayNumber) }

  val logoPresets = listOf("🏪", "👗", "💅", "💊", "🛒", "📱", "💎", "✂️", "🚗", "🍔", "🥖", "👟", "🛠️", "☕")
  val shopTypePresets = listOf(
    "Cloth Shop & Boutique",
    "Beauty Parlour & Salon",
    "Medical Store & Pharmacy",
    "Grocery & Kiryana Store",
    "Mobile & Electronics",
    "General Store & Services"
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(24.dp))
        .testTag("shop_profile_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(IceBlueContainer),
              contentAlignment = Alignment.Center
            ) {
              Text(logoEmoji, fontSize = 24.sp)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Shop Details & Branding",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = DeepNavyText
                )
              )
              Text(
                text = "دکان کا نام، لوگو اور رابطہ نمبر (بل پر پرنٹ ہوگا)",
                style = MaterialTheme.typography.bodySmall.copy(
                  color = TextSecondary,
                  fontSize = 11.5.sp
                )
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFFE2E8F0))

        // 1. Logo Selector
        Text(
          text = "Select Shop Logo / Icon (لوگو منتخب کریں):",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF334155)
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          logoPresets.take(7).forEach { emoji ->
            val isSelected = logoEmoji == emoji
            Surface(
              shape = CircleShape,
              color = if (isSelected) IceBlueContainer else Color(0xFFF7F9F3),
              border = androidx.compose.foundation.BorderStroke(
                if (isSelected) 2.dp else 1.dp,
                if (isSelected) NavyBluePrimary else Color(0xFFCBD5E1)
              ),
              modifier = Modifier
                .size(38.dp)
                .clickable { logoEmoji = emoji }
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(emoji, fontSize = 18.sp)
              }
            }
          }
        }
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          logoPresets.drop(7).forEach { emoji ->
            val isSelected = logoEmoji == emoji
            Surface(
              shape = CircleShape,
              color = if (isSelected) IceBlueContainer else Color(0xFFF7F9F3),
              border = androidx.compose.foundation.BorderStroke(
                if (isSelected) 2.dp else 1.dp,
                if (isSelected) NavyBluePrimary else Color(0xFFCBD5E1)
              ),
              modifier = Modifier
                .size(38.dp)
                .clickable { logoEmoji = emoji }
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(emoji, fontSize = 18.sp)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 2. Shop / Business Name (Mandatory)
        OutlinedTextField(
          value = businessName,
          onValueChange = { businessName = it },
          label = { Text("Shop / Business Name (دکان کا نام) *") },
          placeholder = { Text("e.g. Arshad Cloth House / Glamour Parlour") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("shop_name_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 3. Shop Type / Industry Preset
        Text(
          text = "Shop Category (دکان کی قسم):",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF334155)
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          shopTypePresets.take(3).forEach { type ->
            val isSelected = shopType == type
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) NavyBluePrimary else Color(0xFFF5F7F2),
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isSelected) NavyBluePrimary else Color(0xFFCBD5E1)
              ),
              modifier = Modifier
                .weight(1f)
                .clickable {
                  shopType = type
                  if (type.contains("Cloth")) logoEmoji = "👗"
                  else if (type.contains("Parlour")) logoEmoji = "💅"
                  else if (type.contains("Medical")) logoEmoji = "💊"
                }
            ) {
              Text(
                type.split(" ").first(),
                modifier = Modifier.padding(vertical = 6.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else TextPrimary
              )
            }
          }
        }
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          shopTypePresets.drop(3).forEach { type ->
            val isSelected = shopType == type
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) NavyBluePrimary else Color(0xFFF5F7F2),
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isSelected) NavyBluePrimary else Color(0xFFCBD5E1)
              ),
              modifier = Modifier
                .weight(1f)
                .clickable {
                  shopType = type
                  if (type.contains("Grocery")) logoEmoji = "🛒"
                  else if (type.contains("Mobile")) logoEmoji = "📱"
                  else logoEmoji = "🏪"
                }
            ) {
              Text(
                type.split(" ").first(),
                modifier = Modifier.padding(vertical = 6.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else TextPrimary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Contact Phone & Owner Name
        Row(modifier = Modifier.fillMaxWidth()) {
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Shop Phone / WhatsApp *") },
            placeholder = { Text("0300-1234567") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier
              .weight(1.1f)
              .testTag("shop_phone_input"),
            singleLine = true
          )
          Spacer(modifier = Modifier.width(8.dp))
          OutlinedTextField(
            value = ownerName,
            onValueChange = { ownerName = it },
            label = { Text("Owner Name") },
            placeholder = { Text("Muhammad Arshad") },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier
              .weight(0.9f)
              .testTag("shop_owner_input"),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 5. Address (Mandatory on Bill)
        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text("Shop Address / City (دکان کا پتہ) *") },
          placeholder = { Text("e.g. Shop # 14, Main Commercial Market, Faisalabad") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("shop_address_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 6. Tagline & Invoice Prefix
        Row(modifier = Modifier.fillMaxWidth()) {
          OutlinedTextField(
            value = tagline,
            onValueChange = { tagline = it },
            label = { Text("Tagline / Slogan (اختیاری)") },
            placeholder = { Text("e.g. Quality and Trust") },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.weight(1.3f),
            singleLine = true
          )
          Spacer(modifier = Modifier.width(8.dp))
          OutlinedTextField(
            value = invoicePrefix,
            onValueChange = { invoicePrefix = it.take(6).uppercase() },
            label = { Text("Bill Prefix") },
            placeholder = { Text("AF / INV") },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.weight(0.7f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 7. NTN / Tax Number
        OutlinedTextField(
          value = ntnNumber,
          onValueChange = { ntnNumber = it },
          label = { Text("NTN / Registration Number (Optional)") },
          placeholder = { Text("e.g. 1234567-8") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 8. Shop Payment Accounts (JazzCash, Easypaisa, Bank, SadaPay)
        Text(
          text = "Shop Payment Receiving Accounts (ادائیگی کے اکاؤنٹس):",
          fontSize = 12.5.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF1E293B)
        )
        Text(
          text = "گاہک کو بل پر یہ اکاؤنٹس نظر آئیں گے تاکہ وہ آنلائن ادائیگی کر سکیں",
          fontSize = 10.5.sp,
          color = Color(0xFF64748B)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // JazzCash & Easypaisa
        Row(modifier = Modifier.fillMaxWidth()) {
          OutlinedTextField(
            value = jazzCashNumber,
            onValueChange = { jazzCashNumber = it },
            label = { Text("📱 JazzCash #") },
            placeholder = { Text("0302-7761415") },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
          Spacer(modifier = Modifier.width(8.dp))
          OutlinedTextField(
            value = easyPaisaNumber,
            onValueChange = { easyPaisaNumber = it },
            label = { Text("🟢 Easypaisa #") },
            placeholder = { Text("0345-9876543") },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // SadaPay & Bank Name
        Row(modifier = Modifier.fillMaxWidth()) {
          OutlinedTextField(
            value = sadaPayNumber,
            onValueChange = { sadaPayNumber = it },
            label = { Text("💳 SadaPay #") },
            placeholder = { Text("0302-7761415") },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
          Spacer(modifier = Modifier.width(8.dp))
          OutlinedTextField(
            value = bankName,
            onValueChange = { bankName = it },
            label = { Text("🏦 Bank Name") },
            placeholder = { Text("Meezan Bank Ltd") },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Bank Account Title & IBAN
        OutlinedTextField(
          value = bankAccountTitle,
          onValueChange = { bankAccountTitle = it },
          label = { Text("Bank Account Title") },
          placeholder = { Text("Arshad Finance & Traders") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = bankIban,
          onValueChange = { bankIban = it },
          label = { Text("Bank Account / IBAN #") },
          placeholder = { Text("PK89 MEZN 0001 0203 0405 0607") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Save Button
        Button(
          onClick = {
            if (businessName.isBlank()) {
              Toast.makeText(context, "Please enter shop/business name", Toast.LENGTH_SHORT).show()
              return@Button
            }
            val updated = currentProfile.copy(
              businessName = businessName.trim(),
              ownerName = ownerName.trim(),
              phone = phone.trim(),
              address = address.trim(),
              shopType = shopType.trim(),
              logoEmoji = logoEmoji.trim(),
              tagline = tagline.trim(),
              invoicePrefix = invoicePrefix.trim().ifBlank { "AF" },
              ntnNumber = ntnNumber.trim(),
              bankName = bankName.trim(),
              bankAccountTitle = bankAccountTitle.trim(),
              bankAccountNumber = bankAccountNumber.trim(),
              bankIban = bankIban.trim(),
              jazzCashNumber = jazzCashNumber.trim(),
              easyPaisaNumber = easyPaisaNumber.trim(),
              sadaPayNumber = sadaPayNumber.trim()
            )
            onSaveProfile(updated)
            Toast.makeText(context, "Shop profile saved successfully!", Toast.LENGTH_SHORT).show()
            onDismiss()
          },
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("save_shop_profile_btn")
        ) {
          Icon(Icons.Default.Save, contentDescription = "Save")
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Save Shop Details (محفوظ کریں)",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
        }
      }
    }
  }
}
