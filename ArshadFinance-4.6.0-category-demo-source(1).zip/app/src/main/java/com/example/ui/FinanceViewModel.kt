package com.example.ui

import androidx.room.withTransaction

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.FinanceDatabase
import com.example.data.model.Account
import com.example.data.model.AppLanguage
import com.example.data.model.AppMode
import com.example.data.model.Bill
import com.example.data.model.Budget
import com.example.data.model.Customer
import com.example.data.model.EmployeePermissions
import com.example.data.model.InventoryItem
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItemEntry
import com.example.data.model.RecurringFrequency
import com.example.data.model.RecurringTransaction
import com.example.data.model.ServiceItem
import com.example.data.model.ShopBioData
import com.example.data.model.DefaultServicesProvider
import com.example.data.model.SubscriptionState
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.repository.FinanceRepository
import com.example.util.BusinessProfile
import com.example.util.MultiIndustryCatalog
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class FinanceTab {
  HOME,
  STOCK,
  SERVICES,
  POS,
  LEDGERS,
  ACCOUNTS,
  REPORTS,
  PURCHASES,
  OPERATIONS,
  PLANNER,
  SETTINGS;

  companion object {
    val BILLING = LEDGERS
    val INVENTORY = STOCK
    val STATS = REPORTS
    val CARDS = ACCOUNTS
    val BILLS = LEDGERS
    val PRODUCTS = STOCK
  }
}

enum class PlannerSubTab {
  BUDGETS,
  RECURRING,
  BILLS
}

enum class FilterCategory {
  ALL,
  EXPENSES,
  INCOME,
  SHOPPING,
  FOOD,
  BILLS,
  TRANSPORT
}

data class BudgetAlert(
  val budgetId: Long,
  val category: String,
  val icon: String,
  val limitAmount: Double,
  val spentAmount: Double,
  val percentSpent: Double,
  val isExceeded: Boolean
)

data class FinanceUiState(
  val ownerAuthRequired: Boolean = true,
  val selectedTab: FinanceTab = FinanceTab.HOME,
  val plannerSubTab: PlannerSubTab = PlannerSubTab.BUDGETS,
  val selectedFilter: FilterCategory = FilterCategory.ALL,
  val searchQuery: String = "",
  val currencySymbol: String = "Rs",
  val businessRecords: List<com.example.business.BusinessRecord> = emptyList(),
  val stockMovements: List<com.example.business.StockMovement> = emptyList(),
  val transactions: List<Transaction> = emptyList(),
  val filteredTransactions: List<Transaction> = emptyList(),
  val accounts: List<Account> = emptyList(),
  val bills: List<Bill> = emptyList(),
  val budgets: List<Budget> = emptyList(),
  val recurringTransactions: List<RecurringTransaction> = emptyList(),
  val inventoryItems: List<InventoryItem> = emptyList(),
  val budgetAlerts: List<BudgetAlert> = emptyList(),
  val totalBudgetLimit: Double = 0.0,
  val totalBudgetSpent: Double = 0.0,
  val totalBalance: Double = 0.0,
  val totalIncome: Double = 0.0,
  val totalExpense: Double = 0.0,
  val monthlyChangePercent: Double = 0.0,
  val showAddTransactionDialog: Boolean = false,
  val showAddAccountDialog: Boolean = false,
  val showAddBillDialog: Boolean = false,
  val showAddRecurringDialog: Boolean = false,
  val editingRecurring: RecurringTransaction? = null,
  val showAddEditBudgetDialog: Boolean = false,
  val editingBudget: Budget? = null,
  val showAddEditInventoryDialog: Boolean = false,
  val editingInventoryItem: InventoryItem? = null,
  val showQuickStockAdjustDialog: Boolean = false,
  val adjustingInventoryItem: InventoryItem? = null,
  val showProfileDialog: Boolean = false,
  val selectedTransaction: Transaction? = null,
  val initialTransactionType: TransactionType = TransactionType.EXPENSE,
  val lastProcessedRecurringMessage: String? = null,
  val businessProfile: BusinessProfile = BusinessProfile(),
  val isProMember: Boolean = true,
  val showUpgradeDialog: Boolean = false,
  val showStockExportDialog: Boolean = false,
  val showStockImportDialog: Boolean = false,
  val customers: List<Customer> = emptyList(),
  val invoices: List<Invoice> = emptyList(),
  val selectedCustomer: Customer? = null,
  val selectedInvoice: Invoice? = null,
  val editingInvoice: Invoice? = null,
  val customerForNewBill: Customer? = null,
  val showAddInvoiceDialog: Boolean = false,
  val showAddCustomerDialog: Boolean = false,
  val showCustomerDetailDialog: Boolean = false,
  val showIndustryCatalogDialog: Boolean = false,
  val showInvoiceDetailDialog: Boolean = false,
  val showShopProfileDialog: Boolean = false,
  val showShopAccountsDialog: Boolean = false,
  val userRole: UserRole = UserRole.OWNER,
  val employeePermissions: EmployeePermissions = EmployeePermissions(),
  val appMode: AppMode = AppMode.BUSINESS_RETAIL,
  val appLanguage: AppLanguage = AppLanguage.URDU,
  val subscriptionState: SubscriptionState = SubscriptionState(),
  val showTrialLockDialog: Boolean = false,
  val showRoleLoginDialog: Boolean = false,
  val showEmployeePermissionsDialog: Boolean = false,
  val showPendingScreenshotDialog: Boolean = false,
  val showAuthDialog: Boolean = false,
  val showFbrTaxReportDialog: Boolean = false,
  val userAccount: UserAccount = UserAccount(),
  val isFbrTaxMode: Boolean = false,
  val cartItems: Map<Long, Double> = emptyMap(),
  val services: List<ServiceItem> = emptyList(),
  val selectedFeaturedServiceIds: Set<Long> = emptySet(),
  val selectedServiceCategory: String = "ALL",
  val shopBioData: ShopBioData = ShopBioData(),
  val features: com.example.data.model.BusinessFeatures = com.example.data.model.BusinessFeatures()
) {
  val isBasicTierRestricted: Boolean
    get() = subscriptionState.isBasicTierRestricted

  val totalActiveUdhar: Double
    get() = customers.sumOf { it.currentBalance.coerceAtLeast(0.0) }

  val netEarnings: Double
    get() = (totalIncome - totalExpense).coerceAtLeast(0.0)

  val cartItemCount: Int
    get() = cartItems.size

  val cartSubtotal: Double
    get() = cartItems.entries.sumOf { (id, qty) ->
      val itm = inventoryItems.find { it.id == id }
      (itm?.salePrice ?: 0.0) * qty
    }

  val pendingScreenshotInvoices: List<Invoice>
    get() = invoices.filter {
      it.paymentStatus == "PENDING_APPROVAL"
    }
}

private data class DataState(
  val transactions: List<Transaction> = emptyList(),
  val accounts: List<Account> = emptyList(),
  val bills: List<Bill> = emptyList(),
  val budgets: List<Budget> = emptyList(),
  val recurring: List<RecurringTransaction> = emptyList(),
  val inventory: List<InventoryItem> = emptyList(),
  val customers: List<Customer> = emptyList(),
  val invoices: List<Invoice> = emptyList()
)

private data class BillingDialogState(
  val showAddInvoiceDialog: Boolean = false,
  val showAddCustomerDialog: Boolean = false,
  val showCustomerDetailDialog: Boolean = false,
  val showIndustryCatalogDialog: Boolean = false,
  val showInvoiceDetailDialog: Boolean = false,
  val showShopProfileDialog: Boolean = false,
  val showShopAccountsDialog: Boolean = false,
  val showTrialLockDialog: Boolean = false,
  val showRoleLoginDialog: Boolean = false,
  val showEmployeePermissionsDialog: Boolean = false,
  val showPendingScreenshotDialog: Boolean = false,
  val showAuthDialog: Boolean = false,
  val showFbrTaxReportDialog: Boolean = false,
  val selectedCustomer: Customer? = null,
  val selectedInvoice: Invoice? = null,
  val editingInvoice: Invoice? = null,
  val customerForNewBill: Customer? = null
)

private data class NavState(
  val selectedTab: FinanceTab = FinanceTab.HOME,
  val plannerSubTab: PlannerSubTab = PlannerSubTab.BUDGETS,
  val selectedFilter: FilterCategory = FilterCategory.ALL,
  val searchQuery: String = "",
  val currencySymbol: String = "Rs",
  val userRole: UserRole = UserRole.OWNER,
  val employeePermissions: EmployeePermissions = EmployeePermissions(),
  val appMode: AppMode = AppMode.BUSINESS_RETAIL,
  val appLanguage: AppLanguage = AppLanguage.URDU,
  val subscriptionState: SubscriptionState = SubscriptionState(),
  val userAccount: UserAccount = UserAccount(),
  val isFbrTaxMode: Boolean = false,
  val cartItems: Map<Long, Double> = emptyMap(),
  val services: List<ServiceItem> = emptyList(),
  val selectedFeaturedServiceIds: Set<Long> = emptySet(),
  val selectedServiceCategory: String = "ALL",
  val shopBioData: ShopBioData = ShopBioData()
)

private data class DialogState(
  val showAddTransactionDialog: Boolean = false,
  val showAddAccountDialog: Boolean = false,
  val showAddBillDialog: Boolean = false,
  val showAddRecurringDialog: Boolean = false,
  val editingRecurring: RecurringTransaction? = null,
  val showAddEditBudgetDialog: Boolean = false,
  val editingBudget: Budget? = null,
  val showAddEditInventoryDialog: Boolean = false,
  val editingInventoryItem: InventoryItem? = null,
  val showQuickStockAdjustDialog: Boolean = false,
  val adjustingInventoryItem: InventoryItem? = null,
  val showProfileDialog: Boolean = false,
  val selectedTransaction: Transaction? = null,
  val initialTransactionType: TransactionType = TransactionType.EXPENSE,
  val businessProfile: BusinessProfile = BusinessProfile(),
  val isProMember: Boolean = true,
  val showUpgradeDialog: Boolean = false,
  val showStockExportDialog: Boolean = false,
  val showStockImportDialog: Boolean = false
)

class FinanceViewModel(application: Application) : AndroidViewModel(application) {
  private val repository: FinanceRepository
  private val businessCore: com.example.business.BusinessCore
  private val preferences = com.example.data.local.BusinessPreferences(application)

  private val _features = MutableStateFlow(preferences.read("features", com.example.data.model.BusinessFeatures()))
  private val _selectedTab = MutableStateFlow(FinanceTab.HOME)
  private val _plannerSubTab = MutableStateFlow(PlannerSubTab.BUDGETS)
  private val _selectedFilter = MutableStateFlow(FilterCategory.ALL)
  private val _searchQuery = MutableStateFlow("")
  private val _currencySymbol = MutableStateFlow(preferences.read("currency", "Rs"))
  private val _showAddTransactionDialog = MutableStateFlow(false)
  private val _showAddAccountDialog = MutableStateFlow(false)
  private val _showAddBillDialog = MutableStateFlow(false)
  private val _showAddRecurringDialog = MutableStateFlow(false)
  private val _editingRecurring = MutableStateFlow<RecurringTransaction?>(null)
  private val _showAddEditBudgetDialog = MutableStateFlow(false)
  private val _editingBudget = MutableStateFlow<Budget?>(null)
  private val _showAddEditInventoryDialog = MutableStateFlow(false)
  private val _editingInventoryItem = MutableStateFlow<InventoryItem?>(null)
  private val _showQuickStockAdjustDialog = MutableStateFlow(false)
  private val _adjustingInventoryItem = MutableStateFlow<InventoryItem?>(null)
  private val _showProfileDialog = MutableStateFlow(false)
  private val _selectedTransaction = MutableStateFlow<Transaction?>(null)
  private val _initialTransactionType = MutableStateFlow(TransactionType.EXPENSE)
  private val _lastProcessedMessage = MutableStateFlow<String?>(null)
  private val _businessProfile = MutableStateFlow(preferences.read("profile", BusinessProfile()))
  private val _isProMember = MutableStateFlow(preferences.read("pro", true))
  private val _showUpgradeDialog = MutableStateFlow(false)
  private val _showStockExportDialog = MutableStateFlow(false)
  private val _showStockImportDialog = MutableStateFlow(false)

  // Billing & Customer StateFlows
  private val _showAddInvoiceDialog = MutableStateFlow(false)
  private val _showAddCustomerDialog = MutableStateFlow(false)
  private val _showCustomerDetailDialog = MutableStateFlow(false)
  private val _showIndustryCatalogDialog = MutableStateFlow(false)
  private val _showInvoiceDetailDialog = MutableStateFlow(false)
  private val _showShopProfileDialog = MutableStateFlow(false)
  private val _showShopAccountsDialog = MutableStateFlow(false)
  private val _selectedCustomer = MutableStateFlow<Customer?>(null)
  private val _selectedInvoice = MutableStateFlow<Invoice?>(null)
  private val _editingInvoice = MutableStateFlow<Invoice?>(null)
  private val _customerForNewBill = MutableStateFlow<Customer?>(null)

  // App Config, Roles & Subscription StateFlows
  private var ownerVerified=false
  private val _ownerAuthRequired=MutableStateFlow(true)
  private val _userRole = MutableStateFlow(UserRole.OWNER)
  private val _employeePermissions = MutableStateFlow(preferences.read("permissions", EmployeePermissions()))
  private val _appMode = MutableStateFlow(preferences.read("mode", AppMode.BUSINESS_RETAIL))
  private val _appLanguage = MutableStateFlow(preferences.read("language", AppLanguage.URDU))
  private val _subscriptionState = MutableStateFlow(loadEntitlement())
  private val _showTrialLockDialog = MutableStateFlow(false)
  private val _showRoleLoginDialog = MutableStateFlow(false)
  private val _showEmployeePermissionsDialog = MutableStateFlow(false)
  private val _showPendingScreenshotDialog = MutableStateFlow(false)
  private val _showAuthDialog = MutableStateFlow(false)
  private val _showFbrTaxReportDialog = MutableStateFlow(false)
  private val _userAccount = MutableStateFlow(preferences.read("user", UserAccount()))
  private val _isFbrTaxMode = MutableStateFlow(preferences.read("taxMode", false))
  private val _cartItems = MutableStateFlow<Map<Long, Double>>(readSavedCart())
  val operationsArea = MutableStateFlow("hub")
  private lateinit var advancedEngine: com.example.business.AdvancedWorkflowEngine
  private lateinit var tradeEngine: com.example.business.TradeEngine

  // Services & Shop Bio StateFlows
  private val _services = MutableStateFlow<List<ServiceItem>>(preferences.readServices(DefaultServicesProvider.getInitialDefaultServices()))
  private val _selectedFeaturedServiceIds = MutableStateFlow<Set<Long>>(preferences.readFeatured(setOf(101L, 102L, 103L)))
  private val _selectedServiceCategory = MutableStateFlow(preferences.read("serviceCategory", "ALL"))
  private val _shopBioData = MutableStateFlow(preferences.read("bio", ShopBioData()))

  init {
    val database = FinanceDatabase.getDatabase(application, viewModelScope)
    repository = FinanceRepository(database.financeDao(), database)
    businessCore = com.example.business.BusinessCore(database)
    tradeEngine = com.example.business.TradeEngine(database)
    advancedEngine = com.example.business.AdvancedWorkflowEngine(database)
    persist("features", _features)
    persist("pro", _isProMember)
    persist("taxMode", _isFbrTaxMode)
    persist("serviceCategory", _selectedServiceCategory)
    persist("currency", _currencySymbol)
    persist("profile", _businessProfile)
    persist("permissions", _employeePermissions)
    persist("mode", _appMode)
    persist("language", _appLanguage)
    persist("subscription", _subscriptionState)
    viewModelScope.launch { while (true) { refreshSubscription(); kotlinx.coroutines.delay(60_000L) } }
    persist("user", _userAccount)
    persist("bio", _shopBioData)
    viewModelScope.launch(Dispatchers.IO) { _services.collect { preferences.writeServices(it) } }
    viewModelScope.launch(Dispatchers.IO) { _selectedFeaturedServiceIds.collect { preferences.writeFeatured(it) } }
    viewModelScope.launch(Dispatchers.IO) {
      repository.ensurePakistaniAccounts()
      processDueRecurringTransactions()
    }
  }

  private inline fun <reified T : Any> persist(key: String, flow: MutableStateFlow<T>) {
    viewModelScope.launch(Dispatchers.IO) { flow.collect { preferences.write(key, it) } }
  }

  // Combine repository flows into typed DataState
  private val dataFlow = combine(
    combine(
      repository.allTransactions,
      repository.allAccounts,
      repository.allBills,
      repository.allBudgets
    ) { txs: List<Transaction>, accs: List<Account>, bills: List<Bill>, budgets: List<Budget> ->
      Tuple4(txs, accs, bills, budgets)
    },
    combine(
      repository.allRecurringTransactions,
      repository.allInventoryItems,
      repository.allCustomers,
      repository.allInvoices
    ) { recurring: List<RecurringTransaction>, inventory: List<InventoryItem>, customers: List<Customer>, invoices: List<Invoice> ->
      Tuple4(recurring, inventory, customers, invoices)
    }
  ) { t1, t2 ->
    DataState(
      transactions = t1.first,
      accounts = t1.second,
      bills = t1.third,
      budgets = t1.fourth,
      recurring = t2.first,
      inventory = t2.second,
      customers = t2.third,
      invoices = t2.fourth
    )
  }

  // Combine navigation flows into typed NavState
  private val navFlow = combine(
    combine(_selectedTab, _plannerSubTab, _selectedFilter, _searchQuery, _currencySymbol) { a, b, c, d, e -> Tuple5(a, b, c, d, e) },
    combine(_userRole, _employeePermissions, _appMode, _appLanguage, _subscriptionState) { a, b, c, d, e -> Tuple5(a, b, c, d, e) },
    combine(_userAccount, _isFbrTaxMode, _cartItems) { a, b, c -> Triple(a, b, c) },
    combine(_services, _selectedFeaturedServiceIds, _selectedServiceCategory, _shopBioData) { a, b, c, d -> Tuple4(a, b, c, d) }
  ) { n1, n2, n3, n4 ->
    NavState(
      selectedTab = n1.first,
      plannerSubTab = n1.second,
      selectedFilter = n1.third,
      searchQuery = n1.fourth,
      currencySymbol = n1.fifth,
      userRole = n2.first,
      employeePermissions = n2.second,
      appMode = n2.third,
      appLanguage = n2.fourth,
      subscriptionState = n2.fifth,
      userAccount = n3.first,
      isFbrTaxMode = n3.second,
      cartItems = n3.third,
      services = n4.first,
      selectedFeaturedServiceIds = n4.second,
      selectedServiceCategory = n4.third,
      shopBioData = n4.fourth
    )
  }

  // Combine billing dialog flows
  private val billingDialogFlow = combine(
    combine(_showAddInvoiceDialog, _showAddCustomerDialog, _showCustomerDetailDialog, _showIndustryCatalogDialog) { a, b, c, d -> Tuple4(a, b, c, d) },
    combine(_selectedCustomer, _selectedInvoice, _editingInvoice, _customerForNewBill) { a, b, c, d -> Tuple4(a, b, c, d) },
    combine(_showInvoiceDetailDialog, _showShopProfileDialog, _showShopAccountsDialog, _showTrialLockDialog) { a, b, c, d -> Tuple4(a, b, c, d) },
    combine(_showRoleLoginDialog, _showEmployeePermissionsDialog, _showPendingScreenshotDialog, _showAuthDialog, _showFbrTaxReportDialog) { a, b, c, d, e -> Tuple5(a, b, c, d, e) }
  ) { t1, t2, t3, t4 ->
    BillingDialogState(
      showAddInvoiceDialog = t1.first,
      showAddCustomerDialog = t1.second,
      showCustomerDetailDialog = t1.third,
      showIndustryCatalogDialog = t1.fourth,
      selectedCustomer = t2.first,
      selectedInvoice = t2.second,
      editingInvoice = t2.third,
      customerForNewBill = t2.fourth,
      showInvoiceDetailDialog = t3.first,
      showShopProfileDialog = t3.second,
      showShopAccountsDialog = t3.third,
      showTrialLockDialog = t3.fourth,
      showRoleLoginDialog = t4.first,
      showEmployeePermissionsDialog = t4.second,
      showPendingScreenshotDialog = t4.third,
      showAuthDialog = t4.fourth,
      showFbrTaxReportDialog = t4.fifth
    )
  }

  // Combine dialog flows into typed DialogState
  private val dialogFlow = combine(
    combine(
      _showAddTransactionDialog,
      _showAddAccountDialog,
      _showAddBillDialog,
      _showAddRecurringDialog,
      _editingRecurring
    ) { a, b, c, d, e ->
      Tuple5(a, b, c, d, e)
    },
    combine(
      _showAddEditBudgetDialog,
      _editingBudget,
      _showAddEditInventoryDialog,
      _editingInventoryItem,
      _showQuickStockAdjustDialog
    ) { a, b, c, d, e ->
      Tuple5(a, b, c, d, e)
    },
    combine(
      _adjustingInventoryItem,
      _showProfileDialog,
      _selectedTransaction,
      _initialTransactionType,
      _businessProfile
    ) { a, b, c, d, e ->
      Tuple5(a, b, c, d, e)
    },
    combine(
      _isProMember,
      _showUpgradeDialog,
      _showStockExportDialog,
      _showStockImportDialog
    ) { isPro, showUp, showExp, showImp ->
      Tuple4(isPro, showUp, showExp, showImp)
    }
  ) { d1, d2, d3, d4 ->
    DialogState(
      showAddTransactionDialog = d1.first,
      showAddAccountDialog = d1.second,
      showAddBillDialog = d1.third,
      showAddRecurringDialog = d1.fourth,
      editingRecurring = d1.fifth,
      showAddEditBudgetDialog = d2.first,
      editingBudget = d2.second,
      showAddEditInventoryDialog = d2.third,
      editingInventoryItem = d2.fourth,
      showQuickStockAdjustDialog = d2.fifth,
      adjustingInventoryItem = d3.first,
      showProfileDialog = d3.second,
      selectedTransaction = d3.third,
      initialTransactionType = d3.fourth,
      businessProfile = d3.fifth,
      isProMember = d4.first,
      showUpgradeDialog = d4.second,
      showStockExportDialog = d4.third,
      showStockImportDialog = d4.fourth
    )
  }

  private val baseUiState: StateFlow<FinanceUiState> = combine(
    dataFlow,
    navFlow,
    dialogFlow,
    billingDialogFlow
  ) { data: DataState, nav: NavState, dialog: DialogState, billing: BillingDialogState ->
    val transactions = data.transactions
    val accounts = data.accounts
    val bills = data.bills
    val rawBudgets = data.budgets
    val recurring = data.recurring
    val inventoryItems = data.inventory
    val customers = data.customers
    val invoices = data.invoices

    val calculatedBalance = if (accounts.isNotEmpty()) {
      accounts.sumOf { if (it.accountType == "Credit Card") -it.balance else it.balance }
    } else {
      0.0
    }

    val incomeTotal = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    val expenseTotal = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }

    // Dynamic budget calculation
    val currentMonthExpensesByCategory = transactions
      .filter { it.type == TransactionType.EXPENSE }
      .groupBy { it.category.trim() }
      .mapValues { entry -> entry.value.sumOf { it.amount } }

    val updatedBudgets = rawBudgets.map { budget ->
      val dynamicSpent = currentMonthExpensesByCategory[budget.category.trim()] ?: budget.spentAmount
      budget.copy(spentAmount = dynamicSpent)
    }

    // Budget Alerts
    val alerts = updatedBudgets.mapNotNull { b ->
      val limit = b.limitAmount.coerceAtLeast(0.01)
      val percent = (b.spentAmount / limit) * 100.0
      if (percent >= 80.0) {
        BudgetAlert(
          budgetId = b.id,
          category = b.category,
          icon = b.icon,
          limitAmount = b.limitAmount,
          spentAmount = b.spentAmount,
          percentSpent = percent,
          isExceeded = percent >= 100.0
        )
      } else {
        null
      }
    }.sortedByDescending { it.percentSpent }

    val totalBudgetLimit = updatedBudgets.sumOf { it.limitAmount }
    val totalBudgetSpent = updatedBudgets.sumOf { it.spentAmount }

    val filtered = transactions.filter { tx ->
      val matchesQuery = nav.searchQuery.isBlank() ||
        tx.title.contains(nav.searchQuery, ignoreCase = true) ||
        tx.category.contains(nav.searchQuery, ignoreCase = true) ||
        tx.note.contains(nav.searchQuery, ignoreCase = true)

      val matchesFilter = when (nav.selectedFilter) {
        FilterCategory.ALL -> true
        FilterCategory.EXPENSES -> tx.type == TransactionType.EXPENSE
        FilterCategory.INCOME -> tx.type == TransactionType.INCOME
        FilterCategory.SHOPPING -> tx.category.contains("Shopping", ignoreCase = true)
        FilterCategory.FOOD -> tx.category.contains("Food", ignoreCase = true) || tx.category.contains("Dining", ignoreCase = true)
        FilterCategory.BILLS -> tx.category.contains("Bill", ignoreCase = true) || tx.category.contains("Utility", ignoreCase = true)
        FilterCategory.TRANSPORT -> tx.category.contains("Transport", ignoreCase = true)
      }

      matchesQuery && matchesFilter
    }

    val changePct = if (expenseTotal > 0) {
      ((incomeTotal - expenseTotal) / (incomeTotal.coerceAtLeast(1.0))) * 10.0
    } else {
      4.2
    }

    FinanceUiState(
      selectedTab = nav.selectedTab,
      plannerSubTab = nav.plannerSubTab,
      selectedFilter = nav.selectedFilter,
      searchQuery = nav.searchQuery,
      currencySymbol = nav.currencySymbol,
      transactions = transactions,
      filteredTransactions = filtered,
      accounts = accounts,
      bills = bills,
      budgets = updatedBudgets,
      recurringTransactions = recurring,
      inventoryItems = inventoryItems,
      budgetAlerts = alerts,
      totalBudgetLimit = totalBudgetLimit,
      totalBudgetSpent = totalBudgetSpent,
      totalBalance = calculatedBalance,
      totalIncome = incomeTotal,
      totalExpense = expenseTotal,
      monthlyChangePercent = changePct,
      showAddTransactionDialog = dialog.showAddTransactionDialog,
      showAddAccountDialog = dialog.showAddAccountDialog,
      showAddBillDialog = dialog.showAddBillDialog,
      showAddRecurringDialog = dialog.showAddRecurringDialog,
      editingRecurring = dialog.editingRecurring,
      showAddEditBudgetDialog = dialog.showAddEditBudgetDialog,
      editingBudget = dialog.editingBudget,
      showAddEditInventoryDialog = dialog.showAddEditInventoryDialog,
      editingInventoryItem = dialog.editingInventoryItem,
      showQuickStockAdjustDialog = dialog.showQuickStockAdjustDialog,
      adjustingInventoryItem = dialog.adjustingInventoryItem,
      showProfileDialog = dialog.showProfileDialog,
      selectedTransaction = dialog.selectedTransaction,
      initialTransactionType = dialog.initialTransactionType,
      lastProcessedRecurringMessage = _lastProcessedMessage.value,
      businessProfile = dialog.businessProfile,
      isProMember = dialog.isProMember,
      showUpgradeDialog = dialog.showUpgradeDialog,
      showStockExportDialog = dialog.showStockExportDialog,
      showStockImportDialog = dialog.showStockImportDialog,
      customers = customers,
      invoices = invoices,
      selectedCustomer = billing.selectedCustomer,
      selectedInvoice = billing.selectedInvoice,
      editingInvoice = billing.editingInvoice,
      customerForNewBill = billing.customerForNewBill,
      showAddInvoiceDialog = billing.showAddInvoiceDialog,
      showAddCustomerDialog = billing.showAddCustomerDialog,
      showCustomerDetailDialog = billing.showCustomerDetailDialog,
      showIndustryCatalogDialog = billing.showIndustryCatalogDialog,
      showInvoiceDetailDialog = billing.showInvoiceDetailDialog,
      showShopProfileDialog = billing.showShopProfileDialog,
      showShopAccountsDialog = billing.showShopAccountsDialog,
      showTrialLockDialog = billing.showTrialLockDialog,
      showRoleLoginDialog = billing.showRoleLoginDialog,
      showEmployeePermissionsDialog = billing.showEmployeePermissionsDialog,
      showPendingScreenshotDialog = billing.showPendingScreenshotDialog,
      showAuthDialog = billing.showAuthDialog,
      showFbrTaxReportDialog = billing.showFbrTaxReportDialog,
      userRole = nav.userRole,
      employeePermissions = nav.employeePermissions,
      appMode = nav.appMode,
      appLanguage = nav.appLanguage,
      subscriptionState = nav.subscriptionState,
      userAccount = nav.userAccount,
      isFbrTaxMode = nav.isFbrTaxMode,
      cartItems = nav.cartItems,
      services = nav.services,
      selectedFeaturedServiceIds = nav.selectedFeaturedServiceIds,
      selectedServiceCategory = nav.selectedServiceCategory,
      shopBioData = nav.shopBioData
    )
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = FinanceUiState()
  )

  val uiState: StateFlow<FinanceUiState> = combine(baseUiState, _features, businessCore.records, businessCore.movements,_ownerAuthRequired) { state, features, records, movements, auth -> state.copy(features = features, businessRecords = records, stockMovements = movements,ownerAuthRequired=auth) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinanceUiState(features = _features.value))

  fun saveExpandedItem(item: InventoryItem, done: (String?) -> Unit) {
    viewModelScope.launch {
      try {
        requireBusinessAccess()
        require(item.name.isNotBlank() && item.unit.isNotBlank())
        require(listOf(item.costPrice,item.salePrice,item.currentStock,item.lowStockThreshold).all { it.isFinite() && it >= 0 })
        val details = com.example.business.BusinessLibrary.details(item.detailsJson)
        listOf("conversion","saleConversion").forEach { key -> val factor=details.optString(key,"1").toDoubleOrNull(); require(factor != null && factor.isFinite() && factor > 0) { "Invalid unit conversion / یونٹ تبدیلی درست نہیں" } }
        listOf("wholesale","minimum","taxRate","commission","makingCharges").forEach { key -> val raw=details.optString(key); if(raw.isNotBlank()) require(raw.toDoubleOrNull()?.let { it.isFinite() && it >= 0 } == true) { "Invalid $key / درست رقم درج کریں" } }
        require(uiState.value.inventoryItems.none { it.id != item.id && ((item.barcode.isNotBlank() && it.barcode.equals(item.barcode,true)) || (it.name.equals(item.name,true) && it.category.equals(item.category,true))) }) { "Item / barcode already exists / سامان یا بارکوڈ پہلے موجود ہے" }
        if(item.id==0L) repository.insertInventoryItem(item) else repository.updateInventoryItem(item)
        closeAddEditInventoryDialog(); done(null)
      } catch(error: Exception) { done(error.message ?: "Save failed") }
    }
  }
  fun businessAction(action: suspend com.example.business.BusinessCore.() -> Unit, done: (String?) -> Unit) {
    viewModelScope.launch { try { requireBusinessAccess(); require(ownerVerified && _userRole.value == UserRole.OWNER) { "Owner access required / مالک کی رسائی ضروری ہے" }; businessCore.action(); done(null) } catch(error: Exception) { if(error is kotlinx.coroutines.CancellationException) throw error; done(error.message ?: "Unable to save") } }
  }
  fun seedTemplateDemo(templateId: String, done: (String?) -> Unit) {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) {done("Owner access required / مالک کی رسائی ضروری ہے");return}
    if(!businessAllowed()) {done("Business access required / کاروباری رسائی ضروری ہے");return}
    viewModelScope.launch {
      try {
        val database=FinanceDatabase.getDatabase(getApplication(),viewModelScope)
        database.withTransaction {
          val template = com.example.business.BusinessLibrary.find(templateId)
          val dao = database.financeDao()
          val existing = dao.getAllInventoryItems().first()
          val existingNames = existing.map { it.name.trim().lowercase(Locale.ROOT) }.toSet()
          val demoItems = com.example.business.DemoLibrary.items(templateId)
          val missingItems = demoItems.filter { it.name.trim().lowercase(Locale.ROOT) !in existingNames }
          if (missingItems.isNotEmpty()) dao.insertInventoryItems(missingItems)

          // Seed workflow examples only on a genuinely new workspace. Re-importing
          // a category adds missing catalogue entries but never duplicates ledgers,
          // customers, quotations, jobs or production records.
          val recordsBefore = database.businessDao().allRecords()
          if (existing.isEmpty() && recordsBefore.isEmpty() && dao.getTransactionCount() == 0) {
            com.example.business.DemoLibrary.workflows(database, templateId)
          }

          _businessProfile.value = _businessProfile.value.copy(
            templateId = templateId, sector = template.sector,
            category = template.category, shopType = template.name
          )
          val categoryServices = com.example.business.DemoLibrary.services(templateId)
          if (categoryServices.isNotEmpty()) {
            val oldNames = _services.value.map { it.name.trim().lowercase(Locale.ROOT) }.toSet()
            _services.value = _services.value + categoryServices.filter {
              it.name.trim().lowercase(Locale.ROOT) !in oldNames
            }
          }
          // Respect the feature switches chosen in Business Builder. Demo seeding
          // adds sample records but never silently changes a user's feature choices.
          if (_appMode.value != AppMode.PERSONAL_KHATA) {
            startBusinessTrial()
            _appMode.value = if (template.sector == "Services") AppMode.SERVICE_BASED else AppMode.BUSINESS_RETAIL
            _selectedTab.value = FinanceTab.HOME
            _userAccount.value = _userAccount.value.copy(hasSelectedMode = true)
          }
        }
        done(null)
      } catch(error: Exception) { done(error.message ?: "Demo could not be loaded") }
    }
  }

  fun receiveCustomerCash(customer: Customer, amount: Double, note: String, done: (String?) -> Unit) {
    viewModelScope.launch {
      try {
        requireBusinessAccess(); require(ownerVerified && _userRole.value==UserRole.OWNER)
        val updated = repository.receiveCustomerCashAtomically(customer.id, amount, note)
        _selectedCustomer.value = updated
        done(null)
      } catch (error: Exception) { if (error is kotlinx.coroutines.CancellationException) throw error; done(error.message ?: "Receipt failed") }
    }
  }

  fun exportBusinessBackup(uri: android.net.Uri, password: String, done: (String) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val result = try {
        val context = getApplication<Application>()
        val db = FinanceDatabase.getDatabase(context, viewModelScope)
        val data = com.example.data.local.BusinessBackup.encrypt(com.example.data.local.BusinessBackup.snapshot(context, db), password.toCharArray())
        context.contentResolver.openOutputStream(uri)?.use { it.write(data) } ?: error("Could not open backup destination")
        if (_appLanguage.value == AppLanguage.URDU) "بیک اپ محفوظ ہو گیا" else "Encrypted backup saved"
      } catch (error: Exception) { if (error is kotlinx.coroutines.CancellationException) throw error; error.message ?: "Backup failed" }
      withContext(Dispatchers.Main) { done(result) }
    }
  }

  fun restoreBusinessBackup(uri: android.net.Uri, password: String, done: (String) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val result = try {
        val context = getApplication<Application>()
        val db = FinanceDatabase.getDatabase(context, viewModelScope)
        val bytes = context.contentResolver.openInputStream(uri)?.use { stream ->
          val buffer = java.io.ByteArrayOutputStream(); val chunk = ByteArray(8192)
          while (true) { val n = stream.read(chunk); if (n < 0) break; require(buffer.size() + n <= 100 * 1024 * 1024) { "Backup too large" }; buffer.write(chunk, 0, n) }; buffer.toByteArray()
        } ?: error("Could not open backup")
        val backup = com.example.data.local.BusinessBackup.decrypt(bytes, password.toCharArray())
        val recovery = java.io.File(context.filesDir, "recovery-before-restore.afbackup")
        recovery.writeBytes(com.example.data.local.BusinessBackup.encrypt(com.example.data.local.BusinessBackup.snapshot(context, db), password.toCharArray()))
        com.example.data.local.BusinessBackup.restore(context, db, backup)
        _businessProfile.value = preferences.read("profile", BusinessProfile())
        _features.value = preferences.read("features", com.example.data.model.BusinessFeatures())
        _currencySymbol.value = preferences.read("currency", "Rs")
        _appLanguage.value = preferences.read("language", AppLanguage.URDU)
        _services.value = preferences.readServices(emptyList())
        _selectedFeaturedServiceIds.value = preferences.readFeatured(emptySet())
        _appMode.value = preferences.read("mode", AppMode.BUSINESS_RETAIL)
        _shopBioData.value = preferences.read("bio", ShopBioData())
        _employeePermissions.value = preferences.read("permissions", EmployeePermissions())
        _isFbrTaxMode.value = preferences.read("taxMode", false)
        _userAccount.value = preferences.read("user", UserAccount())
        saveCart(emptyMap()); _selectedTab.value = FinanceTab.HOME
        if (_appLanguage.value == AppLanguage.URDU) "بیک اپ بحال ہو گیا" else "Backup restored"
      } catch (error: Exception) { if (error is kotlinx.coroutines.CancellationException) throw error; "Restore failed / بحالی ناکام: ${error.message ?: "Invalid backup or password"}" }
      withContext(Dispatchers.Main) { done(result) }
    }
  }

  fun updateBusinessSetup(profile: BusinessProfile, features: com.example.data.model.BusinessFeatures, currency: String) {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    if(!businessAllowed()) return
    _businessProfile.value = profile
    _features.value = features
    _currencySymbol.value = currency
    _selectedTab.value = FinanceTab.HOME
  }

  // --- Central POS Shopping Cart Operations ---

  private fun readSavedCart(): Map<Long,Double> {
    val json=org.json.JSONObject(preferences.read("cart","{}"));val result=mutableMapOf<Long,Double>()
    json.keys().forEach {key -> val id=key.toLongOrNull();val qty=json.optDouble(key);if(id!=null&&qty.isFinite()&&qty>0)result[id]=qty}
    return result
  }
  private fun saveCart(cart:Map<Long,Double>) { preferences.write("cart",org.json.JSONObject().apply {cart.forEach {(id,qty)->put(id.toString(),qty)}}.toString());_cartItems.value=cart }
  fun advancedAction(action:suspend com.example.business.AdvancedWorkflowEngine.()->Unit,done:(String?)->Unit) {
    viewModelScope.launch {try {requireBusinessAccess();require(ownerVerified && _userRole.value==UserRole.OWNER){"Owner access required / مالک کی رسائی ضروری ہے"};advancedEngine.action();done(null)}catch(e:Exception){if(e is kotlinx.coroutines.CancellationException)throw e;showOperationError(e);done(e.message ?: "Unable to post")}}
  }
  fun openCommerce() { operationsArea.value="commerce";selectTab(FinanceTab.OPERATIONS) }
  fun tradeAction(action:suspend com.example.business.TradeEngine.()->Unit,done:(String?)->Unit) {
    viewModelScope.launch {try {requireBusinessAccess();require(ownerVerified && _userRole.value==UserRole.OWNER){"Owner access required / مالک کی رسائی ضروری ہے"};tradeEngine.action();done(null)}catch(e:Exception){if(e is kotlinx.coroutines.CancellationException)throw e;done(e.message ?: "Unable to post")}}
  }
  fun holdCart(name:String,done:(String?)->Unit) {
    if(!businessAllowed()) {done("Business access required / کاروباری رسائی ضروری ہے");return}
    viewModelScope.launch {try {
      require(_cartItems.value.isNotEmpty());val lines=org.json.JSONArray().apply {_cartItems.value.forEach {(id,qty)->put(org.json.JSONObject().put("itemId",id).put("quantity",qty))}}
      FinanceDatabase.getDatabase(getApplication(),viewModelScope).businessDao().insert(com.example.business.BusinessRecord(kind="POS_DRAFT",title=name.ifBlank {"Held bill"},payload=org.json.JSONObject().put("lines",lines).toString(),createdBy=_userRole.value.name))
      clearCart();done(null)
    }catch(e:Exception){done(e.message ?: "Hold failed")}}
  }
  fun resumeCart(draftId:String,done:(String?)->Unit) {
    if(!businessAllowed()) {done("Business access required / کاروباری رسائی ضروری ہے");return}
    viewModelScope.launch {try {
      require(_cartItems.value.isEmpty()) {"Hold or clear the current cart first / موجودہ بل پہلے محفوظ یا خالی کریں"}
      val db=FinanceDatabase.getDatabase(getApplication(),viewModelScope);val draft=db.businessDao().record(draftId) ?: error("Draft missing")
      require(draft.kind=="POS_DRAFT"&&draft.status=="OPEN");val lines=org.json.JSONObject(draft.payload).getJSONArray("lines");val cart=mutableMapOf<Long,Double>()
      for(i in 0 until lines.length()){val row=lines.getJSONObject(i);val id=row.getLong("itemId");val q=row.getDouble("quantity");require(db.financeDao().getInventoryItemById(id)!=null&&q.isFinite()&&q>0);cart[id]=q}
      saveCart(cart);db.businessDao().update(draft.copy(status="RESUMED",updatedAt=System.currentTimeMillis()));done(null)
    }catch(e:Exception){done(e.message ?: "Resume failed")}}
  }

  fun addToCart(itemId: Long, qty: Double = 1.0) {
    if(!businessAllowed()) return
    if(!qty.isFinite() || qty<=0) return
    val current = _cartItems.value.toMutableMap()
    val existing = current[itemId] ?: 0.0
    current[itemId] = existing + qty
    saveCart(current)
  }

  fun updateCartQty(itemId: Long, qty: Double) {
    if(!businessAllowed()) return
    if(!qty.isFinite()) return
    val current = _cartItems.value.toMutableMap()
    if (qty <= 0.0) {
      current.remove(itemId)
    } else {
      current[itemId] = qty
    }
    saveCart(current)
  }

  fun removeFromCart(itemId: Long) {
    val current = _cartItems.value.toMutableMap()
    current.remove(itemId)
    saveCart(current)
  }

  fun clearCart() {
    saveCart(emptyMap())
  }

  fun selectTab(tab: FinanceTab) {
    if(_appMode.value==AppMode.PERSONAL_KHATA || !_subscriptionState.value.hasBusinessAccess) {
      _selectedTab.value=FinanceTab.HOME
      if(tab!=FinanceTab.HOME) _showTrialLockDialog.value=true
      return
    }
    val f = _features.value
    val enabled = when (tab) {
      FinanceTab.STOCK -> f.products
      FinanceTab.SERVICES -> f.services
      FinanceTab.POS -> f.pos
      FinanceTab.LEDGERS -> f.khata
      FinanceTab.REPORTS -> f.reports
      FinanceTab.PURCHASES -> f.purchases
      else -> true
    }
    if (enabled) _selectedTab.value = tab
    else android.widget.Toast.makeText(getApplication(), if (_appLanguage.value == AppLanguage.URDU) "یہ فیچر سیٹنگز سے فعال کریں" else "Enable this feature in Settings", android.widget.Toast.LENGTH_SHORT).show()
  }

  fun setPlannerSubTab(subTab: PlannerSubTab) {
    _plannerSubTab.value = subTab
  }

  fun setFilter(filter: FilterCategory) {
    _selectedFilter.value = filter
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setCurrencySymbol(symbol: String) {
    _currencySymbol.value = symbol
  }

  // --- App Mode, Multi-Role & Subscription Management ---

  fun openShopAccountsDialog() {
    _showShopAccountsDialog.value = true
  }

  fun closeShopAccountsDialog() {
    _showShopAccountsDialog.value = false
  }

  fun openRoleLoginDialog() {
    _showRoleLoginDialog.value = true
  }

  fun closeRoleLoginDialog() {
    _showRoleLoginDialog.value = false
  }

  fun openEmployeePermissionsDialog() {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    _showEmployeePermissionsDialog.value = true
  }

  fun closeEmployeePermissionsDialog() {
    _showEmployeePermissionsDialog.value = false
  }

  fun openPendingScreenshotDialog() {
    _showPendingScreenshotDialog.value = true
  }

  fun closePendingScreenshotDialog() {
    _showPendingScreenshotDialog.value = false
  }

  fun openTrialLockDialog() {
    _showTrialLockDialog.value = true
  }

  fun closeTrialLockDialog() {
    _showTrialLockDialog.value = false
  }

  fun openAuthDialog() {
    _showAuthDialog.value = true
  }

  fun closeAuthDialog() {
    _showAuthDialog.value = false
  }

  fun openFbrTaxReportDialog() {
    _showFbrTaxReportDialog.value = true
  }

  fun closeFbrTaxReportDialog() {
    _showFbrTaxReportDialog.value = false
  }

  fun toggleFbrTaxMode() {
    _isFbrTaxMode.value = !_isFbrTaxMode.value
  }

  fun loginUser(mobile: String, shopName: String, ownerName: String = "", region: String = "") {
    _userAccount.value = _userAccount.value.copy(
      mobileNumber = mobile,
      shopName = shopName.ifBlank { "Arshad Finance & Traders" },
      ownerName = ownerName.ifBlank { _userAccount.value.ownerName },
      cityRegion = region.ifBlank { _userAccount.value.cityRegion },
      lastLoginRegion = region.trim(),
      isLoggedIn = true,
      hasSelectedMode = false,
      lastLoginTimeMillis = System.currentTimeMillis()
    )
    _businessProfile.value = _businessProfile.value.copy(
      businessName = shopName.ifBlank { "Arshad Finance & Traders" },
      ownerName = ownerName.ifBlank { _businessProfile.value.ownerName },
      phone = mobile
    )
    // Local profile access must never load demo data or modify business records.
  }

  fun confirmAppMode(mode: AppMode) {
    if(mode!=AppMode.PERSONAL_KHATA) startBusinessTrial()
    _selectedTab.value=FinanceTab.HOME
    _appMode.value = mode
    _userAccount.value = _userAccount.value.copy(
      hasSelectedMode = true
    )
  }

  fun openModeSelection() {
    _userAccount.value = _userAccount.value.copy(
      hasSelectedMode = false
    )
  }

  fun logoutUser() {
    ownerVerified=false;_ownerAuthRequired.value=true
    _userAccount.value = _userAccount.value.copy(
      isLoggedIn = false,
      hasSelectedMode = false
    )
  }

  fun ownerPinConfigured():Boolean = getApplication<Application>().getSharedPreferences("owner_security",android.content.Context.MODE_PRIVATE).contains("pinHash")
  fun validateOwnerPin(pin:String):Boolean {
    if(!pin.matches(Regex("[0-9]{4,8}"))) return false
    val p=getApplication<Application>().getSharedPreferences("owner_security",android.content.Context.MODE_PRIVATE)
    val now=System.currentTimeMillis()
    if(now<p.getLong("blockedUntil",0L))return false
    val fresh=!p.contains("pinHash")
    val salt=if(fresh) ByteArray(16).also {java.security.SecureRandom().nextBytes(it)} else android.util.Base64.decode(p.getString("pinSalt", ""),android.util.Base64.DEFAULT)
    val spec=javax.crypto.spec.PBEKeySpec(pin.toCharArray(),salt,120000,256)
    val digest=try {javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded}finally{spec.clearPassword()}
    val valid=fresh || java.security.MessageDigest.isEqual(digest,android.util.Base64.decode(p.getString("pinHash",""),android.util.Base64.DEFAULT))
    if(valid){val e=p.edit().putInt("failed",0).putLong("blockedUntil",0);if(fresh)e.putString("pinHash",android.util.Base64.encodeToString(digest,android.util.Base64.NO_WRAP)).putString("pinSalt",android.util.Base64.encodeToString(salt,android.util.Base64.NO_WRAP));check(e.commit());ownerVerified=true;_ownerAuthRequired.value=false;return true}
    val failures=p.getInt("failed",0)+1;p.edit().putInt("failed",failures).putLong("blockedUntil",if(failures>=5)now+60_000L else 0).commit();return false
  }
  fun setUserRole(role: UserRole) {
    if(role==UserRole.OWNER && !ownerVerified) return
    if(role==UserRole.EMPLOYEE && !ownerPinConfigured()) return
    _userRole.value = role
    if(role==UserRole.EMPLOYEE) ownerVerified=false
    _ownerAuthRequired.value=false
  }

  fun updateEmployeePermissions(perms: EmployeePermissions) {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    _employeePermissions.value = perms
  }

  fun setAppMode(mode: AppMode) {
    if(mode!=AppMode.PERSONAL_KHATA) startBusinessTrial()
    _selectedTab.value=FinanceTab.HOME
    _appMode.value = mode
    _userAccount.value = _userAccount.value.copy(
      hasSelectedMode = true
    )
  }

  fun setAppLanguage(lang: AppLanguage) {
    _appLanguage.value = lang
  }

  fun toggleLanguage() {
    _appLanguage.value = if (_appLanguage.value == AppLanguage.URDU) AppLanguage.ENGLISH else AppLanguage.URDU
  }

  private fun loadEntitlement(): SubscriptionState {
    val a=getApplication<Application>().getSharedPreferences("entitlement_anchor",android.content.Context.MODE_PRIVATE)
    val saved=preferences.read("subscription",SubscriptionState())
    val id=a.getString("deviceId",null) ?: java.util.UUID.randomUUID().toString()
    val legacy=saved.activationCode.isNotBlank() && !saved.activationCode.startsWith("AF1.")
    val start=a.getLong("trialStarted",if(legacy) saved.installDateMillis else saved.trialStartedMillis)
    val high=maxOf(a.getLong("lastSeen",0),saved.lastSeenMillis)
    val state=com.example.business.SubscriptionPolicy.refresh(saved.copy(deviceId=id,trialStartedMillis=start,lastSeenMillis=high,isSimulatedLocked=false),System.currentTimeMillis())
    check(a.edit().putString("deviceId",id).putLong("trialStarted",start).putLong("lastSeen",state.lastSeenMillis).commit())
    return state
  }
  fun refreshSubscription() {
    val s=com.example.business.SubscriptionPolicy.refresh(_subscriptionState.value,System.currentTimeMillis())
    _subscriptionState.value=s
    getApplication<Application>().getSharedPreferences("entitlement_anchor",android.content.Context.MODE_PRIVATE).edit().putLong("lastSeen",s.lastSeenMillis).commit()
    if(!s.hasBusinessAccess) _selectedTab.value=FinanceTab.HOME
  }
  private fun startBusinessTrial() {
    if(_subscriptionState.value.trialStartedMillis==0L) {
      val now=System.currentTimeMillis()
      _subscriptionState.value=_subscriptionState.value.copy(trialStartedMillis=now,lastSeenMillis=now)
      getApplication<Application>().getSharedPreferences("entitlement_anchor",android.content.Context.MODE_PRIVATE).edit().putLong("trialStarted",now).putLong("lastSeen",now).commit()
    }
  }
  private fun businessAllowed(): Boolean {
    refreshSubscription()
    val ok=!_ownerAuthRequired.value && _appMode.value!=AppMode.PERSONAL_KHATA && _subscriptionState.value.hasBusinessAccess
    if(!ok) _showTrialLockDialog.value=true
    return ok
  }
  private fun requireBusinessAccess() { require(businessAllowed()) { "Business access expired. Personal Khata stays free / کاروباری رسائی ختم؛ ذاتی کھاتہ مفت ہے" } }
  fun toggleSimulateTrialLock() { openTrialLockDialog() } // No production bypass toggle.
  fun activateSubscription(code: String): Boolean = runCatching {
    _subscriptionState.value=com.example.business.SubscriptionPolicy.activate(_subscriptionState.value,code,System.currentTimeMillis())
    preferences.write("subscription",_subscriptionState.value)
    _isProMember.value=true
    true
  }.getOrDefault(false)
  fun importEntitlement(uri:android.net.Uri,done:(String?)->Unit) {
    viewModelScope.launch(Dispatchers.IO) { val result=runCatching {
      val token=getApplication<Application>().contentResolver.openInputStream(uri)?.use {stream->val b=stream.readBytesLimited(16000);b.toString(Charsets.UTF_8).trim()} ?: error("Cannot open file")
      val p=com.example.business.SubscriptionPolicy.signedPayload(token)
      if(p.getString("type")=="merchant") {
        com.example.business.SubscriptionPolicy.merchant(token)
        _subscriptionState.value=_subscriptionState.value.copy(merchantConfig=token)
      } else require(activateSubscription(token)) { "Activation invalid, expired or for another phone / ایکٹیویشن درست نہیں یا دوسرے فون کی ہے" }
      preferences.write("subscription",_subscriptionState.value)
    }.exceptionOrNull()?.message
    withContext(Dispatchers.Main) {done(result)} }
  }
  private fun java.io.InputStream.readBytesLimited(limit:Int):ByteArray {
    val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(2048)
    while(true){val n=read(buffer);if(n<0)break;require(out.size()+n<=limit){"File too large"};out.write(buffer,0,n)}
    return out.toByteArray()
  }
  fun personalContact(name:String,phone:String,done:(String?)->Unit) {
    viewModelScope.launch {try {com.example.business.PersonalKhataEngine(FinanceDatabase.getDatabase(getApplication(),viewModelScope)).contact(name,phone);done(null)}catch(e:Exception){if(e is kotlinx.coroutines.CancellationException)throw e;done(e.message)}}
  }
  fun personalEntry(id:String,amount:Double,direction:String,note:String,done:(String?)->Unit) {
    viewModelScope.launch {try {com.example.business.PersonalKhataEngine(FinanceDatabase.getDatabase(getApplication(),viewModelScope)).entry(id,amount,direction,note);done(null)}catch(e:Exception){if(e is kotlinx.coroutines.CancellationException)throw e;done(e.message)}}
  }

  fun approveScreenshotInvoice(invoice: Invoice) = decideScreenshot(invoice, true)

  fun rejectScreenshotInvoice(invoice: Invoice) = decideScreenshot(invoice, false)

  private fun decideScreenshot(invoice: Invoice, approved: Boolean) {
    viewModelScope.launch(Dispatchers.IO) {
      try { repository.decidePendingPayment(invoice.id, approved, preferences.read("pendingAmount/${invoice.invoiceNumber}", invoice.grandTotal)) }
      catch (error: Exception) { showOperationError(error) }
    }
  }

  private suspend fun showOperationError(error: Exception) {
    if (error is kotlinx.coroutines.CancellationException) throw error
    kotlinx.coroutines.withContext(Dispatchers.Main) {
      android.widget.Toast.makeText(getApplication(), error.message ?: "Could not save / محفوظ نہیں ہو سکا", android.widget.Toast.LENGTH_LONG).show()
    }
  }

  // --- Billing & Invoicing Management ---

  fun openAddInvoiceDialog(customer: Customer? = null) {
    if(!businessAllowed()) return
    _editingInvoice.value = null
    _customerForNewBill.value = customer
    _showAddInvoiceDialog.value = true
  }

  fun openEditInvoiceDialog(invoice: Invoice) {
    if(!businessAllowed()) return
    if(_userRole.value!=UserRole.OWNER) return
    _editingInvoice.value = invoice
    _customerForNewBill.value = null
    _showAddInvoiceDialog.value = true
  }

  fun closeAddInvoiceDialog() {
    _showAddInvoiceDialog.value = false
    _customerForNewBill.value = null
    _editingInvoice.value = null
  }

  fun openInvoiceDetailDialog(invoice: Invoice) {
    _selectedInvoice.value = invoice
    _showInvoiceDetailDialog.value = true
  }

  fun closeInvoiceDetailDialog() {
    _showInvoiceDetailDialog.value = false
  }

  fun openShopProfileDialog() {
    _showShopProfileDialog.value = true
  }

  fun closeShopProfileDialog() {
    _showShopProfileDialog.value = false
  }

  fun openAddCustomerDialog(customer: Customer? = null) {
    if(!businessAllowed()) return
    _selectedCustomer.value = customer
    _showAddCustomerDialog.value = true
  }

  fun closeAddCustomerDialog() {
    _showAddCustomerDialog.value = false
    _selectedCustomer.value = null
  }

  fun openCustomerDetailDialog(customer: Customer) {
    _selectedCustomer.value = customer
    _showCustomerDetailDialog.value = true
  }

  fun closeCustomerDetailDialog() {
    _showCustomerDetailDialog.value = false
    _selectedCustomer.value = null
  }

  fun openIndustryCatalogDialog() {
    _showIndustryCatalogDialog.value = true
  }

  fun closeIndustryCatalogDialog() {
    _showIndustryCatalogDialog.value = false
  }

  fun createInvoice(invoice: Invoice, items: List<InvoiceItemEntry>, syncWithInventory: Boolean,
    onSaved: (Invoice?) -> Unit = {}) {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        requireBusinessAccess()
        require(_userRole.value==UserRole.OWNER || _employeePermissions.value.canGenerateInvoice) { "Billing permission required / بل کی اجازت ضروری ہے" }
        require(invoice.id==0L || ownerVerified && _userRole.value==UserRole.OWNER) { "Only the owner can edit a bill / صرف مالک بل تبدیل کر سکتا ہے" }
        val saved = repository.saveInvoiceAtomically(invoice, items, syncWithInventory, preferences.read("pendingCash/${invoice.invoiceNumber}", 0.0))
        kotlinx.coroutines.withContext(Dispatchers.Main) {
          _selectedInvoice.value = saved
          closeAddInvoiceDialog()
          onSaved(saved)
        }
      } catch (error: Exception) {
        showOperationError(error)
        kotlinx.coroutines.withContext(Dispatchers.Main) { onSaved(null) }
      }
    }
  }

  fun deleteInvoice(invoice: Invoice) {
    viewModelScope.launch(Dispatchers.IO) {
      try { requireBusinessAccess(); require(ownerVerified && _userRole.value==UserRole.OWNER); repository.deleteInvoiceAtomically(invoice.id) }
      catch (error: Exception) { showOperationError(error) }
    }
  }

  fun saveCustomer(customer: Customer) {
    if(!businessAllowed()) return
    viewModelScope.launch(Dispatchers.IO) {
      try { repository.saveCustomerAtomically(customer);closeAddCustomerDialog() }
      catch(error:Exception){showOperationError(error)}
    }
  }

  fun deleteCustomer(customer: Customer) {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    if(!businessAllowed()) return
    viewModelScope.launch(Dispatchers.IO) {
      if (uiState.value.invoices.any { it.customerId == customer.id } || kotlin.math.abs(customer.currentBalance) > 0.000001) {
        withContext(Dispatchers.Main) { android.widget.Toast.makeText(getApplication(), if (_appLanguage.value == AppLanguage.URDU) "بل یا بقایا والے گاہک کا ریکارڈ محفوظ ہے" else "Customers with bills or balances cannot be deleted", android.widget.Toast.LENGTH_LONG).show() }
      } else { try {repository.deleteCustomer(customer); closeCustomerDetailDialog()} catch(error:Exception){showOperationError(error)} }
    }
  }

  fun importIndustryCatalog(industryId: String, shopType: String, logoEmoji: String) {
    if(!businessAllowed()) return
    viewModelScope.launch(Dispatchers.IO) {
      val catalogItems = MultiIndustryCatalog.getCatalogForIndustry(industryId)
      repository.insertInventoryItems(catalogItems)
      _businessProfile.value = _businessProfile.value.copy(
        shopType = shopType,
        logoEmoji = logoEmoji
      )
    }
  }

  fun selectBusinessCategory(categoryItem: com.example.ui.components.BusinessCategoryItem) {
    viewModelScope.launch(Dispatchers.IO) {
      _businessProfile.value = _businessProfile.value.copy(
        shopType = categoryItem.urduTitle,
        logoEmoji = categoryItem.emoji
      )
    }
  }

  // --- Inventory & Stock Management ---

  fun openAddInventoryDialog() {
    if(!businessAllowed()) return
    _editingInventoryItem.value = null
    _showAddEditInventoryDialog.value = true
  }

  fun openEditInventoryDialog(item: InventoryItem) {
    if(!businessAllowed()) return
    _editingInventoryItem.value = item
    _showAddEditInventoryDialog.value = true
  }

  fun closeAddEditInventoryDialog() {
    _showAddEditInventoryDialog.value = false
    _editingInventoryItem.value = null
  }

  fun openQuickStockAdjustDialog(item: InventoryItem) {
    if(!businessAllowed()) return
    _adjustingInventoryItem.value = item
    _showQuickStockAdjustDialog.value = true
  }

  fun closeQuickStockAdjustDialog() {
    _showQuickStockAdjustDialog.value = false
    _adjustingInventoryItem.value = null
  }

  fun saveInventoryItem(
    id: Long,
    name: String,
    category: String,
    icon: String,
    costPrice: Double,
    salePrice: Double,
    currentStock: Double,
    unit: String,
    lowStockThreshold: Double,
    barcode: String,
    supplierName: String,
    note: String
  ) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      val item = InventoryItem(
        id = id,
        name = name,
        category = category,
        icon = icon,
        costPrice = costPrice,
        salePrice = salePrice,
        currentStock = currentStock,
        unit = unit,
        lowStockThreshold = lowStockThreshold,
        barcode = barcode,
        supplierName = supplierName,
        lastUpdatedMillis = System.currentTimeMillis(),
        note = note,
        detailsJson = uiState.value.inventoryItems.firstOrNull { it.id == id }?.detailsJson ?: "{}"
      )
      if (id == 0L) {
        repository.insertInventoryItem(item)
      } else {
        repository.updateInventoryItem(item)
      }
      closeAddEditInventoryDialog()
    }
  }

  fun insertInventoryItemDirectly(item: InventoryItem) {
    if(!businessAllowed()) return
    viewModelScope.launch(Dispatchers.IO) {
      repository.insertInventoryItem(item)
    }
  }

  fun deleteInventoryItem(item: InventoryItem) {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    if(!businessAllowed()) return
    viewModelScope.launch {
      try {repository.deleteInventoryItem(item);closeAddEditInventoryDialog()} catch(error:Exception){showOperationError(error)}
    }
  }

  fun addInventoryStock(item: InventoryItem, quantity: Double, costPrice: Double? = null) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      try {
        repository.purchaseStockAtomically(item.id, quantity, costPrice)
        closeQuickStockAdjustDialog()
      } catch (error: Exception) {
        if (error is kotlinx.coroutines.CancellationException) throw error
        android.widget.Toast.makeText(getApplication(), error.message ?: "Purchase failed", android.widget.Toast.LENGTH_LONG).show()
      }
    }
  }

  fun deductInventoryStock(item: InventoryItem, quantity: Double, recordAsSale: Boolean = true) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      try {
        val database=FinanceDatabase.getDatabase(getApplication(),viewModelScope)
        if(recordAsSale) {
          val line=InvoiceItemEntry(itemId=item.id,itemName=item.name,quantity=quantity,unit=item.unit,unitPrice=item.salePrice,total=quantity*item.salePrice)
          val profile=_businessProfile.value
          repository.saveInvoiceAtomically(Invoice(invoiceNumber="ADJ-${java.util.UUID.randomUUID()}",customerName="Walk-in",grandTotal=line.total,amountPaid=line.total,remainingBalance=0.0,itemsJson=InvoiceItemEntry.toJsonString(listOf(line)),businessName=profile.businessName,paymentMethod="Cash"),listOf(line),true)
        } else database.withTransaction {
          val current=database.financeDao().getInventoryItemById(item.id) ?: error("Item missing")
          require(quantity.isFinite() && quantity>0 && current.currentStock+0.000001>=quantity) { "Insufficient stock / اسٹاک کم ہے" }
          database.financeDao().deductInventoryStock(item.id,quantity)
        }
        closeQuickStockAdjustDialog()
      } catch(error: Exception) {showOperationError(error)}
    }
  }

  fun openStockExportDialog() {
    _showStockExportDialog.value = true
  }

  fun closeStockExportDialog() {
    _showStockExportDialog.value = false
  }

  fun openStockImportDialog() {
    _showStockImportDialog.value = true
  }

  fun closeStockImportDialog() {
    _showStockImportDialog.value = false
  }

  fun importStockItems(items: List<InventoryItem>, replaceExisting: Boolean) {
    if(!businessAllowed()) return
    viewModelScope.launch(Dispatchers.IO) {
      if (replaceExisting) {
        repository.deleteAllInventoryItems()
      }
      repository.insertInventoryItems(items)
      closeStockImportDialog()
    }
  }

  fun openAddTransactionDialog(type: TransactionType = TransactionType.EXPENSE) {
    if(!businessAllowed()) return
    _initialTransactionType.value = type
    _showAddTransactionDialog.value = true
  }

  fun closeAddTransactionDialog() {
    _showAddTransactionDialog.value = false
  }

  fun openAddAccountDialog() {
    if(!businessAllowed()) return
    _showAddAccountDialog.value = true
  }

  fun closeAddAccountDialog() {
    _showAddAccountDialog.value = false
  }

  fun openAddBillDialog() {
    if(!businessAllowed()) return
    _showAddBillDialog.value = true
  }

  fun closeAddBillDialog() {
    _showAddBillDialog.value = false
  }

  fun openAddRecurringDialog() {
    if(!businessAllowed()) return
    _editingRecurring.value = null
    _showAddRecurringDialog.value = true
  }

  fun openEditRecurringDialog(recurring: RecurringTransaction) {
    if(!businessAllowed()) return
    _editingRecurring.value = recurring
    _showAddRecurringDialog.value = true
  }

  fun closeRecurringDialog() {
    _showAddRecurringDialog.value = false
    _editingRecurring.value = null
  }

  fun openAddBudgetDialog() {
    if(!businessAllowed()) return
    _editingBudget.value = null
    _showAddEditBudgetDialog.value = true
  }

  fun openEditBudgetDialog(budget: Budget) {
    if(!businessAllowed()) return
    _editingBudget.value = budget
    _showAddEditBudgetDialog.value = true
  }

  fun closeAddEditBudgetDialog() {
    _showAddEditBudgetDialog.value = false
    _editingBudget.value = null
  }

  fun openProfileDialog() {
    _showProfileDialog.value = true
  }

  fun closeProfileDialog() {
    _showProfileDialog.value = false
  }

  fun selectTransaction(transaction: Transaction?) {
    _selectedTransaction.value = transaction
  }

  fun addTransaction(
    title: String,
    amount: Double,
    type: TransactionType,
    category: String,
    icon: String,
    accountName: String,
    note: String,
    recipientInfo: String = "",
    paymentMethod: String = "",
    receiptImageUri: String = "",
    transactionRef: String = ""
  ) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      val tx = Transaction(
        title = title,
        amount = amount,
        type = type,
        category = category,
        icon = icon,
        accountName = accountName,
        dateMillis = System.currentTimeMillis(),
        note = note,
        recipientInfo = recipientInfo,
        paymentMethod = paymentMethod,
        receiptImageUri = receiptImageUri,
        transactionRef = transactionRef
      )
      try {
        repository.recordTransactionAtomically(tx)
        _showAddTransactionDialog.value = false
      } catch (error: Exception) { showOperationError(error) }
    }
  }

  fun deleteTransaction(transaction: Transaction) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      try {
        repository.deleteTransactionAtomically(transaction.id)
        if (_selectedTransaction.value?.id == transaction.id) _selectedTransaction.value = null
      } catch (error: Exception) { showOperationError(error) }
    }
  }

  fun addAccount(name: String, accountType: String, balance: Double, cardNumber: String, colorHex: Long) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      val account = Account(
        name = name,
        accountType = accountType,
        balance = balance,
        accountNumber = cardNumber,
        colorHex = colorHex
      )
      repository.insertAccount(account)
      _showAddAccountDialog.value = false
    }
  }

  fun deleteAccount(account: Account) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      repository.deleteAccount(account)
    }
  }

  fun addBill(title: String, amount: Double, dueDate: String, category: String, icon: String) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      val bill = Bill(
        title = title,
        amount = amount,
        dueDate = dueDate,
        category = category,
        icon = icon,
        isPaid = false
      )
      repository.insertBill(bill)
      _showAddBillDialog.value = false
    }
  }

  fun toggleBillPaid(bill: Bill) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      repository.updateBill(bill.copy(isPaid = !bill.isPaid))
    }
  }

  fun deleteBill(bill: Bill) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      repository.deleteBill(bill)
    }
  }

  fun saveRecurringTransaction(
    id: Long,
    title: String,
    amount: Double,
    type: TransactionType,
    category: String,
    icon: String,
    accountName: String,
    frequency: RecurringFrequency,
    startDateMillis: Long,
    endDateMillis: Long?,
    nextExecutionDateMillis: Long,
    note: String
  ) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      val recurring = RecurringTransaction(
        id = id,
        title = title,
        amount = amount,
        type = type,
        category = category,
        icon = icon,
        accountName = accountName,
        frequency = frequency,
        startDateMillis = startDateMillis,
        endDateMillis = endDateMillis,
        nextExecutionDateMillis = nextExecutionDateMillis,
        isActive = true,
        note = note
      )
      if (id == 0L) {
        repository.insertRecurringTransaction(recurring)
      } else {
        repository.updateRecurringTransaction(recurring)
      }
      closeRecurringDialog()
      processDueRecurringTransactions()
    }
  }

  fun toggleRecurringActive(recurring: RecurringTransaction) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      repository.updateRecurringTransaction(recurring.copy(isActive = !recurring.isActive))
    }
  }

  fun deleteRecurringTransaction(recurring: RecurringTransaction) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      repository.deleteRecurringTransaction(recurring)
    }
  }

  fun executeRecurringNow(recurring: RecurringTransaction) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      val now = System.currentTimeMillis()
      val tx = Transaction(
        title = recurring.title,
        amount = recurring.amount,
        type = recurring.type,
        category = recurring.category,
        icon = recurring.icon,
        accountName = recurring.accountName,
        dateMillis = now,
        note = "Recurring (${recurring.frequency.displayName})" + if (recurring.note.isNotBlank()) " • ${recurring.note}" else ""
      )
      repository.insertTransaction(tx)

      val currentAccounts = uiState.value.accounts
      val matchingAccount = currentAccounts.find { it.name == recurring.accountName }
      if (matchingAccount != null) {
        val updatedBalance = when (recurring.type) {
          TransactionType.INCOME -> matchingAccount.balance + recurring.amount
          TransactionType.EXPENSE -> matchingAccount.balance - recurring.amount
          TransactionType.TRANSFER -> matchingAccount.balance - recurring.amount
        }
        repository.updateAccount(matchingAccount.copy(balance = updatedBalance))
      }

      val nextDate = recurring.frequency.getNextDate(recurring.nextExecutionDateMillis.coerceAtLeast(now))
      val stillActive = recurring.endDateMillis == null || nextDate <= recurring.endDateMillis
      repository.updateRecurringTransaction(
        recurring.copy(
          lastExecutedDateMillis = now,
          nextExecutionDateMillis = nextDate,
          isActive = stillActive
        )
      )
      _lastProcessedMessage.value = "Executed: ${recurring.title} ($${recurring.amount})"
    }
  }

  fun processDueRecurringTransactions() {
    if(_appMode.value==AppMode.PERSONAL_KHATA || !_subscriptionState.value.hasBusinessAccess) return
    viewModelScope.launch(Dispatchers.IO) {
      val now = System.currentTimeMillis()
      val activeList = repository.getActiveRecurringTransactions()
      var processedCount = 0

      for (recurring in activeList) {
        if (recurring.nextExecutionDateMillis <= now) {
          if (recurring.endDateMillis != null && recurring.nextExecutionDateMillis > recurring.endDateMillis) {
            repository.updateRecurringTransaction(recurring.copy(isActive = false))
            continue
          }

          val tx = Transaction(
            title = recurring.title,
            amount = recurring.amount,
            type = recurring.type,
            category = recurring.category,
            icon = recurring.icon,
            accountName = recurring.accountName,
            dateMillis = now,
            note = "Scheduled (${recurring.frequency.displayName})" + if (recurring.note.isNotBlank()) " • ${recurring.note}" else ""
          )
          repository.insertTransaction(tx)

          val accounts = uiState.value.accounts
          val matchingAccount = accounts.find { it.name == recurring.accountName }
          if (matchingAccount != null) {
            val updatedBalance = when (recurring.type) {
              TransactionType.INCOME -> matchingAccount.balance + recurring.amount
              TransactionType.EXPENSE -> matchingAccount.balance - recurring.amount
              TransactionType.TRANSFER -> matchingAccount.balance - recurring.amount
            }
            repository.updateAccount(matchingAccount.copy(balance = updatedBalance))
          }

          val nextDate = recurring.frequency.getNextDate(recurring.nextExecutionDateMillis)
          val stillActive = recurring.endDateMillis == null || nextDate <= recurring.endDateMillis

          repository.updateRecurringTransaction(
            recurring.copy(
              lastExecutedDateMillis = now,
              nextExecutionDateMillis = nextDate,
              isActive = stillActive
            )
          )
          processedCount++
        }
      }

      if (processedCount > 0) {
        withContext(Dispatchers.Main) {
          _lastProcessedMessage.value = "Processed $processedCount recurring transaction(s)"
        }
      }
    }
  }

  fun saveBudget(id: Long, category: String, limitAmount: Double, icon: String, period: String = "Monthly") {
    if(!businessAllowed()) return
    viewModelScope.launch {
      val currentMonthExpensesByCategory = uiState.value.transactions
        .filter { it.type == TransactionType.EXPENSE }
        .groupBy { it.category.trim() }
        .mapValues { entry -> entry.value.sumOf { it.amount } }

      val spent = currentMonthExpensesByCategory[category.trim()] ?: 0.0

      val budget = Budget(
        id = id,
        category = category.trim(),
        limitAmount = limitAmount,
        spentAmount = spent,
        icon = icon,
        period = period
      )

      if (id == 0L) {
        repository.insertBudget(budget)
      } else {
        repository.updateBudget(budget)
      }
      closeAddEditBudgetDialog()
    }
  }

  fun deleteBudget(budget: Budget) {
    if(!businessAllowed()) return
    viewModelScope.launch {
      repository.deleteBudget(budget)
    }
  }

  fun updateBusinessProfile(profile: BusinessProfile) {
    _businessProfile.value = profile
  }

  fun loadPakistaniBusinessDemo() {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    if(!businessAllowed()) return
    viewModelScope.launch(Dispatchers.IO) {
      if (!repository.loadPakistaniBusinessDemoData()) {
        withContext(Dispatchers.Main) {
          android.widget.Toast.makeText(getApplication(),
            if (_appLanguage.value == AppLanguage.URDU) "موجودہ ریکارڈ محفوظ ہیں۔ ڈیمو صرف خالی کاروبار میں لوڈ ہو سکتا ہے۔"
            else "Existing records are protected. Demo data can only load into an empty business.",
            android.widget.Toast.LENGTH_LONG).show()
        }
        return@launch
      }
      _currencySymbol.value = "Rs"
      _businessProfile.value = BusinessProfile(
        businessName = "Arshad Traders & Khata",
        ownerName = "Muhammad Arshad",
        phone = "+92 300 1234567",
        address = "",
        tagline = "Wholesale & Retail Commercial Accounts",
        ntnNumber = "NTN-892341-PK"
      )
    }
  }

  fun resetAllData() {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    viewModelScope.launch(Dispatchers.IO) {
      repository.clearAllData()
    }
  }

  fun openUpgradeDialog() {
    _showUpgradeDialog.value = true
  }

  fun closeUpgradeDialog() {
    _showUpgradeDialog.value = false
  }

  fun toggleProMembership() { openTrialLockDialog() }

  fun addOrUpdateService(service: ServiceItem) {
    if(!businessAllowed()) return
    val list = _services.value.toMutableList()
    val index = list.indexOfFirst { it.id == service.id }
    if (index >= 0) {
      list[index] = service
    } else {
      list.add(0, service)
    }
    _services.value = list
  }

  fun deleteService(serviceId: Long) {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    if(!businessAllowed()) return
    _services.value = _services.value.filter { it.id != serviceId }
    val featured = _selectedFeaturedServiceIds.value.toMutableSet()
    featured.remove(serviceId)
    _selectedFeaturedServiceIds.value = featured
  }

  fun toggleServiceDiscount(serviceId: Long, isDiscountActive: Boolean, customDiscountPrice: Double? = null) {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    if(!businessAllowed()) return
    val list = _services.value.map { s ->
      if (s.id == serviceId) {
        val newDisc = customDiscountPrice ?: if (s.discountPrice > 0) s.discountPrice else (s.price * 0.8)
        s.copy(isDiscountActive = isDiscountActive, discountPrice = newDisc)
      } else s
    }
    _services.value = list
  }

  fun toggleFeaturedService(serviceId: Long) {
    if(!ownerVerified || _userRole.value!=UserRole.OWNER) return
    if(!businessAllowed()) return
    val current = _selectedFeaturedServiceIds.value.toMutableSet()
    if (current.contains(serviceId)) {
      current.remove(serviceId)
    } else {
      if (current.size >= 3) {
        val first = current.first()
        current.remove(first)
      }
      current.add(serviceId)
    }
    _selectedFeaturedServiceIds.value = current
  }

  fun selectServiceCategory(category: String) {
    _selectedServiceCategory.value = category
  }

  fun updateShopBioData(bio: ShopBioData) {
    if(!businessAllowed()) return
    _shopBioData.value = bio
    _businessProfile.value = _businessProfile.value.copy(
      businessName = bio.shopName,
      address = bio.address,
      phone = bio.phone
    )
  }

  fun addServiceToCart(service: ServiceItem) {
    if(!businessAllowed()) return
    viewModelScope.launch(Dispatchers.IO) {
      val effectivePrice = service.effectivePrice
      val existing = uiState.value.inventoryItems.find { it.barcode == "SRV-${service.id}" }
      val itemId = if (existing != null) {
        if (existing.salePrice != effectivePrice) {
          repository.updateInventoryItem(existing.copy(salePrice = effectivePrice))
        }
        existing.id
      } else {
        val newItem = InventoryItem(
          id = 0L,
          name = service.name,
          category = "Service / سروس",
          icon = service.icon,
          costPrice = 0.0,
          salePrice = effectivePrice,
          currentStock = service.stockOrSlots,
          unit = service.unit,
          lowStockThreshold = 5.0,
          barcode = "SRV-${service.id}",
          supplierName = _shopBioData.value.shopName,
          note = service.description,
          lastUpdatedMillis = System.currentTimeMillis()
        )
        repository.insertInventoryItem(newItem)
      }

      withContext(Dispatchers.Main) {
        addToCart(itemId, 1.0)
      }
    }
  }
}

private data class Tuple4<A, B, C, D>(
  val first: A,
  val second: B,
  val third: C,
  val fourth: D
)

private data class Tuple5<A, B, C, D, E>(
  val first: A,
  val second: B,
  val third: C,
  val fourth: D,
  val fifth: E
)
