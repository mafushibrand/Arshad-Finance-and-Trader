package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Budget
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AddEditBudgetDialog(
  budget: Budget?,
  currencySymbol: String,
  onDismiss: () -> Unit,
  onSave: (id: Long, category: String, limitAmount: Double, icon: String, period: String) -> Unit,
  onDelete: ((Budget) -> Unit)? = null
) {
  val isEditing = budget != null

  var category by remember { mutableStateOf(budget?.category ?: "Food & Dining") }
  var limitText by remember { mutableStateOf(budget?.limitAmount?.let { String.format("%.2f", it) } ?: "") }
  var selectedIcon by remember { mutableStateOf(budget?.icon ?: "🍔") }
  var period by remember { mutableStateOf(budget?.period ?: "Monthly") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val presetCategories = listOf(
    Pair("Food & Dining", "🍔"),
    Pair("Shopping", "🛍️"),
    Pair("Bills & Utilities", "⚡"),
    Pair("Transportation", "🚕"),
    Pair("Health & Wellness", "💊"),
    Pair("Entertainment", "🍿"),
    Pair("Tech & Work", "💻"),
    Pair("Travel & Holiday", "✈️"),
    Pair("Education", "📚")
  )

  val periods = listOf("Monthly", "Weekly", "Yearly")

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(28.dp))
        .testTag("add_edit_budget_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(24.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isEditing) "Edit Category Budget" else "Set Category Budget",
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Category selector
        Text(
          text = "Choose Spending Category",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
        )

        Spacer(modifier = Modifier.height(8.dp))

        val catScroll = rememberScrollState()
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(catScroll),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          presetCategories.forEach { (catName, icon) ->
            val isSelected = category == catName
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable {
                  category = catName
                  selectedIcon = icon
                }
                .padding(horizontal = 12.dp, vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "$icon $catName",
                style = MaterialTheme.typography.bodySmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          label = { Text("Category Name") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_budget_category")
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = limitText,
          onValueChange = { limitText = it },
          label = { Text("Monthly Budget Limit ($currencySymbol)") },
          placeholder = { Text("e.g. 500.00") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_budget_limit")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Budget Cycle / Period
        Text(
          text = "Budget Period",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          periods.forEach { p ->
            val isSelected = period == p
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable { period = p }
                .padding(vertical = 10.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = p,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        if (errorMessage != null) {
          Text(
            text = errorMessage ?: "",
            color = ExpenseRed,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 8.dp)
          )
        }

        Spacer(modifier = Modifier.height(22.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (isEditing && onDelete != null && budget != null) {
            IconButton(
              onClick = { onDelete(budget) },
              modifier = Modifier.testTag("delete_budget_button")
            ) {
              Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete Budget", tint = ExpenseRed)
            }
          } else {
            Spacer(modifier = Modifier.width(8.dp))
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onDismiss) {
              Text(text = "Cancel", color = TextSecondary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = {
                val parsedLimit = limitText.toDoubleOrNull()
                if (category.isBlank()) {
                  errorMessage = "Please enter a category name"
                } else if (parsedLimit == null || parsedLimit <= 0) {
                  errorMessage = "Please enter a valid limit greater than 0"
                } else {
                  onSave(budget?.id ?: 0L, category.trim(), parsedLimit, selectedIcon, period)
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.testTag("save_budget_button")
            ) {
              Text(text = if (isEditing) "Update Budget" else "Set Budget")
            }
          }
        }
      }
    }
  }
}
