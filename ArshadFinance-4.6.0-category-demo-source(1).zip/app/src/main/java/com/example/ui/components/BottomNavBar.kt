package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.AppMode
import com.example.ui.FinanceTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BottomNavBar(
  selectedTab: FinanceTab,
  onTabSelected: (FinanceTab) -> Unit,
  cartItemCount: Int = 0,
  appMode: AppMode = AppMode.BUSINESS_RETAIL,
  appLanguage: AppLanguage = AppLanguage.URDU,
  features: com.example.data.model.BusinessFeatures = com.example.data.model.BusinessFeatures(),
  modifier: Modifier = Modifier
) {
  val urdu = appLanguage == AppLanguage.URDU
  val personal = appMode == AppMode.PERSONAL_KHATA
  var sheet by rememberSaveable { mutableStateOf("") }
  NavigationBar(modifier = modifier, containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
    NavBarChoice(if (urdu) "خلاصہ" else "Home", Icons.Default.Home, selectedTab == FinanceTab.HOME, "nav_tab_home") {
      onTabSelected(FinanceTab.HOME)
    }
    if (!personal) {
      if (features.products || features.services) NavBarChoice(if (urdu) "کیٹلاگ" else "Catalog", Icons.Default.Inventory2,
        selectedTab == FinanceTab.STOCK || selectedTab == FinanceTab.SERVICES, "nav_catalog") { sheet = "catalog" }
      if (features.pos) NavigationBarItem(selected = selectedTab == FinanceTab.POS, onClick = { onTabSelected(FinanceTab.POS) },
        icon = { BadgedBox(badge = { if (cartItemCount > 0) Badge { Text(cartItemCount.toString()) } }) {
          Icon(Icons.Default.PointOfSale, if (urdu) "فروخت" else "POS")
        } }, label = { Text(if (urdu) "فروخت" else "POS") }, modifier = Modifier.testTag("nav_center_pos_fab"))
    } else {
      NavBarChoice(if (urdu) "اکاؤنٹس" else "Accounts", Icons.Default.AccountBalanceWallet,
        selectedTab == FinanceTab.ACCOUNTS, "nav_tab_accounts") { onTabSelected(FinanceTab.ACCOUNTS) }
    }
    if (features.khata) NavBarChoice(if (urdu) "کھاتہ" else "Khata", Icons.Default.ReceiptLong,
      selectedTab == FinanceTab.LEDGERS, "nav_tab_ledgers") { onTabSelected(FinanceTab.LEDGERS) }
    NavBarChoice(if (urdu) "مزید" else "More", Icons.Default.MoreHoriz,
      selectedTab in listOf(FinanceTab.SETTINGS, FinanceTab.REPORTS, FinanceTab.PLANNER) || (!personal && selectedTab == FinanceTab.ACCOUNTS),
      "nav_more") { sheet = "more" }
  }
  if (sheet.isNotEmpty()) {
    ModalBottomSheet(onDismissRequest = { sheet = "" }) {
      Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp)) {
        Text(if (sheet == "catalog") { if (urdu) "آپ کا کیٹلاگ" else "Your catalog" }
          else { if (urdu) "کاروبار کے ٹولز" else "Business tools" }, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        if (sheet == "catalog") {
          if (features.products) MenuDestination("Products & stock", "پروڈکٹس اور اسٹاک", Icons.Default.Inventory2, FinanceTab.STOCK, "nav_tab_products", urdu) { sheet = ""; onTabSelected(FinanceTab.STOCK) }
          if (features.services) MenuDestination("Services", "سروسز", Icons.Default.Handyman, FinanceTab.SERVICES, "nav_tab_services", urdu) { sheet = ""; onTabSelected(FinanceTab.SERVICES) }
        } else {
          MenuDestination("Cash & accounts", "کیش اور اکاؤنٹس", Icons.Default.AccountBalanceWallet, FinanceTab.ACCOUNTS, "nav_tab_accounts", urdu) { sheet = ""; onTabSelected(FinanceTab.ACCOUNTS) }
          if (features.reports) MenuDestination("Reports", "رپورٹس", Icons.Default.Insights, FinanceTab.REPORTS, "nav_reports", urdu) { sheet = ""; onTabSelected(FinanceTab.REPORTS) }
          MenuDestination("Bills, budgets & recurring", "بل، بجٹ اور بار بار ادائیگی", Icons.Default.EventRepeat, FinanceTab.PLANNER, "nav_planner", urdu) { sheet = ""; onTabSelected(FinanceTab.PLANNER) }
          if (features.purchases) MenuDestination("Purchases", "خریداری", Icons.Default.LocalShipping, FinanceTab.PURCHASES, "nav_purchases", urdu) { sheet = ""; onTabSelected(FinanceTab.PURCHASES) }
          MenuDestination("Business workspace", "کاروباری مرکز", Icons.Default.BusinessCenter, FinanceTab.OPERATIONS, "nav_operations", urdu) { sheet = ""; onTabSelected(FinanceTab.OPERATIONS) }
          MenuDestination("Settings", "سیٹنگز", Icons.Default.Settings, FinanceTab.SETTINGS, "nav_tab_settings", urdu) { sheet = ""; onTabSelected(FinanceTab.SETTINGS) }
        }
        Spacer(Modifier.height(24.dp))
      }
    }
  }
}

@Composable
private fun RowScope.NavBarChoice(label: String, icon: ImageVector, selected: Boolean, tag: String, click: () -> Unit) {
  NavigationBarItem(selected = selected, onClick = click,
    icon = { Icon(icon, label) }, label = { Text(label) }, modifier = Modifier.testTag(tag))
}

@Composable
private fun MenuDestination(en: String, ur: String, icon: ImageVector, tab: FinanceTab, tag: String, urdu: Boolean, click: () -> Unit) {
  TextButton(onClick = click, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).testTag(tag)) {
    Icon(icon, null); Spacer(Modifier.width(14.dp)); Text(if (urdu) ur else en, modifier = Modifier.weight(1f))
  }
}
