package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun PurchasesScreen(uiState: FinanceUiState, onPurchase: (InventoryItem) -> Unit, onDocuments: (() -> Unit)? = null) {
  var search by rememberSaveable { mutableStateOf("") }
  val purchases = uiState.transactions.filter { it.transactionRef.startsWith("PURCHASE/") || it.category == "Inventory / Stock" }
  PremiumPage(uiState.word("Purchases", "خریداری"), uiState.word("Restock products and record payment", "سامان کا اسٹاک اور خرید ادائیگی محفوظ کریں"), Icons.Default.LocalShipping) {
    if(onDocuments!=null) item { PremiumButton(uiState.word("Purchase orders, GRN & returns", "خرید آرڈر، وصولی اور واپسی"),onDocuments) }
    item { Metric(uiState.word("Total stock purchases", "کل اسٹاک خریداری"), uiState.money(purchases.sumOf { it.amount }), Peach) }
    item { SearchBox(search, uiState.word("Find product to restock", "خریدنے کے لیے سامان تلاش کریں")) { search = it } }
    items(uiState.inventoryItems.filter { !it.barcode.startsWith("SRV-") && (search.isBlank() || it.name.contains(search, true)) }, key = { it.id }) { item ->
      ListTile(item.name, "${item.currentStock} ${item.unit} • ${item.supplierName}", Icons.Default.Inventory2, uiState.money(item.costPrice), click = { onPurchase(item) }) {
        TextButton(onClick = { onPurchase(item) }) { Icon(Icons.Default.Add, null); Text(uiState.word("Purchase / add stock", "خریداری / اسٹاک شامل کریں")) }
      }
    }
    item { Text(uiState.word("Purchase history", "خریداری کی تفصیل"), fontWeight = FontWeight.Bold) }
    items(purchases, key = { it.id }) { tx -> ListTile(tx.title, tx.note, Icons.Default.ReceiptLong, uiState.money(tx.amount), Peach) }
  }
}
