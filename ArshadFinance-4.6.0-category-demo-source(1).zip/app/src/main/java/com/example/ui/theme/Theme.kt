package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
  primary = NavyBluePrimary,
  onPrimary = Color.White,
  primaryContainer = IceBlueContainer,
  onPrimaryContainer = OnIceBlueContainer,
  secondary = Color(0xFF535F70),
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFE4F3E9),
  onSecondaryContainer = Color(0xFF101C2B),
  tertiary = Color(0xFF6B5778),
  onTertiary = Color.White,
  tertiaryContainer = Color(0xFFECE8FF),
  onTertiaryContainer = Color(0xFF251431),
  background = LightBackground,
  onBackground = TextPrimary,
  surface = LightSurface,
  onSurface = TextPrimary,
  surfaceVariant = LightSurfaceVariant,
  onSurfaceVariant = TextSecondary,
  outline = LightOutline,
  outlineVariant = LightOutlineVariant,
  error = ExpenseRed,
  onError = Color.White,
  errorContainer = ExpenseRedContainer,
  onErrorContainer = OnExpenseRedContainer
)

private val DarkColorScheme = darkColorScheme(
  primary = Color(0xFF9ECAFF),
  onPrimary = Color(0xFF003258),
  primaryContainer = NavyBlueDark,
  onPrimaryContainer = IceBlueContainer,
  secondary = Color(0xFFBBC7DB),
  onSecondary = Color(0xFF253140),
  secondaryContainer = Color(0xFF3B4858),
  onSecondaryContainer = Color(0xFFE4F3E9),
  background = Color(0xFF111318),
  onBackground = Color(0xFFE2E2E9),
  surface = Color(0xFF191C20),
  onSurface = Color(0xFFE2E2E9),
  surfaceVariant = Color(0xFF43474E),
  onSurfaceVariant = Color(0xFFC4C6CF),
  outline = Color(0xFF8E9099),
  error = Color(0xFFFFB4AB),
  onError = Color(0xFF690005)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    shapes = androidx.compose.material3.Shapes(
      small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
      medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
      large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp)
    ),
    content = content
  )
}
