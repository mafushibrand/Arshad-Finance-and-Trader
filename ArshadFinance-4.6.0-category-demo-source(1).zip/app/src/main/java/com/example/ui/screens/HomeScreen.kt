package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.AppMode
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import com.example.data.model.UserRole
import java.util.Calendar
import com.example.ui.FilterCategory
import com.example.ui.FinanceUiState
import com.example.ui.components.BalanceHeroCard
import com.example.ui.components.BestForBusinessShowcase
import com.example.ui.components.BusinessCategoryItem
import com.example.ui.components.TransactionItemCard
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.InputFieldStyles
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.OnIceBlueContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
  uiState: FinanceUiState,
  onSendClick: () -> Unit,
  onReceiveClick: () -> Unit,
  onStockClick: () -> Unit,
  onBillsClick: () -> Unit,
  onBillingClick: () -> Unit = {},
  onServicesClick: () -> Unit = {},
  onFilterSelected: (FilterCategory) -> Unit,
  onSearchQueryChanged: (String) -> Unit,
  onTransactionClick: (Transaction) -> Unit,
  onAddNewClick: () -> Unit,
  onOpenFbrTaxReport: () -> Unit = {},
  onOpenTrialLock: () -> Unit = {},
  onSelectBusinessCategory: (BusinessCategoryItem) -> Unit = {},
  modifier: Modifier = Modifier
) {
  val isUrdu = uiState.appLanguage == AppLanguage.URDU
  val currency = uiState.currencySymbol
  val businessName = uiState.businessProfile.businessName.ifBlank { "Arshad Finance & Traders" }
  val invoices = uiState.invoices
  val customers = uiState.customers
  val inventoryItems = uiState.inventoryItems
  val transactions = uiState.transactions

  var searchQuery by remember { mutableStateOf("") }
  var selectedFilter by remember { mutableStateOf(FilterCategory.ALL) }

  // Stock Banner calculations (100% Real Live Data)
  val totalStockCount = inventoryItems.size
  val totalStockWorth = inventoryItems.sumOf { it.currentStock * it.salePrice }

  // Financial Summary calculations (100% Real Live Data)
  val totalSalesAmount = invoices.sumOf { it.netTotal() }
  val cashSales = invoices.sumOf { it.amountPaid }
  val udhaarSales = invoices.sumOf { it.remainingBalance }
  val totalPurchase = inventoryItems.sumOf { it.currentStock * it.costPrice }
  val purchaseCash = transactions.filter { it.type == TransactionType.EXPENSE && (it.category.contains("Purchase", ignoreCase = true) || it.category.contains("Stock", ignoreCase = true)) }.sumOf { it.amount }
  val purchaseUdhaar = (totalPurchase - purchaseCash).coerceAtLeast(0.0)
  val recoveryMonth = cashSales
  val paymentMonth = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
  val expenseMonth = uiState.totalExpense
  val netProfitMonth = totalSalesAmount - (totalPurchase + expenseMonth)
  val cashInHand = uiState.totalBalance
  val receivableKhata = customers.filter { it.currentBalance > 0 }.sumOf { it.currentBalance }
  val payableKhata = customers.filter { it.currentBalance < 0 }.sumOf { -it.currentBalance }

  // FBR Periodical Tax Deductions (Daily, Weekly, Monthly, Yearly)
  val now = System.currentTimeMillis()
  val startOfToday = remember {
    Calendar.getInstance().apply {
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }.timeInMillis
  }
  val startOfWeek = now - (7L * 24 * 60 * 60 * 1000L)
  val startOfMonth = remember {
    Calendar.getInstance().apply {
      set(Calendar.DAY_OF_MONTH, 1)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }.timeInMillis
  }
  val startOfYear = remember {
    Calendar.getInstance().apply {
      set(Calendar.MONTH, Calendar.JANUARY)
      set(Calendar.DAY_OF_MONTH, 1)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }.timeInMillis
  }

  fun computeTaxSum(invList: List<com.example.data.model.Invoice>): Double {
    return invList.sumOf { inv ->
      inv.taxAmount
    }
  }

  val todayTax = computeTaxSum(invoices.filter { it.dateMillis >= startOfToday })
  val weekTax = computeTaxSum(invoices.filter { it.dateMillis >= startOfWeek })
  val monthTax = computeTaxSum(invoices.filter { it.dateMillis >= startOfMonth })
  val yearTax = computeTaxSum(invoices.filter { it.dateMillis >= startOfYear })
  val netTaxPayable = (monthTax * 0.65).coerceAtLeast(0.0)

  // Filtered transactions for recent activity
  val filteredTransactions = remember(transactions, searchQuery, selectedFilter) {
    var list = transactions
    if (searchQuery.isNotBlank()) {
      list = list.filter {
        it.title.contains(searchQuery, ignoreCase = true) ||
            it.note.contains(searchQuery, ignoreCase = true) ||
            it.category.contains(searchQuery, ignoreCase = true) ||
            it.accountName.contains(searchQuery, ignoreCase = true)
      }
    }
    when (selectedFilter) {
      FilterCategory.EXPENSES -> list.filter { it.type == TransactionType.EXPENSE }
      FilterCategory.INCOME -> list.filter { it.type == TransactionType.INCOME }
      FilterCategory.SHOPPING -> list.filter { it.category.contains("Shop", ignoreCase = true) }
      FilterCategory.FOOD -> list.filter { it.category.contains("Food", ignoreCase = true) }
      FilterCategory.BILLS -> list.filter { it.category.contains("Bill", ignoreCase = true) }
      FilterCategory.TRANSPORT -> list.filter { it.category.contains("Transport", ignoreCase = true) }
      else -> list
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFFF5F7F2))
      .padding(horizontal = 14.dp),
    contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 8.dp, bottom = 120.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item { Spacer(modifier = Modifier.height(2.dp)) }

    // 1. Balance Hero Card (Total Balance)
    item {
      BalanceHeroCard(
        totalBalance = uiState.totalBalance,
        monthlyIncome = uiState.totalIncome,
        monthlyExpense = uiState.totalExpense,
        monthlyChangePercent = uiState.monthlyChangePercent,
        currencySymbol = currency,
        appLanguage = uiState.appLanguage
      )
    }

    // Best For All Businesses & Shops (Screenshot Showcase)
    item {
      BestForBusinessShowcase(
        appLanguage = uiState.appLanguage,
        selectedCategory = uiState.businessProfile.shopType,
        onSelectCategory = { cat ->
          onSelectBusinessCategory(cat)
        }
      )
    }

    // Step 1: Employee Restricted Mode Banner
    if (uiState.userRole == UserRole.EMPLOYEE) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFE5F3EA)),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF99C9AB)),
          modifier = Modifier.fillMaxWidth().testTag("employee_mode_banner")
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = "👤", fontSize = 22.sp)
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(text = "Employee Staff Mode (ملازم موڈ)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0F172A))
                Text(text = "Daily Total Sales: $currency ${"%,.0f".format(cashSales)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF059669))
              }
            }
            Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFF086B4D)) {
              Text(text = "RBAC Active", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
            }
          }
        }
      }
    }

    // 2. 4 Action Buttons: Send / Pay, Receive, Stock, Budget/Ledger (Image 2)
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 6.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        QuickHomeActionButton(
          title = if (isUrdu) "ادائیگی" else "Send / Pay",
          icon = Icons.Default.ArrowUpward,
          tag = "quick_action_send",
          onClick = onSendClick
        )
        QuickHomeActionButton(
          title = if (isUrdu) "وصولی" else "Receive",
          icon = Icons.Default.ArrowDownward,
          tag = "quick_action_receive",
          onClick = onReceiveClick
        )
        if (uiState.appMode == AppMode.PERSONAL_KHATA) {
          QuickHomeActionButton(
            title = if (isUrdu) "حساب کتاب" else "Budget 💰",
            icon = Icons.Default.PieChart,
            tag = "quick_action_budget",
            onClick = onBillsClick
          )
        } else {
          QuickHomeActionButton(
            title = if (isUrdu) "پروڈکٹس" else "Products 📦",
            icon = Icons.Default.Inventory2,
            tag = "quick_action_stock",
            onClick = onStockClick
          )
          QuickHomeActionButton(
            title = if (isUrdu) "سروسز" else "Services 🛠️",
            icon = Icons.Default.Handyman,
            tag = "quick_action_services",
            onClick = onServicesClick
          )
        }
        QuickHomeActionButton(
          title = if (isUrdu) "کھاتہ" else "Khata 📊",
          icon = Icons.Default.Receipt,
          tag = "quick_action_ledger",
          onClick = onBillingClick
        )
      }
    }

    // 2b. Pakistani Digital Wallets Send & Receive Hub (JazzCash, Easypaisa, Bank, SadaPay, Raast, Cash)
    item {
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text("⚡", fontSize = 15.sp)
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isUrdu) "ادائیگی و وصولی والٹس (جازکیش • ایزی پیسہ • بینک)" else "Digital Wallets & Transfers (JazzCash • EasyPaisa • Bank)",
                fontWeight = FontWeight.Bold,
                fontSize = 12.5.sp,
                color = Color(0xFF0F172A)
              )
            }
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(0xFF086B4D).copy(alpha = 0.1f)
            ) {
              Text(
                text = if (isUrdu) "فوری ⚡" else "Instant ⚡",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF086B4D),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 7 Pakistani Channels with direct 1-tap action
          val walletScroll = rememberScrollState()
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(walletScroll),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            listOf(
              Triple(if (isUrdu) "جازکیش" else "JazzCash", "📱", Color(0xFFE11D48)),
              Triple(if (isUrdu) "ایزی پیسہ" else "Easypaisa", "🟢", Color(0xFF059669)),
              Triple(if (isUrdu) "بینک ٹرانسفر" else "Bank Transfer", "🏦", Color(0xFF0A2540)),
              Triple(if (isUrdu) "سادہ پے" else "SadaPay", "💳", Color(0xFF0D9488)),
              Triple(if (isUrdu) "نیا پے" else "NayaPay", "🟣", Color(0xFF7C3AED)),
              Triple(if (isUrdu) "راست پے" else "Raast", "⚡", Color(0xFFEA580C)),
              Triple(if (isUrdu) "نقد کیش" else "Cash", "💵", Color(0xFF16A34A))
            ).forEach { (name, icon, pillColor) ->
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = pillColor.copy(alpha = 0.08f),
                modifier = Modifier
                  .border(1.dp, pillColor.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                  .clickable { onSendClick() }
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(icon, fontSize = 13.sp)
                  Spacer(modifier = Modifier.width(5.dp))
                  Column {
                    Text(
                      text = name,
                      fontSize = 11.5.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF0F172A)
                    )
                    Text(
                      text = if (isUrdu) "ادائیگی / وصولی" else "Send / Receive",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Medium,
                      color = Color(0xFF475569)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // 3. Stock Management Banner (Only in Retail / Shop Mode)
    if (uiState.appMode == AppMode.BUSINESS_RETAIL) {
      item {
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onStockClick() }
            .testTag("home_stock_banner")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .background(Color(0xFF38BDF8).copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Inventory2,
                  contentDescription = "Stock",
                  tint = Color(0xFF38BDF8),
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = if (isUrdu) "📦 اسٹاک انوینٹری مینجمنٹ" else "📦 Stock Management",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    color = Color.White
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFF10B981)
                  ) {
                    Text(
                      text = if (isUrdu) "تازہ" else "LIVE",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                  }
                }
                Text(
                  text = if (isUrdu) "$totalStockCount اشیاء • کل مالیت: $currency ${"%,.0f".format(totalStockWorth)}" else "$totalStockCount Items • Total: $currency ${"%,.0f".format(totalStockWorth)}",
                  fontSize = 11.sp,
                  color = Color(0xFF94A3B8)
                )
              }
            }

            Button(
              onClick = onStockClick,
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Text(text = if (isUrdu) "دیکھیں ←" else "Open →", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
            }
          }
        }
      }

      // 3b. FBR Tax Deductions & Statements Card (Daily, Weekly, Monthly, Yearly)
      item {
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth().testTag("home_fbr_tax_card")
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFF047857).copy(alpha = 0.12f),
                  modifier = Modifier.size(36.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text("🏛️", fontSize = 18.sp)
                  }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = if (isUrdu) "ایف بی آر سیلز ٹیکس کٹوتی (FBR Tax)" else "FBR Tax Deductions & Audits",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF0F172A)
                  )
                  Text(
                    text = if (isUrdu) "GST 18% کٹوتی و اسٹیٹمنٹ ڈاؤنلوڈ" else "Daily, Weekly, Monthly & Yearly Deductions",
                    fontSize = 10.5.sp,
                    color = Color(0xFF047857),
                    fontWeight = FontWeight.SemiBold
                  )
                }
              }
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF047857),
                modifier = Modifier.clickable { onOpenFbrTaxReport() }
              ) {
                Text(
                  text = if (isUrdu) "اسٹیٹمنٹ ڈاؤنلوڈ 📄" else "Download Slip 📄",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 4-box Periodical Tax Deduction
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFF0FDF4),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
                modifier = Modifier.weight(1f)
              ) {
                Column(modifier = Modifier.padding(8.dp)) {
                  Text(text = if (isUrdu) "روزانہ (Daily)" else "Daily", fontSize = 9.5.sp, color = Color(0xFF166534), fontWeight = FontWeight.SemiBold)
                  Text(text = "$currency ${"%,.0f".format(todayTax)}", fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF15803D))
                }
              }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFE5F3EA),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBEDBC8)),
                modifier = Modifier.weight(1f)
              ) {
                Column(modifier = Modifier.padding(8.dp)) {
                  Text(text = if (isUrdu) "ہفتہ وار (Week)" else "Weekly", fontSize = 9.5.sp, color = Color(0xFF006C45), fontWeight = FontWeight.SemiBold)
                  Text(text = "$currency ${"%,.0f".format(weekTax)}", fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF064D3A))
                }
              }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFFAF5FF),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE9D5FF)),
                modifier = Modifier.weight(1f)
              ) {
                Column(modifier = Modifier.padding(8.dp)) {
                  Text(text = if (isUrdu) "ماہانہ (Month)" else "Monthly", fontSize = 9.5.sp, color = Color(0xFF6B21A8), fontWeight = FontWeight.SemiBold)
                  Text(text = "$currency ${"%,.0f".format(monthTax)}", fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF7E22CE))
                }
              }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFFFFBEB),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
                modifier = Modifier.weight(1f)
              ) {
                Column(modifier = Modifier.padding(8.dp)) {
                  Text(text = if (isUrdu) "سالانہ (Year)" else "Yearly", fontSize = 9.5.sp, color = Color(0xFF92400E), fontWeight = FontWeight.SemiBold)
                  Text(text = "$currency ${"%,.0f".format(yearTax)}", fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFB45309))
                }
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (isUrdu) "حکومت کو قابل ادا سیلز ٹیکس (Net Tax to Pay):" else "Net Tax Payable to FBR:",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF475569)
              )
              Text(
                text = "$currency ${"%,.0f".format(netTaxPayable)}",
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF047857)
              )
            }
          }
        }
      }
    }

    // Subscription and payment details are shown on the business overview only.

    // 4. Search Bar (Search transactions, notes... - Image 2)
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = {
          searchQuery = it
          onSearchQueryChanged(it)
        },
        placeholder = { Text(if (isUrdu) "لین دین، گاہک یا نوٹ تلاش کریں..." else "Search transactions, notes...", fontSize = 13.sp, color = Color(0xFF94A3B8)) },
        leadingIcon = {
          Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF94A3B8))
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        textStyle = InputFieldStyles.textStyle,
        colors = InputFieldStyles.colors(),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("home_search_transactions")
      )
    }

    // 5. Filter Chips (All, Expenses, Income, Shopping, Transfer...) (Image 2)
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf(
          Pair(FilterCategory.ALL, if (isUrdu) "سب" else "All"),
          Pair(FilterCategory.EXPENSES, if (isUrdu) "اخراجات" else "Expenses"),
          Pair(FilterCategory.INCOME, if (isUrdu) "آمدن" else "Income"),
          Pair(FilterCategory.SHOPPING, if (isUrdu) "خریداری 🛍️" else "Shopping 🛍️"),
          Pair(FilterCategory.FOOD, if (isUrdu) "کھانا پینا 🍔" else "Food 🍔"),
          Pair(FilterCategory.BILLS, if (isUrdu) "بلز ⚡" else "Bills ⚡"),
          Pair(FilterCategory.TRANSPORT, if (isUrdu) "ٹرانسفر 💸" else "Transfer 💸")
        ).forEach { (cat, label) ->
          val isSelected = selectedFilter == cat
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isSelected) Color(0xFF086B4D) else Color(0xFFF7F9F3),
            modifier = Modifier
              .clickable {
                selectedFilter = cat
                onFilterSelected(cat)
              }
              .padding(vertical = 2.dp)
          ) {
            Text(
              text = label,
              fontSize = 11.5.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) Color.White else Color(0xFF475569),
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
            )
          }
        }
      }
    }

    // 6. Recent Activity Header + Add Button (Image 2)
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isUrdu) "حالیہ لین دین" else "Recent Activity",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
          )
        )

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = Color(0xFFE5F3EA),
          modifier = Modifier.clickable { onAddNewClick() }
        ) {
          Text(
            text = if (isUrdu) "+ نیا اندراج" else "+ Add",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF086B4D),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }
      }
    }

    // 7. Recent Transactions List (Image 2)
    if (filteredTransactions.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          modifier = Modifier.fillMaxWidth()
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = if (isUrdu) "کوئی حالیہ لین دین موجود نہیں۔\nنیا اندراج کرنے کے لیے اوپر '+ نیا اندراج' کا بٹن دبائیں۔" else "No recent transactions found.\nTap '+ Add' or 'Send / Receive' to log a payment.",
              fontSize = 12.sp,
              color = Color(0xFF64748B),
              textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
          }
        }
      }
    } else {
      items(filteredTransactions.take(5)) { tx ->
        TransactionItemCard(
          transaction = tx,
          currencySymbol = currency,
          onClick = { onTransactionClick(tx) }
        )
      }
    }

    // 8. SECTION: FINANCIAL SUMMARY (MAALI HISAAB) (Screenshot 1)
    item {
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = if (isUrdu) "مالی حساب کتاب کا خلاصہ" else "FINANCIAL SUMMARY",
        style = MaterialTheme.typography.labelMedium.copy(
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.1.sp,
          color = Color(0xFF64748B),
          fontSize = 11.5.sp
        )
      )
    }

    // Dual Cards: TOTAL SALE & TOTAL PURCHASE
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Left: TOTAL SALE (Blue Gradient)
        Card(
          shape = RoundedCornerShape(18.dp),
          modifier = Modifier
            .weight(1f)
            .clickable { onBillingClick() },
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(
                Brush.verticalGradient(
                  colors = listOf(Color(0xFF0052D4), Color(0xFF4364F7), Color(0xFF086B4D))
                )
              )
              .padding(12.dp)
          ) {
            Column {
              Text(
                text = if (isUrdu) "کل فروخت (سیل)" else "TOTAL SALE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.9f)
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "$currency ${"%,.0f".format(totalSalesAmount)}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp, horizontal = 6.dp),
                  horizontalArrangement = Arrangement.SpaceAround
                ) {
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (isUrdu) "نقد" else "CASH", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF059669))
                    Text("${"%,.0f".format(cashSales)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                  }
                  Box(modifier = Modifier.width(1.dp).height(18.dp).background(Color(0xFFE2E8F0)))
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (isUrdu) "ادھار" else "UDHAAR", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                    Text("${"%,.0f".format(udhaarSales)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                  }
                }
              }
            }
          }
        }

        // Right: TOTAL PURCHASE (Purple Gradient)
        Card(
          shape = RoundedCornerShape(18.dp),
          modifier = Modifier
            .weight(1f)
            .clickable { onStockClick() },
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(
                Brush.verticalGradient(
                  colors = listOf(Color(0xFF5B21B6), Color(0xFF7C3AED), Color(0xFF8B5CF6))
                )
              )
              .padding(12.dp)
          ) {
            Column {
              Text(
                text = if (isUrdu) "کل خریداری (پرچیز)" else "TOTAL PURCHASE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.9f)
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "$currency ${"%,.0f".format(totalPurchase)}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp, horizontal = 6.dp),
                  horizontalArrangement = Arrangement.SpaceAround
                ) {
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (isUrdu) "نقد" else "CASH", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF059669))
                    Text("${"%,.0f".format(purchaseCash)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                  }
                  Box(modifier = Modifier.width(1.dp).height(18.dp).background(Color(0xFFE2E8F0)))
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (isUrdu) "ادھار" else "UDHAAR", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                    Text("${"%,.0f".format(purchaseUdhaar)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                  }
                }
              }
            }
          }
        }
      }
    }

    // Row 2: RECOVERY MONTH & PAYMENT MONTH
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        SummaryMiniCard(
          title = if (isUrdu) "ماہانہ وصولی" else "MONTHLY RECOVERY",
          amount = "$currency ${"%,.0f".format(recoveryMonth)}",
          urduSubtitle = if (isUrdu) "گاہکوں سے وصول شدہ" else "Cash Collected",
          containerColor = Color(0xFFE8F8F0),
          titleColor = Color(0xFF059669),
          amountColor = Color(0xFF0F172A),
          subtitleColor = Color(0xFF059669),
          modifier = Modifier.weight(1f)
        )

        SummaryMiniCard(
          title = if (isUrdu) "ماہانہ ادائیگی" else "MONTHLY PAYMENTS",
          amount = if (uiState.userRole == UserRole.EMPLOYEE && !uiState.employeePermissions.canAccessDebts) "🔒 Restricted" else "$currency ${"%,.0f".format(paymentMonth)}",
          urduSubtitle = if (uiState.userRole == UserRole.EMPLOYEE && !uiState.employeePermissions.canAccessDebts) "OWNER ONLY" else if (isUrdu) "سپلائرز کو ادائیگیاں" else "Vendor Payments",
          containerColor = Color(0xFFFDF2F4),
          titleColor = Color(0xFFE11D48),
          amountColor = Color(0xFF0F172A),
          subtitleColor = Color(0xFFE11D48),
          modifier = Modifier.weight(1f)
        )
      }
    }

    // Row 3: EXPENSE MONTH & NET PROFIT MONTH
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        SummaryMiniCard(
          title = if (isUrdu) "ماہانہ اخراجات" else "MONTHLY EXPENSES",
          amount = "$currency ${"%,.0f".format(expenseMonth)}",
          urduSubtitle = if (isUrdu) "دکان کے کل اخراجات" else "Shop Expenses",
          containerColor = Color(0xFFFEF2F2),
          titleColor = Color(0xFFDC2626),
          amountColor = Color(0xFF0F172A),
          subtitleColor = Color(0xFFDC2626),
          modifier = Modifier.weight(1f)
        )

        SummaryMiniCard(
          title = if (isUrdu) "خالص منافع (نیٹ پرافٹ)" else "NET PROFIT",
          amount = if (uiState.userRole == UserRole.EMPLOYEE && !uiState.employeePermissions.canViewProfits) "🔒 Restricted" else "$currency ${"%,.0f".format(netProfitMonth)}",
          urduSubtitle = if (uiState.userRole == UserRole.EMPLOYEE && !uiState.employeePermissions.canViewProfits) "OWNER ONLY" else if (isUrdu) "اخراجات کے بعد بچت" else "Profit After Expense",
          containerColor = Color(0xFFECFDF5),
          titleColor = Color(0xFF059669),
          amountColor = Color(0xFF0F172A),
          subtitleColor = Color(0xFF059669),
          modifier = Modifier.weight(1f)
        )
      }
    }

    // Row 4: CASH IN HAND & ADD EXPENSE
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F9FF)),
          modifier = Modifier.weight(1.3f)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = if (isUrdu) "موجودہ نقد رقم (کیش ان ہینڈ)" else "CASH IN HAND",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF13865F)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "$currency ${"%,.0f".format(cashInHand)}",
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (isUrdu) "دکان کے گلے میں موجود کیش" else "Drawer Available Cash",
              fontSize = 9.5.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF13865F)
            )
          }
        }

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F2)),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECDD3)),
          modifier = Modifier
            .weight(0.9f)
            .clickable { onSendClick() }
            .testTag("home_add_expense_btn")
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.AddCircle,
              contentDescription = "Add Expense",
              tint = Color(0xFFE11D48),
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (isUrdu) "نیا خرچہ\nدرج کریں" else "ADD\nEXPENSE",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFFE11D48),
              textAlign = androidx.compose.ui.text.style.TextAlign.Center,
              lineHeight = 13.sp
            )
          }
        }
      }
    }

    // 9. SECTION: LEDGER TOTALS (KHATA SUMMARY)
    item {
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = if (isUrdu) "کھاتہ جات کا مجموعہ" else "LEDGER TOTALS",
        style = MaterialTheme.typography.labelMedium.copy(
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.1.sp,
          color = Color(0xFF64748B),
          fontSize = 11.5.sp
        )
      )
    }

    // Row 5: RECEIVABLE & PAYABLE
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        SummaryMiniCard(
          title = if (isUrdu) "آپ نے لینا ہے" else "RECEIVABLE",
          amount = "$currency ${"%,.0f".format(receivableKhata)}",
          urduSubtitle = if (isUrdu) "گاہکوں سے بقایا ادھار" else "Customer Udhaar Due",
          containerColor = Color(0xFFDCFCE7),
          titleColor = Color(0xFF15803D),
          amountColor = Color(0xFF0F172A),
          subtitleColor = Color(0xFF15803D),
          modifier = Modifier
            .weight(1f)
            .clickable { onBillingClick() }
        )

        SummaryMiniCard(
          title = if (isUrdu) "آپ نے دینا ہے" else "PAYABLE",
          amount = "$currency ${"%,.0f".format(payableKhata)}",
          urduSubtitle = if (isUrdu) "سپلائرز کو ادائیگیاں" else "Supplier Debts Due",
          containerColor = Color(0xFFFFE4E6),
          titleColor = Color(0xFFBE123C),
          amountColor = Color(0xFF0F172A),
          subtitleColor = Color(0xFFBE123C),
          modifier = Modifier.weight(1f)
        )
      }
    }

    item { Spacer(modifier = Modifier.height(70.dp)) }
  }
}

@Composable
private fun QuickHomeActionButton(
  title: String,
  icon: ImageVector,
  tag: String,
  onClick: () -> Unit
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable(onClick = onClick)
      .testTag(tag)
      .padding(4.dp)
  ) {
    Box(
      modifier = Modifier
        .size(54.dp)
        .clip(RoundedCornerShape(16.dp))
        .background(IceBlueContainer),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = OnIceBlueContainer,
        modifier = Modifier.size(24.dp)
      )
    }

    Text(
      text = title,
      style = MaterialTheme.typography.labelSmall.copy(
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        color = TextPrimary,
        lineHeight = 13.sp
      ),
      maxLines = 1,
      modifier = Modifier
        .height(18.dp)
        .padding(top = 2.dp)
    )
  }
}

@Composable
private fun SummaryMiniCard(
  title: String,
  amount: String,
  urduSubtitle: String,
  containerColor: Color,
  titleColor: Color,
  amountColor: Color,
  subtitleColor: Color,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    modifier = modifier
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = title,
        fontSize = 10.5.sp,
        fontWeight = FontWeight.Bold,
        color = titleColor
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = amount,
        fontSize = 17.sp,
        fontWeight = FontWeight.Bold,
        color = amountColor
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = urduSubtitle,
        fontSize = 9.5.sp,
        fontWeight = FontWeight.SemiBold,
        color = subtitleColor
      )
    }
  }
}
