package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.EmployeePermissions
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoPrimary

@Composable
fun EmployeePermissionsDialog(
  currentPermissions: EmployeePermissions,
  onSavePermissions: (EmployeePermissions) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current

  var canAddProducts by remember { mutableStateOf(currentPermissions.canAddProducts) }
  var canUploadStock by remember { mutableStateOf(currentPermissions.canUploadStock) }
  var canGenerateInvoice by remember { mutableStateOf(currentPermissions.canGenerateInvoice) }
  var canGenerateDailyWeeklyReport by remember { mutableStateOf(currentPermissions.canGenerateDailyWeeklyReport) }
  var canGenerateMonthlyReport by remember { mutableStateOf(currentPermissions.canGenerateMonthlyReport) }
  var canGiveDiscounts by remember { mutableStateOf(currentPermissions.canGiveDiscounts) }
  var canViewProfits by remember { mutableStateOf(currentPermissions.canViewProfits) }
  var canAccessDebts by remember { mutableStateOf(currentPermissions.canAccessDebts) }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(24.dp))
        .testTag("employee_permissions_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = IndigoPrimary.copy(alpha = 0.12f),
              modifier = Modifier.size(38.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.AdminPanelSettings,
                  contentDescription = null,
                  tint = IndigoPrimary,
                  modifier = Modifier.size(22.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Employee RBAC Permissions",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
              )
              Text(
                text = "ملازم کے اختیارات و رسائی کا بورڈ",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = "مالک یہاں سے ملازم کو مخصوص کاموں کی اجازت دے سکتا ہے۔ ملازم ماسٹر شاپ منافع اور بینک اکاؤنٹس کو کبھی نہیں دیکھ سکے گا۔",
          fontSize = 11.sp,
          color = Color(0xFF475569)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 1. Add New Products
        PermissionSwitchRow(
          title = "Add New Products",
          urduTitle = "سامان / نیا پراڈکٹ شامل کرنا",
          description = "Employee can add products to inventory list",
          checked = canAddProducts,
          onCheckedChange = { canAddProducts = it }
        )

        HorizontalDivider(color = Color(0xFFF7F9F3), modifier = Modifier.padding(vertical = 8.dp))

        // 2. Upload / Adjust Stock
        PermissionSwitchRow(
          title = "Upload & Restock Inventory",
          urduTitle = "اسٹاک و گودام کا سامان داخل کرنا",
          description = "Employee can update quantities and stock balance",
          checked = canUploadStock,
          onCheckedChange = { canUploadStock = it }
        )

        HorizontalDivider(color = Color(0xFFF7F9F3), modifier = Modifier.padding(vertical = 8.dp))

        // 3. Generate POS Invoices
        PermissionSwitchRow(
          title = "Generate POS Invoices & Bills",
          urduTitle = "کاؤنٹر پر بل اور رسید بنانا",
          description = "Employee can sell goods and print receipts",
          checked = canGenerateInvoice,
          onCheckedChange = { canGenerateInvoice = it }
        )

        HorizontalDivider(color = Color(0xFFF7F9F3), modifier = Modifier.padding(vertical = 8.dp))

        // 4. Daily / Weekly Shift Closure Reports
        PermissionSwitchRow(
          title = "Daily & Weekly Closure Report",
          urduTitle = "روزانہ اور ہفتہ وار شفٹ رپورٹ نکالنا",
          description = "Employee can generate sales summary to clear cash drawer",
          checked = canGenerateDailyWeeklyReport,
          onCheckedChange = { canGenerateDailyWeeklyReport = it }
        )

        HorizontalDivider(color = Color(0xFFF7F9F3), modifier = Modifier.padding(vertical = 8.dp))

        // 5. Monthly Report Access (Owner configurable)
        PermissionSwitchRow(
          title = "Monthly Full Financial Report",
          urduTitle = "ماہانہ مکمل رپورٹ نکالنے کی اجازت",
          description = "Owner can optionally unlock monthly sales closure for manager",
          checked = canGenerateMonthlyReport,
          onCheckedChange = { canGenerateMonthlyReport = it }
        )

        HorizontalDivider(color = Color(0xFFF7F9F3), modifier = Modifier.padding(vertical = 8.dp))

        // 6. Give Discounts
        PermissionSwitchRow(
          title = "Give Discounts at POS",
          urduTitle = "بل بناتے وقت رعایت (ڈسکاؤنٹ) دینا",
          description = "Employee can apply custom discount % or flat PKR",
          checked = canGiveDiscounts,
          onCheckedChange = { canGiveDiscounts = it }
        )

        HorizontalDivider(color = Color(0xFFF7F9F3), modifier = Modifier.padding(vertical = 8.dp))

        // 7. View Net Profits (strictly owner by default)
        PermissionSwitchRow(
          title = "View Shop Net Profits",
          urduTitle = "دکان کا کل منافع (پرافٹ) دیکھنا",
          description = "Warning: Exposes owner margins and net profit sheet",
          checked = canViewProfits,
          onCheckedChange = { canViewProfits = it }
        )

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = {
            val perms = EmployeePermissions(
              canAddProducts = canAddProducts,
              canUploadStock = canUploadStock,
              canGenerateInvoice = canGenerateInvoice,
              canGenerateDailyWeeklyReport = canGenerateDailyWeeklyReport,
              canGenerateMonthlyReport = canGenerateMonthlyReport,
              canGiveDiscounts = canGiveDiscounts,
              canViewProfits = canViewProfits,
              canAccessDebts = canAccessDebts
            )
            onSavePermissions(perms)
            Toast.makeText(context, "Employee permissions updated successfully!", Toast.LENGTH_SHORT).show()
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_employee_permissions_btn")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Save Permissions (اختیارات محفوظ کریں)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }
        }
      }
    }
  }
}

@Composable
private fun PermissionSwitchRow(
  title: String,
  urduTitle: String,
  description: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF0F172A)
      )
      Text(
        text = urduTitle,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = IndigoPrimary
      )
      Text(
        text = description,
        fontSize = 10.sp,
        color = Color(0xFF64748B)
      )
    }
    Spacer(modifier = Modifier.width(10.dp))
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = IndigoPrimary
      )
    )
  }
}
