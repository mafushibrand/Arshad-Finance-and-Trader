package com.example.ui.dialogs

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.Invoice
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.InputFieldStyles
import com.example.util.BusinessProfile
import com.example.util.BusinessUtils
import com.example.util.InvoicePrintExportUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LegacyCustomerDetailDialog(
  customer: Customer,
  invoices: List<Invoice>,
  businessProfile: BusinessProfile,
  currencySymbol: String = "Rs",
  onEditCustomer: (Customer) -> Unit = {},
  onSelectInvoice: (Invoice) -> Unit = {},
  onNewBillForCustomer: (Customer) -> Unit,
  onDeleteCustomer: (Customer) -> Unit,
  onDismiss: () -> Unit,
  onReceiveCash: (Double, String, (String?) -> Unit) -> Unit = { _, _, done -> done("Receipt action unavailable") }
) {
  val context = LocalContext.current
  val shopName = businessProfile.businessName.ifBlank { "ARSHAD FINANCE & TRADERS" }
  val shopLogo = businessProfile.logoEmoji.ifBlank { "🏪" }

  var showDeleteConfirm by remember { mutableStateOf(false) }
  var receiptSaving by remember { mutableStateOf(false) }
  var showMaineLiyeDialog by remember { mutableStateOf(false) }
  var maineLiyeAmount by remember { mutableStateOf("") }
  var maineLiyeNote by remember { mutableStateOf("Recovery / وصول شدہ رقم") }

  // Filter invoices for this customer
  val customerInvoices = invoices.filter {
    it.customerId == customer.id || (it.customerName.equals(customer.name, ignoreCase = true) && customer.name.isNotBlank())
  }

  val outstandingBalance = customer.currentBalance
  val dateFormat = SimpleDateFormat("yyyy-MM-dd • hh:mm a", Locale.getDefault())

  if (showDeleteConfirm) {
    AlertDialog(
      onDismissRequest = { showDeleteConfirm = false },
      title = { Text("Delete Customer Record?", fontWeight = FontWeight.Bold) },
      text = { Text("Are you sure you want to delete ${customer.name}? This will remove customer profile from Khata.") },
      confirmButton = {
        Button(
          onClick = {
            showDeleteConfirm = false
            onDeleteCustomer(customer)
            Toast.makeText(context, "Customer removed", Toast.LENGTH_SHORT).show()
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
        ) {
          Text("Delete")
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteConfirm = false }) {
          Text("Cancel")
        }
      }
    )
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier.fillMaxSize(),
      color = Color(0xFFF5F7F2)
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
          // 1. Top Curved Blue Header (Screenshots 2 & 3)
          Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF086B4D),
            shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(Color.White),
                contentAlignment = Alignment.Center
              ) {
                Text(text = shopLogo, fontSize = 20.sp)
              }
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = shopName.uppercase(),
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  letterSpacing = 0.8.sp
                )
              )
            }
          }

          // 2. Customer Sub-Header Bar (Back Arrow, Customer Name, Call, WhatsApp, Menu)
          Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color.White,
            shadowElevation = 1.dp
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDismiss) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF0F172A)
                  )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = customer.name,
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF0F172A)
                )
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                // Call Icon
                IconButton(onClick = {
                  val phone = customer.phone.ifBlank { "03001234567" }
                  val callIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                  context.startActivity(callIntent)
                }) {
                  Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Call",
                    tint = Color(0xFF086B4D)
                  )
                }

                // WhatsApp Icon
                IconButton(onClick = {
                  val phone = customer.phone.ifBlank { "03001234567" }
                  val msg = "Assalam-o-Alaikum ${customer.name},\nYour outstanding balance with $shopName is $currencySymbol ${"%,.0f".format(outstandingBalance)}. Please clear at your earliest convenience."
                  BusinessUtils.shareWhatsAppMessage(context, phone, msg)
                }) {
                  Surface(
                    shape = CircleShape,
                    color = Color(0xFF25D366),
                    modifier = Modifier.size(32.dp)
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Text("💬", fontSize = 16.sp)
                    }
                  }
                }

                IconButton(onClick = { showDeleteConfirm = true }) {
                  Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "More",
                    tint = Color(0xFF64748B)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // 3. OUTSTANDING BALANCE CARD (Screenshots 2 & 3)
          Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "OUTSTANDING BALANCE",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF64748B),
                  letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = "$currencySymbol. ${"%,.0f".format(outstandingBalance)}",
                  fontSize = 24.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFFEF4444) // Bright Red
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = "AAP NE LENA HAI",
                  fontSize = 10.5.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFFEF4444)
                )
              }

              // Right Buttons: STATEMENT (Black) & SHARE (Green)
              Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.End
              ) {
                // STATEMENT button
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFF0F172A),
                  modifier = Modifier
                    .clickable {
                      Toast.makeText(context, "Exporting Customer Ledger Statement...", Toast.LENGTH_SHORT).show()
                    }
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(Icons.Default.Download, contentDescription = "Statement", tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("STATEMENT", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                  }
                }

                // SHARE button
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFF10B981),
                  modifier = Modifier
                    .clickable {
                      val phone = customer.phone.ifBlank { "03001234567" }
                      val msg = "Statement for ${customer.name}:\nOutstanding Balance: $currencySymbol ${"%,.0f".format(outstandingBalance)}.\nShop: $shopName"
                      BusinessUtils.shareWhatsAppMessage(context, phone, msg)
                    }
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("SHARE", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 3b. 2-Day Overdue Udhaar Reminder Action Banner
          if (outstandingBalance > 0) {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color(0xFFFEF3C7),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp)
                .clickable {
                  val phone = customer.phone.ifBlank { "03001234567" }
                  val reminderMsg = "محترم جناب ${customer.name} صاحب! آپ کے کھاتے کی واجب الادا رقم $currencySymbol ${"%,.0f".format(outstandingBalance)} بقایا ہے جس پر 2 دن کی میعاد گزر چکی ہے۔ برائے مہربانی اپنا کھاتہ جلد از جلد کلیئر فرمائیں۔ شکریہ! دکان: $shopName"
                  BusinessUtils.shareWhatsAppMessage(context, phone, reminderMsg)
                  Toast.makeText(context, "2-Day Overdue Reminder opened in WhatsApp!", Toast.LENGTH_SHORT).show()
                }
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text("⚠️", fontSize = 16.sp)
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(
                      text = "2-Day Overdue Udhaar Reminder (بقایا ادھار یاددہانی)",
                      fontSize = 11.5.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF92400E)
                    )
                    Text(
                      text = "Tap to send automated WhatsApp reminder with due balance",
                      fontSize = 9.5.sp,
                      color = Color(0xFFB45309)
                    )
                  }
                }
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = Color(0xFF25D366)
                ) {
                  Text(
                    text = "Send 💬",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 4. Ledger Transaction Cards History (Screenshots 2 & 3)
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f)
              .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // Customer Invoices / Ledger Entries
            if (customerInvoices.isNotEmpty()) {
              items(customerInvoices) { inv ->
                Card(
                  shape = RoundedCornerShape(16.dp),
                  colors = CardDefaults.cardColors(containerColor = Color.White),
                  elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectInvoice(inv) }
                ) {
                  Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(
                        text = dateFormat.format(Date(inv.dateMillis)),
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                      )

                      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(shape = CircleShape, color = Color(0xFFFEF3C7), modifier = Modifier.size(26.dp)) {
                          Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color(0xFFD97706), modifier = Modifier.size(13.dp))
                          }
                        }
                      }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(
                        text = "Sale ",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                      )
                      Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFFF7F9F3)
                      ) {
                        Text(
                          text = "BILL# ${inv.invoiceNumber}",
                          fontSize = 9.5.sp,
                          fontWeight = FontWeight.Bold,
                          color = Color(0xFF475569),
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 3 Columns: TOTAL BILL | PAID | BAQAYA
                    Surface(
                      shape = RoundedCornerShape(10.dp),
                      color = Color(0xFFF5F7F2)
                    ) {
                      Row(
                        modifier = Modifier
                          .fillMaxWidth()
                          .padding(vertical = 8.dp, horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                      ) {
                        Column {
                          Text("TOTAL BILL", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                          Text("$currencySymbol. ${"%,.0f".format(inv.grandTotal)}", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                        }
                        Column {
                          Text("PAID", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                          Text("$currencySymbol. ${"%,.0f".format(inv.amountPaid)}", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF086B4D))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                          Text("BAQAYA", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                          Text(
                            text = "$currencySymbol. ${"%,.0f".format(inv.remainingBalance)}",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (inv.remainingBalance > 0) Color(0xFFEF4444) else Color(0xFF10B981)
                          )
                        }
                      }
                    }
                  }
                }
              }
            } else {
              item {
                Card(
                  shape = RoundedCornerShape(16.dp),
                  colors = CardDefaults.cardColors(containerColor = Color.White),
                  elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Text(
                      text = "📋",
                      fontSize = 32.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                      text = "No Previous Bills or Transactions",
                      fontWeight = FontWeight.Bold,
                      fontSize = 14.sp,
                      color = Color(0xFF0F172A)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = "Tap '+ MAINE LIYE' to record payment or '- MAINE DIYE' to add new bill/credit.",
                      fontSize = 11.5.sp,
                      color = Color(0xFF64748B),
                      textAlign = TextAlign.Center
                    )
                  }
                }
              }
            }

            item { Spacer(modifier = Modifier.height(80.dp)) }
          }
        }

        // 5. STICKY FLOATING BOTTOM ACTION BAR: + MAINE LIYE & - MAINE DIYE (Screenshots 2 & 3)
        Surface(
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .padding(14.dp),
          shape = RoundedCornerShape(18.dp),
          color = Color.Transparent
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            // Green Button: + MAINE LIYE (Wasooli)
            Button(
              onClick = { showMaineLiyeDialog = true },
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)), // Green
              modifier = Modifier
                .weight(1f)
                .height(52.dp)
                .testTag("btn_maine_liye")
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("MAINE LIYE", fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
            }

            // Red Button: - MAINE DIYE (Udhar Diya / Sale)
            Button(
              onClick = { onNewBillForCustomer(customer) },
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)), // Red
              modifier = Modifier
                .weight(1f)
                .height(52.dp)
                .testTag("btn_maine_diye")
            ) {
              Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("MAINE DIYE", fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }

  // Maine Liye (Wasooli Dialog)
  if (showMaineLiyeDialog) {
    Dialog(onDismissRequest = { showMaineLiyeDialog = false }) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text("نقد وصولی (+ Maine Liye)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = maineLiyeAmount,
            onValueChange = { maineLiyeAmount = it },
            label = { Text("Amount Wasool ($currencySymbol)") },
            placeholder = { Text("500") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = maineLiyeNote,
            onValueChange = { maineLiyeNote = it },
            label = { Text("Note / Detail") },
            singleLine = true,
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(14.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
          ) {
            TextButton(onClick = { showMaineLiyeDialog = false }) { Text("Cancel") }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = {
                val amt = maineLiyeAmount.toDoubleOrNull() ?: 0.0
                if (amt > 0 && !receiptSaving) {
                  receiptSaving = true
                  onReceiveCash(amt, maineLiyeNote) { error ->
                    receiptSaving = false
                    if (error == null) showMaineLiyeDialog = false
                    else Toast.makeText(context, error, Toast.LENGTH_LONG).show()
                  }
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
            ) {
              Text("Save Wasooli")
            }
          }
        }
      }
    }
  }
}
