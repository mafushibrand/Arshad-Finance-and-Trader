package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.LightSurface
import com.example.ui.theme.OnIceBlueContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextTertiary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TransactionItemCard(
  transaction: Transaction,
  currencySymbol: String = "$",
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isIncome = transaction.type == TransactionType.INCOME
  val amountPrefix = if (isIncome) "+" else "-"
  val amountColor = if (isIncome) IncomeGreen else ExpenseRed

  val formattedTime = formatTransactionDate(transaction.dateMillis)

  Row(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(24.dp))
      .background(LightSurface)
      .clickable(onClick = onClick)
      .padding(14.dp)
      .testTag("transaction_item_${transaction.id}"),
    verticalAlignment = Alignment.CenterVertically
  ) {
    // Icon badge inside crisp white circle
    Box(
      modifier = Modifier
        .size(48.dp)
        .clip(CircleShape)
        .background(Color.White),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = transaction.icon.ifBlank { if (isIncome) "💵" else "🛍️" },
        fontSize = 20.sp
      )
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(
      modifier = Modifier.weight(1f)
    ) {
      Text(
        text = transaction.title,
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        ),
        maxLines = 1
      )

      Spacer(modifier = Modifier.height(2.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text(
          text = "$formattedTime • ${transaction.accountName}",
          style = MaterialTheme.typography.bodySmall.copy(
            color = TextTertiary,
            fontWeight = FontWeight.Medium
          ),
          maxLines = 1
        )

        if (transaction.paymentMethod.isNotBlank()) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(IceBlueContainer)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = transaction.paymentMethod,
              style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = OnIceBlueContainer
              )
            )
          }
        }

        if (transaction.receiptImageUri.isNotBlank()) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0xFFE8F5E9))
              .padding(horizontal = 5.dp, vertical = 2.dp)
          ) {
            Text(
              text = "📸 Proof",
              style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = IncomeGreen
              )
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.width(8.dp))

    Text(
      text = String.format(Locale.US, "%s%s%,.2f", amountPrefix, currencySymbol, transaction.amount),
      style = MaterialTheme.typography.titleMedium.copy(
        fontWeight = FontWeight.Bold,
        color = amountColor
      )
    )
  }
}

private fun formatTransactionDate(timeMillis: Long): String {
  val now = System.currentTimeMillis()
  val diff = now - timeMillis
  val oneDay = 86400_000L

  return when {
    diff < oneDay && diff >= 0 -> {
      val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
      "Today, ${timeFormat.format(Date(timeMillis))}"
    }
    diff < 2 * oneDay && diff >= oneDay -> {
      "Yesterday"
    }
    else -> {
      val dateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
      dateFormat.format(Date(timeMillis))
    }
  }
}
