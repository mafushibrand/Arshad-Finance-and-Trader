package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.FinanceUiState
import com.example.business.PersonalKhataEngine
import com.example.ui.dialogs.BusinessField
import com.example.ui.dialogs.BusinessForm

@Composable
fun PersonalKhataScreen(state:FinanceUiState,onBusiness:()->Unit,onLanguage:()->Unit,onBackup:()->Unit,
  addContact:(String,String,(String?)->Unit)->Unit,addEntry:(String,Double,String,String,(String?)->Unit)->Unit) {
  var query by remember {mutableStateOf("")};var newPerson by remember {mutableStateOf(false)}
  var selected by remember {mutableStateOf("")};var direction by remember {mutableStateOf("GAVE")}
  var name by remember {mutableStateOf("")};var phone by remember {mutableStateOf("")};var value by remember {mutableStateOf("")};var note by remember {mutableStateOf("")}
  var error by remember {mutableStateOf("")};var busy by remember {mutableStateOf(false)}
  val contacts=state.businessRecords.filter {it.kind=="PERSONAL_CONTACT" && !it.archived}
  fun done(e:String?){busy=false;error=e ?: "";if(e==null){newPerson=false;selected="";value="";note="";name="";phone=""}}
  PremiumPage(state.word("Personal Khata • Free","ذاتی کھاتہ • مفت"),state.word("Your personal ledger stays free","آپ کا ذاتی کھاتہ ہمیشہ مفت ہے"),Icons.Default.MenuBook,
    footer={PremiumButton(state.word("Add person","نام شامل کریں"),{error="";newPerson=true},modifier=Modifier.padding(16.dp).testTag("personal_add_contact"))}) {
    item {Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
      TextButton(onClick=onLanguage){Icon(Icons.Default.Translate,null);Text("English / اردو")}
      TextButton(onClick=onBackup){Icon(Icons.Default.Backup,null);Text(state.word("Backup","بیک اپ"))}
    }}
    item {Card {Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
      Text(if(state.appMode!=com.example.data.model.AppMode.PERSONAL_KHATA && !state.subscriptionState.hasBusinessAccess)state.word("Business access expired","کاروباری رسائی ختم ہو گئی") else state.word("Need a shop?","دکان کے لیے چاہیے؟"),style=MaterialTheme.typography.titleLarge)
      Text(if(state.subscriptionState.clockBlocked)state.word("Correct your phone date to restore business access.","کاروباری رسائی کے لیے فون کی تاریخ درست کریں۔") else state.word("30 days free, then Rs. 300/month or Rs. 3,000/year. Personal Khata is free.","۳۰ دن مفت، پھر ۳۰۰ روپے ماہانہ یا ۳۰۰۰ روپے سالانہ۔ ذاتی کھاتہ مفت ہے۔"))
      Button(onClick=onBusiness,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp).testTag("personal_business_upgrade")){Text(state.word("Plans & payment / Start shop","پلان اور ادائیگی / دکان شروع کریں"))}
    }}}
    item {SearchBox(query,state.word("Find a person","نام تلاش کریں")){query=it}}
    if(contacts.isEmpty())item {EmptyList(state.word("Add your first person","پہلا نام شامل کریں"),state.word("Record money given and received","دی گئی اور وصول کی گئی رقم درج کریں"),Icons.Default.PersonAdd)}
    items(contacts.filter {it.title.contains(query,true)},key={it.id}) {person->
      val balance=PersonalKhataEngine.balance(state.businessRecords,person.id)
      Card {Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text(person.title,style=MaterialTheme.typography.titleLarge)
        Text(state.word(if(balance>=0)"To receive: " else "To pay: ",if(balance>=0)"وصول کرنا: " else "ادا کرنا: ")+state.money(kotlin.math.abs(balance)))
        Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
          Button(onClick={selected=person.id;direction="GAVE";error=""},modifier=Modifier.weight(1f).heightIn(min=54.dp)){Icon(Icons.Default.NorthEast,null);Text(state.word("I gave","میں نے دیے"))}
          FilledTonalButton(onClick={selected=person.id;direction="RECEIVED";error=""},modifier=Modifier.weight(1f).heightIn(min=54.dp)){Icon(Icons.Default.SouthWest,null);Text(state.word("I received","مجھے ملے"))}
        }
        state.businessRecords.filter {it.kind=="PERSONAL_ENTRY" && it.party==person.id}.take(5).forEach {entry->
          val gave=org.json.JSONObject(entry.payload).optString("direction")=="GAVE"
          Text(state.word(if(gave)"Gave " else "Received ",if(gave)"دیے " else "ملے ")+state.money(entry.amount)+" • "+entry.title)
        }
      }}
    }
    if(error.isNotBlank())item {Text(error,color=MaterialTheme.colorScheme.error)}
  }
  if(newPerson)BusinessForm(state.word("Add person","نام شامل کریں"),state.word("Save","محفوظ کریں"),{if(!busy)newPerson=false},{if(!busy){busy=true;addContact(name,phone,::done)}}) {
    BusinessField(name,state.word("Name","نام")){name=it};BusinessField(phone,state.word("Phone (optional)","فون (اختیاری)")){phone=it}
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
  if(selected.isNotEmpty())BusinessForm(contacts.find {it.id==selected}?.title ?: "",state.word("Save entry","اندراج محفوظ کریں"),{if(!busy)selected=""},{
    if(!busy){val n=value.toDoubleOrNull();if(n==null||!n.isFinite()||n<=0)error=state.word("Enter a valid amount","درست رقم درج کریں") else {busy=true;addEntry(selected,n,direction,note,::done)}}
  }) {
    Text(state.word(if(direction=="GAVE")"Money I gave" else "Money I received",if(direction=="GAVE")"میں نے رقم دی" else "مجھے رقم ملی"),style=MaterialTheme.typography.titleLarge)
    BusinessField(value,state.word("Amount (Rs.)","رقم (روپے)"),true){value=it};BusinessField(note,state.word("Note (optional)","تفصیل (اختیاری)")){note=it}
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}
