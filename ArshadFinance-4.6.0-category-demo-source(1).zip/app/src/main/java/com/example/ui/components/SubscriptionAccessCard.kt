package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.*

@Composable
fun SubscriptionAccessCard(state: SubscriptionState, language: AppLanguage,
  onPlans: () -> Unit, modifier: Modifier = Modifier) {
  val ur = language == AppLanguage.URDU
  fun t(en: String, u: String) = if (ur) u else en
  val status = when {
    state.clockBlocked -> t("Check phone date", "فون کی تاریخ درست کریں")
    state.isActivated && state.hasBusinessAccess -> t("Paid business • ${state.remainingDays} days left", "ادا شدہ کاروبار • ${state.remainingDays} دن باقی")
    state.hasBusinessAccess -> t("Free trial • ${state.remainingDays} days left", "مفت ٹرائل • ${state.remainingDays} دن باقی")
    state.trialStartedMillis == 0L && !state.hasPaidBefore -> t("30-day free business trial", "کاروبار کا ۳۰ دن مفت ٹرائل")
    else -> t("Business expired • Personal Khata stays free", "کاروباری رسائی ختم • ذاتی کھاتہ مفت ہے")
  }
  Card(onClick = onPlans, modifier = modifier.fillMaxWidth().heightIn(min = 64.dp).testTag("subscription_access_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
      Text(status, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
      Text(t("Plans & payment → Rs. 300/month · Rs. 3,000/year", "پلان اور ادائیگی ← ۳۰۰ روپے ماہانہ · ۳۰۰۰ روپے سالانہ"),
        style = MaterialTheme.typography.bodySmall)
    }
  }
}
