package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import com.example.ui.FinanceUiState
import com.example.ui.components.TransactionItemCard
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ExpenseRedContainer
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.IncomeGreenContainer
import com.example.ui.theme.LightSurface
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.util.Locale

@Composable
fun LegacyStatsScreen(
  uiState: FinanceUiState,
  onTransactionClick: (Transaction) -> Unit,
  modifier: Modifier = Modifier
) {
  val expenseTransactions = uiState.transactions.filter { it.type == TransactionType.EXPENSE }
  val totalExpense = uiState.totalExpense.coerceAtLeast(0.01)

  // Group expenses by category
  val categoryGroups = expenseTransactions
    .groupBy { it.category }
    .mapValues { entry -> entry.value.sumOf { it.amount } }
    .toList()
    .sortedByDescending { it.second }

  val savingsRate = if (uiState.totalIncome > 0) {
    (((uiState.totalIncome - uiState.totalExpense) / uiState.totalIncome) * 100).coerceIn(0.0, 100.0)
  } else {
    0.0
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Stats Header
    item {
      Column(modifier = Modifier.padding(top = 8.dp)) {
        Text(
          text = "Financial Analytics",
          style = MaterialTheme.typography.headlineSmall.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )
        Text(
          text = "Income, expenses, budget targets & savings",
          style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
        )
      }
    }

    // 2. Summary 2x2 Metric Cards
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Income Card
        Column(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(24.dp))
            .background(IncomeGreenContainer)
            .padding(16.dp)
            .testTag("stats_income_card")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.ArrowDownward,
              contentDescription = null,
              tint = IncomeGreen,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Total Income",
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.SemiBold,
                color = IncomeGreen
              )
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = String.format(Locale.US, "%s%,.2f", uiState.currencySymbol, uiState.totalIncome),
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
        }

        // Expense Card
        Column(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(24.dp))
            .background(ExpenseRedContainer)
            .padding(16.dp)
            .testTag("stats_expense_card")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.ArrowUpward,
              contentDescription = null,
              tint = ExpenseRed,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Total Expense",
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.SemiBold,
                color = ExpenseRed
              )
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = String.format(Locale.US, "%s%,.2f", uiState.currencySymbol, uiState.totalExpense),
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
        }
      }
    }

    // 3. Savings Rate Card
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(24.dp))
          .background(LightSurface)
          .padding(16.dp)
          .testTag("stats_savings_rate_card"),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(IceBlueContainer),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Savings,
            contentDescription = "Savings",
            tint = NavyBluePrimary,
            modifier = Modifier.size(24.dp)
          )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "Monthly Savings Rate",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          Text(
            text = "Net retained income from cash flows",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
          )
          Spacer(modifier = Modifier.height(8.dp))
          LinearProgressIndicator(
            progress = { (savingsRate / 100.0).toFloat() },
            modifier = Modifier
              .fillMaxWidth()
              .height(8.dp)
              .clip(RoundedCornerShape(4.dp)),
            color = IncomeGreen,
            trackColor = Color(0xFFE2E2E6)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Text(
          text = String.format(Locale.US, "%.1f%%", savingsRate),
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            color = IncomeGreen
          )
        )
      }
    }

    // 4. Category Breakdown Section
    item {
      Text(
        text = "Spending & Budget Progress by Category",
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        ),
        modifier = Modifier.padding(top = 8.dp)
      )
    }

    if (categoryGroups.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "No expenses logged yet",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
          )
        }
      }
    } else {
      items(categoryGroups) { (category, amount) ->
        val percentOfTotalExpense = (amount / totalExpense) * 100.0
        val matchingBudget = uiState.budgets.find { it.category.equals(category, ignoreCase = true) }
        val categoryIcon = matchingBudget?.icon ?: when {
          category.contains("Shopping", true) -> "🛍️"
          category.contains("Food", true) || category.contains("Dining", true) -> "🍔"
          category.contains("Bill", true) || category.contains("Utility", true) -> "⚡"
          category.contains("Transport", true) -> "🚕"
          category.contains("Health", true) -> "💊"
          else -> "🏷️"
        }

        val budgetPercent = if (matchingBudget != null) {
          (amount / matchingBudget.limitAmount.coerceAtLeast(0.01)) * 100.0
        } else null

        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(LightSurface)
            .padding(16.dp)
            .testTag("category_stat_$category")
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = categoryIcon, fontSize = 20.sp)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = category,
                  style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                  )
                )
                if (matchingBudget != null) {
                  Text(
                    text = String.format(Locale.US, "Budget: %s%,.2f cap", uiState.currencySymbol, matchingBudget.limitAmount),
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                  )
                }
              }
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.US, "%s%,.2f", uiState.currencySymbol, amount),
                style = MaterialTheme.typography.bodyMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
              )
              if (budgetPercent != null) {
                val isOver = budgetPercent >= 100.0
                val isWarn = budgetPercent >= 80.0 && !isOver
                Text(
                  text = String.format(Locale.US, "%.0f%% of cap", budgetPercent),
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = when {
                      isOver -> ExpenseRed
                      isWarn -> WarningAmber
                      else -> IncomeGreen
                    }
                  )
                )
              } else {
                Text(
                  text = String.format(Locale.US, "%.1f%% of spend", percentOfTotalExpense),
                  style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          val progress = (budgetPercent?.div(100.0) ?: (percentOfTotalExpense / 100.0)).toFloat().coerceIn(0f, 1f)
          val progressColor = when {
            budgetPercent != null && budgetPercent >= 100.0 -> ExpenseRed
            budgetPercent != null && budgetPercent >= 80.0 -> WarningAmber
            else -> NavyBluePrimary
          }

          LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp)),
            color = progressColor,
            trackColor = Color(0xFFE2E2E6)
          )
        }
      }
    }

    // 5. Recent High Spend Activity
    item {
      Text(
        text = "Top Expense Transactions",
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        ),
        modifier = Modifier.padding(top = 8.dp)
      )
    }

    val topExpenses = expenseTransactions.sortedByDescending { it.amount }.take(4)
    items(topExpenses, key = { it.id }) { tx ->
      TransactionItemCard(
        transaction = tx,
        currencySymbol = uiState.currencySymbol,
        onClick = { onTransactionClick(tx) }
      )
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}
