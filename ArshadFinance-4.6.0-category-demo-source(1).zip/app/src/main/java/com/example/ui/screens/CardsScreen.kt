package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Account
import com.example.ui.FinanceUiState
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun LegacyCardsScreen(
  uiState: FinanceUiState,
  onAddAccountClick: () -> Unit,
  onDeleteAccount: (Account) -> Unit,
  onSendClick: (Account?) -> Unit = {},
  onReceiveClick: (Account?) -> Unit = {},
  onOpenSettings: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var selectedCategoryFilter by remember { mutableStateOf("All") }
  var accountToDelete by remember { mutableStateOf<Account?>(null) }

  if (accountToDelete != null) {
    AlertDialog(
      onDismissRequest = { accountToDelete = null },
      title = { Text("Delete Account?") },
      text = { Text("Are you sure you want to remove '${accountToDelete?.name}'? Past transactions will remain safe.") },
      confirmButton = {
        Button(
          onClick = {
            accountToDelete?.let { onDeleteAccount(it) }
            accountToDelete = null
            Toast.makeText(context, "Account removed", Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
        ) {
          Text("Delete")
        }
      },
      dismissButton = {
        TextButton(onClick = { accountToDelete = null }) { Text("Cancel") }
      }
    )
  }

  val filteredAccounts = remember(uiState.accounts, selectedCategoryFilter) {
    when (selectedCategoryFilter) {
      "Wallets" -> uiState.accounts.filter {
        it.name.contains("JazzCash", ignoreCase = true) ||
          it.name.contains("Easypaisa", ignoreCase = true) ||
          it.name.contains("SadaPay", ignoreCase = true) ||
          it.name.contains("NayaPay", ignoreCase = true) ||
          it.accountType.contains("Wallet", ignoreCase = true)
      }
      "Banks" -> uiState.accounts.filter {
        it.name.contains("Bank", ignoreCase = true) ||
          it.name.contains("Meezan", ignoreCase = true) ||
          it.name.contains("HBL", ignoreCase = true) ||
          it.accountType.contains("Checking", ignoreCase = true) ||
          it.accountType.contains("Savings", ignoreCase = true)
      }
      "Cash" -> uiState.accounts.filter {
        it.name.contains("Cash", ignoreCase = true) || it.accountType.contains("Cash", ignoreCase = true)
      }
      else -> uiState.accounts
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFFF5F7F2))
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item { Spacer(modifier = Modifier.height(4.dp)) }

    // 1. Top Header
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "Accounts & Wallets",
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(0xFF086B4D).copy(alpha = 0.12f)
            ) {
              Text(
                text = "PKR • والٹس",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF086B4D),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
          Text(
            text = "JazzCash, Easypaisa, Bank, SadaPay, NayaPay & Cash",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onOpenSettings,
            modifier = Modifier.testTag("accounts_settings_btn")
          ) {
            Icon(
              imageVector = Icons.Default.Settings,
              contentDescription = "Settings",
              tint = Color(0xFF475569)
            )
          }

          Button(
            onClick = onAddAccountClick,
            colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
            shape = RoundedCornerShape(14.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            modifier = Modifier.testTag("add_account_button")
          ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "Add Account", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // 2. Liquid Assets Balance Card
    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "TOTAL LIQUID BALANCE (کل دستیاب رقم)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                letterSpacing = 0.8.sp
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = String.format(Locale.US, "%s %,.2f", uiState.currencySymbol, uiState.totalBalance),
                style = MaterialTheme.typography.headlineMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              )
            }

            Surface(
              shape = CircleShape,
              color = Color(0xFF38BDF8).copy(alpha = 0.2f),
              modifier = Modifier.size(46.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.AccountBalance,
                  contentDescription = null,
                  tint = Color(0xFF38BDF8),
                  modifier = Modifier.size(24.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
          Spacer(modifier = Modifier.height(12.dp))

          // 3 Quick Action Buttons
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = { onSendClick(null) },
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Send / Pay", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = { onReceiveClick(null) },
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.ArrowDownward, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Receive", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // 3. Category Filter Chips
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        listOf("All" to "All (${uiState.accounts.size})", "Wallets" to "📱 Wallets", "Banks" to "🏦 Banks", "Cash" to "💵 Cash").forEach { (filterKey, label) ->
          val isSelected = selectedCategoryFilter == filterKey
          FilterChip(
            selected = isSelected,
            onClick = { selectedCategoryFilter = filterKey },
            label = { Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = NavyBluePrimary,
              selectedLabelColor = Color.White,
              containerColor = Color.White
            )
          )
        }
      }
    }

    // 4. Pakistani Accounts & Cards List
    items(filteredAccounts, key = { it.id }) { account ->
      PakistaniAccountCardItem(
        account = account,
        currencySymbol = uiState.currencySymbol,
        onSend = { onSendClick(account) },
        onReceive = { onReceiveClick(account) },
        onDelete = { accountToDelete = account }
      )
    }

    item { Spacer(modifier = Modifier.height(70.dp)) }
  }
}

@Composable
fun PakistaniAccountCardItem(
  account: Account,
  currencySymbol: String,
  onSend: () -> Unit,
  onReceive: () -> Unit,
  onDelete: () -> Unit
) {
  val context = LocalContext.current
  val nameLower = account.name.lowercase()

  // Determine Pakistani Branding Gradients & Logo
  val (gradientColors, iconEmoji, badgeLabel) = when {
    nameLower.contains("jazzcash") -> Triple(
      listOf(Color(0xFFE11D48), Color(0xFF9F1239), Color(0xFF4C0519)),
      "📱",
      "JAZZCASH WALLET"
    )
    nameLower.contains("easypaisa") -> Triple(
      listOf(Color(0xFF059669), Color(0xFF047857), Color(0xFF064E3B)),
      "🟢",
      "EASYPAISA MERCHANT"
    )
    nameLower.contains("meezan") || nameLower.contains("bank") -> Triple(
      listOf(Color(0xFF0A2540), Color(0xFF006C45), Color(0xFF172554)),
      "🏦",
      "COMMERCIAL BANK"
    )
    nameLower.contains("sadapay") -> Triple(
      listOf(Color(0xFF0D9488), Color(0xFF0F766E), Color(0xFF134E4A)),
      "💳",
      "SADAPAY WALLET"
    )
    nameLower.contains("nayapay") -> Triple(
      listOf(Color(0xFF7C3AED), Color(0xFF6D28D9), Color(0xFF4C1D95)),
      "🟣",
      "NAYAPAY WALLET"
    )
    nameLower.contains("cash") -> Triple(
      listOf(Color(0xFF15803D), Color(0xFF166534), Color(0xFF14532D)),
      "💵",
      "CASH IN HAND"
    )
    else -> Triple(
      listOf(Color(account.colorHex), Color(account.colorHex).copy(alpha = 0.8f), Color(0xFF0F172A)),
      "💼",
      account.accountType.uppercase()
    )
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(22.dp))
      .testTag("account_card_${account.id}"),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .background(Brush.linearGradient(gradientColors))
        .padding(18.dp)
    ) {
      // Top Row (Badge + Emoji + Delete)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = iconEmoji, fontSize = 20.sp)
          Spacer(modifier = Modifier.width(8.dp))
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color.White.copy(alpha = 0.2f)
          ) {
            Text(
              text = badgeLabel,
              fontSize = 9.5.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }

        IconButton(
          onClick = onDelete,
          modifier = Modifier.size(28.dp)
        ) {
          Icon(
            imageVector = Icons.Default.DeleteOutline,
            contentDescription = "Delete",
            tint = Color.White.copy(alpha = 0.8f),
            modifier = Modifier.size(18.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Account Name & Number with Copy Button
      Text(
        text = account.name,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        color = Color.White
      )

      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
          .padding(top = 2.dp)
          .clickable {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Account Number", account.accountNumber))
            Toast.makeText(context, "Copied: ${account.accountNumber}", Toast.LENGTH_SHORT).show()
          }
      ) {
        Text(
          text = account.accountNumber,
          fontSize = 12.sp,
          fontFamily = FontFamily.Monospace,
          color = Color.White.copy(alpha = 0.9f)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
          imageVector = Icons.Default.ContentCopy,
          contentDescription = "Copy",
          tint = Color.White.copy(alpha = 0.8f),
          modifier = Modifier.size(13.dp)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Bottom Row: Balance & Actions
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
      ) {
        Column {
          Text(
            text = "Balance",
            fontSize = 11.sp,
            color = Color.White.copy(alpha = 0.8f)
          )
          Text(
            text = String.format(Locale.US, "%s %,.2f", currencySymbol, account.balance),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.White.copy(alpha = 0.25f),
            modifier = Modifier.clickable { onSend() }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
              Spacer(modifier = Modifier.width(3.dp))
              Text("Send", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
          }

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.White.copy(alpha = 0.25f),
            modifier = Modifier.clickable { onReceive() }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
              Spacer(modifier = Modifier.width(3.dp))
              Text("Receive", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
          }
        }
      }
    }
  }
}
