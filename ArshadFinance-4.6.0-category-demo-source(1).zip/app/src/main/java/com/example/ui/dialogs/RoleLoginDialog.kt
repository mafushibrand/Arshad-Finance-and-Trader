package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.SubscriptionState
import com.example.data.model.UserRole
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.InputFieldStyles

@Composable
fun RoleLoginDialog(
  currentRole: UserRole,
  subscriptionState: SubscriptionState = SubscriptionState(),
  onSelectRole: (UserRole) -> Unit,
  onDismiss: () -> Unit,
  ownerPinConfigured: Boolean = true,
  validateOwnerPin: (String) -> Boolean = { false }
) {
  val context = LocalContext.current
  var selectedRole by remember { mutableStateOf(currentRole) }
  var pin by remember { mutableStateOf("") }
  var employeeName by remember { mutableStateOf("Ali / Sales Staff") }
  var errorText by remember { mutableStateOf<String?>(null) }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .clip(RoundedCornerShape(24.dp))
        .testTag("role_login_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = IndigoPrimary.copy(alpha = 0.12f),
              modifier = Modifier.size(36.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(20.dp))
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(text = "Switch User Role", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
              Text(text = "مالک و ملازم کا کردار منتخب کریں", fontSize = 11.sp, color = Color(0xFF64748B))
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Role Selection Chips
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Owner Option
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (selectedRole == UserRole.OWNER) IndigoPrimary else Color(0xFFF7F9F3),
            modifier = Modifier
              .weight(1f)
              .clickable { selectedRole = UserRole.OWNER }
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(text = "👑", fontSize = 24.sp)
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Owner (مالک)",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (selectedRole == UserRole.OWNER) Color.White else Color(0xFF0F172A)
              )
              Text(
                text = "Full Access",
                fontSize = 10.sp,
                color = if (selectedRole == UserRole.OWNER) Color.White.copy(alpha = 0.8f) else Color(0xFF64748B)
              )
            }
          }

          // Employee Option
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (selectedRole == UserRole.EMPLOYEE) EmeraldSuccess else Color(0xFFF7F9F3),
            modifier = Modifier
              .weight(1f)
              .clickable { selectedRole = UserRole.EMPLOYEE }
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(text = "👤", fontSize = 24.sp)
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Employee (ملازم)",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (selectedRole == UserRole.EMPLOYEE) Color.White else Color(0xFF0F172A)
              )
              Text(
                text = "Restricted POS",
                fontSize = 10.sp,
                color = if (selectedRole == UserRole.EMPLOYEE) Color.White.copy(alpha = 0.8f) else Color(0xFF64748B)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedRole == UserRole.OWNER) {
          if(!ownerPinConfigured) Text("Create your owner PIN. Remember it for future access. / مالک کا پن بنائیں اور یاد رکھیں۔")
          Text(text = "Owner Security PIN / مالک کا پن:", fontSize = 12.sp, color = Color(0xFF475569))
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedTextField(
            value = pin,
            onValueChange = {
              pin = it
              errorText = null
            },
            placeholder = { Text("4–8 digits / ۴ تا ۸ ہندسے") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF64748B)) },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )
        } else {
          Text(text = "Employee / Staff Name (ملازم کا نام):", fontSize = 12.sp, color = Color(0xFF475569))
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedTextField(
            value = employeeName,
            onValueChange = { employeeName = it },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFF64748B)) },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )
        }

        if (errorText != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(text = errorText!!, fontSize = 11.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = {
            if (selectedRole == UserRole.EMPLOYEE && subscriptionState.isBasicTierRestricted) {
              errorText = "Employee access disabled. Owner subscription has expired.\n(ملازم کی رسائی معطل ہے کیونکہ مالک کا ٹرائل ختم ہو چکا ہے۔)"
              return@Button
            }
            if (selectedRole == UserRole.OWNER && !validateOwnerPin(pin)) {
              errorText = "Enter correct 4–8 digit PIN. After five failed attempts, wait one minute. / درست پن درج کریں۔"
              return@Button
            }
            if(selectedRole==UserRole.EMPLOYEE && !ownerPinConfigured) {errorText="First set the owner PIN / پہلے مالک کا پن بنائیں";return@Button}
            onSelectRole(selectedRole)
            Toast.makeText(
              context,
              if (selectedRole == UserRole.OWNER) "Logged in as OWNER (مکمل اختیارات) ✓" else "Logged in as EMPLOYEE (محدود کاؤنٹر) ✓",
              Toast.LENGTH_SHORT
            ).show()
            onDismiss()
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (selectedRole == UserRole.OWNER) IndigoPrimary else EmeraldSuccess
          ),
          modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
          Text(
            text = if (selectedRole == UserRole.OWNER) "Login as Owner (مالک موڈ)" else "Switch to Employee Mode (ملازم موڈ)",
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
