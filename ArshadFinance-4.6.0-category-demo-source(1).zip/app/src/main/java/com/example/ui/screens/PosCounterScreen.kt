package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import com.example.data.local.BusinessPreferences
import java.io.File
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.InventoryItem
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItemEntry
import com.example.ui.FinanceUiState
import com.example.ui.dialogs.ThermalSlipDialog
import com.example.ui.theme.InputFieldStyles
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegacyPosCounterScreen(
  uiState: FinanceUiState,
  onCompleteSale: (Invoice, List<InvoiceItemEntry>, Boolean, (Invoice?) -> Unit) -> Unit,
  onAddNewProduct: () -> Unit,
  onAddToCart: (InventoryItem, Double) -> Unit = { _, _ -> },
  onUpdateCartQty: (Long, Double) -> Unit = { _, _ -> },
  onClearCart: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var savingSale by remember { mutableStateOf(false) }
  val currency = uiState.currencySymbol
  val shopName = uiState.businessProfile.businessName.ifBlank { "ARSHAD FINANCE & TRADERS" }
  val shopLogo = uiState.businessProfile.logoEmoji.ifBlank { "🏪" }
  val inventoryItems = uiState.inventoryItems
  val customers = uiState.customers

  var activeMode by remember { mutableStateOf("Sale") } // Sale, Purchase, Return Mode
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("ALL ITEMS") }

  // Shared Cart from FinanceUiState
  val cartItems = uiState.cartItems

  var showCheckoutDialog by remember { mutableStateOf(false) }
  var generatedInvoiceForReceipt by remember { mutableStateOf<Invoice?>(null) }
  var customWeightDialogProduct by remember { mutableStateOf<com.example.data.model.InventoryItem?>(null) }
  var customWeightInput by remember { mutableStateOf("") }

  if (customWeightDialogProduct != null) {
    val prod = customWeightDialogProduct!!
    val currentQty = cartItems[prod.id] ?: 0.0
    AlertDialog(
      onDismissRequest = { customWeightDialogProduct = null },
      title = {
        Text("وزن یا مقدار درج کریں (Enter Qty / Weight)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
      },
      text = {
        Column {
          Text(text = "${prod.icon} ${prod.name} (${prod.unit})", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color(0xFF0F172A))
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = customWeightInput,
            onValueChange = { customWeightInput = it },
            placeholder = { Text("مثلاً 0.25, 0.5, 2.5, 40, 50") },
            label = { Text("مقدار / وزن (${prod.unit})") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf(0.25 to "¼ پاؤ", 0.5 to "½ کلو", 1.0 to "1kg", 2.0 to "2kg", 5.0 to "5kg", 40.0 to "40kg من", 50.0 to "50kg بوری").forEach { (v, lbl) ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFE5F3EA),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBEDBC8)),
                modifier = Modifier.clickable { customWeightInput = v.toString() }
              ) {
                Text(lbl, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF086B4D), modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val parsed = customWeightInput.toDoubleOrNull() ?: 0.0
            onUpdateCartQty(prod.id, parsed)
            customWeightDialogProduct = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
        ) {
          Text("شامل کریں (Set Qty)")
        }
      },
      dismissButton = {
        TextButton(onClick = { customWeightDialogProduct = null }) {
          Text("منسوخ (Cancel)")
        }
      }
    )
  }

  // Available categories
  val categories = remember(inventoryItems) {
    val cats = inventoryItems.map { it.category }.distinct().toMutableList()
    listOf("ALL ITEMS") + cats
  }

  // Filtered Products
  val displayedProducts = remember(inventoryItems, searchQuery, selectedCategory) {
    var list = inventoryItems
    if (selectedCategory != "ALL ITEMS") {
      list = list.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }
    if (searchQuery.isNotBlank()) {
      list = list.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
            it.barcode.contains(searchQuery, ignoreCase = true) ||
            it.category.contains(searchQuery, ignoreCase = true)
      }
    }
    list
  }

  val totalCartQty = cartItems.values.sum()
  val totalCartAmount = cartItems.entries.sumOf { (itemId, qty) ->
    val item = inventoryItems.find { it.id == itemId }
    (item?.salePrice ?: 0.0) * qty
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFFF5F7F2))
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // 1. Top Curved Blue Header (Al-Makkah Traders / Arshad Finance)
      Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF086B4D),
        shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Color.White),
            contentAlignment = Alignment.Center
          ) {
            Text(text = shopLogo, fontSize = 22.sp)
          }
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = shopName.uppercase(),
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White,
              letterSpacing = 0.8.sp
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 2. Mode Selector: Sale | Purchase | Return Mode
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFFE2E8F0))
          .padding(3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        listOf("Sale", "Purchase", "Return Mode").forEach { mode ->
          val isSelected = activeMode == mode
          val bgColor = if (isSelected) {
            if (mode == "Sale") Color(0xFF10B981) else Color(0xFF086B4D)
          } else Color.Transparent

          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(bgColor)
              .clickable { activeMode = mode }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = mode,
              fontSize = 12.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) Color.White else Color(0xFF475569)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 3. Search Bar with Barcode Scanner Icon
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("Search or Scan Barcode...", fontSize = 13.sp, color = Color(0xFF94A3B8)) },
          trailingIcon = {
            IconButton(onClick = {
              Toast.makeText(context, "Barcode camera ready (Auto-detecting...)", Toast.LENGTH_SHORT).show()
            }) {
              Icon(
                imageVector = Icons.Default.QrCodeScanner,
                contentDescription = "Scan",
                tint = Color(0xFF10B981),
                modifier = Modifier.size(24.dp)
              )
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("pos_search_input")
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 4. Category Filter Chips (ALL ITEMS, OIL, BISCUITS, DRINKS...)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState())
          .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        categories.forEach { cat ->
          val isSelected = selectedCategory == cat
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .background(if (isSelected) Color(0xFF0F172A) else Color(0xFFF7F9F3))
              .border(1.dp, if (isSelected) Color(0xFF0F172A) else Color(0xFFCBD5E1), RoundedCornerShape(20.dp))
              .clickable { selectedCategory = cat }
              .padding(horizontal = 14.dp, vertical = 6.dp)
          ) {
            Text(
              text = cat.uppercase(),
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) Color.White else Color(0xFF334155)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 5. Products Grid (3 Columns)
      LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier
          .weight(1f)
          .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
      ) {
        items(displayedProducts) { product ->
          val currentQty = cartItems[product.id] ?: 0.0

          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(
              width = if (currentQty > 0) 2.dp else 1.dp,
              color = if (currentQty > 0) Color(0xFF10B981) else Color(0xFFE2E8F0)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                onUpdateCartQty(product.id, currentQty + 1.0)
              }
              .testTag("pos_product_${product.id}")
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              // Product Image/Thumbnail
              Box(
                modifier = Modifier
                  .size(68.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(Color(0xFFF5F7F2)),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = product.icon.ifBlank { "📦" },
                  fontSize = 34.sp
                )
                if (currentQty > 0) {
                  Surface(
                    shape = CircleShape,
                    color = Color(0xFF10B981),
                    modifier = Modifier
                      .align(Alignment.TopEnd)
                      .size(20.dp)
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Text(
                        text = currentQty.toInt().toString(),
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                      )
                    }
                  }
                }
              }

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = product.name,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
              )

              Text(
                text = "$currency ${product.salePrice.toInt()}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF475569)
              )

              val isWeightItem = product.unit.contains("Kg", ignoreCase = true) ||
                  product.unit.contains("Gram", ignoreCase = true) ||
                  product.unit.contains("Liter", ignoreCase = true) ||
                  product.unit.contains("من", ignoreCase = true) ||
                  product.unit.contains("بوری", ignoreCase = true) ||
                  product.unit.contains("Maund", ignoreCase = true) ||
                  product.unit.contains("Bag", ignoreCase = true)

              val isClothItem = product.unit.contains("Meter", ignoreCase = true) ||
                  product.unit.contains("Gaz", ignoreCase = true) ||
                  product.unit.contains("گز", ignoreCase = true)

              if (isWeightItem) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                  listOf(
                    0.25 to "¼ پاؤ",
                    0.5 to "½ کلو",
                    1.0 to "1kg",
                    2.0 to "2kg",
                    5.0 to "5kg",
                    40.0 to "40kg",
                    50.0 to "50kg"
                  ).forEach { (frac, label) ->
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = if (currentQty == frac) Color(0xFF086B4D) else Color(0xFFE5F3EA),
                      border = androidx.compose.foundation.BorderStroke(1.dp, if (currentQty == frac) Color(0xFF086B4D) else Color(0xFFE4F3E9)),
                      modifier = Modifier.clickable {
                        onUpdateCartQty(product.id, frac)
                      }
                    ) {
                      Text(
                        text = label,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentQty == frac) Color.White else Color(0xFF086B4D),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                      )
                    }
                  }
                  // Custom Qty Button
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFFEF3C7),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
                    modifier = Modifier.clickable {
                      customWeightDialogProduct = product
                      customWeightInput = if (currentQty > 0) currentQty.toString() else ""
                    }
                  ) {
                    Text(
                      text = "✏️ وزن",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFFB45309),
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                  }
                }
              } else if (isClothItem) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                  listOf(
                    0.5 to "0.5m",
                    1.0 to "1m",
                    2.5 to "2.5m سوٹ",
                    4.5 to "4.5m پورا"
                  ).forEach { (frac, label) ->
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = if (currentQty == frac) Color(0xFF086B4D) else Color(0xFFE5F3EA),
                      border = androidx.compose.foundation.BorderStroke(1.dp, if (currentQty == frac) Color(0xFF086B4D) else Color(0xFFE4F3E9)),
                      modifier = Modifier.clickable {
                        onUpdateCartQty(product.id, frac)
                      }
                    ) {
                      Text(
                        text = label,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentQty == frac) Color.White else Color(0xFF086B4D),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                      )
                    }
                  }
                  // Custom Gaz Button
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFFEF3C7),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
                    modifier = Modifier.clickable {
                      customWeightDialogProduct = product
                      customWeightInput = if (currentQty > 0) currentQty.toString() else ""
                    }
                  ) {
                    Text(
                      text = "✏️ گز",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFFB45309),
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                  }
                }
              }

              if (currentQty > 0) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Surface(
                    shape = CircleShape,
                    color = Color(0xFFFEE2E2),
                    modifier = Modifier
                      .size(22.dp)
                      .clickable {
                        val step = if (isWeightItem) 0.25 else 1.0
                        if (currentQty <= step) {
                          onUpdateCartQty(product.id, 0.0)
                        } else {
                          onUpdateCartQty(product.id, currentQty - step)
                        }
                      }
                  ) {
                    Icon(
                      imageVector = Icons.Default.Remove,
                      contentDescription = "Minus",
                      tint = Color(0xFFDC2626),
                      modifier = Modifier.padding(3.dp)
                    )
                  }

                  Text(
                    text = "${if (currentQty % 1.0 == 0.0) currentQty.toInt().toString() else "%.2f".format(currentQty)}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                  )

                  Surface(
                    shape = CircleShape,
                    color = Color(0xFFDCFCE7),
                    modifier = Modifier
                      .size(22.dp)
                      .clickable {
                        val step = if (isWeightItem) 0.25 else 1.0
                        onUpdateCartQty(product.id, currentQty + step)
                      }
                  ) {
                    Icon(
                      imageVector = Icons.Default.Add,
                      contentDescription = "Plus",
                      tint = Color(0xFF166534),
                      modifier = Modifier.padding(3.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // 6. Floating Bottom Cart Checkout Bar (Sticky Bottom Bar from Screenshot 6)
    if (totalCartQty > 0) {
      Surface(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF0F172A), // Dark Navy Slate
        shadowElevation = 8.dp
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "TOTAL QTY: ${if (totalCartQty % 1.0 == 0.0) totalCartQty.toInt().toString() else "%.2f".format(totalCartQty)}",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF94A3B8)
            )
            Text(
              text = "$currency ${"%,.0f".format(totalCartAmount)}",
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }

          Button(
            onClick = { showCheckoutDialog = true },
            enabled = !savingSale && cartItems.isNotEmpty(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)), // Bright Green
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp),
            modifier = Modifier.testTag("pos_checkout_button")
          ) {
            Text(
              text = "Checkout",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }
      }
    }
  }

  // Checkout Dialog
  if (showCheckoutDialog) {
    PosCheckoutModal(
      customers = customers,
      cartItems = cartItems,
      inventoryItems = inventoryItems,
      currency = currency,
      businessProfile = uiState.businessProfile,
      onConfirmSale = { invoice, entries, syncStock ->
        showCheckoutDialog = false
        savingSale = true
        onCompleteSale(invoice, entries, syncStock) { saved ->
          savingSale = false
          if (saved != null) {
            onClearCart()
            generatedInvoiceForReceipt = saved
          }
        }
      },
      onDismiss = { showCheckoutDialog = false }
    )
  }

  // Thermal Slip Preview Dialog (Screenshots 7 & 8)
  if (generatedInvoiceForReceipt != null) {
    ThermalSlipDialog(
      invoice = generatedInvoiceForReceipt!!,
      businessProfile = uiState.businessProfile,
      currencySymbol = currency,
      onDismiss = { generatedInvoiceForReceipt = null }
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PosCheckoutModal(
  customers: List<Customer>,
  cartItems: Map<Long, Double>,
  inventoryItems: List<InventoryItem>,
  currency: String,
  businessProfile: com.example.util.BusinessProfile,
  onConfirmSale: (Invoice, List<InvoiceItemEntry>, Boolean) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  var selectedCustomerId by remember { mutableStateOf(0L) }
  var customerName by remember { mutableStateOf("Walk-in Customer") }
  var customerPhone by remember { mutableStateOf("") }
  var customerDropdownExpanded by remember { mutableStateOf(false) }

  var discountStr by remember { mutableStateOf("0") }
  var paymentMethod by remember { mutableStateOf("Cash") }
  var isUdhar by remember { mutableStateOf(false) }
  var isFbrTaxMode by remember { mutableStateOf(false) }
  var isSplitPayment by remember { mutableStateOf(false) }
  var splitCashStr by remember { mutableStateOf("") }
  var splitOnlineStr by remember { mutableStateOf("") }
  var splitKhataStr by remember { mutableStateOf("") }
  var receiptPath by remember { mutableStateOf("") }
  var copyingReceipt by remember { mutableStateOf(false) }
  val hasAttachedScreenshot = receiptPath.isNotBlank()
  val receiptScope = rememberCoroutineScope()
  val receiptPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
    if (uri != null) receiptScope.launch {
      copyingReceipt = true
      try {
        receiptPath = withContext(Dispatchers.IO) {
          val folder = File(context.filesDir, "payment-receipts").apply { mkdirs() }
          val file = File(folder, "receipt-${java.util.UUID.randomUUID()}.image")
          context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { input.copyTo(it) } }
            ?: error("Could not read image")
          android.net.Uri.fromFile(file).toString()
        }
      } catch (error: Exception) {
        Toast.makeText(context, "Receipt could not be saved / رسید محفوظ نہیں ہوئی", Toast.LENGTH_LONG).show()
      } finally { copyingReceipt = false }
    }
  }

  val subtotal = cartItems.entries.sumOf { (id, qty) ->
    val itm = inventoryItems.find { it.id == id }
    (itm?.salePrice ?: 0.0) * qty
  }
  val discount = discountStr.toDoubleOrNull() ?: 0.0
  val taxableAmount = (subtotal - discount).coerceAtLeast(0.0)
  val fbrTax = if (isFbrTaxMode) taxableAmount * 0.18 else 0.0
  val grandTotal = taxableAmount + fbrTax

  val amountPaid = if (isUdhar) {
    0.0
  } else if (isSplitPayment) {
    val c = splitCashStr.toDoubleOrNull() ?: 0.0
    val o = splitOnlineStr.toDoubleOrNull() ?: 0.0
    (c + o).coerceAtMost(grandTotal)
  } else {
    grandTotal
  }
  val remainingBalance = (grandTotal - amountPaid).coerceAtLeast(0.0)

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.94f)
        .clip(RoundedCornerShape(20.dp)),
      colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "🛒 Checkout & Bill",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Customer Selection
        ExposedDropdownMenuBox(
          expanded = customerDropdownExpanded,
          onExpandedChange = { customerDropdownExpanded = !customerDropdownExpanded }
        ) {
          OutlinedTextField(
            value = customerName,
            onValueChange = { customerName = it },
            label = { Text("Customer Name / گاہک کا نام") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerDropdownExpanded) },
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            singleLine = true
          )

          ExposedDropdownMenu(
            expanded = customerDropdownExpanded,
            onDismissRequest = { customerDropdownExpanded = false }
          ) {
            DropdownMenuItem(
              text = { Text("Walk-in Customer (نقد گاہک)", fontWeight = FontWeight.Bold) },
              onClick = {
                customerName = "Walk-in Customer"
                customerPhone = ""
                selectedCustomerId = 0L
                customerDropdownExpanded = false
              }
            )
            customers.forEach { c ->
              DropdownMenuItem(
                text = { Text("${c.name} (${c.phone})") },
                onClick = {
                  customerName = c.name
                  customerPhone = c.phone
                  selectedCustomerId = c.id
                  customerDropdownExpanded = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = customerPhone,
          onValueChange = { customerPhone = it },
          label = { Text("Customer WhatsApp / Phone") },
          placeholder = { Text("0300-1234567") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // FBR Tax Mode Switch
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("FBR Sales Tax (18% GST)", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
            Text("Append simulated FBR POS token & tax", fontSize = 10.sp, color = Color(0xFF64748B))
          }
          androidx.compose.material3.Switch(
            checked = isFbrTaxMode,
            onCheckedChange = { isFbrTaxMode = it }
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Payment Method Chips (Cash, Split, Udhar, EasyPaisa, Bank)
        Text("Payment Mode (ادائیگی کی قسم):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF475569))
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          listOf("Cash", "Split (مکس)", "Udhar (ادھار)", "EasyPaisa", "Bank").forEach { mode ->
            val isSelected = when (mode) {
              "Udhar (ادھار)" -> isUdhar
              "Split (مکس)" -> isSplitPayment
              else -> !isUdhar && !isSplitPayment && paymentMethod == mode
            }
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) (if (mode.startsWith("Udhar")) Color(0xFFEF4444) else Color(0xFF10B981)) else Color(0xFFF7F9F3),
              modifier = Modifier
                .weight(1f)
                .clickable {
                  if (mode.startsWith("Udhar")) {
                    isUdhar = true
                    isSplitPayment = false
                    paymentMethod = "Udhar"
                  } else if (mode.startsWith("Split")) {
                    isSplitPayment = true
                    isUdhar = false
                    paymentMethod = "Split"
                  } else {
                    isUdhar = false
                    isSplitPayment = false
                    paymentMethod = mode
                  }
                }
                .padding(vertical = 2.dp)
            ) {
              Text(
                text = mode,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else Color(0xFF334155),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 8.dp)
              )
            }
          }
        }

        if (isSplitPayment) {
          Spacer(modifier = Modifier.height(8.dp))
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFFF5F7F2),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("Split Streams (نقد + آن لائن):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
              Spacer(modifier = Modifier.height(6.dp))
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                  value = splitCashStr,
                  onValueChange = { splitCashStr = it },
                  label = { Text("Cash (نقد)") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  modifier = Modifier.weight(1f),
                  singleLine = true,
                  textStyle = InputFieldStyles.textStyle,
                  colors = InputFieldStyles.colors()
                )
                OutlinedTextField(
                  value = splitOnlineStr,
                  onValueChange = { splitOnlineStr = it },
                  label = { Text("Online (جازکیش)") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  modifier = Modifier.weight(1f),
                  singleLine = true,
                  textStyle = InputFieldStyles.textStyle,
                  colors = InputFieldStyles.colors()
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              OutlinedButton(
                onClick = { receiptPicker.launch("image/*") },
                enabled = !copyingReceipt,
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = if (hasAttachedScreenshot) "✓ Screenshot Uploaded (رسید منسلک ہے)" else "📷 Attach Payment Screenshot (اختیاری رسید)",
                  fontSize = 11.sp
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Total & Discount
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Subtotal:", fontSize = 13.sp, color = Color(0xFF64748B))
          Text("$currency ${"%,.0f".format(subtotal)}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }

        if (isFbrTaxMode) {
          Spacer(modifier = Modifier.height(4.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("FBR Sales Tax (18%):", fontSize = 12.sp, color = Color(0xFF13865F))
            Text("$currency ${"%,.0f".format(fbrTax)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF13865F))
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Discount ($currency):", fontSize = 13.sp, color = Color(0xFF64748B))
          OutlinedTextField(
            value = discountStr,
            onValueChange = { discountStr = it },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.width(100.dp).height(50.dp)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = Color(0xFFE2E8F0))
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("NET TOTAL:", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
          Text("$currency ${"%,.0f".format(grandTotal)}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF086B4D))
        }

        if (isUdhar || remainingBalance > 0.0) {
          Text(
            text = "● Remaining balance of $currency ${"%,.0f".format(remainingBalance)} recorded in Khata",
            fontSize = 11.sp,
            color = Color(0xFFEF4444),
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 4.dp)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Generate Bill Button
        Button(
          enabled = !copyingReceipt && cartItems.isNotEmpty(),
          onClick = {
            val invoiceNumber = "INV-${System.currentTimeMillis()}"
            val fbrToken = if (isFbrTaxMode) "FBR-${(100000000000L..999999999999L).random()}" else ""
            val entries = cartItems.mapNotNull { (id, qty) ->
              val item = inventoryItems.find { it.id == id } ?: return@mapNotNull null
              InvoiceItemEntry(
                itemId = item.id,
                itemName = item.name,
                category = item.category,
                quantity = qty,
                unit = item.unit,
                unitPrice = item.salePrice,
                total = qty * item.salePrice,
                isService = item.barcode.startsWith("SRV-")
              )
            }

            val newInvoice = Invoice(
              id = 0L,
              invoiceNumber = invoiceNumber,
              customerId = selectedCustomerId,
              customerName = customerName.ifBlank { "Walk-in Customer" },
              customerPhone = customerPhone,
              customerAddress = "",
              dateMillis = System.currentTimeMillis(),
              subtotal = subtotal,
              discountAmount = discount,
              taxAmount = fbrTax,
              deliveryOrLabour = 0.0,
              grandTotal = grandTotal,
              amountPaid = amountPaid,
              remainingBalance = remainingBalance,
              paymentMethod = if (isSplitPayment) "Split [Cash=${splitCashStr.toDoubleOrNull() ?: 0.0};$paymentMethod=${splitOnlineStr.toDoubleOrNull() ?: 0.0}]" else if (hasAttachedScreenshot) "$paymentMethod (Screenshot)" else paymentMethod,
              itemsJson = InvoiceItemEntry.toJsonString(entries),
              paymentStatus = if (hasAttachedScreenshot) "PENDING_APPROVAL" else if (remainingBalance <= 0.0) "PAID" else if (amountPaid > 0.0) "PARTIAL" else "UNPAID / UDHAR",
              note = if (fbrToken.isNotBlank()) "FBR POS Token: $fbrToken" else "Counter POS Sale",
              syncWithInventory = true
            )

            if (hasAttachedScreenshot) {
              val prefs = BusinessPreferences(context)
              prefs.write("receipt/$invoiceNumber", receiptPath)
              prefs.write("pendingAmount/$invoiceNumber", amountPaid)
              prefs.write("pendingCash/$invoiceNumber", if (isSplitPayment) (splitCashStr.toDoubleOrNull() ?: 0.0) else 0.0)
            }
            onConfirmSale(newInvoice, entries, true)
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
          modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
          Text("✓ Complete & Print Slip (بل بنائیں)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
