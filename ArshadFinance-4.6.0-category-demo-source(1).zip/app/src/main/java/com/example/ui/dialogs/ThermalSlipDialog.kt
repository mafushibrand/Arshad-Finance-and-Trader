package com.example.ui.dialogs

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Invoice
import com.example.util.BusinessProfile
import com.example.util.InvoicePrintExportUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ThermalSlipDialog(
  invoice: Invoice,
  businessProfile: BusinessProfile,
  currencySymbol: String = "Rs",
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val saveBillImage = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.CreateDocument("image/png")) { uri ->
    if (uri != null) runCatching { com.example.util.ThermalReceiptImage.save(context, uri, invoice, businessProfile, currencySymbol) }
      .onSuccess { android.widget.Toast.makeText(context, "Bill image saved / بل کی تصویر محفوظ ہو گئی", android.widget.Toast.LENGTH_LONG).show() }
      .onFailure { android.widget.Toast.makeText(context, "Could not save image / تصویر محفوظ نہیں ہوئی: ${it.localizedMessage}", android.widget.Toast.LENGTH_LONG).show() }
  }

  val items = invoice.parseItems()
  val dateFormat = SimpleDateFormat("yyyy-MM-dd | hh:mm a", Locale.getDefault())
  val dateFormatted = dateFormat.format(Date(invoice.dateMillis))

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .clip(RoundedCornerShape(20.dp))
        .testTag("thermal_slip_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F9F3))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp)
      ) {
        // Dialog Action Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "🖨️ Thermal Receipt / بل کی پرچی",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Thermal Paper Slip Box (Screenshots 7 & 8)
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f, fill = false)
            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp)),
          color = Color(0xFFFEFDFB), // Thermal Paper Off-White
          shape = RoundedCornerShape(10.dp),
          shadowElevation = 3.dp
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .verticalScroll(rememberScrollState())
              .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            // Shop Details
            Text(
              text = businessProfile.businessName.uppercase(),
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace,
              color = Color(0xFF0F172A),
              textAlign = TextAlign.Center
            )
            if (businessProfile.address.isNotBlank()) {
              Text(
                text = "📍 ${businessProfile.address}",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF475569),
                textAlign = TextAlign.Center
              )
            }
            if (businessProfile.phone.isNotBlank()) {
              Text(
                text = "📞 ${businessProfile.phone}",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF475569),
                textAlign = TextAlign.Center
              )
            }

            Spacer(modifier = Modifier.height(6.dp))
            DottedLine()
            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = "INVOICE DETAILS",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace,
              color = Color(0xFF1E293B)
            )

            DottedLine()
            Spacer(modifier = Modifier.height(4.dp))

            // Invoice Meta
            Column(modifier = Modifier.fillMaxWidth()) {
              Text(
                text = "Inv No: ${invoice.invoiceNumber}",
                fontSize = 11.5.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF0F172A)
              )
              Text(
                text = "Date: $dateFormatted",
                fontSize = 10.5.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF475569)
              )
              val custContact = if (invoice.customerPhone.isNotBlank()) " (${invoice.customerPhone})" else ""
              Text(
                text = "Customer: ${invoice.customerName}$custContact",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF0F172A)
              )
            }

            Spacer(modifier = Modifier.height(6.dp))
            DottedLine()
            Spacer(modifier = Modifier.height(6.dp))

            // Item List
            items.forEachIndexed { index, item ->
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 3.dp)
              ) {
                Text(
                  text = "${index + 1}. ${item.itemName}",
                  fontSize = 11.5.sp,
                  fontWeight = FontWeight.Bold,
                  fontFamily = FontFamily.Monospace,
                  color = Color(0xFF0F172A)
                )
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  val qtyStr = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else item.quantity.toString()
                  Text(
                    text = "   $qtyStr x ${item.unitPrice.toInt()}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF475569)
                  )
                  Text(
                    text = "$currencySymbol ${"%,.0f".format(item.total)}",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF0F172A)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(6.dp))
            DottedLine()
            Spacer(modifier = Modifier.height(6.dp))

            // Totals
            ThermalRow("Subtotal:", "$currencySymbol ${"%,.0f".format(invoice.subtotal)}")
            if (invoice.discountAmount > 0) {
              ThermalRow("Discount:", "-$currencySymbol ${"%,.0f".format(invoice.discountAmount)}")
            }
            if (invoice.deliveryOrLabour > 0) {
              ThermalRow("Delivery/Labour:", "+$currencySymbol ${"%,.0f".format(invoice.deliveryOrLabour)}")
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "TOTAL BILL:",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF0F172A)
              )
              Text(
                text = "$currencySymbol ${"%,.0f".format(invoice.netTotal())}",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF0F172A)
              )
            }

            val isPaid = invoice.remainingBalance <= 0.0
            val statusStr = if (isPaid) "Full Paid (${invoice.paymentMethod})" else "Udhar: $currencySymbol ${"%,.0f".format(invoice.remainingBalance)}"
            ThermalRow("Status:", statusStr)

            Spacer(modifier = Modifier.height(10.dp))

            // Digital Graphical Payment Stamp
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isPaid) Color(0xFFECFDF5) else Color(0xFFFEF2F2),
              border = androidx.compose.foundation.BorderStroke(2.dp, if (isPaid) Color(0xFF059669) else Color(0xFFDC2626)),
              modifier = Modifier.padding(vertical = 4.dp)
            ) {
              Text(
                text = if (isPaid) "[ PAID ✅ وصول شدہ ]" else "[ UNPAID / CREDIT ⚠️ ادھار ]",
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = if (isPaid) Color(0xFF059669) else Color(0xFFDC2626),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
              )
            }

            if (invoice.taxAmount > 0) {
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "🏛️ FBR POS Tax: $currencySymbol ${"%,.0f".format(invoice.taxAmount)}",
                fontSize = 9.5.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF475569),
                textAlign = TextAlign.Center
              )
            }

            Spacer(modifier = Modifier.height(8.dp))
            DottedLine()
            Spacer(modifier = Modifier.height(8.dp))

            // Footer
            Text(
              text = "Shukriya! Phir zaroor aayein.\nشکریہ! آپ کے تعاون کا شکریہ۔",
              fontSize = 10.5.sp,
              fontFamily = FontFamily.Monospace,
              color = Color(0xFF475569),
              textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Powered by ${businessProfile.businessName}",
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace,
              color = Color(0xFF94A3B8),
              textAlign = TextAlign.Center
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedButton(onClick = { saveBillImage.launch("Bill_${invoice.id}.png") }, modifier = Modifier.fillMaxWidth().testTag("save_bill_image")) {
          Text("Save bill image / بل کی تصویر محفوظ کریں")
        }

        // Action Buttons: WhatsApp Slip Image, WhatsApp Text, Keypad Mode, Print PDF
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // WhatsApp Image Slip (Same as Print Slip, No Clutter)
            Button(
              onClick = {
                InvoicePrintExportUtils.generateAndShareInvoiceImage(context, invoice, businessProfile, currencySymbol)
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text("📸 WhatsApp Slip (تصویر)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }

            // Keypad / Low-End Phone Mode (Compact essentials only)
            Button(
              onClick = {
                InvoicePrintExportUtils.shareCompactTextWhatsApp(context, invoice, businessProfile, currencySymbol)
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text("📱 Keypad Mobile (مختصر)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // WhatsApp Clean Text
            OutlinedButton(
              onClick = {
                InvoicePrintExportUtils.shareInvoiceViaWhatsApp(context, invoice, businessProfile, currencySymbol)
              },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text("💬 WhatsApp Text", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = Color(0xFF0F172A))
            }

            // Print Thermal Receipt / PDF
            Button(
              onClick = {
                InvoicePrintExportUtils.generateAndShareInvoicePdf(context, invoice, businessProfile, currencySymbol)
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.Print, contentDescription = "Print", modifier = Modifier.size(15.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Print / PDF", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun DottedLine() {
  Text(
    text = "------------------------------------------",
    fontSize = 10.sp,
    fontFamily = FontFamily.Monospace,
    color = Color(0xFF94A3B8),
    textAlign = TextAlign.Center,
    modifier = Modifier.fillMaxWidth()
  )
}

@Composable
private fun ThermalRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 1.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = label,
      fontSize = 11.sp,
      fontFamily = FontFamily.Monospace,
      color = Color(0xFF475569)
    )
    Text(
      text = value,
      fontSize = 11.5.sp,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.SemiBold,
      color = Color(0xFF0F172A)
    )
  }
}
