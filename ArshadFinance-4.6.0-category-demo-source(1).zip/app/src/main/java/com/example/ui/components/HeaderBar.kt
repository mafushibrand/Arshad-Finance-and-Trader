package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.*

@Composable
fun HeaderBar(
  onProfileClick: () -> Unit,
  userRole: UserRole = UserRole.OWNER,
  appLanguage: AppLanguage = AppLanguage.URDU,
  appMode: AppMode = AppMode.BUSINESS_RETAIL,
  subscriptionState: SubscriptionState = SubscriptionState(),
  onSwitchRole: () -> Unit = {},
  onToggleLanguage: () -> Unit = {},
  onTrialAlertClick: () -> Unit = {},
  onAuthClick: () -> Unit = {},
  modifier: Modifier = Modifier,
  businessName: String = "Arshad Finance"
) {
  val urdu = appLanguage == AppLanguage.URDU
  Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 1.dp) {
    Column(modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp)) {
      Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
          Icon(Icons.Default.Storefront, null, tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(12.dp).size(24.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
          Text(businessName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.testTag("app_header_title"))
          Text(when (appMode) {
            AppMode.BUSINESS_RETAIL -> if (urdu) "کاروبار • فروخت اور اسٹاک" else "Business • Sales & stock"
            AppMode.SERVICE_BASED -> if (urdu) "سروسز • بلنگ اور کھاتہ" else "Services • Billing & khata"
            AppMode.PERSONAL_KHATA -> if (urdu) "ذاتی حساب • آمدنی اور خرچ" else "Personal • Income & expenses"
          }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = onProfileClick, modifier = Modifier.testTag("profile_avatar_button")) {
          Icon(Icons.Default.AccountCircle, if (urdu) "پروفائل" else "Profile", tint = MaterialTheme.colorScheme.primary)
        }
      }
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        TextButton(onClick = onToggleLanguage, modifier = Modifier.testTag("header_language_toggle")) {
          Text(if (urdu) "English" else "اردو")
        }
        TextButton(onClick = onSwitchRole, modifier = Modifier.testTag("header_role_badge")) {
          Text(if (userRole == UserRole.OWNER) { if (urdu) "مالک" else "Owner" }
            else { if (urdu) "عملہ" else "Staff" })
        }
        TextButton(onClick = onAuthClick, modifier = Modifier.testTag("header_auth_cloud_button")) {
          Text(if (urdu) "اکاؤنٹ" else "Account")
        }
      }
    }
  }
}
