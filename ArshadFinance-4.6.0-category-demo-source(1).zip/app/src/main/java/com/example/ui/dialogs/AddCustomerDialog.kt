package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Customer
import com.example.ui.theme.DeepNavyText
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.InputFieldStyles
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LegacyAddCustomerDialog(
  editingCustomer: Customer? = null,
  totalExistingCustomersCount: Int = 0,
  isBasicTierRestricted: Boolean = false,
  onSaveCustomer: (Customer) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val isEditing = editingCustomer != null

  // Basic tier boundary check
  if (!isEditing && isBasicTierRestricted && totalExistingCustomersCount >= 5) {
    Dialog(onDismissRequest = onDismiss) {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.padding(16.dp)
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text("🔒 Basic Tier Limit Reached", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFFDC2626))
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "You have reached the maximum of 5 clients allowed in the Basic Tier. Please activate your subscription (PKR 300/mo or PKR 3000/yr) to add unlimited customers.",
            fontSize = 12.sp,
            color = Color(0xFF475569)
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D))) {
            Text("Got It")
          }
        }
      }
    }
    return
  }

  var name by remember { mutableStateOf(editingCustomer?.name ?: "") }
  var phone by remember { mutableStateOf(editingCustomer?.phone ?: "") }
  var address by remember { mutableStateOf(editingCustomer?.address ?: "") }
  var customerType by remember { mutableStateOf(editingCustomer?.customerType ?: "Regular") }
  var note by remember { mutableStateOf(editingCustomer?.note ?: "") }

  val customerTypes = listOf("Regular", "Client", "Wholesale", "VIP")

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(24.dp))
        .testTag("add_customer_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(IceBlueContainer),
              contentAlignment = Alignment.Center
            ) {
              Icon(imageVector = Icons.Default.PersonAdd, contentDescription = "Customer", tint = NavyBluePrimary)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (isEditing) "Edit Client (گاہک کی تفصیل)" else "Add New Client (نیا گاہک)",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = DeepNavyText
                )
              )
              Text(
                text = "Save record for billing & khata history",
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.5.sp)
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFFE2E8F0))

        // 1. Customer Name
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Customer / Client Name (گاہک کا نام) *") },
          placeholder = { Text("e.g. Haji Usman / Mrs. Sadia") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("customer_name_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 2. Phone / WhatsApp
        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text("Phone / WhatsApp Number (فون نمبر)") },
          placeholder = { Text("0300-1234567") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("customer_phone_input"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 3. Address
        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text("Address / City (پتہ و شہر)") },
          placeholder = { Text("e.g. Main Bazar, Faisalabad") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 4. Customer Category
        Text(
          text = "Customer Category (گاہک کی قسم):",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF334155)
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          customerTypes.forEach { type ->
            val isSelected = customerType == type
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) NavyBluePrimary else Color(0xFFF7F9F3),
              border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) NavyBluePrimary else Color(0xFFCBD5E1)),
              modifier = Modifier
                .weight(1f)
                .clickable { customerType = type }
            ) {
              Text(
                type,
                modifier = Modifier.padding(vertical = 6.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else TextPrimary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 5. Optional Note
        OutlinedTextField(
          value = note,
          onValueChange = { note = it },
          label = { Text("Note / Business Remarks (اختیاری نوٹ)") },
          placeholder = { Text("e.g. regular boutique client, credit limit 50,000") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Save Button
        Button(
          onClick = {
            if (name.isBlank()) {
              Toast.makeText(context, "Please enter customer name", Toast.LENGTH_SHORT).show()
              return@Button
            }

            val now = System.currentTimeMillis()
            val customer = if (isEditing) {
              editingCustomer!!.copy(
                name = name.trim(),
                phone = phone.trim(),
                address = address.trim(),
                customerType = customerType,
                note = note.trim(),
                lastInteractionMillis = now
              )
            } else {
              Customer(
                id = 0L,
                name = name.trim(),
                phone = phone.trim(),
                address = address.trim(),
                customerType = customerType,
                totalBilled = 0.0,
                totalPaid = 0.0,
                currentBalance = 0.0,
                note = note.trim(),
                createdDateMillis = now,
                lastInteractionMillis = now
              )
            }

            onSaveCustomer(customer)
            Toast.makeText(context, if (isEditing) "Client updated!" else "Client saved successfully!", Toast.LENGTH_SHORT).show()
            onDismiss()
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("save_customer_button")
        ) {
          Icon(Icons.Default.Save, contentDescription = "Save")
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isEditing) "Update Client (محفوظ کریں)" else "Save Client (گاہک محفوظ کریں)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
      }
    }
  }
}
