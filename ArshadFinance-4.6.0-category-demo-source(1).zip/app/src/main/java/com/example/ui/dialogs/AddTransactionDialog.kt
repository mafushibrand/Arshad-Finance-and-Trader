package com.example.ui.dialogs

import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.Account
import com.example.data.model.TransactionType
import com.example.util.BusinessUtils
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.InputFieldStyles
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun LegacyAddTransactionDialog(
  initialType: TransactionType,
  accounts: List<Account>,
  currencySymbol: String,
  onDismiss: () -> Unit,
  onSave: (
    title: String,
    amount: Double,
    type: TransactionType,
    category: String,
    icon: String,
    accountName: String,
    note: String,
    recipientInfo: String,
    paymentMethod: String,
    receiptImageUri: String,
    transactionRef: String
  ) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var amountText by remember { mutableStateOf("") }
  var selectedType by remember { mutableStateOf(initialType) }
  var selectedCategory by remember { mutableStateOf("Shopping") }
  var selectedIcon by remember { mutableStateOf("🛍️") }
  var selectedAccountName by remember {
    mutableStateOf(accounts.firstOrNull()?.name ?: "Main Checking")
  }
  var selectedPaymentMethod by remember { mutableStateOf("JazzCash") }
  var recipientInfo by remember { mutableStateOf("") }
  var transactionRef by remember { mutableStateOf("") }
  var receiptImageUri by remember { mutableStateOf<String?>(null) }
  var note by remember { mutableStateOf("") }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var voiceTranscriptionText by remember { mutableStateOf<String?>(null) }
  val context = LocalContext.current

  val speechRecognizerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    val data = result.data
    val spokenList = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
    val spokenText = spokenList?.firstOrNull()
    if (!spokenText.isNullOrBlank()) {
      voiceTranscriptionText = spokenText
      val parsed = BusinessUtils.parseVoiceQuery(spokenText)
      title = parsed.title
      if (parsed.amount > 0) {
        amountText = if (parsed.amount % 1.0 == 0.0) parsed.amount.toLong().toString() else parsed.amount.toString()
      }
      selectedType = parsed.type
      selectedCategory = parsed.category
      selectedIcon = parsed.icon
      Toast.makeText(context, "Voice parsed: ${parsed.title}", Toast.LENGTH_SHORT).show()
    }
  }

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      receiptImageUri = uri.toString()
    }
  }

  val paymentMethods = listOf(
    Pair("JazzCash", "📱"),
    Pair("Bank Transfer", "🏦"),
    Pair("Easypaisa", "🟢"),
    Pair("Raast", "⚡"),
    Pair("SadaPay", "💳"),
    Pair("NayaPay", "🟣"),
    Pair("Cash", "💵"),
    Pair("Debit Card", "💳")
  )

  val categories = listOf(
    Pair("Shopping", "🛍️"),
    Pair("Transfer & Remittance", "💸"),
    Pair("Food & Dining", "🍔"),
    Pair("Bills & Utilities", "⚡"),
    Pair("Salary & Income", "💼"),
    Pair("Transportation", "🚕"),
    Pair("Health & Wellness", "💊"),
    Pair("Investments", "📈"),
    Pair("Entertainment", "🎬")
  )

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(28.dp))
        .testTag("add_transaction_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Dialog Title & Close
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (selectedType == TransactionType.INCOME) "Receive Money / رقم وصول کریں" else "Send Money / رقم بھیجیں",
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            )
            Text(
              text = "JazzCash, Easypaisa, Bank, SadaPay & Proof Receipts",
              style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
            )
          }

          // Voice Entry Button
          Button(
            onClick = {
              try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                  putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                  putExtra(RecognizerIntent.EXTRA_PROMPT, "بولیں: مثال 'Ali 1500 sugar' یا '5000 salary'")
                }
                speechRecognizerLauncher.launch(intent)
              } catch (e: Exception) {
                Toast.makeText(context, "Speech recognition not available on this device", Toast.LENGTH_SHORT).show()
              }
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5F3EA)),
            modifier = Modifier.testTag("voice_entry_button")
          ) {
            Icon(
              imageVector = Icons.Default.Mic,
              contentDescription = "Voice Input",
              tint = NavyBluePrimary,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "آواز سے", color = NavyBluePrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }

          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = TextSecondary
            )
          }
        }

        if (!voiceTranscriptionText.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(8.dp))
          Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(text = "🎙️", fontSize = 14.sp)
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "سنا گیا: \"$voiceTranscriptionText\"",
                style = MaterialTheme.typography.labelMedium.copy(
                  color = Color(0xFF166534),
                  fontWeight = FontWeight.SemiBold
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Type Selector (Expense / Transfer / Income)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFF2F3F7))
            .padding(4.dp),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          TypeToggleChip(
            label = "Expense / Pay",
            isSelected = selectedType == TransactionType.EXPENSE || selectedType == TransactionType.TRANSFER,
            activeColor = ExpenseRed,
            onClick = {
              selectedType = TransactionType.EXPENSE
              if (selectedCategory == "Salary & Income") {
                selectedCategory = "Transfer & Remittance"
                selectedIcon = "💸"
              }
            }
          )
          TypeToggleChip(
            label = "Income / Received",
            isSelected = selectedType == TransactionType.INCOME,
            activeColor = IncomeGreen,
            onClick = {
              selectedType = TransactionType.INCOME
              selectedCategory = "Salary & Income"
              selectedIcon = "💼"
            }
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Title Input
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Title / Description") },
          placeholder = { Text("e.g. Payment to Ali, Bill pay, Freelance") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_transaction_title")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Amount Input
        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("Amount ($currencySymbol)") },
          placeholder = { Text("0.00") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          textStyle = InputFieldStyles.boldTextStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_transaction_amount")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Payment Method Selector
        Text(
          text = "Payment Method / Source",
          style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(6.dp))

        val methodScroll = rememberScrollState()
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(methodScroll),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          paymentMethods.forEach { (methodName, icon) ->
            val isSelected = selectedPaymentMethod == methodName
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable { selectedPaymentMethod = methodName }
                .padding(horizontal = 12.dp, vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "$icon $methodName",
                style = MaterialTheme.typography.bodySmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Bank Presets if Bank Transfer is selected
        if (selectedPaymentMethod == "Bank Transfer") {
          Text(
            text = "Select Bank (بینک منتخب کریں):",
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF475569)
          )
          Spacer(modifier = Modifier.height(4.dp))
          val bankPresets = listOf("Meezan Bank", "HBL", "UBL", "Bank Alfalah", "Allied Bank", "MCB", "Faysal Bank")
          val bankScroll = rememberScrollState()
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(bankScroll),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            bankPresets.forEach { bName ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (recipientInfo.contains(bName)) NavyBluePrimary else Color(0xFFF7F9F3),
                modifier = Modifier.clickable {
                  recipientInfo = if (recipientInfo.isBlank()) "$bName: " else "$bName - $recipientInfo"
                }
              ) {
                Text(
                  text = bName,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Medium,
                  color = if (recipientInfo.contains(bName)) Color.White else Color(0xFF334155),
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
        }

        val recipientLabel = when (selectedPaymentMethod) {
          "JazzCash" -> "JazzCash Mobile # / Beneficiary"
          "Easypaisa" -> "Easypaisa Mobile # / Beneficiary"
          "Bank Transfer" -> "Bank Name, Account # or IBAN"
          "SadaPay" -> "SadaPay Mobile / IBAN / @Username"
          "NayaPay" -> "NayaPay Mobile or ID"
          "Raast" -> "Raast ID (Mobile #)"
          "Cash" -> "Customer / Person Name"
          else -> "Recipient / Beneficiary (Optional)"
        }
        val recipientPlaceholder = when (selectedPaymentMethod) {
          "JazzCash" -> "e.g. 0302-1234567 (Ali)"
          "Easypaisa" -> "e.g. 0345-9876543 (Khan)"
          "Bank Transfer" -> "e.g. Meezan Bank - PK89MEZN... (Muhammad)"
          "SadaPay" -> "e.g. 03001234567 or @username"
          "NayaPay" -> "e.g. 03211234567"
          "Raast" -> "e.g. 03001234567"
          "Cash" -> "e.g. Walk-in Customer"
          else -> "e.g. Ali Khan - 03001234567"
        }

        // Recipient Info Input (Bank / Mobile Number / IBAN)
        OutlinedTextField(
          value = recipientInfo,
          onValueChange = { recipientInfo = it },
          label = { Text(recipientLabel) },
          placeholder = { Text(recipientPlaceholder) },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_recipient_info")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Transaction ID / Reference (TRX ID)
        OutlinedTextField(
          value = transactionRef,
          onValueChange = { transactionRef = it },
          label = { Text("Transaction ID / Reference # (Optional)") },
          placeholder = { Text("e.g. TID 9874561230") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_transaction_ref")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Screenshot / Receipt Attachment Section
        Text(
          text = "Payment Proof / Screenshot Receipt",
          style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(6.dp))

        if (receiptImageUri == null) {
          OutlinedButton(
            onClick = { photoPickerLauncher.launch("image/*") },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("attach_screenshot_button")
          ) {
            Icon(
              imageVector = Icons.Default.AddPhotoAlternate,
              contentDescription = "Attach screenshot",
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Attach Screenshot / Slip (Gallery)")
          }
        } else {
          // Display attached screenshot preview
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(16.dp))
              .border(1.dp, Color(0xFFE2E2E6), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FC))
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(56.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(Color.White)
              ) {
                AsyncImage(
                  model = receiptImageUri,
                  contentDescription = "Receipt Preview",
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.matchParentSize()
                )
              }

              Spacer(modifier = Modifier.width(12.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Screenshot Attached ✓",
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = IncomeGreen
                  )
                )
                Text(
                  text = "Tap delete to remove or change",
                  style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary)
                )
              }

              IconButton(onClick = { receiptImageUri = null }) {
                Icon(
                  imageVector = Icons.Default.Delete,
                  contentDescription = "Remove screenshot",
                  tint = ExpenseRed
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Category Picker
        Text(
          text = "Category",
          style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(6.dp))

        val catScroll = rememberScrollState()
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(catScroll),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          categories.forEach { (catName, icon) ->
            val isSelected = selectedCategory == catName
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable {
                  selectedCategory = catName
                  selectedIcon = icon
                }
                .padding(horizontal = 12.dp, vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "$icon $catName",
                style = MaterialTheme.typography.bodySmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Account Picker
        Text(
          text = "Account",
          style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(6.dp))

        val accScroll = rememberScrollState()
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(accScroll),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          accounts.forEach { acc ->
            val isSelected = selectedAccountName == acc.name
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable { selectedAccountName = acc.name }
                .padding(horizontal = 12.dp, vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = acc.name,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Note Input
        OutlinedTextField(
          value = note,
          onValueChange = { note = it },
          label = { Text("Note (Optional)") },
          placeholder = { Text("Additional details...") },
          shape = RoundedCornerShape(16.dp),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_transaction_note")
        )

        if (errorMessage != null) {
          Text(
            text = errorMessage ?: "",
            color = ExpenseRed,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 8.dp)
          )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically
        ) {
          TextButton(onClick = onDismiss) {
            Text(text = "Cancel", color = TextSecondary)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              val parsedAmount = amountText.toDoubleOrNull()
              if (title.isBlank()) {
                errorMessage = "Please enter a title or vendor"
              } else if (parsedAmount == null || parsedAmount <= 0) {
                errorMessage = "Please enter a valid positive amount"
              } else {
                onSave(
                  title.trim(),
                  parsedAmount,
                  selectedType,
                  selectedCategory,
                  selectedIcon,
                  selectedAccountName,
                  note.trim(),
                  recipientInfo.trim(),
                  selectedPaymentMethod,
                  receiptImageUri ?: "",
                  transactionRef.trim()
                )
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.testTag("save_transaction_button")
          ) {
            Text(text = "Save & Record")
          }
        }
      }
    }
  }
}

@Composable
private fun TypeToggleChip(
  label: String,
  isSelected: Boolean,
  activeColor: Color,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(12.dp))
      .background(if (isSelected) activeColor else Color.Transparent)
      .clickable(onClick = onClick)
      .padding(horizontal = 20.dp, vertical = 8.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium.copy(
        fontWeight = FontWeight.Bold,
        color = if (isSelected) Color.White else TextPrimary
      )
    )
  }
}
