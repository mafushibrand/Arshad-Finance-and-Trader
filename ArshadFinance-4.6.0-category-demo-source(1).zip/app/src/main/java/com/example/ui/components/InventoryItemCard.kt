package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InventoryItem
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.OnIceBlueContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun InventoryItemCard(
  item: InventoryItem,
  currencySymbol: String,
  onEditClick: () -> Unit,
  onQuickSaleClick: () -> Unit,
  onQuickAddStockClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isLowStock = item.currentStock <= item.lowStockThreshold
  val isOutOfStock = item.currentStock <= 0.0

  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .border(
        width = if (isOutOfStock) 1.5.dp else if (isLowStock) 1.dp else 0.5.dp,
        color = if (isOutOfStock) ExpenseRed else if (isLowStock) Color(0xFFF59E0B) else Color(0xFFE2E2E6),
        shape = RoundedCornerShape(20.dp)
      )
      .clickable(onClick = onEditClick)
      .testTag("inventory_item_${item.id}"),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Top Row: Icon + Title + Category + Edit Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(if (isOutOfStock) Color(0xFFFEE2E2) else IceBlueContainer),
            contentAlignment = Alignment.Center
          ) {
            Text(text = item.icon, fontSize = 22.sp)
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = item.name,
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              ),
              maxLines = 1
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = item.category,
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
              )
              if (item.barcode.isNotBlank()) {
                Text(
                  text = " • #${item.barcode}",
                  style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary)
                )
              }
            }
          }
        }

        IconButton(
          onClick = onEditClick,
          modifier = Modifier.size(36.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Edit,
            contentDescription = "Edit Item",
            tint = TextSecondary,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Middle Row: Price and Stock Highlights
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFFF8F9FC))
          .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Price Info (Cost vs Sale)
        Column {
          Text(
            text = "Sale Price (فروخت)",
            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
          )
          Text(
            text = "$currencySymbol ${String.format("%.2f", item.salePrice)} / ${item.unit}",
            style = MaterialTheme.typography.titleSmall.copy(
              fontWeight = FontWeight.Bold,
              color = NavyBluePrimary
            )
          )
          if (item.costPrice > 0) {
            val margin = item.salePrice - item.costPrice
            Text(
              text = "Cost: $currencySymbol ${String.format("%.1f", item.costPrice)} (منافع: +$currencySymbol ${String.format("%.1f", margin)})",
              style = MaterialTheme.typography.labelSmall.copy(
                color = if (margin >= 0) IncomeGreen else ExpenseRed,
                fontSize = 10.sp
              )
            )
          }
        }

        // Remaining Stock Badge
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "Remaining Stock (موجودہ مال)",
            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
          )

          Row(verticalAlignment = Alignment.CenterVertically) {
            if (isOutOfStock) {
              Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Out of stock",
                tint = ExpenseRed,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "ختم (Out of Stock)",
                style = MaterialTheme.typography.bodyMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = ExpenseRed
                )
              )
            } else {
              if (isLowStock) {
                Icon(
                  imageVector = Icons.Default.Warning,
                  contentDescription = "Low stock",
                  tint = Color(0xFFD97706),
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
              }
              Text(
                text = "${if (item.currentStock % 1.0 == 0.0) item.currentStock.toLong().toString() else item.currentStock.toString()} ${item.unit}",
                style = MaterialTheme.typography.bodyLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = if (isLowStock) Color(0xFFD97706) else IncomeGreen
                )
              )
            }
          }

          if (isLowStock && !isOutOfStock) {
            Text(
              text = "کم اسٹاک الرٹ (< ${item.lowStockThreshold.toInt()})",
              style = MaterialTheme.typography.labelSmall.copy(
                color = Color(0xFFD97706),
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
              )
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Bottom Row: Quick 1-Tap Action Buttons (+ Stock In, - Sale / Deduct)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Stock In (+ Add Stock)
        OutlinedButton(
          onClick = onQuickAddStockClick,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .weight(1f)
            .height(40.dp)
            .testTag("quick_add_stock_${item.id}")
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Add Stock",
            tint = IncomeGreen,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "اسٹاک شامل کریں",
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              color = IncomeGreen,
              fontSize = 12.sp
            )
          )
        }

        // Sale / Minus (- Auto-Deduct on sale)
        Button(
          onClick = onQuickSaleClick,
          enabled = !isOutOfStock,
          colors = ButtonDefaults.buttonColors(
            containerColor = if (!isOutOfStock) NavyBluePrimary else Color.LightGray
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .weight(1f)
            .height(40.dp)
            .testTag("quick_sale_item_${item.id}")
        ) {
          Icon(
            imageVector = Icons.Default.ShoppingCart,
            contentDescription = "Sell item",
            tint = Color.White,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "بیچیں (Sale)",
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White,
              fontSize = 12.sp
            )
          )
        }
      }
    }
  }
}
