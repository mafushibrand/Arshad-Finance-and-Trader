package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.AppMode

@Composable
fun LegacyModeSelectionScreen(
  currentMode: AppMode,
  appLanguage: AppLanguage,
  onModeSelected: (AppMode) -> Unit,
  modifier: Modifier = Modifier
) {
  val isUrdu = appLanguage == AppLanguage.URDU
  var selectedMode by remember { mutableStateOf(currentMode) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFFF5F7F2))
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 20.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(10.dp))

      // Header Banner
      Surface(
        shape = CircleShape,
        color = Color(0xFF086B4D).copy(alpha = 0.1f),
        modifier = Modifier.size(68.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Text("⚙️", fontSize = 32.sp)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = if (isUrdu) "کاروبار یا استعمال کا موڈ منتخب کریں" else "Select Your Usage / Business Mode",
        fontSize = 20.sp,
        fontWeight = FontWeight.ExtraBold,
        color = Color(0xFF0F172A),
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = if (isUrdu)
          "آپ جس موڈ کا انتخاب کریں گے، ایپ کا لے آؤٹ اور مینیو اسی کے مطابق ہوگا تا کہ کوئی اضافی یا غیر ضروری چیز تنگ نہ کرے۔"
        else
          "Choose your mode below. The layout and navigation tabs will automatically adapt so that unnecessary features are hidden.",
        fontSize = 12.sp,
        color = Color(0xFF64748B),
        textAlign = TextAlign.Center,
        lineHeight = 16.sp
      )

      Spacer(modifier = Modifier.height(20.dp))

      // Card 1: Shop / Retail Mart Mode
      ModeCard(
        title = if (isUrdu) "1. دکان، مارٹ اور جنرل اسٹور موڈ" else "1. Shop, Mart & Retail Store Mode",
        urduBadge = if (isUrdu) "مکمل بزنس فیچرز" else "Full Business POS",
        description = if (isUrdu)
          "پی او ایس کاؤنٹر، بارکوڈ اسکینر، دکان کا مکمل اسٹاک، لو اسٹاک الرٹس، ایف بی آر سیلز ٹیکس، تھرمل پرنٹنگ، اور گاہکوں کا کھاتہ۔"
        else
          "Complete POS Counter, Barcode scanner, Inventory stock, low-stock alerts, FBR tax deductions, thermal invoices & customer ledgers.",
        icon = "🏪",
        badges = listOf(
          if (isUrdu) "پی او ایس کاؤنٹر" else "POS Counter",
          if (isUrdu) "اسٹاک و بارکوڈ" else "Stock & Barcode",
          if (isUrdu) "ایف بی آر ٹیکس" else "FBR Tax Mode",
          if (isUrdu) "تھرمل بلنگ" else "Thermal Billing",
          if (isUrdu) "گاہک کھاتہ" else "Customer Khata"
        ),
        isSelected = selectedMode == AppMode.BUSINESS_RETAIL,
        gradientColors = listOf(Color(0xFF006C45), Color(0xFF086B4D)),
        onClick = { selectedMode = AppMode.BUSINESS_RETAIL }
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Card 2: Services / Salon / Repair Mode
      ModeCard(
        title = if (isUrdu) "2. سروس، سیلون اور ورک شاپ موڈ" else "2. Service, Salon & Repairing Mode",
        urduBadge = if (isUrdu) "سروسز و لیبر چارجز" else "Service Billing",
        description = if (isUrdu)
          "سیلون، ورک شاپ، جم، کلینک اور سروسز کے لیے: لیبر چارجز، سروسز ریٹس، کسٹمر بلنگ، اور ادھار کھاتہ۔"
        else
          "For Salons, Repair shops, Gyms & Clinics: Service charges, hourly/labor rates, customer billing & ledgers.",
        icon = "💇",
        badges = listOf(
          if (isUrdu) "سروسز کیٹلاگ" else "Service Catalog",
          if (isUrdu) "مزدوری و چارجز" else "Labor Charges",
          if (isUrdu) "گاہک رسید" else "Customer Slip",
          if (isUrdu) "کیش فلو" else "Cash Flow"
        ),
        isSelected = selectedMode == AppMode.SERVICE_BASED,
        gradientColors = listOf(Color(0xFF0F766E), Color(0xFF0D9488)),
        onClick = { selectedMode = AppMode.SERVICE_BASED }
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Card 3: Personal Finance & Khata Mode
      ModeCard(
        title = if (isUrdu) "3. ذاتی کھاتہ اور فنانس موڈ" else "3. Personal Finance & Ledger Mode",
        urduBadge = if (isUrdu) "صرف کھاتہ اور حساب کتاب" else "Personal Ledger Only",
        description = if (isUrdu)
          "کوئی غیر ضروری دکان یا اسٹاک کا بوجھ نہیں! صرف ذاتی کھاتہ، دوست و رشتہ داروں کا ادھار، جازکیش/ایزی پیسہ/بینک، اور روزانہ کا حساب کتاب۔"
        else
          "No shop stock or POS clutter! Only personal Khata, friends/family credits, digital wallets (JazzCash/EasyPaisa/Banks), and income/expense.",
        icon = "👤",
        badges = listOf(
          if (isUrdu) "ذاتی کھاتہ" else "Personal Khata",
          if (isUrdu) "روزانہ آمدن و خرچ" else "Daily Income/Expense",
          if (isUrdu) "جازکیش و بینک والٹس" else "Digital Wallets",
          if (isUrdu) "واٹس ایپ یاددہانی" else "WhatsApp Reminder"
        ),
        isSelected = selectedMode == AppMode.PERSONAL_KHATA,
        gradientColors = listOf(Color(0xFF064D3A), Color(0xFF6366F1)),
        onClick = { selectedMode = AppMode.PERSONAL_KHATA }
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Confirm & Enter Button
      Button(
        onClick = {
          onModeSelected(selectedMode)
        },
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D)),
        modifier = Modifier
          .fillMaxWidth()
          .height(54.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = if (isUrdu) "انتخاب کی تصدیق کریں اور ایپ شروع کریں ✓" else "Confirm Mode & Enter App ✓",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))
    }
  }
}

@Composable
private fun ModeCard(
  title: String,
  urduBadge: String,
  description: String,
  icon: String,
  badges: List<String>,
  isSelected: Boolean,
  gradientColors: List<Color>,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .clickable(onClick = onClick)
      .border(
        width = if (isSelected) 3.dp else 1.dp,
        color = if (isSelected) Color(0xFF086B4D) else Color(0xFFE2E8F0),
        shape = RoundedCornerShape(20.dp)
      ),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 6.dp else 1.5.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = gradientColors.first().copy(alpha = 0.12f),
            modifier = Modifier.size(46.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(icon, fontSize = 24.sp)
            }
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = title,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = gradientColors.first().copy(alpha = 0.1f)
            ) {
              Text(
                text = urduBadge,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = gradientColors.first(),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }

        if (isSelected) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "Selected",
            tint = Color(0xFF086B4D),
            modifier = Modifier.size(24.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = description,
        fontSize = 11.5.sp,
        color = Color(0xFF475569),
        lineHeight = 16.sp
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Badges
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        badges.take(4).forEach { b ->
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFF7F9F3)
          ) {
            Text(
              text = b,
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF334155),
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }
    }
  }
}
