package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.Invoice
import com.example.ui.FinanceUiState
import com.example.ui.theme.DeepNavyText
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.InputFieldStyles
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.InvoicePrintExportUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LegacyBillingScreen(
  uiState: FinanceUiState,
  onOpenAddInvoice: () -> Unit,
  onOpenEditInvoice: (Invoice) -> Unit,
  onSelectInvoice: (Invoice) -> Unit,
  onOpenAddCustomer: () -> Unit,
  onEditCustomer: (Customer) -> Unit,
  onSelectCustomer: (Customer) -> Unit,
  onOpenEditProfile: () -> Unit,
  onOpenShopProfile: () -> Unit,
  onOpenIndustryCatalog: () -> Unit,
  onDeleteInvoice: (Invoice) -> Unit,
  onOpenAddProduct: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var searchQuery by remember { mutableStateOf("") }
  var selectedTab by remember { mutableIntStateOf(0) } // 0: All Invoices, 1: Udhar / Due, 2: Paid, 3: Customers

  val invoices = uiState.invoices
  val customers = uiState.customers
  val profile = uiState.businessProfile
  val currency = uiState.currencySymbol

  val totalBilled = invoices.sumOf { it.netTotal() }
  val totalCollected = invoices.sumOf { it.amountPaid }
  val totalUdhar = invoices.sumOf { it.remainingBalance }

  val filteredInvoices = remember(invoices, searchQuery, selectedTab) {
    var list = invoices
    if (searchQuery.isNotBlank()) {
      list = list.filter {
        it.customerName.contains(searchQuery, ignoreCase = true) ||
            it.customerPhone.contains(searchQuery, ignoreCase = true) ||
            it.invoiceNumber.contains(searchQuery, ignoreCase = true) ||
            it.itemsJson.contains(searchQuery, ignoreCase = true)
      }
    }
    when (selectedTab) {
      1 -> list.filter { it.remainingBalance > 0 }
      2 -> list.filter { it.remainingBalance <= 0 }
      else -> list
    }
  }

  val filteredCustomers = remember(customers, searchQuery) {
    if (searchQuery.isBlank()) customers else {
      customers.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
            it.phone.contains(searchQuery, ignoreCase = true) ||
            it.address.contains(searchQuery, ignoreCase = true)
      }
    }
  }

  val dateFormat = SimpleDateFormat("dd-MMM-yyyy, hh:mm a", Locale.getDefault())

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 14.dp),
      contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 4.dp, bottom = 100.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      item { Spacer(modifier = Modifier.height(4.dp)) }

      // 1. Business Shop Header Card with Custom Logo & Branding
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)) // Slate 900
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                  modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E293B))
                    .border(2.dp, Color(0xFF38BDF8), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Text(text = profile.logoEmoji.ifBlank { "🏪" }, fontSize = 26.sp)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = profile.businessName,
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontWeight = FontWeight.Bold,
                      color = Color.White
                    )
                  )
                  Text(
                    text = "${profile.shopType} • Ph: ${profile.phone}",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF94A3B8), fontSize = 11.sp)
                  )
                  if (profile.address.isNotBlank()) {
                    Text(
                      text = "📍 ${profile.address}",
                      style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF64748B), fontSize = 10.sp),
                      maxLines = 1
                    )
                  }
                }
              }

              // Edit Business Profile Button
              Button(
                onClick = onOpenShopProfile,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8)),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Shop Logo", fontSize = 11.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFF334155))
            Spacer(modifier = Modifier.height(8.dp))

            // Fast category load button
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "⚡ Beauty Parlour, Cloth, Medical, Grocery:",
                style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF94A3B8), fontSize = 11.sp)
              )
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8)),
                modifier = Modifier.clickable(onClick = onOpenIndustryCatalog)
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text("💅 👗 💊 🛒 Load Shop Items", fontSize = 11.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }

      // 2. Billing Key Statistics Cards
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("Total Sales", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
              Text(
                "$currency ${"%,.0f".format(totalBilled)}",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = NavyBluePrimary
              )
              Text("${invoices.size} Bills", fontSize = 10.sp, color = TextSecondary)
            }
          }

          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("Cash Received", fontSize = 11.sp, color = Color(0xFF166534), fontWeight = FontWeight.Medium)
              Text(
                "$currency ${"%,.0f".format(totalCollected)}",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = IncomeGreen
              )
              Text("Collected", fontSize = 10.sp, color = Color(0xFF166534))
            }
          }

          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("Total Udhar", fontSize = 11.sp, color = if (totalUdhar > 0) ExpenseRed else TextSecondary, fontWeight = FontWeight.Medium)
              Text(
                "$currency ${"%,.0f".format(totalUdhar)}",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = if (totalUdhar > 0) ExpenseRed else IncomeGreen
              )
              Text("Receivable", fontSize = 10.sp, color = TextSecondary)
            }
          }
        }
      }

      // 3. Quick Action Buttons (+ New Bill, + Add Product, + Add Client)
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Button(
            onClick = onOpenAddInvoice,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 10.dp),
            modifier = Modifier
              .weight(1.2f)
              .height(48.dp)
              .testTag("btn_create_customer_bill")
          ) {
            Icon(imageVector = Icons.Default.Receipt, contentDescription = "New Bill", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("+ New Bill (بل)", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
          }

          Button(
            onClick = onOpenAddProduct,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF047857)), // Emerald Green
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 10.dp),
            modifier = Modifier
              .weight(1.1f)
              .height(48.dp)
              .testTag("btn_add_store_product")
          ) {
            Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = "Add Item", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("+ Product (سامان)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
          }

          Button(
            onClick = onOpenAddCustomer,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 10.dp),
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("btn_add_client")
          ) {
            Icon(imageVector = Icons.Default.PersonAdd, contentDescription = "Add Client", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("+ Client (گاہک)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
          }
        }
      }

      // 4. Search Bar
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("Search customer name, phone, bill #...") },
          leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = TextSecondary) },
          trailingIcon = {
            if (searchQuery.isNotBlank()) {
              IconButton(onClick = { searchQuery = "" }) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("billing_search_input")
        )
      }

      // 5. Tabs (All Invoices, Udhar, Paid, Customers)
      item {
        TabRow(
          selectedTabIndex = selectedTab,
          containerColor = Color.Transparent,
          contentColor = NavyBluePrimary,
          divider = { HorizontalDivider(color = Color(0xFFE2E8F0)) }
        ) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = { Text("All Bills (${invoices.size})", fontWeight = FontWeight.Bold, fontSize = 11.sp) }
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = { Text("Udhar (${invoices.count { it.remainingBalance > 0 }})", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = ExpenseRed) }
          )
          Tab(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            text = { Text("Paid", fontWeight = FontWeight.Bold, fontSize = 11.sp) }
          )
          Tab(
            selected = selectedTab == 3,
            onClick = { selectedTab = 3 },
            text = { Text("Clients (${customers.size})", fontWeight = FontWeight.Bold, fontSize = 11.sp) }
          )
        }
      }

      // 6. Content Section (Invoices or Customers List)
      if (selectedTab != 3) {
        // INVOICES LIST
        if (filteredInvoices.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🧾", fontSize = 40.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("No bills found", fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Click '+ New Bill' to create an invoice.", fontSize = 12.sp, color = TextSecondary)
              }
            }
          }
        } else {
          items(filteredInvoices, key = { it.id }) { invoice ->
            val items = invoice.parseItems()
            val isPaid = invoice.remainingBalance <= 0.0

            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectInvoice(invoice) }
                .testTag("invoice_card_${invoice.id}"),
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                // Header Row: Customer Name & Status
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                      modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(IceBlueContainer),
                      contentAlignment = Alignment.Center
                    ) {
                      Text(
                        text = invoice.customerName.take(1).uppercase().ifBlank { "C" },
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = DeepNavyText
                      )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Text(
                        text = invoice.customerName.ifBlank { "Walk-in Customer" },
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                      )
                      Text(
                        text = "${invoice.invoiceNumber} • ${dateFormat.format(Date(invoice.dateMillis))}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                      )
                    }
                  }

                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPaid) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                  ) {
                    Text(
                      text = if (isPaid) "PAID" else "UDHAR: $currency ${"%,.0f".format(invoice.remainingBalance)}",
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (isPaid) IncomeGreen else ExpenseRed,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Items list snippet
                Text(
                  text = items.joinToString(" • ") { "${if (it.quantity % 1.0 == 0.0) it.quantity.toInt().toString() else it.quantity.toString()} ${it.itemName}" },
                  style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF475569)),
                  maxLines = 2
                )

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = Color(0xFFF7F9F3))
                Spacer(modifier = Modifier.height(8.dp))

                // Financials Row
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(
                      text = "Total: $currency ${"%,.0f".format(invoice.grandTotal)}",
                      fontWeight = FontWeight.Bold,
                      fontSize = 15.sp,
                      color = NavyBluePrimary
                    )
                    Text(
                      text = "Paid: $currency ${"%,.0f".format(invoice.amountPaid)} (${invoice.paymentMethod})",
                      fontSize = 11.sp,
                      color = TextSecondary
                    )
                  }

                  // 1-Click PDF / WhatsApp / Image / Edit / Delete Buttons
                  Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // WhatsApp
                    IconButton(
                      onClick = {
                        InvoicePrintExportUtils.shareInvoiceViaWhatsApp(context, invoice, profile, currency)
                      },
                      modifier = Modifier.size(34.dp)
                    ) {
                      Icon(imageVector = Icons.Default.Send, contentDescription = "WhatsApp Bill", tint = IncomeGreen, modifier = Modifier.size(18.dp))
                    }

                    // PDF
                    IconButton(
                      onClick = {
                        InvoicePrintExportUtils.generateAndShareInvoicePdf(context, invoice, profile, currency)
                      },
                      modifier = Modifier.size(34.dp)
                    ) {
                      Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = "PDF Bill", tint = NavyBluePrimary, modifier = Modifier.size(18.dp))
                    }

                    // Image
                    IconButton(
                      onClick = {
                        InvoicePrintExportUtils.generateAndShareInvoiceImage(context, invoice, profile, currency)
                      },
                      modifier = Modifier.size(34.dp)
                    ) {
                      Icon(imageVector = Icons.Default.Image, contentDescription = "Image Bill", tint = Color(0xFF7C3AED), modifier = Modifier.size(18.dp))
                    }

                    // Owner-only editing
                    if(uiState.userRole==com.example.data.model.UserRole.OWNER) IconButton(
                      onClick = { onOpenEditInvoice(invoice) },
                      modifier = Modifier.size(34.dp)
                    ) {
                      Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Bill", tint = Color(0xFF13865F), modifier = Modifier.size(18.dp))
                    }

                    // Owner-only deletion
                    if(uiState.userRole==com.example.data.model.UserRole.OWNER) IconButton(
                      onClick = { onDeleteInvoice(invoice) },
                      modifier = Modifier.size(34.dp)
                    ) {
                      Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFF94A3B8), modifier = Modifier.size(18.dp))
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        // CUSTOMERS / CLIENTS LIST
        if (filteredCustomers.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("👥", fontSize = 40.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("No customers registered", fontWeight = FontWeight.Bold)
                Text("Click 'Add Client' to create customer records.", fontSize = 12.sp, color = TextSecondary)
              }
            }
          }
        } else {
          items(filteredCustomers, key = { it.id }) { customer ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectCustomer(customer) }
                .testTag("customer_card_${customer.id}"),
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                  Box(
                    modifier = Modifier
                      .size(44.dp)
                      .clip(CircleShape)
                      .background(IceBlueContainer),
                    contentAlignment = Alignment.Center
                  ) {
                    Text(
                      text = customer.name.take(1).uppercase().ifBlank { "C" },
                      fontSize = 18.sp,
                      fontWeight = FontWeight.Bold,
                      color = DeepNavyText
                    )
                  }
                  Spacer(modifier = Modifier.width(12.dp))
                  Column {
                    Text(
                      text = customer.name,
                      style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                      text = "${customer.customerType} • Ph: ${customer.phone.ifBlank { "N/A" }}",
                      style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                    if (customer.address.isNotBlank()) {
                      Text(
                        text = "📍 ${customer.address}",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF64748B)),
                        maxLines = 1
                      )
                    }
                  }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                  Column(horizontalAlignment = Alignment.End) {
                    Text(
                      text = if (customer.currentBalance > 0) "Udhar: $currency ${"%,.0f".format(customer.currentBalance)}" else "Balance Clear",
                      fontWeight = FontWeight.Bold,
                      fontSize = 13.sp,
                      color = if (customer.currentBalance > 0) ExpenseRed else IncomeGreen
                    )
                    Text(
                      text = "Billed: $currency ${"%,.0f".format(customer.totalBilled)}",
                      fontSize = 10.sp,
                      color = TextSecondary
                    )
                    Text(
                      text = "View Ledger ➔",
                      fontSize = 11.sp,
                      color = NavyBluePrimary,
                      fontWeight = FontWeight.SemiBold
                    )
                  }

                  IconButton(
                    onClick = { onEditCustomer(customer) },
                    modifier = Modifier.size(36.dp)
                  ) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Client", tint = NavyBluePrimary, modifier = Modifier.size(18.dp))
                  }
                }
              }
            }
          }
        }
      }

      item { Spacer(modifier = Modifier.height(80.dp)) }
    }
  }
}
