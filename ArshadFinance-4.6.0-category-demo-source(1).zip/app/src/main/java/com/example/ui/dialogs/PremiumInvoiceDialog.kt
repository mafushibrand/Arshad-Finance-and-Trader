package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.util.BusinessProfile
import com.example.business.*
import java.util.UUID

@Composable
fun AddEditInvoiceDialog(businessProfile:BusinessProfile,customers:List<Customer>,inventoryItems:List<InventoryItem>,editingInvoice:Invoice?=null,initialCustomer:Customer?=null,currencySymbol:String="Rs",onOpenShopProfile:()->Unit={},onSaveInvoice:(Invoice,List<InvoiceItemEntry>,Boolean,(Invoice?)->Unit)->Unit,onAddNewProductToInventory:((InventoryItem)->Unit)?=null,onDismiss:()->Unit,appLanguage:AppLanguage=AppLanguage.ENGLISH) {
  val urdu=appLanguage==AppLanguage.URDU;fun t(en:String,ur:String)=if(urdu)ur else en
  var name by remember {mutableStateOf(editingInvoice?.customerName ?: initialCustomer?.name ?: "")}
  var phone by remember {mutableStateOf(editingInvoice?.customerPhone ?: initialCustomer?.phone ?: "")}
  var address by remember {mutableStateOf(editingInvoice?.customerAddress ?: initialCustomer?.address ?: "")}
  var customerId by remember {mutableStateOf(editingInvoice?.customerId ?: initialCustomer?.id ?: 0L)}
  var lines by remember {mutableStateOf(editingInvoice?.parseItems() ?: emptyList<InvoiceItemEntry>())}
  var itemId by remember {mutableStateOf(inventoryItems.firstOrNull()?.id ?: 0L)}
  var qty by remember {mutableStateOf("1")};var customName by remember {mutableStateOf("")};var customPrice by remember {mutableStateOf("")}
  var discount by remember {mutableStateOf(editingInvoice?.discountAmount?.toString() ?: "0")}
  var taxRate by remember {mutableStateOf(if(editingInvoice!=null && editingInvoice.subtotal>0) (editingInvoice.taxAmount/editingInvoice.subtotal*100).toString() else if(businessProfile.isFbrTaxEnabled)businessProfile.fbrTaxRatePercent.toString() else "0")}
  var labour by remember {mutableStateOf(editingInvoice?.deliveryOrLabour?.toString() ?: "0")}
  var paid by remember {mutableStateOf(editingInvoice?.amountPaid?.toString() ?: "0")}
  var method by remember {mutableStateOf(editingInvoice?.paymentMethod ?: "Cash")};var note by remember {mutableStateOf(editingInvoice?.note ?: "")}
  var error by remember {mutableStateOf("")};var saving by remember {mutableStateOf(false)};var advanced by remember {mutableStateOf(false)}
  val subtotal=lines.sumOf {it.total};val discountValue=discount.toDoubleOrNull() ?: 0.0;val tax=subtotal*(taxRate.toDoubleOrNull() ?: 0.0)/100;val grand=(subtotal-discountValue+tax+(labour.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)
  if(advanced){LegacyAddEditInvoiceDialog(businessProfile,customers,inventoryItems,editingInvoice,initialCustomer,currencySymbol,onOpenShopProfile,onSaveInvoice,onAddNewProductToInventory,onDismiss);return}
  BusinessForm(if(editingInvoice==null)t("New Invoice","نیا بل") else t("Edit Invoice","بل کی ترمیم"),if(saving)t("Saving…","محفوظ ہو رہا ہے…") else t("Save Invoice","بل محفوظ کریں"),onDismiss,{
    if(!saving) {
      val payment=paid.toDoubleOrNull();val values=listOf(discount.toDoubleOrNull(),taxRate.toDoubleOrNull(),labour.toDoubleOrNull(),payment)
      if(lines.isEmpty()||values.any{it==null||!it.isFinite()||it<0}||discountValue>subtotal||payment!!>grand)error=t("Check items, discount, tax and payment amounts","سامان، رعایت، ٹیکس اور ادائیگی درست درج کریں")
      else if(payment<grand && name.isBlank())error=t("Select or enter a customer for Khata","کھاتے کے لیے گاہک کا نام درج کریں")
      else {
        val invoice=(editingInvoice ?: Invoice(invoiceNumber="${businessProfile.invoicePrefix}-${UUID.randomUUID().toString().take(8).uppercase()}",customerName=""))
          .copy(customerId=customerId,customerName=name.ifBlank {"Walk-in"},customerPhone=phone,customerAddress=address,itemsJson=InvoiceItemEntry.toJsonString(lines),subtotal=subtotal,discountAmount=discountValue,taxAmount=tax,deliveryOrLabour=labour.toDouble(),grandTotal=grand,amountPaid=payment,remainingBalance=grand-payment,paymentStatus=if(payment>=grand)"PAID" else if(payment>0)"PARTIAL" else "UNPAID",paymentMethod=method,businessName=businessProfile.businessName,businessPhone=businessProfile.phone,businessAddress=businessProfile.address,businessLogoEmoji=businessProfile.logoEmoji,shopType=businessProfile.shopType,note=note)
        saving=true;onSaveInvoice(invoice,lines,true){saved -> saving=false;if(saved!=null)onDismiss() else error=t("Invoice could not be saved. Check stock and amounts.","بل محفوظ نہیں ہوا۔ اسٹاک اور رقم درست کریں۔")}
      }
    }
  }) {
    BusinessChoice(customers.find {it.id==customerId}?.name ?: t("Walk-in / custom","عام / نیا گاہک"),t("Customer","گاہک"),listOf(t("Walk-in / custom","عام / نیا گاہک"))+customers.map {it.name}) {selected ->
      val customer=customers.firstOrNull{it.name==selected};customerId=customer?.id ?: 0L;name=customer?.name ?: "";phone=customer?.phone ?: "";address=customer?.address ?: ""
    }
    BusinessField(name,t("Customer name","گاہک کا نام")){name=it};BusinessField(phone,t("Phone","فون")){phone=it};BusinessField(address,t("Address","پتہ")){address=it}
    Text(t("Add products / services","سامان / سروس شامل کریں"),style=MaterialTheme.typography.titleMedium)
    BusinessChoice(inventoryItems.find {it.id==itemId}?.name ?: "",t("Item","سامان"),inventoryItems.map {it.name}) {selected -> itemId=inventoryItems.first {it.name==selected}.id}
    BusinessField(qty,t("Quantity / weight (decimal)","مقدار / وزن (اعشاریہ)"),true){qty=it}
    Button(onClick={val item=inventoryItems.find {it.id==itemId};val q=qty.toDoubleOrNull();if(item!=null&&q!=null&&q.isFinite()&&q>0){val f=item.saleFactor();lines=lines+InvoiceItemEntry(itemId=item.id,itemName=item.name,category=item.category,quantity=q*f,unit=item.unit,unitPrice=item.salePrice/f,total=q*item.salePrice,isService=item.isServiceItem())}else error=t("Select an item and positive quantity","سامان اور مثبت مقدار منتخب کریں")},modifier=Modifier.fillMaxWidth()){Text(t("Add to invoice","بل میں شامل کریں"))}
    lines.forEachIndexed {index,line -> Card {Column(Modifier.padding(12.dp)){Text("${line.itemName} • ${line.quantity} ${line.unit}");Text("$currencySymbol ${line.total}");TextButton(onClick={lines=lines.filterIndexed{i,_->i!=index}}){Text(t("Remove line","لائن حذف کریں"))}}} }
    BusinessField(customName,t("Custom service name","اپنی سروس کا نام")){customName=it};BusinessField(customPrice,t("Custom service price","اپنی سروس کی قیمت"),true){customPrice=it}
    TextButton(onClick={val price=customPrice.toDoubleOrNull();if(customName.isNotBlank()&&price!=null&&price.isFinite()&&price>=0){lines=lines+InvoiceItemEntry(itemName=customName,quantity=1.0,unit="service",unitPrice=price,total=price,isService=true);customName="";customPrice=""}else error=t("Enter service name and price","سروس نام اور قیمت درج کریں")}){Text(t("Add custom service","اپنی سروس شامل کریں"))}
    BusinessField(discount,t("Discount amount","رعایت کی رقم"),true){discount=it};BusinessField(taxRate,t("Configured tax %","مقرر کردہ ٹیکس %"),true){taxRate=it}
    BusinessField(labour,t("Delivery / labour","ڈلیوری / مزدوری"),true){labour=it}
    Text(t("Total: $currencySymbol $grand","کل رقم: $currencySymbol $grand"),style=MaterialTheme.typography.headlineSmall)
    BusinessChoice(method,t("Payment method","ادائیگی طریقہ"),listOf("Cash","Bank","Card","JazzCash","EasyPaisa","Raast","Khata")){method=it}
    BusinessField(paid,t("Amount received","وصول شدہ رقم"),true){paid=it};Text(t("Khata due: $currencySymbol ${(grand-(paid.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)}","کھاتہ بقایا: $currencySymbol ${(grand-(paid.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)}"))
    BusinessField(note,t("Notes","نوٹ")){note=it};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
    TextButton(onClick={advanced=true}){Text(t("Existing detailed invoice tools","موجودہ بل کے تفصیلی ٹولز"))}
  }
}
