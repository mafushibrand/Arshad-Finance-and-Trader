package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Account
import com.example.data.model.Transaction
import com.example.ui.theme.DeepNavyText
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IceBlueContainerLight
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.InputFieldStyles
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.util.BusinessProfile
import com.example.util.BusinessUtils

@Composable
fun ProfileDialog(
  currentCurrency: String,
  businessProfile: BusinessProfile = BusinessProfile(),
  accounts: List<Account> = emptyList(),
  transactions: List<Transaction> = emptyList(),
  onCurrencySelected: (String) -> Unit,
  onSaveBusinessProfile: (BusinessProfile) -> Unit = {},
  onLoadDemoData: () -> Unit = {},
  onResetAllData: () -> Unit = {},
  onOpenUpgradePro: () -> Unit = {},
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val currencies = listOf("Rs", "$", "PKR", "AED", "€", "£")

  var isEditingBusiness by remember { mutableStateOf(false) }
  var bName by remember { mutableStateOf(businessProfile.businessName) }
  var bOwner by remember { mutableStateOf(businessProfile.ownerName) }
  var bPhone by remember { mutableStateOf(businessProfile.phone) }
  var bAddress by remember { mutableStateOf(businessProfile.address) }
  var bTagline by remember { mutableStateOf(businessProfile.tagline) }
  var bNtn by remember { mutableStateOf(businessProfile.ntnNumber) }
  var bShopType by remember { mutableStateOf(businessProfile.shopType) }
  var bLogoEmoji by remember { mutableStateOf(businessProfile.logoEmoji) }

  var showResetConfirmation by remember { mutableStateOf(false) }

  if (showResetConfirmation) {
    AlertDialog(
      onDismissRequest = { showResetConfirmation = false },
      title = { Text(text = "Reset All App Data?") },
      text = { Text("Are you sure you want to clear all transactions, accounts, and budgets?") },
      confirmButton = {
        Button(
          onClick = {
            showResetConfirmation = false
            onResetAllData()
            Toast.makeText(context, "All data reset successfully", Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
        ) {
          Text("Yes, Clear")
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetConfirmation = false }) {
          Text("Cancel")
        }
      }
    )
  }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(28.dp))
        .testTag("profile_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(22.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Title Bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Business Profile & Settings",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Avatar & Store Badge
        Box(
          modifier = Modifier
            .size(68.dp)
            .clip(CircleShape)
            .background(IceBlueContainerLight)
            .border(3.dp, IceBlueContainer, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = businessProfile.businessName.take(1).ifBlank { "A" },
            style = MaterialTheme.typography.headlineMedium.copy(
              fontWeight = FontWeight.Bold,
              color = DeepNavyText,
              fontSize = 30.sp
            )
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = businessProfile.businessName,
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )

        Text(
          text = "${businessProfile.ownerName} • ${businessProfile.phone}",
          style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
        )

        Row(
          modifier = Modifier.padding(top = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.VerifiedUser,
            contentDescription = "Verified",
            tint = IncomeGreen,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Commercial Edition • Ready for Client Demo",
            style = MaterialTheme.typography.labelSmall.copy(
              color = IncomeGreen,
              fontWeight = FontWeight.SemiBold
            )
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 1-CLICK PAKISTANI CLIENT DEMO BUTTON
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFE5F3EA)),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBEDBC8))
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "🚀", fontSize = 20.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = "1-Click Client Demo",
                    style = MaterialTheme.typography.titleSmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = NavyBluePrimary
                    )
                  )
                  Text(
                    text = "Load Pakistani Khata & accounts",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
              onClick = {
                onLoadDemoData()
                Toast.makeText(context, "Pakistani Business Demo Loaded!", Toast.LENGTH_LONG).show()
              },
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("load_demo_button")
            ) {
              Icon(imageVector = Icons.Default.RocketLaunch, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "ڈیمو لوڈ کریں (Load Demo)", fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // GENERATE FULL PDF STATEMENT BUTTON
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0))
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "📑", fontSize = 20.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = "Full Account Statement PDF",
                    style = MaterialTheme.typography.titleSmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF166534)
                    )
                  )
                  Text(
                    text = "Export official business ledger",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF15803D))
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
              onClick = {
                val inc = transactions.filter { it.type == com.example.data.model.TransactionType.INCOME }.sumOf { it.amount }
                val exp = transactions.filter { it.type == com.example.data.model.TransactionType.EXPENSE }.sumOf { it.amount }
                val bal = inc - exp
                BusinessUtils.generateAndShareStatementPdf(
                  context = context,
                  transactions = transactions,
                  totalIncome = inc,
                  totalExpense = exp,
                  totalBalance = bal,
                  currencySymbol = currentCurrency,
                  businessProfile = businessProfile
                )
              },
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("generate_statement_pdf_button")
            ) {
              Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "Export Statement PDF", fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Business Profile Form Toggle
        if (isEditingBusiness) {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7F2)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = "Edit Business Information",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
              )
              Spacer(modifier = Modifier.height(8.dp))

              OutlinedTextField(
                value = bName,
                onValueChange = { bName = it },
                label = { Text("Shop / Business Name") },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
              Spacer(modifier = Modifier.height(6.dp))

              OutlinedTextField(
                value = bOwner,
                onValueChange = { bOwner = it },
                label = { Text("Owner / Manager Name") },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
              Spacer(modifier = Modifier.height(6.dp))

              OutlinedTextField(
                value = bPhone,
                onValueChange = { bPhone = it },
                label = { Text("WhatsApp Phone (+92 ...)") },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
              Spacer(modifier = Modifier.height(6.dp))

              OutlinedTextField(
                value = bAddress,
                onValueChange = { bAddress = it },
                label = { Text("Shop Address") },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
              Spacer(modifier = Modifier.height(6.dp))

              OutlinedTextField(
                value = bTagline,
                onValueChange = { bTagline = it },
                label = { Text("Invoice Tagline / Note") },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
              Spacer(modifier = Modifier.height(6.dp))

              OutlinedTextField(
                value = bNtn,
                onValueChange = { bNtn = it },
                label = { Text("NTN / Tax ID (Optional)") },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
              Spacer(modifier = Modifier.height(6.dp))

              Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                  value = bLogoEmoji,
                  onValueChange = { bLogoEmoji = it },
                  label = { Text("Logo Emoji") },
                  placeholder = { Text("🏪 💅 👗 💊 🛒 📱") },
                  textStyle = InputFieldStyles.textStyle,
                  colors = InputFieldStyles.colors(),
                  modifier = Modifier.weight(0.8f),
                  singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedTextField(
                  value = bShopType,
                  onValueChange = { bShopType = it },
                  label = { Text("Shop Category") },
                  placeholder = { Text("e.g. Beauty Parlour / Cloth Shop") },
                  textStyle = InputFieldStyles.textStyle,
                  colors = InputFieldStyles.colors(),
                  modifier = Modifier.weight(1.4f),
                  singleLine = true
                )
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Button(
                  onClick = {
                    val updated = BusinessProfile(
                      businessName = bName.ifBlank { "Arshad Traders" },
                      ownerName = bOwner.ifBlank { "Muhammad Arshad" },
                      phone = bPhone.ifBlank { "+92 300 1234567" },
                      address = bAddress.trim(),
                      tagline = bTagline.ifBlank { "Official Invoice" },
                      ntnNumber = bNtn,
                      shopType = bShopType.ifBlank { "General Store" },
                      logoEmoji = bLogoEmoji.ifBlank { "🏪" }
                    )
                    onSaveBusinessProfile(updated)
                    isEditingBusiness = false
                    Toast.makeText(context, "Business profile saved", Toast.LENGTH_SHORT).show()
                  },
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("Save Details")
                }

                OutlinedButton(
                  onClick = { isEditingBusiness = false },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("Cancel")
                }
              }
            }
          }
        } else {
          OutlinedButton(
            onClick = { isEditingBusiness = true },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(imageVector = Icons.Default.Store, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Customize Business & Shop Info")
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Currency Selector
        Text(
          text = "Preferred Currency",
          style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          ),
          modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          currencies.forEach { cur ->
            val isSelected = currentCurrency == cur
            Box(
              modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable { onCurrencySelected(cur) },
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = cur,
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Commercial / Pro Licensing Button
        FilledTonalButton(
          onClick = {
            onOpenUpgradePro()
          },
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFEF3C7)),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("open_pro_portal_button")
        ) {
          Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "⭐ Commercial & Monetization Portal", color = Color(0xFF92400E), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Clear Data Button
        OutlinedButton(
          onClick = { showResetConfirmation = true },
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = ExpenseRed),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(imageVector = Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Reset / Clear All Data")
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = onDismiss,
          colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Done")
        }
      }
    }
  }
}
