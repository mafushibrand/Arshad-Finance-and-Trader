package com.example.ui.dialogs

import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.example.data.model.AppLanguage

@Composable
fun AddAccountDialog(currencySymbol:String,onDismiss:()->Unit,onSave:(String,String,Double,String,Long)->Unit,appLanguage:AppLanguage=AppLanguage.ENGLISH) {
  val urdu=appLanguage==AppLanguage.URDU;fun t(en:String,ur:String)=if(urdu)ur else en
  var name by remember {mutableStateOf("")};var type by remember {mutableStateOf("Cash")};var balance by remember {mutableStateOf("0")};var number by remember {mutableStateOf("")};var error by remember {mutableStateOf("")}
  BusinessForm(t("Add cash / bank account","کیش / بینک اکاؤنٹ شامل کریں"),t("Save account","اکاؤنٹ محفوظ کریں"),onDismiss,{
    val amount=balance.toDoubleOrNull();if(name.isBlank()||amount==null||!amount.isFinite())error=t("Enter account name and valid opening balance","اکاؤنٹ نام اور درست ابتدائی رقم درج کریں") else onSave(name.trim(),type,amount,number.trim(),0xFF006C45)
  }) {
    BusinessField(name,t("Account name","اکاؤنٹ کا نام")){name=it}
    BusinessChoice(type,t("Account type","اکاؤنٹ قسم"),listOf("Cash","Bank","Mobile Wallet","Card","Other")){type=it}
    BusinessField(balance,t("Opening balance ($currencySymbol)","ابتدائی رقم ($currencySymbol)"),true){balance=it}
    BusinessField(number,t("Account / wallet number (optional)","اکاؤنٹ / والٹ نمبر (اختیاری)")){number=it}
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}
