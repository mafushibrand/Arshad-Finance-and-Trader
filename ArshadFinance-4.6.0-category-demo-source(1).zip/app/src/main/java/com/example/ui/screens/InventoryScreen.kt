package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.InventoryItem
import com.example.ui.FinanceUiState
import com.example.ui.dialogs.PerformanceHubDialog
import com.example.ui.theme.InputFieldStyles

@Composable
fun LegacyInventoryScreen(
  uiState: FinanceUiState,
  onAddItemClick: () -> Unit,
  onEditItemClick: (InventoryItem) -> Unit,
  onQuickAdjustClick: (InventoryItem) -> Unit,
  onDownloadStockClick: () -> Unit,
  onUploadStockClick: () -> Unit,
  onOpenIndustryCatalog: () -> Unit = {},
  onDeleteItem: (InventoryItem) -> Unit = {},
  onAddToCart: (InventoryItem) -> Unit = {},
  onUpdateCartQty: (Long, Double) -> Unit = { _, _ -> },
  onClearCart: () -> Unit = {},
  onGoToPos: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val currency = uiState.currencySymbol
  val isUrdu = uiState.appLanguage == AppLanguage.URDU
  val shopName = uiState.businessProfile.businessName.ifBlank { "ARSHAD FINANCE & TRADERS" }
  val shopLogo = uiState.businessProfile.logoEmoji.ifBlank { "🏪" }
  val inventoryItems = uiState.inventoryItems
  val cartItems = uiState.cartItems

  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("ALL") }
  var selectedStatusTab by remember { mutableStateOf("ALL") } // ALL, OUT OF STOCK, LOW STOCK, NEAR EXPIRY
  var showPerformanceHub by remember { mutableStateOf(false) }

  // Extract categories
  val categories = remember(inventoryItems) {
    val cats = inventoryItems.map { it.category }.distinct().toMutableList()
    listOf("ALL") + cats
  }

  // Filter items
  val filteredItems = remember(inventoryItems, searchQuery, selectedCategory, selectedStatusTab) {
    var list = inventoryItems
    if (selectedCategory != "ALL") {
      list = list.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }
    if (searchQuery.isNotBlank()) {
      list = list.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
            it.barcode.contains(searchQuery, ignoreCase = true) ||
            it.category.contains(searchQuery, ignoreCase = true)
      }
    }
    when (selectedStatusTab) {
      "OUT OF STOCK" -> list.filter { it.currentStock <= 0 }
      "LOW STOCK" -> list.filter { it.currentStock in 0.1..it.lowStockThreshold }
      "IN STOCK" -> list.filter { it.currentStock > it.lowStockThreshold }
      else -> list
    }
  }

  // Stock calculations
  val totalStockWorth = inventoryItems.sumOf { it.currentStock * it.salePrice }
  val lowStockCount = inventoryItems.count { it.currentStock <= it.lowStockThreshold }
  val totalCartQty = cartItems.values.sum().toInt()
  val totalCartAmount = cartItems.entries.sumOf { (itemId, qty) ->
    val item = inventoryItems.find { it.id == itemId }
    (item?.salePrice ?: 0.0) * qty
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFFF7F9F3))
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(bottom = if (totalCartQty > 0) 110.dp else 20.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // 1. Modern Colorful Gradient Hero Header
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(
              Brush.horizontalGradient(
                colors = listOf(
                  Color(0xFF0F172A), // Dark Navy
                  Color(0xFF006C45), // Royal Indigo
                  Color(0xFF13865F)  // Electric Sky Blue
                )
              )
            )
            .padding(horizontal = 16.dp, vertical = 18.dp)
        ) {
          Column {
            // Shop Bar
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                  shape = CircleShape,
                  color = Color.White,
                  shadowElevation = 4.dp,
                  modifier = Modifier.size(44.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text(text = shopLogo, fontSize = 24.sp)
                  }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text(
                    text = shopName,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                  )
                  Text(
                    text = if (isUrdu) "پروڈکٹس کیٹلاگ و اسٹاک مینجمنٹ" else "Products Catalog & Inventory",
                    fontSize = 11.sp,
                    color = Color(0xFFBAE6FD)
                  )
                }
              }

              // Cart indicator badge
              Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (totalCartQty > 0) Color(0xFF10B981) else Color.White.copy(alpha = 0.2f),
                modifier = Modifier
                  .clickable { if (totalCartQty > 0) onGoToPos() }
                  .testTag("inventory_cart_indicator")
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "$totalCartQty ${if (isUrdu) "آئٹم" else "Items"}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3 Colorful Stats Cards
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              // Total Items Card
              Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.White.copy(alpha = 0.15f),
                modifier = Modifier.weight(1f)
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text(
                    text = if (isUrdu) "کل پروڈکٹس" else "Total Items",
                    fontSize = 10.sp,
                    color = Color(0xFFE2E8F0)
                  )
                  Text(
                    text = "${inventoryItems.size}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                }
              }

              // Stock Worth Card
              Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.White.copy(alpha = 0.15f),
                modifier = Modifier.weight(1.3f)
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text(
                    text = if (isUrdu) "اسٹاک کی مالیت" else "Stock Value",
                    fontSize = 10.sp,
                    color = Color(0xFFE2E8F0)
                  )
                  Text(
                    text = "$currency ${"%,.0f".format(totalStockWorth)}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF6EE7B7) // Light Emerald
                  )
                }
              }

              // Low Stock Warning Card
              Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (lowStockCount > 0) Color(0xFFEF4444).copy(alpha = 0.35f) else Color.White.copy(alpha = 0.15f),
                modifier = Modifier.weight(1f)
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text(
                    text = if (isUrdu) "کم اسٹاک" else "Low Stock",
                    fontSize = 10.sp,
                    color = Color(0xFFE2E8F0)
                  )
                  Text(
                    text = "$lowStockCount",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (lowStockCount > 0) Color(0xFFFCA5A5) else Color.White
                  )
                }
              }
            }
          }
        }
      }

      // 2. MAIN CALL-TO-ACTION BUTTON: "+ ADD NEW PRODUCT" (نیا پروڈکٹ شامل کریں)
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = Color.Transparent),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
              Brush.horizontalGradient(
                colors = listOf(
                  Color(0xFF059669), // Vivid Emerald Green
                  Color(0xFF10B981), // Mint Emerald
                  Color(0xFF13865F)  // Cyan Blue
                )
              )
            )
            .clickable { onAddItemClick() }
            .testTag("btn_add_new_product_main")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = Color.White,
                modifier = Modifier.size(42.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = Color(0xFF059669),
                    modifier = Modifier.size(26.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.width(14.dp))
              Column {
                Text(
                  text = if (isUrdu) "+ نیا پروڈکٹ لگائیں (Add Product)" else "+ Add New Product",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = Color.White
                )
                Text(
                  text = if (isUrdu) "قیمت، بارکوڈ اور اسٹاک درج کریں" else "Set sale price, cost, barcode & stock",
                  fontSize = 11.sp,
                  color = Color.White.copy(alpha = 0.9f)
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color.White.copy(alpha = 0.25f)
            ) {
              Text(
                text = if (isUrdu) "نیا ➕" else "NEW ➕",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }
        }
      }

      // 3. Quick Utility Toolbar (Barcode, Bulk Catalog, Reports)
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Barcode Scanner button
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .weight(1f)
              .clickable {
                Toast.makeText(context, if (isUrdu) "بارکوڈ اسکینر کیمرہ فعال..." else "Barcode scanner ready...", Toast.LENGTH_SHORT).show()
              }
              .testTag("btn_barcode_scanner")
          ) {
            Row(
              modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, tint = Color(0xFF086B4D), modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = if (isUrdu) "اسکین" else "Scanner", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
            }
          }

          // Catalog Templates button
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .weight(1f)
              .clickable { onOpenIndustryCatalog() }
              .testTag("btn_industry_catalogs")
          ) {
            Row(
              modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              Icon(imageVector = Icons.Default.Storefront, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = if (isUrdu) "کیٹلاگ" else "Templates", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
            }
          }

          // Export/Download Stock CSV
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
              .weight(1f)
              .clickable { onDownloadStockClick() }
              .testTag("btn_download_stock")
          ) {
            Row(
              modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = if (isUrdu) "ایکسپورٹ" else "CSV", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
            }
          }
        }
      }

      // 4. Search Bar
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = "Search",
              tint = Color(0xFF64748B),
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            OutlinedTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it },
              placeholder = {
                Text(
                  text = if (isUrdu) "نام یا بارکوڈ سے سامان تلاش کریں..." else "Search products by name, barcode...",
                  fontSize = 13.sp,
                  color = Color(0xFF94A3B8)
                )
              },
              singleLine = true,
              colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent
              ),
              modifier = Modifier
                .weight(1f)
                .testTag("search_inventory_input")
            )
            if (searchQuery.isNotBlank()) {
              IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(28.dp)) {
                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFF94A3B8))
              }
            }
          }
        }
      }

      // 5. Category Chips Row (Horizontal Scroll)
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          categories.forEach { cat ->
            val isSelected = selectedCategory.equals(cat, ignoreCase = true)
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = if (isSelected) Color(0xFF086B4D) else Color.White,
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isSelected) Color(0xFF086B4D) else Color(0xFFE2E8F0)
              ),
              shadowElevation = if (isSelected) 2.dp else 0.dp,
              modifier = Modifier
                .clickable { selectedCategory = cat }
                .testTag("cat_chip_$cat")
            ) {
              Text(
                text = if (cat == "ALL" && isUrdu) "تمام کیٹگریز" else cat,
                fontSize = 11.5.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color(0xFF475569),
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
              )
            }
          }
        }
      }

      // 6. Stock Status Filter Tabs
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          listOf("ALL", "IN STOCK", "LOW STOCK", "OUT OF STOCK").forEach { status ->
            val isSelected = selectedStatusTab == status
            val count = when (status) {
              "OUT OF STOCK" -> inventoryItems.count { it.currentStock <= 0 }
              "LOW STOCK" -> inventoryItems.count { it.currentStock in 0.1..it.lowStockThreshold }
              "IN STOCK" -> inventoryItems.count { it.currentStock > it.lowStockThreshold }
              else -> inventoryItems.size
            }
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) Color(0xFF0F172A) else Color.White,
              border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) Color(0xFF0F172A) else Color(0xFFE2E8F0)),
              modifier = Modifier
                .weight(1f)
                .clickable { selectedStatusTab = status }
            ) {
              Column(
                modifier = Modifier.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(
                  text = when (status) {
                    "IN STOCK" -> if (isUrdu) "موجود" else "In Stock"
                    "LOW STOCK" -> if (isUrdu) "کم" else "Low"
                    "OUT OF STOCK" -> if (isUrdu) "ختم" else "Empty"
                    else -> if (isUrdu) "سب" else "All"
                  },
                  fontSize = 10.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else Color(0xFF475569)
                )
                Text(
                  text = "$count",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF64748B)
                )
              }
            }
          }
        }
      }

      // 7. Product Cards List with Direct "Add to Cart" and Stepper
      items(filteredItems) { product ->
        val qtyInCart = cartItems[product.id] ?: 0.0

        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .testTag("product_card_${product.id}")
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Avatar + Title + Price Badges + Edit/Delete
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
              ) {
                // Product Icon Avatar
                Box(
                  modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                      when {
                        product.category.contains("Drink", ignoreCase = true) -> Color(0xFFE0F2FE)
                        product.category.contains("Food", ignoreCase = true) -> Color(0xFFFEF3C7)
                        product.category.contains("Dairy", ignoreCase = true) -> Color(0xFFF3E8FF)
                        else -> Color(0xFFECFDF5)
                      }
                    ),
                  contentAlignment = Alignment.Center
                ) {
                  Text(text = product.icon.ifBlank { "📦" }, fontSize = 28.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                  Text(
                    text = product.name,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                  )

                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = Color(0xFFF7F9F3)
                    ) {
                      Text(
                        text = product.category,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF64748B),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }

                    if (product.barcode.isNotBlank()) {
                      Text(
                        text = "• #${product.barcode}",
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8)
                      )
                    }
                  }
                }
              }

              // Actions: Edit & Delete buttons
              Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Surface(
                  shape = CircleShape,
                  color = Color(0xFFFEF3C7),
                  modifier = Modifier
                    .size(32.dp)
                    .clickable { onEditItemClick(product) }
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = Color(0xFFD97706), modifier = Modifier.size(16.dp))
                  }
                }

                Surface(
                  shape = CircleShape,
                  color = Color(0xFFFEE2E2),
                  modifier = Modifier
                    .size(32.dp)
                    .clickable { onDeleteItem(product) }
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Middle Row: Price Badges
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              // Badges: Sale Price (Green) | Cost Price (Gray) | Stock (Blue/Red)
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // Sale Price Badge
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = Color(0xFFECFDF5),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0))
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(text = if (isUrdu) "فروخت: " else "Sale: ", fontSize = 10.sp, color = Color(0xFF065F46))
                    Text(
                      text = "$currency ${"%,.0f".format(product.salePrice)}",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.ExtraBold,
                      color = Color(0xFF047857)
                    )
                  }
                }

                // Cost Price Badge
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = Color(0xFFF5F7F2),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(text = if (isUrdu) "خرید: " else "Cost: ", fontSize = 10.sp, color = Color(0xFF64748B))
                    Text(
                      text = "${product.costPrice.toInt()}",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = Color(0xFF475569)
                    )
                  }
                }

                // Stock Badge
                val isOut = product.currentStock <= 0
                val isLow = product.currentStock in 0.1..product.lowStockThreshold
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = when {
                    isOut -> Color(0xFFFEE2E2)
                    isLow -> Color(0xFFFEF3C7)
                    else -> Color(0xFFE5F3EA)
                  }
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = "${if (isUrdu) "اسٹاک: " else "Stock: "}${product.currentStock.toInt()}",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = when {
                        isOut -> Color(0xFFDC2626)
                        isLow -> Color(0xFFD97706)
                        else -> Color(0xFF086B4D)
                      }
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom Section: DIRECT "ADD TO CART" & QUANTITY STEPPER
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (qtyInCart <= 0.0) {
                // "Add to Cart" Button (Vibrant & High Contrast)
                Button(
                  onClick = {
                    onAddToCart(product)
                    Toast.makeText(context, "${product.name} ${if (isUrdu) "کارٹ میں شامل کر دیا گیا" else "added to cart"}", Toast.LENGTH_SHORT).show()
                  },
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF086B4D)
                  ),
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .testTag("btn_add_to_cart_${product.id}")
                ) {
                  Icon(
                    imageVector = Icons.Default.AddShoppingCart,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = if (isUrdu) "کارٹ میں شامل کریں (Add to Cart)" else "Add to Cart 🛒",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              } else {
                // Interactive Stepper: [-] [ Qty: X in Cart ] [+]
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFE5F3EA))
                    .border(1.5.dp, Color(0xFF168765), RoundedCornerShape(12.dp))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  // Decrement / Remove button
                  Surface(
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 2.dp,
                    modifier = Modifier
                      .size(34.dp)
                      .clickable { onUpdateCartQty(product.id, qtyInCart - 1.0) }
                      .testTag("btn_cart_minus_${product.id}")
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "Decrease",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(18.dp)
                      )
                    }
                  }

                  // Quantity Display
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = "${qtyInCart.toInt()} ${if (isUrdu) "کارٹ میں موجود" else "in Cart"}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF006C45)
                      )
                    }
                    Text(
                      text = "= $currency ${"%,.0f".format(qtyInCart * product.salePrice)}",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = Color(0xFF059669)
                    )
                  }

                  // Increment button
                  Surface(
                    shape = CircleShape,
                    color = Color(0xFF086B4D),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                      .size(34.dp)
                      .clickable { onUpdateCartQty(product.id, qtyInCart + 1.0) }
                      .testTag("btn_cart_plus_${product.id}")
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Increase",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Empty State
      if (filteredItems.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp)
          ) {
            Column(
              modifier = Modifier.padding(28.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(text = "📦", fontSize = 42.sp)
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = if (isUrdu) "کوئی پروڈکٹ نہیں ملا" else "No Products Found",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF0F172A)
              )
              Text(
                text = if (isUrdu) "نیا سامان شامل کرنے کے لیے اوپر دیا گیا بٹن دبائیں" else "Tap '+ Add New Product' above to list your inventory",
                fontSize = 12.sp,
                color = Color(0xFF64748B)
              )
              Spacer(modifier = Modifier.height(14.dp))
              Button(
                onClick = onAddItemClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
              ) {
                Text(text = if (isUrdu) "+ پروڈکٹ شامل کریں" else "+ Add First Product")
              }
            }
          }
        }
      }
    }

    // 8. STICKY FLOATING CART SUMMARY BAR (When Cart has items)
    AnimatedVisibility(
      visible = totalCartQty > 0,
      enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
      exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF0F172A), // Dark Slate Navy
        shadowElevation = 10.dp,
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF38BDF8)),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("floating_cart_summary_bar")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Left: Cart items count & Total Amount
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = Color(0xFF086B4D),
              modifier = Modifier.size(40.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.ShoppingCart,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(20.dp)
                )
              }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
              Text(
                text = "$totalCartQty ${if (isUrdu) "آئٹمز کارٹ میں" else "Items in Cart"}",
                fontSize = 11.5.sp,
                color = Color(0xFF94A3B8)
              )
              Text(
                text = "$currency ${"%,.0f".format(totalCartAmount)}",
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF4ADE80) // Bright Green
              )
            }
          }

          // Right: Clear + Proceed to Checkout in POS
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = CircleShape,
              color = Color.White.copy(alpha = 0.15f),
              modifier = Modifier
                .size(34.dp)
                .clickable { onClearCart() }
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
              }
            }

            Button(
              onClick = onGoToPos,
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF10B981)
              ),
              modifier = Modifier.testTag("btn_proceed_to_pos")
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = if (isUrdu) "بل بنائیں" else "Checkout",
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                  imageVector = Icons.Default.ArrowForward,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          }
        }
      }
    }
  }

  // Performance Hub Dialog
  if (showPerformanceHub) {
    PerformanceHubDialog(
      inventoryItems = inventoryItems,
      invoices = uiState.invoices,
      currencySymbol = currency,
      onDismiss = { showPerformanceHub = false }
    )
  }
}
