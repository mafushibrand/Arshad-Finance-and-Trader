package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AppLanguage
import com.example.data.model.ServiceItem
import com.example.data.model.ShopBioData
import com.example.ui.FinanceUiState

@Composable
fun LegacyServicesScreen(
  uiState: FinanceUiState,
  onAddOrUpdateService: (ServiceItem) -> Unit,
  onDeleteService: (Long) -> Unit,
  onToggleServiceDiscount: (Long, Boolean, Double?) -> Unit,
  onToggleFeaturedService: (Long) -> Unit,
  onSelectServiceCategory: (String) -> Unit,
  onUpdateShopBioData: (ShopBioData) -> Unit,
  onAddServiceToCart: (ServiceItem) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val isUrdu = uiState.appLanguage == AppLanguage.URDU
  val currency = uiState.currencySymbol

  var searchQuery by remember { mutableStateOf("") }
  var showAddEditDialog by remember { mutableStateOf(false) }
  var editingItem by remember { mutableStateOf<ServiceItem?>(null) }
  var showBioDialog by remember { mutableStateOf(false) }
  var instantSlipService by remember { mutableStateOf<ServiceItem?>(null) }

  // Filter services by category and search
  val allServices = uiState.services
  val filteredServices = allServices.filter { item ->
    val matchesCategory = uiState.selectedServiceCategory == "ALL" ||
      item.businessCategory.equals(uiState.selectedServiceCategory, ignoreCase = true)
    val matchesQuery = searchQuery.isBlank() ||
      item.name.contains(searchQuery, ignoreCase = true) ||
      item.urduName.contains(searchQuery, ignoreCase = true) ||
      item.serviceType.contains(searchQuery, ignoreCase = true)
    matchesCategory && matchesQuery
  }

  // 3 Primary/Featured Services
  val featuredServices = allServices.filter {
    uiState.selectedFeaturedServiceIds.contains(it.id) || it.isFeatured
  }.take(3)

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFFF5F7F2))
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Top Lavish Header
      item {
        Spacer(modifier = Modifier.height(10.dp))
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = Color.White,
          shadowElevation = 4.dp,
          modifier = Modifier.fillMaxWidth()
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(
                Brush.horizontalGradient(
                  colors = listOf(
                    Color(0xFF0F172A),
                    Color(0xFF006C45),
                    Color(0xFF13865F)
                  )
                )
              )
              .padding(18.dp)
          ) {
            Column {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.size(44.dp)
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Text("🛠️", fontSize = 22.sp)
                    }
                  }
                  Spacer(modifier = Modifier.width(12.dp))
                  Column {
                    Text(
                      text = if (isUrdu) "کاروبار سروسز و پیکیجز" else "Business Services & Rates",
                      fontSize = 18.sp,
                      fontWeight = FontWeight.ExtraBold,
                      color = Color.White
                    )
                    Text(
                      text = if (isUrdu) "تمام دکانوں، سیلون، جم، ریپئرنگ اور فاسٹ فوڈ کیلئے" else "Universal All-Shop Service Catalog & Booking",
                      fontSize = 11.5.sp,
                      color = Color(0xFFBAE6FD)
                    )
                  }
                }

                IconButton(
                  onClick = { showBioDialog = true },
                  modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.2f))
                    .size(38.dp)
                    .testTag("btn_open_shop_bio")
                ) {
                  Icon(Icons.Default.Storefront, contentDescription = "Shop Bio", tint = Color.White)
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Shop Bio summary bar
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.White.copy(alpha = 0.15f),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = uiState.shopBioData.shopName,
                      fontSize = 12.5.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                    Text(
                      text = "${uiState.shopBioData.ownerName} • 📞 ${uiState.shopBioData.phone}",
                      fontSize = 10.5.sp,
                      color = Color(0xFFE2E8F0)
                    )
                  }
                  OutlinedButton(
                    onClick = { showBioDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.height(30.dp)
                  ) {
                    Text(text = if (isUrdu) "بائیو تبدیل کریں" else "Edit Bio", fontSize = 10.5.sp)
                  }
                }
              }
            }
          }
        }
      }

      // 2. Search & Add Service Button
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = {
              Text(
                text = if (isUrdu) "سروس، کام یا پیکیج تلاش کریں..." else "Search services or packages...",
                fontSize = 12.5.sp,
                color = Color(0xFF94A3B8)
              )
            },
            leadingIcon = {
              Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF086B4D))
            },
            shape = RoundedCornerShape(14.dp),
            singleLine = true,
            modifier = Modifier
              .weight(1f)
              .testTag("search_services_input")
          )

          Spacer(modifier = Modifier.width(8.dp))

          Button(
            onClick = {
              editingItem = null
              showAddEditDialog = true
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
            modifier = Modifier
              .height(52.dp)
              .testTag("btn_add_new_service")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isUrdu) "نئی سروس" else "+ Service",
                fontWeight = FontWeight.Bold,
                fontSize = 12.5.sp
              )
            }
          }
        }
      }

      // 3. Category Selector Carousel (Choose your business)
      item {
        val categories = listOf(
          "ALL" to (if (isUrdu) "🌟 تمام سروسز" else "🌟 All Services"),
          "SALON" to (if (isUrdu) "💇 سیلون و پارلر" else "💇 Salon & Parlour"),
          "GYM" to (if (isUrdu) "🏋️ جم و فٹنس" else "🏋️ Gym & Fitness"),
          "MOBILE_REPAIR" to (if (isUrdu) "📱 موبائل ریپئر" else "📱 Mobile Repair"),
          "LAPTOP_REPAIR" to (if (isUrdu) "💻 لیپ ٹاپ شاپ" else "💻 Laptop Repair"),
          "CAR_SHOWROOM" to (if (isUrdu) "🚗 گاڑی شو روم" else "🚗 Auto Showroom"),
          "TAILOR" to (if (isUrdu) "🧵 درزی و کپڑا" else "🧵 Tailor & Garments"),
          "FAST_FOOD" to (if (isUrdu) "🍔 فاسٹ فوڈ و پیزا" else "🍔 Fast Food"),
          "ELECTRONICS" to (if (isUrdu) "❄️ اے سی و الیکٹرک" else "❄️ AC & Electric"),
          "CROCKERY" to (if (isUrdu) "🍽️ کراکری و رینٹل" else "🍽️ Crockery Rental")
        )

        Column {
          Text(
            text = if (isUrdu) "کاروبار کے لحاظ سے سروسز منتخب کریں:" else "Filter By Business Type:",
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155),
            modifier = Modifier.padding(bottom = 6.dp)
          )

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            categories.forEach { (catId, catLabel) ->
              val isSelected = uiState.selectedServiceCategory == catId
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) Color(0xFF086B4D) else Color.White,
                border = androidx.compose.foundation.BorderStroke(
                  1.dp,
                  if (isSelected) Color(0xFF086B4D) else Color(0xFFE2E8F0)
                ),
                shadowElevation = if (isSelected) 3.dp else 1.dp,
                modifier = Modifier
                  .clickable { onSelectServiceCategory(catId) }
                  .testTag("cat_pill_$catId")
              ) {
                Text(
                  text = catLabel,
                  fontSize = 12.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else Color(0xFF334155),
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
              }
            }
          }
        }
      }

      // 4. ⭐ Featured 3 Primary Services Card (User Requirement: 3 services select honi chahye)
      item {
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⭐", fontSize = 18.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isUrdu) "آپ کے کاروبار کی 3 منتخب بنیادی سروسز:" else "Selected 3 Primary Services:",
                  fontSize = 13.5.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF92400E)
                )
              }
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xFFD97706)
              ) {
                Text(
                  text = "${featuredServices.size}/3",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Text(
              text = if (isUrdu)
                "کسی بھی سروس کارڈ پر ستارہ (⭐) دبا کر اسے اپنے کاروبار کی اہم 3 سروسز میں شامل کریں"
              else
                "Tap star (⭐) on any service to pin as your business's 3 primary quick services",
              fontSize = 10.5.sp,
              color = Color(0xFFB45309),
              modifier = Modifier.padding(vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (featuredServices.isEmpty()) {
              Text(
                text = if (isUrdu) "کوئی بنیادی سروس منتخب نہیں کی گئی" else "No primary service pinned yet",
                fontSize = 11.5.sp,
                color = Color(0xFF78350F),
                modifier = Modifier.padding(vertical = 8.dp)
              )
            } else {
              Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                featuredServices.forEach { feat ->
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Text(feat.icon, fontSize = 22.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                          Text(
                            text = if (isUrdu && feat.urduName.isNotBlank()) feat.urduName else feat.name,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                          )
                          Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                              text = "$currency ${feat.effectivePrice.toInt()}",
                              fontSize = 12.sp,
                              fontWeight = FontWeight.ExtraBold,
                              color = Color(0xFF059669)
                            )
                            if (feat.isDiscountActive && feat.discountSaved > 0) {
                              Spacer(modifier = Modifier.width(6.dp))
                              Text(
                                text = "$currency ${feat.price.toInt()}",
                                fontSize = 10.5.sp,
                                color = Color(0xFF94A3B8),
                                textDecoration = TextDecoration.LineThrough
                              )
                            }
                          }
                        }
                      }

                      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        // 1-Tap Add to Bill
                        Button(
                          onClick = {
                            onAddServiceToCart(feat)
                            Toast.makeText(
                              context,
                              if (isUrdu) "${feat.urduName} کاؤنٹر بل میں شامل کر دی گئی ✓" else "${feat.name} added to POS Bill ✓",
                              Toast.LENGTH_SHORT
                            ).show()
                          },
                          shape = RoundedCornerShape(8.dp),
                          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D)),
                          modifier = Modifier.height(32.dp)
                        ) {
                          Text(
                            text = if (isUrdu) "بل میں شامل" else "+ Cart",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                          )
                        }

                        // Instant Receipt Slip
                        OutlinedButton(
                          onClick = { instantSlipService = feat },
                          shape = RoundedCornerShape(8.dp),
                          modifier = Modifier.height(32.dp)
                        ) {
                          Text(
                            text = if (isUrdu) "فوری رسید" else "Slip",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD97706)
                          )
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // 5. Section Title: All Services
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isUrdu) "تمام سروسز و پیکیجز لسٹ (${filteredServices.size}):" else "Services List (${filteredServices.size}):",
            fontSize = 13.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1E293B)
          )
          Text(
            text = if (isUrdu) "ڈسکاؤنٹ، اسٹاک و بکنگ فعال" else "Discount, Stock & POS Active",
            fontSize = 10.5.sp,
            color = Color(0xFF64748B)
          )
        }
      }

      // 6. Interactive Services List
      if (filteredServices.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text("🔍", fontSize = 36.sp)
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = if (isUrdu) "کوئی سروس نہیں ملی" else "No matching services found",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF334155)
              )
              Text(
                text = if (isUrdu) "اوپر دیے گئے بٹن سے نئی سروس شامل کریں" else "Use '+ Service' button above to add custom services",
                fontSize = 11.5.sp,
                color = Color(0xFF64748B)
              )
            }
          }
        }
      } else {
        items(filteredServices, key = { it.id }) { service ->
          ServiceCardItem(
            service = service,
            currency = currency,
            isUrdu = isUrdu,
            isFeatured = uiState.selectedFeaturedServiceIds.contains(service.id) || service.isFeatured,
            onToggleFeatured = { onToggleFeaturedService(service.id) },
            onToggleDiscount = { isActive ->
              onToggleServiceDiscount(service.id, isActive, null)
            },
            onAddToCart = {
              onAddServiceToCart(service)
              Toast.makeText(
                context,
                if (isUrdu) "${service.urduName.ifBlank { service.name }} بل میں شامل کر دی گئی ✓" else "${service.name} added to cart ✓",
                Toast.LENGTH_SHORT
              ).show()
            },
            onInstantSlip = { instantSlipService = service },
            onEdit = {
              editingItem = service
              showAddEditDialog = true
            },
            onDelete = { onDeleteService(service.id) }
          )
        }
      }

      item {
        Spacer(modifier = Modifier.height(80.dp))
      }
    }

    // Add / Edit Service Dialog
    if (showAddEditDialog) {
      AddEditServiceDialog(
        service = editingItem,
        isUrdu = isUrdu,
        currency = currency,
        onDismiss = { showAddEditDialog = false },
        onSave = { updated ->
          onAddOrUpdateService(updated)
          showAddEditDialog = false
          Toast.makeText(
            context,
            if (isUrdu) "سروس کامیابی سے محفوظ کر لی گئی ✓" else "Service saved successfully ✓",
            Toast.LENGTH_SHORT
          ).show()
        }
      )
    }

    // Shop Bio Data Dialog
    if (showBioDialog) {
      ShopBioDataDialog(
        bioData = uiState.shopBioData,
        isUrdu = isUrdu,
        onDismiss = { showBioDialog = false },
        onSave = { updated ->
          onUpdateShopBioData(updated)
          showBioDialog = false
          Toast.makeText(
            context,
            if (isUrdu) "شاپ بائیو ڈیٹا اپ ڈیٹ ہو گیا ✓" else "Shop bio updated ✓",
            Toast.LENGTH_SHORT
          ).show()
        }
      )
    }

    // Instant Slip Modal
    instantSlipService?.let { item ->
      InstantServiceSlipDialog(
        service = item,
        bioData = uiState.shopBioData,
        currency = currency,
        isUrdu = isUrdu,
        onDismiss = { instantSlipService = null }
      )
    }
  }
}

@Composable
fun ServiceCardItem(
  service: ServiceItem,
  currency: String,
  isUrdu: Boolean,
  isFeatured: Boolean,
  onToggleFeatured: () -> Unit,
  onToggleDiscount: (Boolean) -> Unit,
  onAddToCart: () -> Unit,
  onInstantSlip: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("service_card_${service.id}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Row 1: Title, Category badge, Star pin
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = CircleShape,
            color = Color(0xFFF7F9F3),
            modifier = Modifier.size(42.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(service.icon, fontSize = 22.sp)
            }
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = if (isUrdu && service.urduName.isNotBlank()) service.urduName else service.name,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
            Text(
              text = service.serviceType,
              fontSize = 11.sp,
              color = Color(0xFF64748B),
              fontWeight = FontWeight.Medium
            )
          }
        }

        // Star Toggle (Primary 3 Services)
        IconButton(
          onClick = onToggleFeatured,
          modifier = Modifier.size(34.dp)
        ) {
          Icon(
            imageVector = if (isFeatured) Icons.Default.Star else Icons.Outlined.StarOutline,
            contentDescription = "Pin Primary Service",
            tint = if (isFeatured) Color(0xFFF59E0B) else Color(0xFF94A3B8)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Row 2: Price, Discount Switch & Calculation, Quantity & Unit
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Price breakdown
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "$currency ${service.effectivePrice.toInt()}",
              fontSize = 16.sp,
              fontWeight = FontWeight.ExtraBold,
              color = if (service.isDiscountActive) Color(0xFF059669) else Color(0xFF086B4D)
            )

            if (service.isDiscountActive && service.discountSaved > 0) {
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "$currency ${service.price.toInt()}",
                fontSize = 11.5.sp,
                color = Color(0xFF94A3B8),
                textDecoration = TextDecoration.LineThrough
              )
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color(0xFFDCFCE7)
              ) {
                Text(
                  text = if (isUrdu) "بچت: $currency ${service.discountSaved.toInt()}" else "-$currency ${service.discountSaved.toInt()} OFF",
                  fontSize = 9.5.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF15803D),
                  modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
              }
            }
          }

          // Quantity / Stock / Unit
          Text(
            text = if (isUrdu)
              "تعداد/سیشن: ${service.quantity.toInt()} ${service.unit} • اسٹاک/سلاٹ: ${service.stockOrSlots.toInt()}"
            else
              "Qty: ${service.quantity.toInt()} ${service.unit} • Slots/Stock: ${service.stockOrSlots.toInt()}",
            fontSize = 10.5.sp,
            color = Color(0xFF64748B),
            modifier = Modifier.padding(top = 2.dp)
          )
        }

        // Discount ON/OFF Switch
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = if (isUrdu) "ڈسکاؤنٹ:" else "Discount:",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF334155)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Switch(
            checked = service.isDiscountActive,
            onCheckedChange = { onToggleDiscount(it) },
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color.White,
              checkedTrackColor = Color(0xFF059669),
              uncheckedThumbColor = Color(0xFFCBD5E1),
              uncheckedTrackColor = Color(0xFFF7F9F3)
            ),
            modifier = Modifier.size(36.dp)
          )
        }
      }

      if (service.description.isNotBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "📝 ${service.description}",
          fontSize = 11.sp,
          color = Color(0xFF475569)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider(thickness = 0.5.dp, color = Color(0xFFE2E8F0))
      Spacer(modifier = Modifier.height(8.dp))

      // Row 3: Action Buttons (Add to POS Bill, Instant Slip, Edit, Delete)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          // Add to POS Cart
          Button(
            onClick = onAddToCart,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D)),
            modifier = Modifier.height(36.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isUrdu) "بل میں شامل" else "Add to POS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          // Instant Slip
          OutlinedButton(
            onClick = onInstantSlip,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.height(36.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Receipt, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(15.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isUrdu) "فوری رسید" else "Slip",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFD97706)
              )
            }
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
          }
        }
      }
    }
  }
}

@Composable
fun LegacyAddEditServiceDialog(
  service: ServiceItem?,
  isUrdu: Boolean,
  currency: String,
  onDismiss: () -> Unit,
  onSave: (ServiceItem) -> Unit
) {
  var name by remember { mutableStateOf(service?.name ?: "") }
  var urduName by remember { mutableStateOf(service?.urduName ?: "") }
  var businessCategory by remember { mutableStateOf(service?.businessCategory ?: "SALON") }
  var serviceType by remember { mutableStateOf(service?.serviceType ?: "") }
  var priceStr by remember { mutableStateOf(service?.price?.toInt()?.toString() ?: "1000") }
  var isDiscountActive by remember { mutableStateOf(service?.isDiscountActive ?: false) }
  var discountPriceStr by remember { mutableStateOf(service?.discountPrice?.toInt()?.toString() ?: "800") }
  var quantityStr by remember { mutableStateOf(service?.quantity?.toInt()?.toString() ?: "1") }
  var unit by remember { mutableStateOf(service?.unit ?: "Session (سیشن)") }
  var stockSlotsStr by remember { mutableStateOf(service?.stockOrSlots?.toInt()?.toString() ?: "50") }
  var icon by remember { mutableStateOf(service?.icon ?: "🛠️") }
  var description by remember { mutableStateOf(service?.description ?: "") }

  val unitPresets = listOf(
    "Session (سیشن)",
    "Hour (گھنٹہ)",
    "Day (دن)",
    "Job / Work (جاب)",
    "Piece (عدد)",
    "Suit (سوٹ)",
    "Vehicle (گاڑی)",
    "Deal (ڈیل)",
    "Month (ماہانہ)",
    "Kg (کلوگرام)"
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(20.dp)),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      val scrollState = rememberScrollState()
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(scrollState)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (service == null) {
              if (isUrdu) "➕ نئی سروس یا پیکیج شامل کریں" else "➕ Add New Business Service"
            } else {
              if (isUrdu) "✏️ سروس تبدیل کریں" else "✏️ Edit Service"
            },
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Service Name (English & Urdu)
        Text(
          text = if (isUrdu) "سروس کا نام (اردو یا انگلش):" else "Service Name:",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF334155)
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = urduName,
          onValueChange = { urduName = it },
          placeholder = { Text(if (isUrdu) "مثلاً: اسپیشل ہیئر کٹنگ، اسکرین چینج، جم فیس" else "e.g. Hair Cut, Screen Repair, Gym Fee") },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Business Category
        Text(
          text = if (isUrdu) "کاروبار کی قسم (Business Category):" else "Business Category:",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF334155)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          listOf(
            "SALON" to "💇 سیلون",
            "GYM" to "🏋️ جم",
            "MOBILE_REPAIR" to "📱 موبائل",
            "LAPTOP_REPAIR" to "💻 لیپ ٹاپ",
            "CAR_SHOWROOM" to "🚗 گاڑی",
            "TAILOR" to "🧵 درزی",
            "FAST_FOOD" to "🍔 فاسٹ فوڈ",
            "ELECTRONICS" to "❄️ الیکٹرانکس",
            "CROCKERY" to "🍽️ کراکری",
            "GENERAL" to "🛠️ جنرل"
          ).forEach { (id, label) ->
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (businessCategory == id) Color(0xFF086B4D) else Color(0xFFF7F9F3),
              modifier = Modifier.clickable { businessCategory = id }
            ) {
              Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (businessCategory == id) Color.White else Color(0xFF334155),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Service Type / Sub-category
        Text(
          text = if (isUrdu) "سروس کی قسم یا اسپیشلٹی:" else "Service Specialty / Type:",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF334155)
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = serviceType,
          onValueChange = { serviceType = it },
          placeholder = { Text(if (isUrdu) "مثلاً: کٹنگ، فیشل، ممبرشپ، ٹیوننگ، سلائی" else "e.g. Haircut, Tuning, Stitching") },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Price & Discount Switch
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (isUrdu) "اصل قیمت ($currency):" else "Regular Price ($currency):",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = priceStr,
              onValueChange = { priceStr = it },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          // Discount Switch
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = if (isUrdu) "ڈسکاؤنٹ آن/آف" else "Discount ON/OFF",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF334155)
            )
            Switch(
              checked = isDiscountActive,
              onCheckedChange = { isDiscountActive = it },
              colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF059669)
              )
            )
          }
        }

        // Discounted Price (Visible if Discount is ON)
        AnimatedVisibility(visible = isDiscountActive) {
          Column(modifier = Modifier.padding(top = 10.dp)) {
            Text(
              text = if (isUrdu) "رعایتی / ڈسکاؤنٹ قیمت ($currency):" else "Discounted Price ($currency):",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF059669)
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = discountPriceStr,
              onValueChange = { discountPriceStr = it },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quantity, Stock and Unit
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (isUrdu) "تعداد/کوانٹٹی:" else "Quantity:",
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = quantityStr,
              onValueChange = { quantityStr = it },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            )
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (isUrdu) "اسٹاک / سلاٹ:" else "Stock / Slots:",
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = stockSlotsStr,
              onValueChange = { stockSlotsStr = it },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Unit selector chips
        Text(
          text = if (isUrdu) "یونٹ منتخب کریں:" else "Select Unit:",
          fontSize = 11.5.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          unitPresets.forEach { u ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (unit == u) Color(0xFF086B4D) else Color(0xFFF7F9F3),
              modifier = Modifier.clickable { unit = u }
            ) {
              Text(
                text = u,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (unit == u) Color.White else Color(0xFF334155),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Description / Bio note
        Text(
          text = if (isUrdu) "تفصیل، ہدایات یا وارنٹی:" else "Description / Notes:",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          placeholder = { Text(if (isUrdu) "سروس کی تفصیل، وارنٹی و ہدایات درج کریں..." else "Enter service details...") },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth(),
          maxLines = 2
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Save Button
        Button(
          onClick = {
            val regPrice = priceStr.toDoubleOrNull() ?: 1000.0
            val discPrice = discountPriceStr.toDoubleOrNull() ?: (regPrice * 0.8)
            val qty = quantityStr.toDoubleOrNull() ?: 1.0
            val stock = stockSlotsStr.toDoubleOrNull() ?: 50.0

            val itemToSave = ServiceItem(
              id = service?.id ?: System.currentTimeMillis(),
              name = if (name.isBlank()) urduName else name,
              urduName = if (urduName.isBlank()) name else urduName,
              businessCategory = businessCategory,
              serviceType = serviceType.ifBlank { "General Service" },
              price = regPrice,
              isDiscountActive = isDiscountActive,
              discountPrice = discPrice,
              quantity = qty,
              unit = unit,
              stockOrSlots = stock,
              icon = icon,
              description = description,
              isFeatured = service?.isFeatured ?: false
            )
            onSave(itemToSave)
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D)),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
        ) {
          Text(
            text = if (isUrdu) "سروس محفوظ کریں ✓" else "Save Service ✓",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }
      }
    }
  }
}

@Composable
fun ShopBioDataDialog(
  bioData: ShopBioData,
  isUrdu: Boolean,
  onDismiss: () -> Unit,
  onSave: (ShopBioData) -> Unit
) {
  var shopName by remember { mutableStateOf(bioData.shopName) }
  var ownerName by remember { mutableStateOf(bioData.ownerName) }
  var phone by remember { mutableStateOf(bioData.phone) }
  var email by remember { mutableStateOf(bioData.email) }
  var address by remember { mutableStateOf(bioData.address) }
  var city by remember { mutableStateOf(bioData.city) }
  var openingHours by remember { mutableStateOf(bioData.openingHours) }
  var bioDescription by remember { mutableStateOf(bioData.bioDescription) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(20.dp)),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      val scrollState = rememberScrollState()
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(scrollState)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isUrdu) "🏪 شاپ بائیو ڈیٹا و پروفائل" else "🏪 Shop Bio Data & Profile",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Shop Name
        Text(text = if (isUrdu) "دکان یا کاروبار کا نام:" else "Shop / Business Name:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = shopName,
          onValueChange = { shopName = it },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Owner Name & Phone
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(text = if (isUrdu) "مالک کا نام:" else "Owner Name:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = ownerName,
              onValueChange = { ownerName = it },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(text = if (isUrdu) "موبائل فون نمبر:" else "Phone Number:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = phone,
              onValueChange = { phone = it },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Address & City
        Text(text = if (isUrdu) "دکان کا مکمل پتہ و شہر:" else "Address & City:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Timings
        Text(text = if (isUrdu) "اوقات کار (Opening Timings):" else "Opening Hours:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = openingHours,
          onValueChange = { openingHours = it },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Bio Description
        Text(text = if (isUrdu) "کاروبار کا تعارف و بائیو ڈیٹا:" else "Business Bio & Description:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = bioDescription,
          onValueChange = { bioDescription = it },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth(),
          maxLines = 3
        )

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = {
            onSave(
              bioData.copy(
                shopName = shopName,
                ownerName = ownerName,
                phone = phone,
                email = email,
                address = address,
                city = city,
                openingHours = openingHours,
                bioDescription = bioDescription
              )
            )
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D)),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
        ) {
          Text(text = if (isUrdu) "بائیو محفوظ کریں ✓" else "Save Bio Data ✓", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
      }
    }
  }
}

@Composable
fun InstantServiceSlipDialog(
  service: ServiceItem,
  bioData: ShopBioData,
  currency: String,
  isUrdu: Boolean,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  var isPaid by remember { mutableStateOf(true) }
  var customerName by remember { mutableStateOf("واک ان کسٹمر") }
  var customerPhone by remember { mutableStateOf("") }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .clip(RoundedCornerShape(20.dp)),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      val scrollState = rememberScrollState()
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Receipt Header
        Text(
          text = bioData.shopName,
          fontSize = 17.sp,
          fontWeight = FontWeight.ExtraBold,
          color = Color(0xFF0F172A),
          textAlign = TextAlign.Center
        )
        Text(
          text = "${bioData.address} • 📞 ${bioData.phone}",
          fontSize = 10.5.sp,
          color = Color(0xFF64748B),
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(thickness = 1.dp, color = Color(0xFFCBD5E1))
        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = if (isUrdu) "🧾 سروس رسید / سروس واؤچر" else "🧾 SERVICE INVOICE / SLIP",
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF006C45)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Service Details Box
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFF5F7F2),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = if (isUrdu && service.urduName.isNotBlank()) service.urduName else service.name,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color(0xFF0F172A)
              )
              Text(
                text = "$currency ${service.effectivePrice.toInt()}",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp,
                color = Color(0xFF086B4D)
              )
            }
            Text(
              text = "Category: ${service.businessCategory} • Type: ${service.serviceType}",
              fontSize = 10.5.sp,
              color = Color(0xFF64748B)
            )

            if (service.isDiscountActive && service.discountSaved > 0) {
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = if (isUrdu)
                  "اصل ریٹ: $currency ${service.price.toInt()} (رعایت بچت: $currency ${service.discountSaved.toInt()})"
                else
                  "Regular: $currency ${service.price.toInt()} (Saved: $currency ${service.discountSaved.toInt()})",
                fontSize = 11.sp,
                color = Color(0xFF15803D),
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Payment status toggle: PAID vs UDHAAR
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isPaid) Color(0xFF10B981) else Color(0xFFF7F9F3),
            modifier = Modifier
              .clickable { isPaid = true }
              .padding(4.dp)
          ) {
            Text(
              text = if (isUrdu) "✅ ادا شدہ (PAID)" else "✅ PAID",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = if (isPaid) Color.White else Color(0xFF64748B),
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
            )
          }

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (!isPaid) Color(0xFFDC2626) else Color(0xFFF7F9F3),
            modifier = Modifier
              .clickable { isPaid = false }
              .padding(4.dp)
          ) {
            Text(
              text = if (isUrdu) "⚠️ ادھار (UDHAAR)" else "⚠️ UDHAAR",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = if (!isPaid) Color.White else Color(0xFF64748B),
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Stamp Box
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (isPaid) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
          border = androidx.compose.foundation.BorderStroke(2.dp, if (isPaid) Color(0xFF16A34A) else Color(0xFFDC2626)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = if (isPaid) "【 ✅ PAID / ادا شدہ رسید 】" else "【 ⚠️ UDHAAR / ادھار کھاتہ 】",
              fontSize = 14.sp,
              fontWeight = FontWeight.ExtraBold,
              color = if (isPaid) Color(0xFF16A34A) else Color(0xFFDC2626)
            )
            Text(
              text = if (isPaid) "مکمل وصول شدہ • ALL DUES CLEARED" else "بقایا واجب الادا: $currency ${service.effectivePrice.toInt()}",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = if (isPaid) Color(0xFF15803D) else Color(0xFFB91C1C)
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Action Buttons: Share on WhatsApp & Close
        Button(
          onClick = {
            val stampText = if (isPaid) "✅ [ PAID / ادا شدہ ]" else "⚠️ [ UDHAAR / ادھار ]"
            val textToShare = """
              🧾 *${bioData.shopName}*
              📍 ${bioData.address}
              📞 ${bioData.phone}
              ━━━━━━━━━━━━━━━━━━━━
              📄 *SERVICE INVOICE / رسید*
              🛠️ *سروس:* ${if (isUrdu && service.urduName.isNotBlank()) service.urduName else service.name}
              💰 *ٹوٹل رقم:* $currency ${service.effectivePrice.toInt()}
              ━━━━━━━━━━━━━━━━━━━━
              $stampText
              ━━━━━━━━━━━━━━━━━━━━
              شکریہ! ارشد فنانس و سروسز
            """.trimIndent()

            val sendIntent = android.content.Intent().apply {
              action = android.content.Intent.ACTION_SEND
              putExtra(android.content.Intent.EXTRA_TEXT, textToShare)
              type = "text/plain"
            }
            try {
              context.startActivity(android.content.Intent.createChooser(sendIntent, "Share Receipt Via WhatsApp"))
            } catch (e: Exception) {
              Toast.makeText(context, "Could not share: ${e.message}", Toast.LENGTH_SHORT).show()
            }
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Share, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isUrdu) "واٹس ایپ پر رسید بھیجیں" else "Share Slip on WhatsApp",
              fontWeight = FontWeight.Bold,
              fontSize = 13.5.sp,
              color = Color.White
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(
          onClick = onDismiss,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().height(42.dp)
        ) {
          Text(text = if (isUrdu) "بند کریں" else "Close", fontSize = 12.sp)
        }
      }
    }
  }
}
