package com.example.ui.dialogs

import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.example.data.model.AppLanguage
import com.example.util.BusinessProfile

@Composable
fun ShopProfileDialog(currentProfile: BusinessProfile,onSaveProfile: (BusinessProfile) -> Unit,onDismiss: () -> Unit,appLanguage: AppLanguage=AppLanguage.ENGLISH) {
  val urdu=appLanguage==AppLanguage.URDU;fun t(en:String,ur:String)=if(urdu)ur else en
  var profile by remember {mutableStateOf(currentProfile)};var error by remember {mutableStateOf("")};var advanced by remember {mutableStateOf(false)}
  if(advanced){LegacyShopProfileDialog(currentProfile,onSaveProfile,onDismiss);return}
  BusinessForm(t("Business profile","کاروبار کی تفصیل"),t("Save profile","تفصیل محفوظ کریں"),onDismiss,{
    if(profile.businessName.isBlank()||profile.invoicePrefix.isBlank()||!profile.fbrTaxRatePercent.isFinite()||profile.fbrTaxRatePercent<0)error=t("Enter a business name, invoice prefix and valid tax rate","کاروبار کا نام، بل حوالہ اور درست ٹیکس شرح درج کریں")
    else {onSaveProfile(profile);onDismiss()}
  }) {
    BusinessField(profile.businessName,t("Business name","کاروبار کا نام")){profile=profile.copy(businessName=it)}
    BusinessField(profile.ownerName,t("Owner name","مالک کا نام")){profile=profile.copy(ownerName=it)}
    BusinessField(profile.phone,t("Phone","فون")){profile=profile.copy(phone=it)}
    BusinessField(profile.address,t("Address / city / country","پتہ / شہر / ملک")){profile=profile.copy(address=it)}
    BusinessField(profile.shopType,t("Business type","کاروبار کی قسم")){profile=profile.copy(shopType=it)}
    BusinessField(profile.tagline,t("Tagline","کاروباری تعارف")){profile=profile.copy(tagline=it)}
    BusinessField(profile.logoEmoji,t("Logo icon","لوگو آئیکن")){profile=profile.copy(logoEmoji=it)}
    BusinessField(profile.invoicePrefix,t("Invoice prefix","بل حوالہ")){profile=profile.copy(invoicePrefix=it)}
    BusinessField(profile.ntnNumber,t("NTN (optional)","این ٹی این (اختیاری)")){profile=profile.copy(ntnNumber=it)}
    Text(t("Payment account details","ادائیگی اکاؤنٹ کی تفصیل"),style=MaterialTheme.typography.titleLarge)
    BusinessField(profile.bankName,t("Bank","بینک")){profile=profile.copy(bankName=it)}
    BusinessField(profile.bankAccountTitle,t("Account title","اکاؤنٹ کا نام")){profile=profile.copy(bankAccountTitle=it)}
    BusinessField(profile.bankAccountNumber,t("Account number","اکاؤنٹ نمبر")){profile=profile.copy(bankAccountNumber=it)}
    BusinessField(profile.bankIban,t("IBAN","آئی بان")){profile=profile.copy(bankIban=it)}
    BusinessField(profile.jazzCashNumber,"JazzCash"){profile=profile.copy(jazzCashNumber=it)}
    BusinessField(profile.easyPaisaNumber,"EasyPaisa"){profile=profile.copy(easyPaisaNumber=it)}
    BusinessField(profile.sadaPayNumber,"SadaPay"){profile=profile.copy(sadaPayNumber=it)}
    BusinessField(profile.nayaPayNumber,"NayaPay"){profile=profile.copy(nayaPayNumber=it)}
    BusinessField(profile.raastId,"Raast"){profile=profile.copy(raastId=it)}
    BusinessField(profile.customPaymentSlots,t("Additional payment details","دیگر ادائیگی تفصیل")){profile=profile.copy(customPaymentSlots=it)}
    BusinessField(profile.fbrPosId,t("Tax / POS registration (optional)","ٹیکس / پی او ایس رجسٹریشن (اختیاری)")){profile=profile.copy(fbrPosId=it)}
    BusinessField(profile.fbrTaxRatePercent.toString(),t("Configured tax rate %","آپ کی مقرر کردہ ٹیکس شرح %"),true){profile=profile.copy(fbrTaxRatePercent=it.toDoubleOrNull() ?: Double.NaN)}
    Text(t("Set the rate applicable to your business. This app does not determine your legal tax obligations.","اپنے کاروبار کے مطابق شرح مقرر کریں۔ ایپ قانونی ٹیکس ذمہ داری مقرر نہیں کرتی۔"),style=MaterialTheme.typography.bodySmall)
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
    TextButton(onClick={advanced=true}){Text(t("Existing profile tools","موجودہ تفصیلی ٹولز"))}
  }
}
