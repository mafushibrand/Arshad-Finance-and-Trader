package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONObject

internal val Cream = Color(0xFFF7F9F3)
internal val Forest = Color(0xFF006C45)
internal val Mint = Color(0xFFE4F3E9)
internal val Peach = Color(0xFFFFEDD8)
internal val Ink = Color(0xFF172C24)
internal fun FinanceUiState.word(en: String, ur: String) = if (appLanguage == AppLanguage.URDU) ur else en
internal fun FinanceUiState.money(amount: Double) = String.format(Locale.US, "%s %,.2f", currencySymbol, amount)

@Composable
internal fun PremiumPage(title: String, subtitle: String, icon: ImageVector,
  modifier: Modifier = Modifier, action: String = "", onAction: () -> Unit = {},
  footer: @Composable () -> Unit = {}, body: LazyListScope.() -> Unit) {
  Column(modifier.fillMaxSize().background(Cream)) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
      Surface(shape = RoundedCornerShape(16.dp), color = Mint) { Icon(icon, null, Modifier.padding(12.dp).size(24.dp), tint = Forest) }
      Spacer(Modifier.width(12.dp))
      Column(Modifier.weight(1f)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
      if (action.isNotEmpty()) FilledTonalIconButton(onClick = onAction) { Icon(Icons.Default.Add, action) }
    }
    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 20.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp), content = body)
    footer()
  }
}

@Composable
internal fun SearchBox(value: String, placeholder: String, changed: (String) -> Unit) {
  OutlinedTextField(value, changed, modifier = Modifier.fillMaxWidth(), singleLine = true,
    placeholder = { Text(placeholder, style = MaterialTheme.typography.bodyMedium) },
    leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(24.dp),
    colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White, focusedContainerColor = Color.White,
      unfocusedBorderColor = Color(0xFFDEE8DF)))
}

@Composable
internal fun PremiumButton(text: String, click: () -> Unit, enabled: Boolean = true, modifier: Modifier = Modifier) {
  Button(onClick = click, enabled = enabled, modifier = modifier.fillMaxWidth().heightIn(min = 54.dp),
    shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Forest)) {
    Icon(Icons.Default.Add, null, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)); Text(text, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
internal fun ListTile(title: String, subtitle: String, icon: ImageVector, trailing: String = "",
  tint: Color = Mint, click: () -> Unit = {}, controls: @Composable RowScope.() -> Unit = {},
  leadingEmoji: String = "") {
  Surface(onClick = click, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = Color.White,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEBEFE8))) {
    Column(Modifier.padding(14.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(shape = RoundedCornerShape(14.dp), color = tint) {
          if (leadingEmoji.isNotBlank()) {
            Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
              Text(leadingEmoji, fontSize = 25.sp)
            }
          } else {
            Icon(icon, null, Modifier.padding(12.dp).size(24.dp), tint = Forest)
          }
        }
        Column(Modifier.weight(1f)) {
          Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall, color = Ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
          if (subtitle.isNotEmpty()) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (trailing.isNotEmpty()) Text(trailing, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = Forest)
      }
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically, content = controls)
    }
  }
}

@Composable
internal fun Metric(title: String, value: String, tint: Color = Mint, modifier: Modifier = Modifier) {
  Surface(modifier = modifier, shape = RoundedCornerShape(20.dp), color = tint) {
    Column(Modifier.padding(16.dp)) {
      Text(title, style = MaterialTheme.typography.labelMedium, color = Ink)
      Spacer(Modifier.height(6.dp))
      Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Forest, maxLines = 2)
    }
  }
}

@Composable
internal fun FilterRow(labels: List<String>, selected: Int, changed: (Int) -> Unit) {
  Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    labels.forEachIndexed { i, label -> FilterChip(selected == i, { changed(i) }, label = { Text(label) }, shape = RoundedCornerShape(14.dp)) }
  }
}

@Composable
internal fun EmptyList(title: String, hint: String, icon: ImageVector) {
  Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = Color.White) {
    Column(Modifier.padding(vertical = 36.dp, horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Icon(icon, null, Modifier.size(44.dp), tint = Forest); Spacer(Modifier.height(12.dp))
      Text(title, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(6.dp))
      Text(hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@Composable
internal fun AdvancedButton(state: FinanceUiState, click: () -> Unit) {
  TextButton(onClick = click, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Tune, null); Spacer(Modifier.width(8.dp)); Text(state.word("More tools & detailed view", "مزید ٹولز اور تفصیلی منظر")) }
}

@Composable
fun InventoryScreen(
  uiState: FinanceUiState,
  onAddItemClick: () -> Unit,
  onEditItemClick: (InventoryItem) -> Unit,
  onQuickAdjustClick: (InventoryItem) -> Unit,
  onDownloadStockClick: () -> Unit,
  onUploadStockClick: () -> Unit,
  onOpenIndustryCatalog: () -> Unit = {},
  onDeleteItem: (InventoryItem) -> Unit = {},
  onAddToCart: (InventoryItem) -> Unit = {},
  onUpdateCartQty: (Long, Double) -> Unit = { _, _ -> },
  onClearCart: () -> Unit = {},
  onGoToPos: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  var advanced by rememberSaveable { mutableStateOf(false) }
  if (advanced) {
    BackHandler { advanced = false }
    Column(modifier.fillMaxSize().background(Cream)) {
      TextButton(onClick = { advanced = false }, modifier = Modifier.padding(horizontal = 16.dp)) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(8.dp)); Text(uiState.word("Back to overview", "خلاصے پر واپس")) }
      LegacyInventoryScreen(uiState = uiState, onAddItemClick = onAddItemClick, onEditItemClick = onEditItemClick, onQuickAdjustClick = onQuickAdjustClick, onDownloadStockClick = onDownloadStockClick, onUploadStockClick = onUploadStockClick, onOpenIndustryCatalog = onOpenIndustryCatalog, onDeleteItem = onDeleteItem, onAddToCart = onAddToCart, onUpdateCartQty = onUpdateCartQty, onClearCart = onClearCart, onGoToPos = onGoToPos, modifier = Modifier.weight(1f))
    }
    return
  }
  var search by rememberSaveable { mutableStateOf("") }
  var filter by rememberSaveable { mutableIntStateOf(0) }
  val products = uiState.inventoryItems.filter { !it.barcode.startsWith("SRV-") }
  val visible = products.filter { (search.isBlank() || it.name.contains(search, true) || it.barcode.contains(search, true) || it.category.contains(search, true)) &&
    (filter == 0 || (filter == 1 && it.currentStock <= it.lowStockThreshold) || (filter == 2 && it.currentStock <= 0.0)) }
  PremiumPage(uiState.word("Products & stock", "سامان اور اسٹاک"), uiState.word("Your catalog, always in control", "آپ کا سامان، مکمل کنٹرول"), Icons.Default.Inventory2,
    modifier, uiState.word("Add product", "نیا سامان"), onAddItemClick,
    footer = { Column(Modifier.padding(16.dp)) {
      PremiumButton(uiState.word("Add New Product", "نیا سامان شامل کریں"), onAddItemClick)
      if (uiState.cartItemCount > 0) TextButton(onClick = onGoToPos, modifier = Modifier.fillMaxWidth()) { Text(uiState.word("Open bill • ${uiState.cartItemCount} items", "بل کھولیں • ${uiState.cartItemCount} اشیاء")) }
    } }) {
    item { SearchBox(search, uiState.word("Search name, category or barcode", "نام، قسم یا بارکوڈ تلاش کریں")) { search = it } }
    item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      Metric(uiState.word("Stock value at cost", "اسٹاک کی خرید قدر"), uiState.money(products.sumOf { it.currentStock * it.costPrice }), modifier = Modifier.weight(1f))
      Metric(uiState.word("Low stock", "کم اسٹاک"), products.count { it.currentStock <= it.lowStockThreshold }.toString(), Peach, Modifier.weight(1f))
    } }
    item { FilterRow(listOf(uiState.word("All", "تمام"), uiState.word("Low stock", "کم اسٹاک"), uiState.word("Out of stock", "اسٹاک ختم")), filter) { filter = it } }
    if (visible.isEmpty()) item { EmptyList(uiState.word("No products found", "کوئی سامان نہیں ملا"), uiState.word("Add your first product to start billing.", "بلنگ شروع کرنے کے لیے پہلا سامان شامل کریں۔"), Icons.Default.Inventory2) }
    items(visible, key = { it.id }) { product ->
      val demoEmoji = runCatching { JSONObject(product.detailsJson).optString("demoImageEmoji") }.getOrDefault("")
      ListTile(product.name, "${product.category} • ${product.currentStock} ${product.unit}", Icons.Default.Inventory2,
        uiState.money(product.salePrice), click = { onEditItemClick(product) }, leadingEmoji = demoEmoji) {
        TextButton(onClick = { onEditItemClick(product) }) { Text(uiState.word("Edit", "ترمیم")) }
        TextButton(onClick = { onQuickAdjustClick(product) }) { Text(uiState.word("Adjust stock", "اسٹاک تبدیل")) }
        FilledTonalIconButton(onClick = { onAddToCart(product) }, enabled = product.currentStock > 0) { Icon(Icons.Default.AddShoppingCart, uiState.word("Add to bill", "بل میں شامل")) }
      }
    }
    item { Row { TextButton(onClick = onDownloadStockClick, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileDownload, null); Text(uiState.word("Export", "ایکسپورٹ")) }
      TextButton(onClick = onUploadStockClick, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileUpload, null); Text(uiState.word("Import", "امپورٹ")) } } }
    item { AdvancedButton(uiState) { advanced = true } }
  }
}
