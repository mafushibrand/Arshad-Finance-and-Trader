package com.example.ui.theme

import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object InputFieldStyles {
  val textStyle = TextStyle(
    color = Color(0xFF0F172A), // Pure deep slate/black - 100% sharp contrast
    fontSize = 15.sp,
    fontWeight = FontWeight.Medium
  )

  val boldTextStyle = TextStyle(
    color = Color(0xFF0F172A),
    fontSize = 16.sp,
    fontWeight = FontWeight.Bold
  )

  @Composable
  fun colors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color(0xFF0F172A),
    unfocusedTextColor = Color(0xFF0F172A),
    focusedContainerColor = Color.White,
    unfocusedContainerColor = Color.White,
    disabledContainerColor = Color(0xFFF5F7F2),
    disabledTextColor = Color(0xFF334155),
    focusedBorderColor = NavyBluePrimary,
    unfocusedBorderColor = Color(0xFF94A3B8), // Clear visible border
    focusedLabelColor = NavyBluePrimary,
    unfocusedLabelColor = Color(0xFF334155), // Dark readable label
    focusedPlaceholderColor = Color(0xFF64748B),
    unfocusedPlaceholderColor = Color(0xFF64748B),
    cursorColor = NavyBluePrimary
  )
}
