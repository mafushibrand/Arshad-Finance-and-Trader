package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.InventoryItem
import com.example.data.model.Invoice

data class ProductPerformance(
  val name: String,
  val icon: String,
  val qtySold: Int,
  val totalSale: Double,
  val totalProfit: Double
)

@Composable
fun PerformanceHubDialog(
  inventoryItems: List<InventoryItem>,
  invoices: List<Invoice>,
  currencySymbol: String = "Rs",
  onDismiss: () -> Unit
) {
  var selectedFilter by remember { mutableStateOf("ALL TIME") }

  // Sample or calculated performance analytics
  val mostSelling = listOf(
    ProductPerformance("Pizza", "🍕", 13, 13000.0, 2600.0),
    ProductPerformance("Shawarma", "🌯", 9, 1350.0, 450.0),
    ProductPerformance("Coca Cola", "🥤", 8, 800.0, 80.0),
    ProductPerformance("Burger", "🍔", 7, 3500.0, 700.0),
    ProductPerformance("Photonic Shampoo", "🧴", 7, 3500.0, 700.0)
  )

  val mostProfitable = listOf(
    ProductPerformance("Pizza", "🍕", 13, 13000.0, 2600.0),
    ProductPerformance("Burger", "🍔", 7, 3500.0, 700.0),
    ProductPerformance("Photonic Shampoo", "🧴", 7, 3500.0, 700.0),
    ProductPerformance("Shawarma", "🌯", 9, 1350.0, 450.0),
    ProductPerformance("Cooking Oil 5L", "🛢️", 4, 11000.0, 1200.0)
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier.fillMaxSize(),
      color = Color(0xFFF5F7F2)
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // 1. Top Header Bar (Screenshot 4)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 14.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color(0xFF0F172A)
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Column {
            Text(
              text = "PERFORMANCE HUB",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A),
              letterSpacing = 0.5.sp
            )
            Text(
              text = "FULL PRODUCT ANALYTICS",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF086B4D),
              letterSpacing = 0.8.sp
            )
          }
        }

        HorizontalDivider(color = Color(0xFFE2E8F0))

        // 2. Filter Chips: ALL TIME, TODAY, YESTERDAY, THIS MONTH
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 16.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("ALL TIME", "TODAY", "YESTERDAY", "THIS MONTH").forEach { f ->
            val isSelected = selectedFilter == f
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = if (isSelected) Color(0xFF086B4D) else Color(0xFFF7F9F3),
              modifier = Modifier
                .clickable { selectedFilter = f }
                .padding(vertical = 2.dp)
            ) {
              Text(
                text = f,
                fontSize = 10.5.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color(0xFF475569),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
              )
            }
          }
        }

        // 3. Performance Cards Sections
        LazyColumn(
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          // SECTION 1: MOST SELLING ITEMS (Blue Banner Header)
          item {
            Card(
              shape = RoundedCornerShape(18.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column {
                // Header Banner
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF086B4D))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(
                      text = "MOST SELLING ITEMS",
                      fontSize = 12.5.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White
                    )
                    Text(
                      text = "SAB SE ZYADA BIKNAY WALA MAAL",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Medium,
                      color = Color.White.copy(alpha = 0.85f)
                    )
                  }
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.clickable { }
                  ) {
                    Text(
                      text = "SEE ALL",
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                  }
                }

                // Item Rows
                mostSelling.take(3).forEachIndexed { idx, p ->
                  ProductRankRow(rank = idx + 1, item = p, currencySymbol = currencySymbol)
                  if (idx < 2) HorizontalDivider(color = Color(0xFFF7F9F3))
                }

                Text(
                  text = "+ 10 MORE ITEMS / MAZEED DEKHEIN",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF64748B),
                  textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
                )
              }
            }
          }

          // SECTION 2: MOST PROFITABLE ITEMS (Green Banner Header)
          item {
            Card(
              shape = RoundedCornerShape(18.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column {
                // Header Banner
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF059669)) // Emerald Green
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(
                      text = "MOST PROFITABLE ITEMS",
                      fontSize = 12.5.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White
                    )
                    Text(
                      text = "SAB SE ZYADA MUNAFA DENAY WALA MAAL",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Medium,
                      color = Color.White.copy(alpha = 0.85f)
                    )
                  }
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.clickable { }
                  ) {
                    Text(
                      text = "SEE ALL",
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                  }
                }

                // Item Rows
                mostProfitable.take(3).forEachIndexed { idx, p ->
                  ProductRankRow(rank = idx + 1, item = p, currencySymbol = currencySymbol)
                  if (idx < 2) HorizontalDivider(color = Color(0xFFF7F9F3))
                }

                Text(
                  text = "+ 10 MORE ITEMS / MAZEED DEKHEIN",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF64748B),
                  textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ProductRankRow(
  rank: Int,
  item: ProductPerformance,
  currencySymbol: String
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 14.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = "#$rank",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF94A3B8),
        modifier = Modifier.width(24.dp)
      )

      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(Color(0xFFF7F9F3)),
        contentAlignment = Alignment.Center
      ) {
        Text(text = item.icon, fontSize = 20.sp)
      }

      Spacer(modifier = Modifier.width(10.dp))

      Column {
        Text(
          text = item.name,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF0F172A)
        )
        Text(
          text = "QTY: ${item.qtySold} SOLD",
          fontSize = 10.sp,
          fontWeight = FontWeight.SemiBold,
          color = Color(0xFF64748B)
        )
      }
    }

    Column(horizontalAlignment = Alignment.End) {
      Text(
        text = "Sale: $currencySymbol.${item.totalSale.toInt()}",
        fontSize = 11.5.sp,
        fontWeight = FontWeight.SemiBold,
        color = Color(0xFF0F172A)
      )
      Text(
        text = "Profit: $currencySymbol.${item.totalProfit.toInt()}",
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF10B981)
      )
    }
  }
}
