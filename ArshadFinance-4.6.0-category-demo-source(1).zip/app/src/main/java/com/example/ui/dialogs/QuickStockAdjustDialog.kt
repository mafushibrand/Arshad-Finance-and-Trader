package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.InventoryItem
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LegacyQuickStockAdjustDialog(
  item: InventoryItem,
  currencySymbol: String,
  onDismiss: () -> Unit,
  onAddStock: (quantity: Double, costPrice: Double?) -> Unit,
  onDeductStock: (quantity: Double, recordAsSale: Boolean) -> Unit
) {
  var quantityText by remember { mutableStateOf("1") }
  var isStockIn by remember { mutableStateOf(true) } // Stock In (Add) or Stock Out (Sale/Deduct)
  var recordAsSale by remember { mutableStateOf(true) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val currentQty = item.currentStock
  val unit = item.unit

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(24.dp))
        .testTag("quick_stock_adjust_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = item.icon, fontSize = 24.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = item.name,
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                ),
                maxLines = 1
              )
              Text(
                text = "موجودہ اسٹاک: $currentQty $unit",
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = TextSecondary
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mode Toggle: Stock In (Add) vs Stock Out (Sale / Minus)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFF2F3F7))
            .padding(4.dp),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(12.dp))
              .background(if (isStockIn) IncomeGreen else Color.Transparent)
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            TextButton(onClick = { isStockIn = true }) {
              Text(
                text = "➕ Stock In (نیا مال)",
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = if (isStockIn) Color.White else TextPrimary
                )
              )
            }
          }

          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(12.dp))
              .background(if (!isStockIn) ExpenseRed else Color.Transparent)
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            TextButton(onClick = { isStockIn = false }) {
              Text(
                text = "🛒 Sale / Deduct (سیل)",
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = if (!isStockIn) Color.White else TextPrimary
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quantity Quick Controls + Field
        Text(
          text = if (isStockIn) "کتنی مقدار شامل کرنی ہے؟ (Qty to Add)" else "کتنی مقدار فروخت ہوئی؟ (Qty Sold)",
          style = MaterialTheme.typography.labelMedium.copy(
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
          )
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          IconButton(
            onClick = {
              val current = quantityText.toDoubleOrNull() ?: 1.0
              if (current > 1.0) quantityText = (current - 1.0).let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() }
            },
            modifier = Modifier
              .size(44.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFFF2F3F7))
          ) {
            Icon(Icons.Default.Remove, contentDescription = "Minus", tint = TextPrimary)
          }

          OutlinedTextField(
            value = quantityText,
            onValueChange = { quantityText = it },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("input_adjust_stock_qty")
          )

          IconButton(
            onClick = {
              val current = quantityText.toDoubleOrNull() ?: 0.0
              quantityText = (current + 1.0).let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() }
            },
            modifier = Modifier
              .size(44.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFFF2F3F7))
          ) {
            Icon(Icons.Default.Add, contentDescription = "Add", tint = TextPrimary)
          }
        }

        // Live calculation preview
        val parsedQty = quantityText.toDoubleOrNull() ?: 0.0
        val remainingAfter = if (isStockIn) currentQty + parsedQty else currentQty - parsedQty
        val saleTotalAmount = parsedQty * item.salePrice

        Spacer(modifier = Modifier.height(12.dp))

        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (remainingAfter >= item.lowStockThreshold) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)
          ),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "اس کے بعد بچا ہوا اسٹاک:",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
              )
              Text(
                text = "$remainingAfter $unit",
                style = MaterialTheme.typography.bodyMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = if (remainingAfter >= item.lowStockThreshold) IncomeGreen else ExpenseRed
                )
              )
            }

            if (!isStockIn && parsedQty > 0) {
              Spacer(modifier = Modifier.height(4.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "کل سیل رقم (Total Amount):",
                  style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
                Text(
                  text = "$currencySymbol ${String.format("%.2f", saleTotalAmount)}",
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NavyBluePrimary
                  )
                )
              }
            }
          }
        }

        if (errorMessage != null) {
          Text(
            text = errorMessage ?: "",
            color = ExpenseRed,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 8.dp)
          )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically
        ) {
          TextButton(onClick = onDismiss) {
            Text(text = "Cancel", color = TextSecondary)
          }

          Spacer(modifier = Modifier.width(8.dp))

          Button(
            onClick = {
              if (parsedQty <= 0) {
                errorMessage = "Please enter valid quantity (درست مقدار لکھیں)"
              } else if (!isStockIn && parsedQty > currentQty) {
                errorMessage = "Not enough stock available! (دکان میں اتنا اسٹاک موجود نہیں ہے)"
              } else {
                if (isStockIn) {
                  onAddStock(parsedQty, item.costPrice)
                } else {
                  onDeductStock(parsedQty, recordAsSale)
                }
              }
            },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isStockIn) IncomeGreen else ExpenseRed
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.testTag("confirm_stock_adjust_button")
          ) {
            Text(text = if (isStockIn) "Confirm Stock In (+)" else "Confirm Sale & Minus (-)")
          }
        }
      }
    }
  }
}
