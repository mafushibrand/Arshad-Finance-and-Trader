package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.DeepNavyText
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BusinessProfile
import com.example.util.MultiIndustryCatalog

@Composable
fun IndustryCatalogDialog(
  currentBusinessProfile: BusinessProfile,
  onImportCatalog: (String, String, String) -> Unit, // industryId, shopType, logoEmoji
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  var selectedIndustryId by remember { mutableStateOf("BEAUTY_PARLOUR") }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(24.dp))
        .testTag("industry_catalog_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(IceBlueContainer),
              contentAlignment = Alignment.Center
            ) {
              Text("🏪", fontSize = 20.sp)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Load Shop Category & Items",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
              )
              Text(
                text = "Beauty, Cloth, Medical, Grocery & More",
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFFE2E8F0))

        Text(
          text = "Select your shop type to automatically add items, services, and rates to your inventory & billing:",
          style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
          modifier = Modifier
            .weight(1f, fill = false)
            .fillMaxWidth()
        ) {
          items(MultiIndustryCatalog.industries) { industry ->
            val isSelected = selectedIndustryId == industry.id
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clickable { selectedIndustryId = industry.id },
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(
                containerColor = if (isSelected) Color(0xFFE5F3EA) else Color(0xFFF5F7F2)
              ),
              border = androidx.compose.foundation.BorderStroke(
                if (isSelected) 2.dp else 1.dp,
                if (isSelected) NavyBluePrimary else Color(0xFFE2E8F0)
              )
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(1.dp, Color(0xFFCBD5E1), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Text(industry.emoji, fontSize = 22.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = industry.name,
                      style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) NavyBluePrimary else TextPrimary
                      )
                    )
                  }
                  Text(
                    text = industry.urduName,
                    style = MaterialTheme.typography.bodySmall.copy(
                      fontWeight = FontWeight.SemiBold,
                      color = Color(0xFF475569)
                    )
                  )
                  Text(
                    text = industry.description,
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                    maxLines = 2
                  )
                }

                if (isSelected) {
                  Box(
                    modifier = Modifier
                      .size(24.dp)
                      .clip(CircleShape)
                      .background(NavyBluePrimary),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = "Selected", tint = Color.White, modifier = Modifier.size(16.dp))
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        val selectedInfo = MultiIndustryCatalog.industries.firstOrNull { it.id == selectedIndustryId }

        Button(
          onClick = {
            if (selectedInfo != null) {
              onImportCatalog(selectedInfo.id, selectedInfo.name, selectedInfo.emoji)
              Toast.makeText(context, "${selectedInfo.name} Catalog loaded into Stock!", Toast.LENGTH_LONG).show()
              onDismiss()
            }
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("import_industry_catalog_btn")
        ) {
          Icon(imageVector = Icons.Default.Download, contentDescription = "Import")
          Spacer(modifier = Modifier.width(6.dp))
          Text("Load ${selectedInfo?.emoji ?: ""} ${selectedInfo?.name ?: "Catalog"}", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
