package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Invoice
import com.example.ui.theme.DeepNavyText
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BusinessProfile
import com.example.util.InvoicePrintExportUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun InvoiceDetailDialog(
  invoice: Invoice,
  businessProfile: BusinessProfile,
  currencySymbol: String = "Rs",
  onEditInvoice: (Invoice) -> Unit,
  onDeleteInvoice: (Invoice) -> Unit,
  onDismiss: () -> Unit,
  canEdit: Boolean = true
) {
  val context = LocalContext.current
  val saveBillImage = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.CreateDocument("image/png")) { uri ->
    if (uri != null) runCatching { com.example.util.ThermalReceiptImage.save(context, uri, invoice, businessProfile, currencySymbol) }
      .onSuccess { android.widget.Toast.makeText(context, "Bill image saved / بل کی تصویر محفوظ ہو گئی", android.widget.Toast.LENGTH_LONG).show() }
      .onFailure { android.widget.Toast.makeText(context, "Could not save image / تصویر محفوظ نہیں ہوئی: ${it.localizedMessage}", android.widget.Toast.LENGTH_LONG).show() }
  }

  val items = remember(invoice) { invoice.parseItems() }
  val isPaid = invoice.remainingBalance <= 0.0
  val dateFormat = SimpleDateFormat("dd-MMM-yyyy, hh:mm a", Locale.getDefault())
  var showDeleteConfirm by remember { mutableStateOf(false) }

  if (showDeleteConfirm) {
    AlertDialog(
      onDismissRequest = { showDeleteConfirm = false },
      title = { Text("Delete Bill?", fontWeight = FontWeight.Bold) },
      text = { Text("Are you sure you want to delete bill #${invoice.invoiceNumber}? This action cannot be undone.") },
      confirmButton = {
        Button(
          onClick = {
            showDeleteConfirm = false
            onDeleteInvoice(invoice)
            Toast.makeText(context, "Bill deleted", Toast.LENGTH_SHORT).show()
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
        ) {
          Text("Delete")
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteConfirm = false }) {
          Text("Cancel")
        }
      }
    )
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(24.dp))
        .testTag("invoice_detail_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp)
      ) {
        // 1. Top Header with Shop Logo & Close Button
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color(0xFF0F172A)),
              contentAlignment = Alignment.Center
            ) {
              Text(businessProfile.logoEmoji.ifBlank { "🧾" }, fontSize = 22.sp)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = businessProfile.businessName,
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = DeepNavyText
                )
              )
              Text(
                text = "${businessProfile.shopType} • Ph: ${businessProfile.phone}",
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = Color(0xFFE2E8F0))

        // 2. Bill Metadata Box
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFF5F7F2),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "Bill #: ${invoice.invoiceNumber}",
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = NavyBluePrimary
                )
                Text(
                  text = "Date: ${dateFormat.format(Date(invoice.dateMillis))}",
                  fontSize = 11.sp,
                  color = TextSecondary
                )
              }
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isPaid) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
              ) {
                Text(
                  text = if (isPaid) "PAID" else "UDHAR: $currencySymbol ${"%,.0f".format(invoice.remainingBalance)}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isPaid) IncomeGreen else ExpenseRed,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider(color = Color(0xFFE2E8F0))
            Spacer(modifier = Modifier.height(6.dp))

            Text(
              text = "Customer: ${invoice.customerName.ifBlank { "Walk-in Customer" }}",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = TextPrimary
            )
            if (invoice.customerPhone.isNotBlank()) {
              Text(
                text = "Phone: ${invoice.customerPhone}",
                fontSize = 11.sp,
                color = TextSecondary
              )
            }
            if (invoice.customerAddress.isNotBlank()) {
              Text(
                text = "Address: ${invoice.customerAddress}",
                fontSize = 11.sp,
                color = TextSecondary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3. Items List
        Text(
          text = "Bill Items (${items.size}):",
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp,
          color = Color(0xFF334155)
        )
        Spacer(modifier = Modifier.height(4.dp))

        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f, fill = false)
        ) {
          itemsIndexed(items) { index, item ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Text("${index + 1}.", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                  Text(item.itemName, fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp, color = TextPrimary)
                  val qStr = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else item.quantity.toString()
                  Text("$qStr ${item.unit} × $currencySymbol ${"%,.0f".format(item.unitPrice)}", fontSize = 10.5.sp, color = TextSecondary)
                }
              }
              Text(
                "$currencySymbol ${"%,.0f".format(item.total)}",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = NavyBluePrimary
              )
            }
            HorizontalDivider(color = Color(0xFFF7F9F3))
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 4. Financial Calculations Box
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFE5F3EA),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFC7D2FE)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Subtotal:", fontSize = 11.sp, color = TextSecondary)
              Text("$currencySymbol ${"%,.0f".format(invoice.subtotal)}", fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
            if (invoice.discountAmount > 0) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Discount:", fontSize = 11.sp, color = IncomeGreen)
                Text("-$currencySymbol ${"%,.0f".format(invoice.discountAmount)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IncomeGreen)
              }
            }
            if (invoice.deliveryOrLabour > 0) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Delivery / Labour:", fontSize = 11.sp, color = TextSecondary)
                Text("+$currencySymbol ${"%,.0f".format(invoice.deliveryOrLabour)}", fontSize = 11.sp, fontWeight = FontWeight.Medium)
              }
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color(0xFFC7D2FE))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("GRAND TOTAL:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E1B4B))
              Text("$currencySymbol ${"%,.0f".format(invoice.netTotal())}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF1E1B4B))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Paid Amount (${invoice.paymentMethod}):", fontSize = 11.sp, color = IncomeGreen)
              Text("$currencySymbol ${"%,.0f".format(invoice.amountPaid)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IncomeGreen)
            }
            if (invoice.remainingBalance > 0) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Remaining Balance (Udhar):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ExpenseRed)
                Text("$currencySymbol ${"%,.0f".format(invoice.remainingBalance)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ExpenseRed)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 4b. Shop Payment Accounts Information
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFF0FDF4),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = "Shop Payment Receiving Accounts (ادائیگی کے ذرائع):",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF166534)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("📱 JazzCash: ${businessProfile.jazzCashNumber.ifBlank { "0302-7761415" }}", fontSize = 10.5.sp, color = TextPrimary)
              Text("🟢 Easypaisa: ${businessProfile.easyPaisaNumber.ifBlank { "0345-9876543" }}", fontSize = 10.5.sp, color = TextPrimary)
            }
            Text(
              "🏦 ${businessProfile.bankName.ifBlank { "Meezan Bank" }}: ${businessProfile.bankIban.ifBlank { "PK89 MEZN 0001 0203 0405 0607" }}",
              fontSize = 10.sp,
              color = TextSecondary,
              modifier = Modifier.padding(top = 2.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(onClick = { saveBillImage.launch("Bill_${invoice.id}.png") }, modifier = Modifier.fillMaxWidth().testTag("save_bill_image")) {
          Text("Save bill image / بل کی تصویر محفوظ کریں")
        }

        // 5. Four Big Direct Share Action Buttons (WhatsApp, PDF, Image, Print)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          // WhatsApp
          Button(
            onClick = {
              InvoicePrintExportUtils.generateAndShareInvoiceImage(context, invoice, businessProfile, currencySymbol)
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Send, contentDescription = "WhatsApp", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("WhatsApp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          // PDF
          Button(
            onClick = {
              InvoicePrintExportUtils.generateAndShareInvoicePdf(context, invoice, businessProfile, currencySymbol)
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("PDF Bill", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          // Image
          Button(
            onClick = {
              InvoicePrintExportUtils.generateAndShareInvoiceImage(context, invoice, businessProfile, currencySymbol)
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Image, contentDescription = "Image", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Image", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          // Print
          Button(
            onClick = {
              InvoicePrintExportUtils.printInvoice(context, invoice, businessProfile, currencySymbol)
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF13865F)),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Print, contentDescription = "Print", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Print", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Owner-only bill editing; enforced again before posting.
        if(canEdit) Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = {
              onEditInvoice(invoice)
              onDismiss()
            },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1.2f)
          ) {
            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = NavyBluePrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Edit / Update Bill (تبدیل کریں)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = NavyBluePrimary)
          }

          OutlinedButton(
            onClick = { showDeleteConfirm = true },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = ExpenseRed),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
            modifier = Modifier.weight(0.8f)
          ) {
            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ExpenseRed, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Delete", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = ExpenseRed)
          }
        }
      }
    }
  }
}
