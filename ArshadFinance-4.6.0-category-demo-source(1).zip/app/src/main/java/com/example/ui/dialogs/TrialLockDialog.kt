package com.example.ui.dialogs
import androidx.compose.runtime.Composable
import androidx.compose.material3.*
import com.example.data.model.SubscriptionState
@Composable
fun TrialLockDialog(subscriptionState:SubscriptionState,isHardLock:Boolean=false,onActivate:(String)->Boolean,onDismiss:()->Unit) {
  AlertDialog(onDismissRequest=onDismiss,title={Text("Business access / کاروباری رسائی")},text={Text("30-day trial • Rs. 300/month • Rs. 3,000/year • Save 16.67%. Personal Khata stays free. Use Plans & payment to import a verified activation file.")},confirmButton={TextButton(onClick=onDismiss){Text("Close / بند کریں")}})
}
