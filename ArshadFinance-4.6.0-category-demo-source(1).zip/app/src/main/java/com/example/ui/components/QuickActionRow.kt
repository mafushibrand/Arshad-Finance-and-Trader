package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.OnIceBlueContainer
import com.example.ui.theme.TextPrimary

@Composable
fun QuickActionRow(
  onSendClick: () -> Unit,
  onReceiveClick: () -> Unit,
  onBillingClick: () -> Unit,
  onStockClick: () -> Unit,
  onBillsClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 2.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    QuickActionButton(
      title = "Send",
      icon = Icons.Default.ArrowUpward,
      tag = "quick_action_send",
      onClick = onSendClick
    )
    QuickActionButton(
      title = "Receive",
      icon = Icons.Default.ArrowDownward,
      tag = "quick_action_receive",
      onClick = onReceiveClick
    )
    QuickActionButton(
      title = "Bill 🧾",
      icon = Icons.Default.Receipt,
      tag = "quick_action_billing",
      onClick = onBillingClick
    )
    QuickActionButton(
      title = "Stock 📦",
      icon = Icons.Default.Inventory2,
      tag = "quick_action_stock",
      onClick = onStockClick
    )
    QuickActionButton(
      title = "Budget",
      icon = Icons.Default.PieChart,
      tag = "quick_action_budget",
      onClick = onBillsClick
    )
  }
}

@Composable
fun QuickActionButton(
  title: String,
  icon: ImageVector,
  tag: String,
  onClick: () -> Unit
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable(onClick = onClick)
      .testTag(tag)
      .padding(2.dp)
  ) {
    Box(
      modifier = Modifier
        .size(50.dp)
        .clip(RoundedCornerShape(14.dp))
        .background(IceBlueContainer),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = OnIceBlueContainer,
        modifier = Modifier.size(24.dp)
      )
    }

    Text(
      text = title,
      style = MaterialTheme.typography.labelSmall.copy(
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        color = TextPrimary
      ),
      modifier = Modifier.padding(top = 4.dp)
    )
  }
}
