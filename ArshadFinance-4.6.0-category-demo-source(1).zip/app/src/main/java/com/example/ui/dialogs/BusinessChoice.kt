package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
internal fun BusinessChoice(value: String, label: String, choices: List<String>, allowCustom: Boolean = false, onChange: (String) -> Unit) {
  var open by remember { mutableStateOf(false) }
  var query by remember { mutableStateOf("") }
  OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth().heightIn(min=52.dp)) { Text("$label: $value") }
  if(open) AlertDialog(onDismissRequest={open=false},title={Text(label)},text={
    Column { BusinessField(query,"Search / تلاش یا اپنا یونٹ") {query=it}; LazyColumn(Modifier.heightIn(max=340.dp)) {
      items(choices.filter { it.contains(query,true) }) { choice -> TextButton(onClick={onChange(choice);open=false}, modifier=Modifier.fillMaxWidth().heightIn(min=48.dp)) {Text(choice)} }
    } }
  },confirmButton={ if(allowCustom && query.isNotBlank()) TextButton(onClick={onChange(query.trim());open=false}) {Text("Use custom / اپنا یونٹ")} },dismissButton={TextButton(onClick={open=false}) {Text("Close / بند")}})
}
