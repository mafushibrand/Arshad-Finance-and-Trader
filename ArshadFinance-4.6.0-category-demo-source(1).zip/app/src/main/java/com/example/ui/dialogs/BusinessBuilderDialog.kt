package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import com.example.data.model.*
import com.example.ui.FinanceUiState
import com.example.util.BusinessProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusinessBuilderDialog(state: FinanceUiState, featuresOnly: Boolean = false,
  onSave: (BusinessProfile, BusinessFeatures, String) -> Unit, onDismiss: () -> Unit) {
  val urdu = state.appLanguage == AppLanguage.URDU
  fun text(en: String, ur: String) = if (urdu) ur else en
  var name by remember { mutableStateOf(state.businessProfile.businessName) }
  var owner by remember { mutableStateOf(state.businessProfile.ownerName) }
  var phone by remember { mutableStateOf(state.businessProfile.phone) }
  var address by remember { mutableStateOf(state.businessProfile.address) }
  var industry by remember { mutableStateOf(state.businessProfile.shopType) }
  var templateId by remember { mutableStateOf(state.businessProfile.templateId) }
  var sector by remember { mutableStateOf(state.businessProfile.sector) }
  var category by remember { mutableStateOf(state.businessProfile.category) }
  var subcategory by remember { mutableStateOf(state.businessProfile.subcategory) }
  var templateSearch by remember { mutableStateOf("") }
  var currency by remember { mutableStateOf(state.currencySymbol) }
  var features by remember { mutableStateOf(state.features) }
  var error by remember { mutableStateOf(false) }
  androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
      Scaffold(topBar = { TopAppBar(title = { Text(if (featuresOnly) text("Enable Features", "فیچرز منتخب کریں") else text("Create Your Business", "اپنا کاروبار بنائیں")) }, navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, text("Close", "بند کریں")) } }) },
        bottomBar = { Surface { Button(onClick = {
          if (name.isBlank() || currency.isBlank()) error = true else onSave(state.businessProfile.copy(businessName = name.trim(), ownerName = owner.trim(), phone = phone.trim(), address = address.trim(), shopType = industry.trim(), templateId = templateId, sector = sector, category = category.trim(), subcategory = subcategory.trim()), features, currency.trim())
        }, modifier = Modifier.fillMaxWidth().padding(16.dp).height(54.dp)) { Text(text("Save Business", "کاروبار محفوظ کریں")) } } }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          if (!featuresOnly) {
            Text(text("A workspace for every business", "ہر کاروبار کے لیے اپنا مرکز"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            OutlinedTextField(name, { name = it }, label = { Text(text("Business / Shop name", "کاروبار / دکان کا نام")) }, modifier = Modifier.fillMaxWidth(), singleLine = true, isError = error && name.isBlank())
            OutlinedTextField(owner, { owner = it }, label = { Text(text("Owner name", "مالک کا نام")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(phone, { phone = it }, label = { Text(text("Mobile number", "موبائل نمبر")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(address, { address = it }, label = { Text(text("Address", "پتہ")) }, modifier = Modifier.fillMaxWidth())
            Text(text("Sector → Business → Category → Subcategory", "شعبہ ← کاروبار ← قسم ← ذیلی قسم"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            BusinessChoice(sector, text("Sector", "شعبہ"), com.example.business.BusinessLibrary.templates.map { it.sector }.distinct()) { sector = it }
            val availableTemplates=com.example.business.BusinessLibrary.templates.filter { it.sector == sector }
            BusinessChoice(com.example.business.BusinessLibrary.find(templateId).label(urdu),text("Business template", "کاروباری نمونہ"),availableTemplates.map { it.label(urdu) }) { label ->
              val template=availableTemplates.first { it.label(urdu)==label }
              templateId=template.id;industry=template.name;category=template.category
              features=features.copy(products=template.mode!="appointment",services=template.sector=="Services"||template.mode!="stock",purchases=template.sector!="Services")
            }
            Text(if(urdu) "متعلقہ یونٹ اور فیلڈز خود منتخب ہوں گے" else "${com.example.business.BusinessLibrary.find(templateId).unit} • ${com.example.business.BusinessLibrary.find(templateId).mode} • Relevant fields enabled automatically",style=MaterialTheme.typography.bodySmall)
            BusinessField(industry, text("Business type / custom name", "کاروبار کی قسم / اپنا نام")) { industry = it }
            BusinessField(category, text("Category", "قسم")) { category = it }
            BusinessField(subcategory, text("Subcategory", "ذیلی قسم")) { subcategory = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Rs", "USD", "AED", "GBP").forEach { value -> FilterChip(currency == value, { currency = value }, label = { Text(value) }) } }
            OutlinedTextField(currency, { currency = it }, label = { Text(text("Currency symbol", "کرنسی کا نشان")) }, modifier = Modifier.fillMaxWidth(), singleLine = true, isError = error && currency.isBlank())
          }
          Text(text("Enable features", "فیچرز فعال کریں"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
          FeatureSwitch(text("Products & stock", "سامان اور اسٹاک"), features.products) { features = features.copy(products = it) }
          FeatureSwitch(text("Services", "سروسز"), features.services) { features = features.copy(services = it) }
          FeatureSwitch(text("POS / billing", "فروخت اور بلنگ"), features.pos) { features = features.copy(pos = it) }
          FeatureSwitch(text("Khata", "کھاتہ"), features.khata) { features = features.copy(khata = it) }
          FeatureSwitch(text("Purchases", "خریداری"), features.purchases) { features = features.copy(purchases = it) }
          FeatureSwitch(text("Expenses", "اخراجات"), features.expenses) { features = features.copy(expenses = it) }
          FeatureSwitch(text("Reports", "رپورٹس"), features.reports) { features = features.copy(reports = it) }
          FeatureSwitch(text("Online payment receipts", "آن لائن ادائیگی کی رسیدیں"), features.onlinePayments) { features = features.copy(onlinePayments = it) }
          FeatureSwitch(text("Manufacturing / recipes", "پیداوار / ریسپی"), features.manufacturing) { features = features.copy(manufacturing = it) }
          FeatureSwitch(text("Rental contracts", "کرایہ معاہدے"), features.rentals) { features = features.copy(rentals = it) }
          FeatureSwitch(text("Appointment scheduling", "اپائنٹمنٹ شیڈول"), features.appointments) { features = features.copy(appointments = it) }
          Text(text("Turning off a feature keeps its existing records safe.", "فیچر بند کرنے سے اس کا موجودہ ریکارڈ حذف نہیں ہوگا۔"), style = MaterialTheme.typography.bodySmall)
        }
      }
    }
  }
}

@Composable
private fun FeatureSwitch(label: String, checked: Boolean, changed: (Boolean) -> Unit) {
  Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
      Text(label, Modifier.weight(1f)); Switch(checked, changed)
    }
  }
}
