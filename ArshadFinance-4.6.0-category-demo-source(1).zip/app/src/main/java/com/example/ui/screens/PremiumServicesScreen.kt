package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun ServicesScreen(
  uiState: FinanceUiState,
  onAddOrUpdateService: (ServiceItem) -> Unit,
  onDeleteService: (Long) -> Unit,
  onToggleServiceDiscount: (Long, Boolean, Double?) -> Unit,
  onToggleFeaturedService: (Long) -> Unit,
  onSelectServiceCategory: (String) -> Unit,
  onUpdateShopBioData: (ShopBioData) -> Unit,
  onAddServiceToCart: (ServiceItem) -> Unit,
  modifier: Modifier = Modifier
) {
  var advanced by rememberSaveable { mutableStateOf(false) }
  if (advanced) {
    BackHandler { advanced = false }
    Column(modifier.fillMaxSize().background(Cream)) {
      TextButton(onClick = { advanced = false }, modifier = Modifier.padding(horizontal = 16.dp)) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(8.dp)); Text(uiState.word("Back to overview", "خلاصے پر واپس")) }
      LegacyServicesScreen(uiState = uiState, onAddOrUpdateService = onAddOrUpdateService, onDeleteService = onDeleteService, onToggleServiceDiscount = onToggleServiceDiscount, onToggleFeaturedService = onToggleFeaturedService, onSelectServiceCategory = onSelectServiceCategory, onUpdateShopBioData = onUpdateShopBioData, onAddServiceToCart = onAddServiceToCart, modifier = Modifier.weight(1f))
    }
    return
  }
  var search by rememberSaveable { mutableStateOf("") }
  var showEditor by remember { mutableStateOf(false) }
  var editing by remember { mutableStateOf<ServiceItem?>(null) }
  var removal by remember { mutableStateOf<ServiceItem?>(null) }
  val services = uiState.services.filter { search.isBlank() || it.name.contains(search, true) || it.urduName.contains(search, true) || it.businessCategory.contains(search, true) }
  PremiumPage(uiState.word("Services", "سروسز"), uiState.word("Appointments, repairs & your expertise", "اپائنٹمنٹ، مرمت اور آپ کی مہارت"), Icons.Default.Handyman,
    modifier, uiState.word("Add service", "نئی سروس"), { editing = null; showEditor = true }, footer = {
      Column(Modifier.padding(16.dp)) { PremiumButton(uiState.word("Add New Service", "نئی سروس شامل کریں"), { editing = null; showEditor = true }) }
    }) {
    item { SearchBox(search, uiState.word("Search service…", "سروس تلاش کریں…")) { search = it } }
    item { Metric(uiState.word("Services in your catalog", "آپ کی دستیاب سروسز"), uiState.services.size.toString()) }
    if (services.isEmpty()) item { EmptyList(uiState.word("No services found", "کوئی سروس نہیں ملی"), uiState.word("Create a service with your own price.", "اپنی قیمت کے ساتھ نئی سروس بنائیں۔"), Icons.Default.Handyman) }
    items(services, key = { it.id }) { service ->
      ListTile(if (uiState.appLanguage == AppLanguage.URDU) service.urduName.ifBlank { service.name } else service.name,
        "${service.businessCategory.replace('_', ' ')} • ${service.unit}", Icons.Default.Handyman, uiState.money(service.effectivePrice), Color(0xFFECE8FF), { editing = service; showEditor = true }) {
        IconButton(onClick = { onToggleFeaturedService(service.id) }) { Icon(if (service.isFeatured) Icons.Default.Star else Icons.Default.StarBorder, uiState.word("Featured", "نمایاں"), tint = Forest) }
        IconButton(onClick = { removal = service }) { Icon(Icons.Default.DeleteOutline, uiState.word("Delete", "حذف")) }
        TextButton(onClick = { onAddServiceToCart(service) }) { Icon(Icons.Default.AddShoppingCart, null); Spacer(Modifier.width(6.dp)); Text(uiState.word("Add to bill", "بل میں شامل")) }
      }
    }
    item { AdvancedButton(uiState) { advanced = true } }
  }
  if (showEditor) AddEditServiceDialog(editing, uiState.appLanguage == AppLanguage.URDU, uiState.currencySymbol,
    { showEditor = false }, { onAddOrUpdateService(it); showEditor = false })
  removal?.let { service -> AlertDialog(onDismissRequest = { removal = null }, title = { Text(uiState.word("Delete service?", "سروس حذف کریں؟")) }, text = { Text(service.name) },
    confirmButton = { TextButton(onClick = { onDeleteService(service.id); removal = null }) { Text(uiState.word("Delete", "حذف")) } }, dismissButton = { TextButton(onClick = { removal = null }) { Text(uiState.word("Cancel", "منسوخ")) } }) }
}
