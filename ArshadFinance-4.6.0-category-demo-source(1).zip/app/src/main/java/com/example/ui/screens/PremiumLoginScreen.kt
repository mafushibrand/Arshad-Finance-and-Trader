package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun LoginScreen(
  userAccount: UserAccount,
  appLanguage: AppLanguage,
  onToggleLanguage: () -> Unit,
  onLoginSuccess: (mobile: String, shopName: String, ownerName: String, city: String) -> Unit,
  modifier: Modifier = Modifier
) {
  val urdu = appLanguage == AppLanguage.URDU
  fun label(en: String, ur: String) = if (urdu) ur else en
  var setup by rememberSaveable { mutableStateOf(false) }
  var mobile by rememberSaveable { mutableStateOf(userAccount.mobileNumber) }
  var shop by rememberSaveable { mutableStateOf(userAccount.shopName) }
  var owner by rememberSaveable { mutableStateOf(userAccount.ownerName) }
  var city by rememberSaveable { mutableStateOf(userAccount.cityRegion) }
  Column(modifier.fillMaxSize().background(Cream).statusBarsPadding().navigationBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
    TextButton(onClick = onToggleLanguage, modifier = Modifier.align(Alignment.End)) { Icon(Icons.Default.Language, null); Spacer(Modifier.width(8.dp)); Text(if (urdu) "English" else "اردو") }
    LazyColumn(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
      item { Surface(shape = RoundedCornerShape(40.dp), color = Mint, modifier = Modifier.padding(top = 16.dp).size(160.dp)) {
        Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Storefront, null, Modifier.size(94.dp), tint = Forest) }
      } }
      item { Text(label("Your business, made simple", "اپنا کاروبار آسان بنائیں"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
      item { Text(label("Manage your shop, services, stock, khata and billing in one app.", "اپنی دکان، سروسز، اسٹاک، کھاتہ اور بلنگ ایک ایپ میں سنبھالیں۔"), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant) }
      item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Metric(label("Billing", "بلنگ"), label("Sell", "فروخت"), Color(0xFFFFEEDD), Modifier.weight(1f))
        Metric(label("Inventory", "سامان"), label("Stock", "اسٹاک"), Mint, Modifier.weight(1f))
        Metric(label("Balance", "حساب"), label("Khata", "کھاتہ"), Color(0xFFECE8FF), Modifier.weight(1f))
      } }
      if (setup) {
        item { OutlinedTextField(shop, { shop = it }, label = { Text(label("Business name", "کاروبار کا نام")) }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { OutlinedTextField(owner, { owner = it }, label = { Text(label("Owner name", "مالک کا نام")) }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { OutlinedTextField(mobile, { mobile = it }, label = { Text(label("Mobile number", "موبائل نمبر")) }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { OutlinedTextField(city, { city = it }, label = { Text(label("City / country", "شہر / ملک")) }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
      }
      item { Text(label("Your workspace is saved on this device.", "آپ کا کاروباری ریکارڈ اس ڈیوائس پر محفوظ ہوتا ہے۔"), style = MaterialTheme.typography.bodySmall) }
    }
    PremiumButton(if (setup) label("Create my workspace", "اپنا کاروبار بنائیں") else label("Set up my business", "اپنا کاروبار شروع کریں"), {
      if (!setup) setup = true else if (shop.isNotBlank()) onLoginSuccess(mobile.trim(), shop.trim(), owner.trim(), city.trim())
    }, enabled = !setup || shop.isNotBlank())
    TextButton(onClick = { onLoginSuccess(mobile, shop, owner, city) }, modifier = Modifier.fillMaxWidth()) { Text(label("Open existing workspace", "موجودہ کاروبار کھولیں")) }
  }
}
