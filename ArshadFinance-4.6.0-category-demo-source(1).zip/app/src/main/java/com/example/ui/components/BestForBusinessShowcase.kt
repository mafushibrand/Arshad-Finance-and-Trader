package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage

data class BusinessCategoryItem(
  val id: String,
  val urduTitle: String,
  val englishTitle: String,
  val emoji: String,
  val bgGradientStart: Color,
  val bgGradientEnd: Color,
  val textColor: Color = Color.Black,
  val defaultUnit: String = "Piece",
  val sampleItems: List<String> = emptyList()
)

object BusinessCategoryList {
  val allCategories = listOf(
    BusinessCategoryItem(
      id = "CASH_AND_CARRY",
      urduTitle = "کیش اینڈ کیری",
      englishTitle = "Cash & Carry",
      emoji = "🛒",
      bgGradientStart = Color(0xFFFFD54F),
      bgGradientEnd = Color(0xFFFFB300),
      textColor = Color(0xFF1E293B),
      defaultUnit = "Kg",
      sampleItems = listOf("چینی (Sugar)", "دال چنا (Daal)", "گھی (Ghee)", "چاول (Rice)")
    ),
    BusinessCategoryItem(
      id = "GENERAL_STORE",
      urduTitle = "جنرل سٹور",
      englishTitle = "General Store",
      emoji = "🏬",
      bgGradientStart = Color(0xFF38BDF8),
      bgGradientEnd = Color(0xFF13865F),
      textColor = Color.White,
      defaultUnit = "Piece",
      sampleItems = listOf("صابن (Soap)", "شیمپو (Shampoo)", "سرف (Detergent)", "بسکٹ (Biscuits)")
    ),
    BusinessCategoryItem(
      id = "MARTS",
      urduTitle = "مارٹس",
      englishTitle = "Marts & Superstore",
      emoji = "🛒",
      bgGradientStart = Color(0xFFA3E635),
      bgGradientEnd = Color(0xFF65A30D),
      textColor = Color(0xFF1E293B),
      defaultUnit = "Piece",
      sampleItems = listOf("کوکنگ آئل", "چائے کی پتی", "کولڈ ڈرنکس", "منرل واٹر")
    ),
    BusinessCategoryItem(
      id = "MOBILE_SHOP",
      urduTitle = "موبائل شاپ",
      englishTitle = "Mobile Shop",
      emoji = "📱",
      bgGradientStart = Color(0xFFFDE047),
      bgGradientEnd = Color(0xFFCA8A04),
      textColor = Color(0xFF1E293B),
      defaultUnit = "Piece",
      sampleItems = listOf("Smart Phone", "AirPods", "Charger", "Glass Protector")
    ),
    BusinessCategoryItem(
      id = "GARMENTS_CLOTH",
      urduTitle = "گارمنٹس اینڈ کلاتھ",
      englishTitle = "Garments & Cloth",
      emoji = "👕",
      bgGradientStart = Color(0xFFF87171),
      bgGradientEnd = Color(0xFFDC2626),
      textColor = Color.White,
      defaultUnit = "Meter",
      sampleItems = listOf("لان سوٹ (Lawn)", "کاٹن سوٹ (Cotton)", "شلوار قمیض", "ٹی شرٹ")
    ),
    BusinessCategoryItem(
      id = "SHOES",
      urduTitle = "شوز و جوتے",
      englishTitle = "Shoes & Footwear",
      emoji = "👟",
      bgGradientStart = Color(0xFF6EE7B7),
      bgGradientEnd = Color(0xFF059669),
      textColor = Color(0xFF064E3B),
      defaultUnit = "Pair",
      sampleItems = listOf("پیشاوری چپل", "سپورٹس جوگرز", "چمڑے کے جوتے", "سینڈل")
    ),
    BusinessCategoryItem(
      id = "SANITARY_HARDWARE",
      urduTitle = "سینیٹری اینڈ ہارڈویئر",
      englishTitle = "Sanitary & Hardware",
      emoji = "🛠️",
      bgGradientStart = Color(0xFFC084FC),
      bgGradientEnd = Color(0xFF7E22CE),
      textColor = Color.White,
      defaultUnit = "Piece",
      sampleItems = listOf("پائپ فٹنگ", "سیمنٹ بوری", "پینٹ بالٹی", "نلکے و مکسر")
    ),
    BusinessCategoryItem(
      id = "FAST_FOOD",
      urduTitle = "فاسٹ فوڈ و پیزا",
      englishTitle = "Fast Food & Pizza",
      emoji = "🍔",
      bgGradientStart = Color(0xFF4ADE80),
      bgGradientEnd = Color(0xFF16A34A),
      textColor = Color.White,
      defaultUnit = "Deal",
      sampleItems = listOf("لارج پیزا", "زنگر برگر", "چکن شوارما", "فرائز پلیٹ")
    ),
    BusinessCategoryItem(
      id = "PHARMACY",
      urduTitle = "فارمیسی و میڈیکل",
      englishTitle = "Pharmacy & Medical",
      emoji = "💊",
      bgGradientStart = Color(0xFFFBBF24),
      bgGradientEnd = Color(0xFFD97706),
      textColor = Color(0xFF1E293B),
      defaultUnit = "Strip",
      sampleItems = listOf("پیناڈول (Panadol)", "بروفین (Brufen)", "سرنج (Syringe)", "سیرپ (Syrup)")
    ),
    BusinessCategoryItem(
      id = "BAKERY_SWEETS",
      urduTitle = "بیکری اینڈ سویٹس",
      englishTitle = "Bakery & Sweets",
      emoji = "🧁",
      bgGradientStart = Color(0xFFFB7185),
      bgGradientEnd = Color(0xFFBE123C),
      textColor = Color.White,
      defaultUnit = "Kg",
      sampleItems = listOf("مکس مٹھائی", "کیک (Cake)", "رس گلے", "تازہ ڈبل روٹی")
    ),
    BusinessCategoryItem(
      id = "BOOK_STATIONERY",
      urduTitle = "بک اینڈ سٹیشنری",
      englishTitle = "Book & Stationery",
      emoji = "📖",
      bgGradientStart = Color(0xFF38BDF8),
      bgGradientEnd = Color(0xFF13865F),
      textColor = Color.White,
      defaultUnit = "Piece",
      sampleItems = listOf("رجسٹر (Register)", "کاپی (Notebook)", "پین و مارکر", "فوٹو کاپی رم")
    ),
    BusinessCategoryItem(
      id = "GIFT_TOY_SHOP",
      urduTitle = "گفٹ اینڈ ٹائے شاپ",
      englishTitle = "Gift & Toy Shop",
      emoji = "🧸",
      bgGradientStart = Color(0xFF818CF8),
      bgGradientEnd = Color(0xFF064D3A),
      textColor = Color.White,
      defaultUnit = "Piece",
      sampleItems = listOf("ریموٹ کنٹرول گاڑی", "ٹیڈی بیئر", "گفٹ پیک", "گھڑی")
    ),
    BusinessCategoryItem(
      id = "FARM_DAIRY",
      urduTitle = "فارم اینڈ ڈیری ڈسٹری بیوٹرز",
      englishTitle = "Farm & Dairy",
      emoji = "🐄",
      bgGradientStart = Color(0xFFFB923C),
      bgGradientEnd = Color(0xFFC2410C),
      textColor = Color.White,
      defaultUnit = "Liter",
      sampleItems = listOf("خالص دودھ (Milk)", "دیسی دہی (Yogurt)", "دیسی مکھن", "انڈے کریٹ")
    ),
    BusinessCategoryItem(
      id = "ELECTRONICS_ELECTRIC",
      urduTitle = "الیکٹرانکس اینڈ الیکٹرک",
      englishTitle = "Electronics & Electric",
      emoji = "🔌",
      bgGradientStart = Color(0xFFA3E635),
      bgGradientEnd = Color(0xFF4D7C0F),
      textColor = Color(0xFF1E293B),
      defaultUnit = "Piece",
      sampleItems = listOf("ایل ای ڈی بلب", "پنکھا (Fan)", "تار بنڈل (Wire)", "سوئچ بورڈ")
    ),
    BusinessCategoryItem(
      id = "DISTRIBUTOR",
      urduTitle = "ڈسٹری بیوٹر و ہول سیل",
      englishTitle = "Distributor & Wholesale",
      emoji = "🚚",
      bgGradientStart = Color(0xFFFB7185),
      bgGradientEnd = Color(0xFF9F1239),
      textColor = Color.White,
      defaultUnit = "Bag",
      sampleItems = listOf("50kg چینی بوری", "40kg دال من", "گھی کارٹن", "صابن پیٹی")
    ),
    BusinessCategoryItem(
      id = "SALON_BEAUTY",
      urduTitle = "سیلون و بیوٹی پارلر",
      englishTitle = "Salon & Parlour",
      emoji = "💇‍♂️",
      bgGradientStart = Color(0xFFE879F9),
      bgGradientEnd = Color(0xFFA21CAF),
      textColor = Color.White,
      defaultUnit = "Service",
      sampleItems = listOf("ہیئر کٹنگ (Haircut)", "شیو و خط", "فیشل (Facial)", "ہیئر کلر")
    ),
    BusinessCategoryItem(
      id = "GYM_FITNESS",
      urduTitle = "جم و فٹنس سنٹر",
      englishTitle = "Gym & Fitness Club",
      emoji = "🏋️‍♂️",
      bgGradientStart = Color(0xFF38BDF8),
      bgGradientEnd = Color(0xFF0369A1),
      textColor = Color.White,
      defaultUnit = "Month",
      sampleItems = listOf("ماہانہ فیس", "ایڈمیشن فیس", "پروٹین شیک", "پرسنل ٹریننگ")
    ),
    BusinessCategoryItem(
      id = "LAPTOP_REPAIR",
      urduTitle = "لیپ ٹاپ و کمپیوٹر ریپیئر",
      englishTitle = "Laptop & Computer Repair",
      emoji = "💻",
      bgGradientStart = Color(0xFF64748B),
      bgGradientEnd = Color(0xFF334155),
      textColor = Color.White,
      defaultUnit = "Job",
      sampleItems = listOf("ونڈوز انسٹالیشن", "ایس ایس ڈی اپگریڈ", "مدر بورڈ ریپیئر", "چارجر")
    ),
    BusinessCategoryItem(
      id = "CROCKERY_STORE",
      urduTitle = "کراکری و برتن سٹور",
      englishTitle = "Crockery & Utensils",
      emoji = "🍽️",
      bgGradientStart = Color(0xFFFBBF24),
      bgGradientEnd = Color(0xFFB45309),
      textColor = Color.White,
      defaultUnit = "Set",
      sampleItems = listOf("ڈنر سیٹ (Dinner Set)", "ٹی سیٹ (Tea Set)", "پریشر ککر", "نان اسٹک پین")
    ),
    BusinessCategoryItem(
      id = "AUTO_SHOWROOM",
      urduTitle = "کار شو روم و آٹو پارٹس",
      englishTitle = "Showroom & Auto Parts",
      emoji = "🚗",
      bgGradientStart = Color(0xFF94A3B8),
      bgGradientEnd = Color(0xFF475569),
      textColor = Color.White,
      defaultUnit = "Unit",
      sampleItems = listOf("گاڑی بکنگ ایڈوانس", "انجن آئل", "بریک پیڈز", "کار پالش")
    )
  )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BestForBusinessShowcase(
  appLanguage: AppLanguage,
  selectedCategory: String? = null,
  onSelectCategory: (BusinessCategoryItem) -> Unit,
  modifier: Modifier = Modifier
) {
  val isUrdu = appLanguage == AppLanguage.URDU

  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("best_for_business_showcase")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      // Header matching the user screenshot banner: "• Best For •"
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .weight(1f)
            .height(1.dp)
            .background(Color(0xFFCBD5E1))
        )
        Row(
          modifier = Modifier.padding(horizontal = 10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFF086B4D)))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isUrdu) "ہر کاروبار کیلئے بہترین (Best For All Shops)" else "• Best For All Businesses •",
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF0F172A),
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.width(6.dp))
          Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFF086B4D)))
        }
        Box(
          modifier = Modifier
            .weight(1f)
            .height(1.dp)
            .background(Color(0xFFCBD5E1))
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = if (isUrdu)
          "اپنی دکان منتخب کریں — مناسب اوزان (0.25kg، 0.5kg، 40kg من، 50kg بوری، گز، سروسز) فوری سیٹ ہو جائیں گے"
        else
          "Select your business type — automatic units (Kg, 0.25kg, 0.5kg, 40kg, 50kg, Gaz, Services) adjust instantly",
        fontSize = 10.5.sp,
        color = Color(0xFF64748B),
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth()
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Horizontal Scrolling Category Pills exactly as in screenshot
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        BusinessCategoryList.allCategories.chunked(2).forEach { pair ->
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            pair.forEach { cat ->
              CategoryPill(
                item = cat,
                isUrdu = isUrdu,
                isSelected = selectedCategory == cat.id || selectedCategory == cat.urduTitle,
                onClick = { onSelectCategory(cat) }
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun CategoryPill(
  item: BusinessCategoryItem,
  isUrdu: Boolean,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = Color.Transparent,
    border = if (isSelected) androidx.compose.foundation.BorderStroke(2.5.dp, Color(0xFF086B4D)) else null,
    modifier = Modifier
      .clickable { onClick() }
      .testTag("pill_${item.id}")
  ) {
    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(12.dp))
        .background(
          Brush.horizontalGradient(
            colors = listOf(item.bgGradientStart, item.bgGradientEnd)
          )
        )
        .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Text(text = item.emoji, fontSize = 16.sp)
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (isUrdu) item.urduTitle else item.englishTitle,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = item.textColor
        )
        if (isSelected) {
          Spacer(modifier = Modifier.width(6.dp))
          Icon(
            imageVector = Icons.Default.Check,
            contentDescription = null,
            tint = item.textColor,
            modifier = Modifier.size(14.dp)
          )
        }
      }
    }
  }
}
