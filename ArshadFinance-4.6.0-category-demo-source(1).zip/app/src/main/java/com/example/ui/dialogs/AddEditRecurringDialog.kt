package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Account
import com.example.data.model.RecurringFrequency
import com.example.data.model.RecurringTransaction
import com.example.data.model.TransactionType
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AddEditRecurringDialog(
  recurring: RecurringTransaction?,
  accounts: List<Account>,
  currencySymbol: String,
  onDismiss: () -> Unit,
  onSave: (
    id: Long,
    title: String,
    amount: Double,
    type: TransactionType,
    category: String,
    icon: String,
    accountName: String,
    frequency: RecurringFrequency,
    startDateMillis: Long,
    endDateMillis: Long?,
    nextExecutionDateMillis: Long,
    note: String
  ) -> Unit,
  onDelete: ((RecurringTransaction) -> Unit)? = null
) {
  val isEditing = recurring != null
  val dateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())

  var title by remember { mutableStateOf(recurring?.title ?: "") }
  var amountText by remember { mutableStateOf(recurring?.amount?.let { String.format("%.2f", it) } ?: "") }
  var selectedType by remember { mutableStateOf(recurring?.type ?: TransactionType.EXPENSE) }
  var selectedFrequency by remember { mutableStateOf(recurring?.frequency ?: RecurringFrequency.MONTHLY) }
  var selectedCategory by remember { mutableStateOf(recurring?.category ?: "Subscriptions") }
  var selectedIcon by remember { mutableStateOf(recurring?.icon ?: "🔄") }
  var selectedAccount by remember { mutableStateOf(recurring?.accountName ?: accounts.firstOrNull()?.name ?: "Main Checking") }

  var startDateText by remember {
    mutableStateOf(
      if (recurring != null) dateFormat.format(Date(recurring.startDateMillis))
      else dateFormat.format(Date())
    )
  }

  var hasEndDate by remember { mutableStateOf(recurring?.endDateMillis != null) }
  var endDateText by remember {
    mutableStateOf(
      if (recurring?.endDateMillis != null) dateFormat.format(Date(recurring.endDateMillis))
      else "Dec 31, 2026"
    )
  }

  var note by remember { mutableStateOf(recurring?.note ?: "") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val categories = listOf(
    Pair("Subscriptions", "📺"),
    Pair("Salary & Income", "💼"),
    Pair("Bills & Utilities", "⚡"),
    Pair("Rent & Housing", "🏠"),
    Pair("Health & Gym", "🏋️"),
    Pair("Groceries", "🛒"),
    Pair("Insurance", "🛡️"),
    Pair("Investments", "📈"),
    Pair("Education", "📚")
  )

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(28.dp))
        .testTag("add_edit_recurring_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(24.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isEditing) "Edit Recurring Rule" else "New Recurring Rule",
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Type Selector (Expense / Income)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(12.dp))
              .background(if (selectedType == TransactionType.EXPENSE) ExpenseRed else Color(0xFFF2F3F7))
              .clickable { selectedType = TransactionType.EXPENSE }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Recurring Expense",
              style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (selectedType == TransactionType.EXPENSE) Color.White else TextPrimary
              )
            )
          }

          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(12.dp))
              .background(if (selectedType == TransactionType.INCOME) IncomeGreen else Color(0xFFF2F3F7))
              .clickable { selectedType = TransactionType.INCOME }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Recurring Income",
              style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (selectedType == TransactionType.INCOME) Color.White else TextPrimary
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Title / Source Name") },
          placeholder = { Text("e.g. Netflix, Astute Payroll, Rent") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_recurring_title")
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("Amount ($currencySymbol)") },
          placeholder = { Text("0.00") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_recurring_amount")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Frequency Selector
        Text(
          text = "Recurrence Frequency",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
        )

        Spacer(modifier = Modifier.height(6.dp))

        val freqScroll = rememberScrollState()
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(freqScroll),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          RecurringFrequency.values().forEach { freq ->
            val isSelected = selectedFrequency == freq
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable { selectedFrequency = freq }
                .padding(horizontal = 12.dp, vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = freq.displayName,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Category Selector
        Text(
          text = "Category",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
        )

        Spacer(modifier = Modifier.height(6.dp))

        val catScroll = rememberScrollState()
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(catScroll),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          categories.forEach { (catName, icon) ->
            val isSelected = selectedCategory == catName
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable {
                  selectedCategory = catName
                  selectedIcon = icon
                }
                .padding(horizontal = 12.dp, vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "$icon $catName",
                style = MaterialTheme.typography.bodySmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextPrimary
                )
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Account Selector
        if (accounts.isNotEmpty()) {
          Text(
            text = "Payment / Deposit Account",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
          )
          Spacer(modifier = Modifier.height(6.dp))
          val accScroll = rememberScrollState()
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(accScroll),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            accounts.forEach { acc ->
              val isSelected = selectedAccount == acc.name
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(14.dp))
                  .background(if (isSelected) NavyBluePrimary else Color(0xFFF2F3F7))
                .clickable { selectedAccount = acc.name }
                .padding(horizontal = 12.dp, vertical = 8.dp)
              ) {
                Text(
                  text = acc.name,
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) Color.White else TextPrimary
                  )
                )
              }
            }
          }
          Spacer(modifier = Modifier.height(14.dp))
        }

        // Start Date
        OutlinedTextField(
          value = startDateText,
          onValueChange = { startDateText = it },
          label = { Text("Start Date") },
          placeholder = { Text("e.g. Aug 20, 2026") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("input_recurring_start_date")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Optional End Date
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth()
        ) {
          Checkbox(
            checked = hasEndDate,
            onCheckedChange = { hasEndDate = it },
            colors = CheckboxDefaults.colors(checkedColor = NavyBluePrimary)
          )
          Text(
            text = "Specify End Date (optional)",
            style = MaterialTheme.typography.bodyMedium.copy(
              fontWeight = FontWeight.Medium,
              color = TextPrimary
            ),
            modifier = Modifier.clickable { hasEndDate = !hasEndDate }
          )
        }

        if (hasEndDate) {
          OutlinedTextField(
            value = endDateText,
            onValueChange = { endDateText = it },
            label = { Text("End Date") },
            placeholder = { Text("e.g. Dec 31, 2026") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().testTag("input_recurring_end_date")
          )
          Spacer(modifier = Modifier.height(10.dp))
        }

        OutlinedTextField(
          value = note,
          onValueChange = { note = it },
          label = { Text("Notes / Memo (optional)") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth()
        )

        if (errorMessage != null) {
          Text(
            text = errorMessage ?: "",
            color = ExpenseRed,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 8.dp)
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (isEditing && onDelete != null && recurring != null) {
            IconButton(
              onClick = { onDelete(recurring) },
              modifier = Modifier.testTag("delete_recurring_button")
            ) {
              Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete Recurring", tint = ExpenseRed)
            }
          } else {
            Spacer(modifier = Modifier.width(8.dp))
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onDismiss) {
              Text(text = "Cancel", color = TextSecondary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = {
                val parsedAmount = amountText.toDoubleOrNull()
                if (title.isBlank()) {
                  errorMessage = "Please enter a title or vendor name"
                } else if (parsedAmount == null || parsedAmount <= 0) {
                  errorMessage = "Please enter a valid amount"
                } else {
                  val startMillis = try {
                    dateFormat.parse(startDateText)?.time ?: System.currentTimeMillis()
                  } catch (e: Exception) {
                    System.currentTimeMillis()
                  }

                  val endMillis = if (hasEndDate) {
                    try {
                      dateFormat.parse(endDateText)?.time
                    } catch (e: Exception) {
                      null
                    }
                  } else null

                  val nextExecution = recurring?.nextExecutionDateMillis ?: startMillis

                  onSave(
                    recurring?.id ?: 0L,
                    title.trim(),
                    parsedAmount,
                    selectedType,
                    selectedCategory,
                    selectedIcon,
                    selectedAccount,
                    selectedFrequency,
                    startMillis,
                    endMillis,
                    nextExecution,
                    note.trim()
                  )
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.testTag("save_recurring_button")
            ) {
              Text(text = if (isEditing) "Update Rule" else "Create Rule")
            }
          }
        }
      }
    }
  }
}
