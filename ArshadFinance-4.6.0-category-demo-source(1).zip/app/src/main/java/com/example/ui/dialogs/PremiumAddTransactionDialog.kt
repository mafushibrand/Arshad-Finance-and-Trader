package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.*

@Composable
fun AddTransactionDialog(initialType: TransactionType, accounts: List<Account>, currencySymbol: String,
  onDismiss: () -> Unit, onSave: (String,Double,TransactionType,String,String,String,String,String,String,String,String) -> Unit,
  appLanguage: AppLanguage = AppLanguage.ENGLISH, initialAccount: String = "") {
  val urdu=appLanguage==AppLanguage.URDU; fun t(en:String,ur:String)=if(urdu)ur else en
  var title by remember {mutableStateOf("")}; var amount by remember {mutableStateOf("")}; var type by remember {mutableStateOf(initialType)}
  var account by remember {mutableStateOf(initialAccount.ifBlank {accounts.firstOrNull()?.name ?: ""})}; var category by remember {mutableStateOf("")}
  var notes by remember {mutableStateOf("")}; var recipient by remember {mutableStateOf("")}; var ref by remember {mutableStateOf("")}
  var method by remember {mutableStateOf("Cash")}; var error by remember {mutableStateOf("")}; var advanced by remember {mutableStateOf(false)}
  if(advanced) {LegacyAddTransactionDialog(initialType,accounts,currencySymbol,onDismiss,onSave);return}
  BusinessForm(if(type==TransactionType.EXPENSE)t("Add Expense / Payment","خرچہ / ادائیگی شامل کریں") else t("Receive Money / Income","رقم وصول / آمدن"),t("Save entry","اندراج محفوظ کریں"),onDismiss,{
    val value=amount.toDoubleOrNull()
    if(title.isBlank()||value==null||!value.isFinite()||value<=0||accounts.none {it.name==account}) error=t("Enter title, amount and select an account","نام، درست رقم اور اکاؤنٹ منتخب کریں")
    else onSave(title.trim(),value,type,category.ifBlank {if(type==TransactionType.EXPENSE) "Expense" else "Income"},if(type==TransactionType.EXPENSE)"💸" else "💵",account,notes,recipient,method,"",ref)
  }) {
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {FilterChip(type==TransactionType.EXPENSE,{type=TransactionType.EXPENSE},label={Text(t("Expense","خرچہ"))});FilterChip(type==TransactionType.INCOME,{type=TransactionType.INCOME},label={Text(t("Income","آمدن"))})}
    BusinessField(title,t("Description","تفصیل")){title=it};BusinessField(amount,t("Amount ($currencySymbol)","رقم ($currencySymbol)"),true){amount=it}
    BusinessChoice(account,t("Cash / bank / wallet account","کیش / بینک / والٹ اکاؤنٹ"),accounts.map {it.name}) {account=it}
    BusinessChoice(method,t("Payment method","ادائیگی کا طریقہ"),listOf("Cash","Bank","Card","JazzCash","EasyPaisa","Raast","Other")) {method=it}
    BusinessField(category,t("Category","قسم")){category=it};BusinessField(recipient,t("Paid to / received from","کس کو دیا / کس سے لیا")){recipient=it}
    BusinessField(ref,t("Transaction reference","ادائیگی حوالہ")){ref=it};BusinessField(notes,t("Notes","نوٹ")){notes=it}
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
    TextButton(onClick={advanced=true}) {Text(t("Receipt image / voice and advanced tools","رسید تصویر / آواز اور مزید ٹولز"))}
  }
}
