package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.*
import com.example.business.*
import com.example.data.model.*
import com.example.ui.dialogs.*
import org.json.JSONObject
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BusinessOperationsScreen(state: FinanceUiState, viewModel: FinanceViewModel) {
  val area by viewModel.operationsArea.collectAsState()
  if(area=="commerce") { TradeWorkspaceScreen(state,viewModel,{viewModel.operationsArea.value="hub"});return }
  if(area=="advanced") { AdvancedWorkspaceScreen(state,viewModel,{viewModel.operationsArea.value="hub"});return }
  val urdu=state.appLanguage==AppLanguage.URDU
  fun text(en: String, ur: String)=if(urdu) ur else en
  val sections=linkedMapOf("JOB" to text("Jobs","جاب کارڈ"),"APPOINTMENT" to text("Appointments","اپائنٹمنٹ"),"BOM" to text("Recipes / BOM","ریسپی / بی او ایم"),"PRODUCTION" to text("Production","پیداوار"),"SUPPLIER" to text("Suppliers","سپلائر"),"MOVEMENTS" to text("Stock history","اسٹاک تاریخ"),"QUOTATION" to text("Quotations","کوٹیشن"),"ORDER" to text("Orders","آرڈر"),"CHALLAN" to text("Challans","چالان"),"PROJECT" to text("Projects","پروجیکٹ"),"RENTAL" to text("Rentals","کرایہ"),"SUBSCRIPTION" to text("Recurring dues","ماہانہ واجبات"),"BRANCH" to text("Branches","برانچ"),"WAREHOUSE" to text("Warehouses","گودام"),"AUDIT" to text("Audit log","آڈٹ لاگ"),"UNITS" to text("Units","یونٹ"),"DEMO" to text("Demo workspaces","ڈیمو کاروبار")).filterKeys {when(it){"BOM","PRODUCTION"->state.features.manufacturing;"RENTAL"->state.features.rentals;"APPOINTMENT"->state.features.appointments;else->true}}
  var section by remember { mutableStateOf("JOB") }
  LaunchedEffect(sections.keys) {if(section !in sections)section="JOB"}
  var query by remember { mutableStateOf("") }
  var form by remember { mutableStateOf(false) }
  var billing by remember {mutableStateOf<BusinessRecord?>(null)}
  var selected by remember { mutableStateOf<BusinessRecord?>(null) }
  var message by remember { mutableStateOf("") }
  val actor=state.userRole.name.lowercase()
  val writable=state.userRole==UserRole.OWNER
  fun result(error: String?) { message=error ?: text("Saved successfully","محفوظ ہو گیا"); if(error==null) {form=false;selected=null} }
  PremiumPage(text("Business workspace","کاروباری مرکز"),BusinessLibrary.find(state.businessProfile.templateId).label(urdu),Icons.Default.BusinessCenter,
    footer={ if(writable && section !in listOf("MOVEMENTS","AUDIT","UNITS","DEMO")) PremiumButton(if(section=="PRODUCTION") text("Record production","پیداوار درج کریں") else text("Add ${sections[section]}","نیا ریکارڈ شامل کریں"),{form=true}) }) {
    item { PremiumButton(text("Sales, purchases, returns & warehouses","فروخت، خریداری، واپسی اور گودام"),{viewModel.openCommerce()}) }
    item { PremiumButton(text("Production WIP, rentals & appointments","پیداوار، کرایہ اور اپائنٹمنٹ"),{viewModel.operationsArea.value="advanced"}) }
    item { Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) { sections.forEach { (key,label) -> FilterChip(section==key,{section=key;query=""},label={Text(label)}) } } }
    item { SearchBox(query,text("Search records","ریکارڈ تلاش کریں")){query=it} }
    if(message.isNotBlank()) item { Text(message,color=MaterialTheme.colorScheme.primary) }
    if(!writable) item { Text(text("Owner access is required to change business records.","کاروباری ریکارڈ تبدیل کرنے کے لیے مالک کی رسائی ضروری ہے۔")) }
    when(section) {
      "MOVEMENTS" -> {
        item { Text(text("Every stock change is captured automatically. Quantities use base units.","ہر اسٹاک تبدیلی خود درج ہوتی ہے۔ مقدار بنیادی یونٹ میں ہے۔")) }
        items(state.stockMovements.filter { movement -> query.isBlank() || state.inventoryItems.find {it.id==movement.itemId}?.name?.contains(query,true)==true }.take(500),key={it.id}) { m ->
          val item=state.inventoryItems.find {it.id==m.itemId}
          ListTile(item?.name ?: "#${m.itemId}","${m.reason} • ${SimpleDateFormat("dd MMM HH:mm",Locale.getDefault()).format(Date(m.createdAt))}",Icons.Default.SwapVert, controls={ Text("${if(m.quantity>0) "+" else ""}${m.quantity} ${item?.unit ?: ""}") })
        }
      }
      "UNITS" -> {
        item { UnitCalculator(urdu) }
        BusinessLibrary.units.forEach { (group,units) -> item { Metric(group,units.filter {it.contains(query,true)}.joinToString(" • ")) } }
      }
      "DEMO" -> {
        item { Text(text("Load category examples. Existing records are kept; only missing sample items are added.","کاروباری نمونے شامل کریں۔ موجودہ ریکارڈ محفوظ رہیں گے اور صرف غیر موجود نمونے شامل ہوں گے۔")) }
        items(BusinessLibrary.templates, key = { it.id }) { template ->
          val sampleDescription = if (template.sector == "Services")
            text("Sample services, rates and job examples", "نمونہ سروسز، نرخ اور کام کی مثالیں")
          else
            text("Sample products, stock and category fields", "نمونہ مصنوعات، اسٹاک اور کاروباری تفصیلات")
          ListTile(
            template.label(urdu), sampleDescription, Icons.Default.Science,
            click = {
              if (writable) selected = BusinessRecord(
                id = template.id, kind = "DEMO", title = template.label(urdu)
              )
            }
          )
        }
      }
      "SUPPLIER" -> {
        val suppliers=state.businessRecords.filter { it.kind=="SUPPLIER" && !it.archived && it.title.contains(query,true) }
        if(suppliers.isEmpty()) item { EmptyList(text("No suppliers yet","ابھی کوئی سپلائر نہیں"),text("Add a supplier to start a ledger","کھاتہ شروع کرنے کے لیے سپلائر شامل کریں"),Icons.Default.LocalShipping) }
        items(suppliers,key={it.id}) { supplier ->
          val due=state.businessRecords.filter {it.party==supplier.title}.sumOf {if(it.kind=="SUPPLIER_DEBIT")it.amount else if(it.kind=="SUPPLIER_CREDIT")-it.amount else 0.0}
          ListTile(supplier.title,supplier.party,Icons.Default.LocalShipping,click={selected=supplier},controls={Text(state.money(due),fontWeight=FontWeight.Bold)})
        }
      }
      else -> {
        val rows=state.businessRecords.filter {it.kind==section && !it.archived && (it.title.contains(query,true)||it.party.contains(query,true))}
        if(rows.isEmpty()) item { EmptyList(text("No records yet","ابھی کوئی ریکارڈ نہیں"),text("Add your first record","پہلا ریکارڈ شامل کریں"),Icons.Default.Description) }
        items(rows,key={it.id}) { record -> ListTile(record.title,"${record.party} • ${record.status}",Icons.Default.Description,click={selected=record},controls={if(record.amount>0)Text(state.money(record.amount))}) }
      }
    }
  }
  if(form && writable) OperationForm(section,state,onDismiss={form=false},save={title,party,amount,payload ->
    viewModel.businessAction({create(section,title,party,amount,payload,actor)}) {result(it)}
  },produce={id,qty,waste -> viewModel.businessAction({produce(id,qty,waste,actor)}) {result(it)}})
  billing?.let {work->WorkBillingForm(work,state,{billing=null}){customer,parts,labour,period->viewModel.tradeAction({billWork(work.id,customer,parts,labour,period,actor)}){error->result(error);if(error==null)billing=null}}}
  selected?.let { record ->
    when(record.kind) {
      "DEMO" -> AlertDialog(onDismissRequest={selected=null},title={Text(text("Load demo?","ڈیمو شامل کریں؟"))},text={Text(record.title)},confirmButton={TextButton(onClick={viewModel.seedTemplateDemo(record.id) {result(it)}}){Text(text("Load","شامل کریں"))}},dismissButton={TextButton(onClick={selected=null}){Text(text("Cancel","منسوخ"))}})
      "SUPPLIER" -> SupplierStatement(record,state,onDismiss={selected=null},post={amount,payment,note -> viewModel.businessAction({supplierEntry(record.title,amount,payment,note,actor)}) {result(it)}})
      else -> AlertDialog(onDismissRequest={selected=null},title={Text(record.title)},text={Column { Text("${record.party}\n${record.status}\n${state.money(record.amount)}"); val data=JSONObject(record.payload)
        listOf("schedule" to text("Schedule","شیڈول"),"technician" to text("Staff / device / site","عملہ / ڈیوائس / سائٹ"),"notes" to text("Notes","نوٹ"),"outputQuantity" to text("Output quantity","پیداوار مقدار"),"wastage" to text("Wastage","ضیاع")).forEach { (key,label) -> val value=data.optString(key);if(value.isNotBlank())Text("$label: $value") }
        if(record.kind=="BOM") { val rows=data.optJSONArray("ingredients");if(rows!=null)for(i in 0 until rows.length()){val line=rows.getJSONObject(i);Text("${state.inventoryItems.find {it.id==line.optLong("itemId")}?.name ?: ""}: ${line.optDouble("quantity")}")} } }},confirmButton={if(writable&&record.kind in listOf("JOB","APPOINTMENT","PROJECT","SUBSCRIPTION")&&record.status !in listOf("INVOICED","CANCELLED")) TextButton(onClick={selected=null;billing=record}){Text(text("Create invoice / dues","بل / واجبات بنائیں"))} else if(writable && record.kind !in listOf("AUDIT","PRODUCTION") && record.status!="COMPLETED") TextButton(onClick={viewModel.businessAction({complete(record.id,actor)}) {result(it)}}){Text(text("Mark complete","مکمل کریں"))}},dismissButton={TextButton(onClick={selected=null}){Text(text("Close","بند"))}})
    }
  }
}

@Composable
private fun UnitCalculator(urdu: Boolean) {
  var qty by remember {mutableStateOf("1")}; var factor by remember {mutableStateOf("24")}
  var result by remember {mutableStateOf("")}
  Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
    Text(if(urdu) "یونٹ تبدیلی کیلکولیٹر" else "Unit conversion calculator",style=MaterialTheme.typography.titleMedium)
    BusinessField(qty,if(urdu) "خرید مقدار" else "Purchase quantity",true){qty=it}
    BusinessField(factor,if(urdu) "ایک یونٹ کی بنیادی مقدار" else "Base quantity per unit",true){factor=it}
    Button(onClick={result=runCatching {BusinessLibrary.convert(qty,factor).stripTrailingZeros().toPlainString()}.getOrElse{it.message ?: "Invalid"}}){Text(if(urdu) "تبدیل کریں" else "Convert")}; if(result.isNotBlank()) Text(result)
  }
}

@Composable
private fun OperationForm(kind: String,state: FinanceUiState,onDismiss: () -> Unit,save: (String,String,Double,String) -> Unit,produce: (String,Double,Double) -> Unit) {
  val urdu=state.appLanguage==AppLanguage.URDU; fun t(en:String,ur:String)=if(urdu)ur else en
  var title by remember {mutableStateOf("")}; var party by remember {mutableStateOf("")}; var amount by remember {mutableStateOf("0")}; var error by remember {mutableStateOf("")}
  var notes by remember {mutableStateOf("")}; var schedule by remember {mutableStateOf("")}; var technician by remember {mutableStateOf("")}
  var outputId by remember {mutableStateOf(state.inventoryItems.firstOrNull()?.id ?: 0L)}
  var ingredientId by remember {mutableStateOf(state.inventoryItems.firstOrNull {it.id!=outputId}?.id ?: 0L)}
  var ingredientQty by remember {mutableStateOf("1")}; var ingredients by remember {mutableStateOf(listOf<Pair<Long,Double>>())}
  var bomId by remember {mutableStateOf(state.businessRecords.firstOrNull {it.kind=="BOM"}?.id ?: "")}; var outputQty by remember {mutableStateOf("1")}; var waste by remember {mutableStateOf("0")}
  var branch by remember {mutableStateOf("main")}; var warehouse by remember {mutableStateOf("main")}
  BusinessForm(t("New business record","نیا کاروباری ریکارڈ"),t("Save record","ریکارڈ محفوظ کریں"),onDismiss,{
    val money=amount.toDoubleOrNull(); val qty=outputQty.toDoubleOrNull(); val loss=waste.toDoubleOrNull()
    if(kind=="PRODUCTION") { if(bomId.isBlank()||qty==null||!qty.isFinite()||qty<=0||loss==null||!loss.isFinite()||loss<0) error=t("Select a recipe and valid output/wastage","ریسپی، پیداوار اور ضیاع درست درج کریں") else produce(bomId,qty,loss) }
    else if(title.isBlank()||money==null||!money.isFinite()||money<0) error=t("Enter a title and valid amount","نام اور درست رقم درج کریں")
    else if(kind=="BOM" && (outputId==0L||ingredients.isEmpty())) error=t("Select output and add ingredients","پیداوار اور اجزاء منتخب کریں")
    else { val data=JSONObject().put("notes",notes).put("schedule",schedule).put("technician",technician).put("branch",branch).put("warehouse",warehouse)
      if(kind=="BOM") data.put("outputId",outputId).put("ingredients",JSONArray().apply {ingredients.forEach {put(JSONObject().put("itemId",it.first).put("quantity",it.second))}})
      save(title,party,money,data.toString()) }
  }) {
    if(kind=="PRODUCTION") {
      val boms=state.businessRecords.filter {it.kind=="BOM"}
      BusinessChoice(boms.find {it.id==bomId}?.title ?: "",t("Recipe / BOM","ریسپی"),boms.map {it.title}) {name -> bomId=boms.first {it.title==name}.id}
      BusinessField(outputQty,t("Finished output quantity","تیار پیداوار مقدار"),true){outputQty=it}
      BusinessField(waste,t("Wastage in output units","پیداوار یونٹ میں ضیاع"),true){waste=it}
      Text(t("Ingredients are consumed for output + wastage. Posting is atomic; insufficient stock rejects the whole operation.","اجزاء پیداوار اور ضیاع کے حساب سے کم ہوں گے۔ اسٹاک کم ہونے پر پوری کارروائی محفوظ نہیں ہوگی۔"))
    } else {
      BusinessField(title,t("Name / reference","نام / حوالہ")){title=it}
      BusinessField(party,t(if(kind=="SUPPLIER")"Contact / phone" else "Customer / client", "گاہک / رابطہ")){party=it}
      if(kind!="BOM") BusinessField(amount,t("Amount / estimate","رقم / تخمینہ"),true){amount=it}
      if(kind in listOf("JOB","APPOINTMENT","PROJECT","RENTAL","SUBSCRIPTION")) {
        BusinessField(schedule,t("Date / due date / schedule","تاریخ / آخری تاریخ / شیڈول")){schedule=it}
        BusinessField(technician,t("Technician / staff / vehicle / site","ٹیکنیشن / عملہ / گاڑی / سائٹ")){technician=it}
      }
      if(kind=="BOM") {
        val products=state.inventoryItems
        BusinessChoice(products.find {it.id==outputId}?.name ?: "",t("Finished output item","تیار سامان"),products.map {it.name}) {name -> outputId=products.first {it.name==name}.id}
        BusinessChoice(products.find {it.id==ingredientId}?.name ?: "",t("Ingredient / raw material","جزو / خام مال"),products.filter {it.id!=outputId}.map {it.name}) {name -> ingredientId=products.first {it.name==name}.id}
        BusinessField(ingredientQty,t("Base quantity per 1 output unit","ایک پیداوار یونٹ کے لیے بنیادی مقدار"),true){ingredientQty=it}
        Button(onClick={val q=ingredientQty.toDoubleOrNull(); if(q!=null&&q.isFinite()&&q>0&&ingredientId!=0L&&ingredientId!=outputId) ingredients=ingredients+(ingredientId to q) else error=t("Invalid ingredient quantity","جزو کی مقدار درست نہیں")}) {Text(t("Add ingredient","جزو شامل کریں"))}
        ingredients.forEachIndexed {index,line -> TextButton(onClick={ingredients=ingredients.filterIndexed {i,_->i!=index}}){Text("${products.find {it.id==line.first}?.name}: ${line.second} ×   ${t("Remove","حذف")}")} }
      }
      BusinessField(branch,t("Branch identifier","برانچ شناخت")){branch=it}
      BusinessField(warehouse,t("Warehouse identifier","گودام شناخت")){warehouse=it}
      BusinessField(notes,t("Notes / details","نوٹ / تفصیل")){notes=it}
    }
    if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
  }
}

@Composable
private fun SupplierStatement(supplier: BusinessRecord,state: FinanceUiState,onDismiss: () -> Unit,post: (Double,Boolean,String) -> Unit) {
  val urdu=state.appLanguage==AppLanguage.URDU; fun t(en:String,ur:String)=if(urdu)ur else en
  var amount by remember {mutableStateOf("")}; var note by remember {mutableStateOf("")}; var payment by remember {mutableStateOf(false)}; var error by remember {mutableStateOf("")}
  val entries=state.businessRecords.filter {it.party==supplier.title && it.kind in listOf("SUPPLIER_DEBIT","SUPPLIER_CREDIT")}
  val balance=entries.sumOf {if(it.kind=="SUPPLIER_DEBIT")it.amount else -it.amount}
  BusinessForm(supplier.title,t("Post entry","اندراج محفوظ کریں"),onDismiss,{
    val value=amount.toDoubleOrNull(); if(value==null||!value.isFinite()||value<=0)error=t("Enter a valid amount","درست رقم درج کریں") else if(state.userRole!=UserRole.OWNER)error=t("Owner access required","مالک کی رسائی ضروری ہے") else post(value,payment,note)
  }) {
    Metric(t("Supplier payable","سپلائر کا بقایا"),state.money(balance))
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(!payment,{payment=false},label={Text(t("Bill / opening","بل / ابتدائی بقایا"))}); FilterChip(payment,{payment=true},label={Text(t("Pay cash","کیش ادائیگی"))})}
    BusinessField(amount,t("Amount","رقم"),true){amount=it}; BusinessField(note,t("Reference / note","حوالہ / نوٹ")){note=it}
    if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
    entries.forEach {Text("${it.title} • ${if(it.kind=="SUPPLIER_CREDIT") "−" else "+"}${state.money(it.amount)}")}
  }
}
