package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.FinanceUiState
import com.example.data.model.Invoice
import com.example.business.isServiceItem
import com.example.business.netInvoiceLines
import org.json.JSONObject

@Composable
internal fun BusinessReportDetails(state:FinanceUiState,sales:List<Invoice>,start:Long) {
  var section by remember {mutableStateOf("Stock")}
  val reports=linkedMapOf("Stock" to state.word("Stock valuation / alerts","اسٹاک قیمت / الرٹ"),"Aging" to state.word("Receivable aging","وصولیوں کی مدت"),"Suppliers" to state.word("Purchase / supplier summary","خرید / سپلائر خلاصہ"),"Branches" to state.word("Branch sales","برانچ فروخت"),"Production" to state.word("Production / wastage","پیداوار / ضیاع"),"Rentals" to state.word("Rental deposits / outstanding assets","کرایہ ڈپازٹ / جاری سامان"),"Appointments" to state.word("Appointment schedule","اپائنٹمنٹ شیڈول"),"Services" to state.word("Service billing","سروس بل"),"Profit" to state.word("Estimated gross margin","تخمینی مجموعی منافع"),"Items" to state.word("Item sales / movement","سامان فروخت / حرکت"),"Tax" to state.word("Tax summary","ٹیکس خلاصہ"))
  Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
    com.example.ui.dialogs.BusinessChoice(reports[section] ?: "",state.word("Business report","کاروباری رپورٹ"),reports.values.toList()){name->section=reports.entries.first {it.value==name}.key}
    when(section) {
      "Stock" -> {
        Metric(state.word("Current stock valuation (average cost)","موجودہ اسٹاک قیمت (اوسط لاگت)"),state.money(state.inventoryItems.filter {!it.isServiceItem()}.sumOf {it.currentStock*it.costPrice}))
        state.inventoryItems.filter {it.currentStock<=it.lowStockThreshold&&!it.isServiceItem()}.forEach {Text(state.word("Low stock: ","کم اسٹاک: ")+it.name+" • "+it.currentStock+" "+it.unit)}
        val today=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).apply {timeZone=java.util.TimeZone.getTimeZone("Asia/Karachi")}.format(java.util.Date())
        state.inventoryItems.filter {JSONObject(it.detailsJson).optString("expiry").let {d->d.isNotBlank()&&d<=today}}.forEach {Text(state.word("Expired / expiry today: ","میعاد ختم / آج آخری تاریخ: ")+it.name+" • "+JSONObject(it.detailsJson).optString("expiry"))}
      }
      "Aging" -> {
        Text(state.word("Age is measured from invoice date; opening balances are shown separately.","مدت بل کی تاریخ سے ہے؛ ابتدائی بقایا الگ دکھایا گیا ہے۔"))
        val now=System.currentTimeMillis();val groups=listOf(0L to 30L,31L to 60L,61L to 90L,91L to Long.MAX_VALUE)
        groups.forEach {(low,high)->val total=state.invoices.filter {it.remainingBalance>0 && ((now-it.dateMillis)/86400000).coerceAtLeast(0) in low..high}.sumOf {it.remainingBalance};Metric(if(high==Long.MAX_VALUE)"90+ "+state.word("days","دن") else "$low–$high "+state.word("days","دن"),state.money(total))}
        val opening=state.customers.sumOf {it.currentBalance}-state.invoices.sumOf {it.remainingBalance}
        Metric(state.word("Opening / non-invoice balance","ابتدائی / بل کے علاوہ بقایا"),state.money(opening))
      }
      "Suppliers" -> {
        val purchase=state.businessRecords.filter {it.createdAt>=start}
        Metric(state.word("Net purchase bills","خالص خرید بل"),state.money(purchase.filter {it.kind=="PURCHASE_BILL"}.sumOf {it.amount}-purchase.filter {it.kind=="PURCHASE_RETURN"}.sumOf {it.amount}))
        state.businessRecords.filter {it.kind=="SUPPLIER"&&!it.archived}.forEach {supplier->val due=state.businessRecords.filter {it.party==supplier.title}.sumOf {if(it.kind=="SUPPLIER_DEBIT")it.amount else if(it.kind=="SUPPLIER_CREDIT")-it.amount else 0.0};Metric(supplier.title,state.money(due))}
      }
      "Branches" -> sales.groupBy {JSONObject(it.detailsJson).optString("branch","main")}.forEach {(name,rows)->Metric(name,state.money(rows.sumOf {it.netTotal()}))}
      "Production" -> {
        Metric(state.word("Current WIP cost","زیر تیاری مال لاگت"),state.money(state.businessRecords.filter {it.kind=="PRODUCTION_ORDER"&&it.status=="WIP"}.sumOf {it.amount}))
        val rows=state.businessRecords.filter {it.kind=="PRODUCTION"&&it.createdAt>=start}
        Metric(state.word("Recorded production cost","درج پیداوار لاگت"),state.money(rows.sumOf {it.amount}))
        rows.groupBy {it.title}.forEach {(title,group)->val output=group.sumOf {JSONObject(it.payload).optDouble("outputQuantity")};val waste=group.sumOf {JSONObject(it.payload).optDouble("wastage")};Text(title+" • "+state.word("Output ","پیداوار ")+output+" • "+state.word("Wastage ","ضیاع ")+waste)}
      }
      "Rentals" -> {
        Metric(state.word("Refundable deposits held","قابل واپسی ڈپازٹ"),state.money(state.businessRecords.sumOf {when(it.kind){"RENTAL_DEPOSIT"->it.amount;"RENTAL_DEPOSIT_APPLIED","RENTAL_DEPOSIT_REFUND"->-it.amount;else->0.0}}))
        state.businessRecords.filter {it.kind=="RENTAL_CONTRACT"&&it.status=="ACTIVE"}.forEach {r->val d=JSONObject(r.payload);Text(r.title+" • "+r.party+" • "+d.optDouble("quantity")+" • "+businessTime(d.getLong("due")))}
      }
      "Appointments" -> state.businessRecords.filter {it.kind=="APPOINTMENT"&&JSONObject(it.payload).has("start")}.sortedBy {JSONObject(it.payload).getLong("start")}.forEach {r->val d=JSONObject(r.payload);Text(businessTime(d.getLong("start"))+" • "+r.title+" • "+d.optString("staff")+" • "+workflowStatus(state,r.status))}
      "Services" -> state.businessRecords.filter {it.kind in listOf("JOB_BILLING","DUES_POSTING")&&it.createdAt>=start}.forEach {Metric(it.title+" • "+it.party,state.money(it.amount))}
      "Profit" -> {
        val cost=sales.sumOf {invoice->netInvoiceLines(invoice,state.businessRecords){id->state.inventoryItems.find {it.id==id}?.costPrice ?: 0.0}.sumOf {it.cost}}
        Metric(state.word("Estimated gross margin","تخمینی مجموعی منافع"),state.money(sales.sumOf {it.netTotal()-it.taxAmount*(if(it.grandTotal>0)it.netTotal()/it.grandTotal else 0.0)}-cost))
        Text(state.word("New invoices keep sale-time costs; older invoices use current costs. Service labour costs are excluded.","نئے بل میں فروخت وقت کی لاگت محفوظ ہے؛ پرانے بل میں موجودہ لاگت۔ سروس کی محنت لاگت شامل نہیں۔"))
      }
      "Items" -> {
        state.inventoryItems.sortedByDescending {item->sales.sumOf {invoice->invoice.parseItems().count {it.itemId==item.id}}}.forEach {item->
          val rows=sales.flatMap {invoice->netInvoiceLines(invoice,state.businessRecords){id->state.inventoryItems.find {it.id==id}?.costPrice ?: 0.0}.filter {it.line.itemId==item.id}}
          val revenue=rows.sumOf {it.revenue}
          Text(item.name+" • "+state.word("Invoice lines: ","بل کی لائنیں: ")+rows.size+" • "+state.word("Net line revenue: ","خالص لائن آمدنی: ")+state.money(revenue))
        }
      }
      "Tax" -> {
        Metric(state.word("Net invoice tax","خالص بل ٹیکس"),state.money(sales.sumOf {if(it.grandTotal>0)it.taxAmount*it.netTotal()/it.grandTotal else 0.0}))
        Text(state.word("Uses your configured invoice rates; this is an operational summary.","یہ آپ کی مقرر کردہ بل شرحوں کا کاروباری خلاصہ ہے۔"))
      }
    }
  }
}
