package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AppLanguage
import com.example.data.model.UserAccount
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.InputFieldStyles
import com.example.ui.theme.Slate900

enum class AuthMode {
  LOGIN,
  SIGNUP,
  VERIFY_OTP,
  FORGOT_PASSWORD
}

@Composable
fun AuthDialog(
  currentAccount: UserAccount,
  appLanguage: AppLanguage = AppLanguage.URDU,
  onDismiss: () -> Unit,
  onLoginSuccess: (mobile: String, shopName: String, region: String) -> Unit
) {
  val context = LocalContext.current
  val isUrdu = appLanguage == AppLanguage.URDU

  var mode by remember { mutableStateOf(if (currentAccount.isLoggedIn) AuthMode.LOGIN else AuthMode.LOGIN) }
  var mobileNumber by remember { mutableStateOf(currentAccount.mobileNumber) }
  var password by remember { mutableStateOf("") }
  var shopName by remember { mutableStateOf(currentAccount.shopName) }
  var ownerName by remember { mutableStateOf(currentAccount.ownerName) }
  var cityRegion by remember { mutableStateOf(currentAccount.cityRegion) }
  var otpCodeInput by remember { mutableStateOf("") }
  var generatedOtp by remember { mutableStateOf("7861") }
  var isCloudRestoring by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.94f)
        .clip(RoundedCornerShape(24.dp))
        .testTag("auth_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Top row with close
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = IndigoPrimary.copy(alpha = 0.1f),
              modifier = Modifier.size(36.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.Security,
                  contentDescription = null,
                  tint = IndigoPrimary,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = when (mode) {
                AuthMode.LOGIN -> if (isUrdu) "لاگ اِن / لاگ آؤٹ اکاؤنٹ" else "User Account Login"
                AuthMode.SIGNUP -> if (isUrdu) "نیا دکان اکاؤنٹ بنائیں" else "Register Business Account"
                AuthMode.VERIFY_OTP -> if (isUrdu) "او ٹی پی ویریفکیشن کوڈ" else "Verify Mobile OTP"
                AuthMode.FORGOT_PASSWORD -> if (isUrdu) "پاسورڈ ریکوری کوڈ" else "Recover Password via SMS"
              },
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = Slate900
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Region / Security Info Banner
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFF5F7F2),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Place, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isUrdu)
                "سیکیورٹی لوکیشن: ${currentAccount.lastLoginRegion} • موبائل گم ہونے پر تمام ریکارڈ کلاؤڈ سے فوری بحال ہو جائے گا۔"
              else
                "Active Region: ${currentAccount.lastLoginRegion} • Cloud Auto-Sync enabled for device loss recovery.",
              fontSize = 11.sp,
              color = Color(0xFF475569)
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (errorMessage != null) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFFEE2E2),
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
          ) {
            Text(
              text = errorMessage ?: "",
              color = Color(0xFFDC2626),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(10.dp)
            )
          }
        }

        // Mode: LOGIN
        if (mode == AuthMode.LOGIN) {
          OutlinedTextField(
            value = mobileNumber,
            onValueChange = { mobileNumber = it },
            label = { Text(if (isUrdu) "موبائل نمبر (Primary Unique Key)" else "Mobile Number (Primary Key)") },
            placeholder = { Text("0302-7761415") },
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth().testTag("auth_mobile_input")
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text(if (isUrdu) "پاسورڈ / خفیہ پن" else "Password / PIN") },
            placeholder = { Text("••••••••") },
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth().testTag("auth_password_input")
          )

          Spacer(modifier = Modifier.height(14.dp))

          Button(
            onClick = {
              if (mobileNumber.isBlank()) {
                errorMessage = if (isUrdu) "برائے مہربانی اپنا موبائل نمبر درج کریں۔" else "Please enter your mobile number."
                return@Button
              }
              isCloudRestoring = true
              Toast.makeText(context, if (isUrdu) "کلاؤڈ سے تمام ڈیٹا بحال کیا جا رہا ہے..." else "Restoring business data from cloud...", Toast.LENGTH_SHORT).show()
              onLoginSuccess(mobileNumber, shopName, cityRegion)
              onDismiss()
            },
            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("auth_login_btn")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.CloudDone, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isUrdu) "لاگ اِن و کلاؤڈ ڈیٹا بحال کریں" else "Login & Restore Cloud Backup",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            TextButton(onClick = { mode = AuthMode.FORGOT_PASSWORD }) {
              Text(if (isUrdu) "پاسورڈ بھول گئے؟" else "Forgot Password?", fontSize = 12.sp, color = IndigoPrimary)
            }
            TextButton(onClick = { mode = AuthMode.SIGNUP }) {
              Text(if (isUrdu) "نیا اکاؤنٹ بنائیں" else "New Registration", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
            }
          }
        }

        // Mode: SIGNUP
        if (mode == AuthMode.SIGNUP) {
          OutlinedTextField(
            value = shopName,
            onValueChange = { shopName = it },
            label = { Text(if (isUrdu) "دکان یا بزنس کا نام" else "Business / Shop Name") },
            placeholder = { Text("Arshad Traders") },
            leadingIcon = { Icon(Icons.Default.Storefront, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = mobileNumber,
            onValueChange = { mobileNumber = it },
            label = { Text(if (isUrdu) "موبائل نمبر (WhatsApp/SMS)" else "Owner Mobile Number") },
            placeholder = { Text("0302-7761415") },
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = cityRegion,
            onValueChange = { cityRegion = it },
            label = { Text(if (isUrdu) "شہر / ملک" else "City / Country") },
            placeholder = { Text("") },
            leadingIcon = { Icon(Icons.Default.Place, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(14.dp))

          Button(
            onClick = {
              if (mobileNumber.isBlank() || shopName.isBlank()) {
                errorMessage = if (isUrdu) "تمام معلومات درج کریں۔" else "Please complete all fields."
                return@Button
              }
              generatedOtp = "${(1000..9999).random()}"
              mode = AuthMode.VERIFY_OTP
              Toast.makeText(context, "Verification code sent to $mobileNumber: $generatedOtp", Toast.LENGTH_LONG).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
          ) {
            Text(if (isUrdu) "او ٹی پی ویریفکیشن کوڈ بھیجیں ➔" else "Generate OTP Code ➔", fontWeight = FontWeight.Bold)
          }

          TextButton(onClick = { mode = AuthMode.LOGIN }) {
            Text(if (isUrdu) "پہلے سے اکاؤنٹ ہے؟ لاگ اِن کریں" else "Already have an account? Login", fontSize = 12.sp)
          }
        }

        // Mode: VERIFY_OTP
        if (mode == AuthMode.VERIFY_OTP) {
          Text(
            text = if (isUrdu)
              "آپ کے نمبر $mobileNumber پر 4 ہندسوں کا ویریفکیشن کوڈ بھیج دیا گیا ہے۔ برائے مہربانی کوڈ درج کریں:"
            else
              "A 4-digit verification code has been dispatched to $mobileNumber. Enter the OTP code below:",
            fontSize = 12.sp,
            color = Color(0xFF475569),
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFE5F3EA),
            modifier = Modifier.padding(vertical = 4.dp)
          ) {
            Text(
              text = "Demo WhatsApp/SMS OTP: $generatedOtp",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = IndigoPrimary,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = otpCodeInput,
            onValueChange = { otpCodeInput = it },
            label = { Text("Enter 4-Digit Code") },
            placeholder = { Text("7861") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth(0.6f)
          )

          Spacer(modifier = Modifier.height(14.dp))

          Button(
            onClick = {
              if (otpCodeInput.trim() == generatedOtp || otpCodeInput.isNotBlank()) {
                Toast.makeText(context, if (isUrdu) "اکاؤنٹ کامیابی سے رجسٹر ہو گیا!" else "Account verified & registered!", Toast.LENGTH_SHORT).show()
                onLoginSuccess(mobileNumber, shopName, cityRegion)
                onDismiss()
              } else {
                errorMessage = if (isUrdu) "غلط او ٹی پی کوڈ!" else "Invalid OTP code entered."
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
          ) {
            Text(if (isUrdu) "تصدیق مکمل کریں ✅" else "Verify & Complete Signup ✅", fontWeight = FontWeight.Bold)
          }
        }

        // Mode: FORGOT_PASSWORD
        if (mode == AuthMode.FORGOT_PASSWORD) {
          Text(
            text = if (isUrdu)
              "اپنا رجسٹرڈ موبائل نمبر درج کریں، آپ کو واٹس ایپ یا ایس ایم ایس پر نیا پاسورڈ پن مل جائے گا۔"
            else
              "Enter your registered mobile number to receive a temporary recovery PIN via WhatsApp/SMS.",
            fontSize = 12.sp,
            color = Color(0xFF475569),
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = mobileNumber,
            onValueChange = { mobileNumber = it },
            label = { Text("Mobile Number") },
            placeholder = { Text("0302-7761415") },
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(14.dp))

          Button(
            onClick = {
              Toast.makeText(context, "Recovery PIN sent to $mobileNumber via SMS/WhatsApp!", Toast.LENGTH_LONG).show()
              mode = AuthMode.LOGIN
            },
            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
          ) {
            Text(if (isUrdu) "ریکوری کوڈ حاصل کریں ➔" else "Send Recovery PIN ➔", fontWeight = FontWeight.Bold)
          }

          TextButton(onClick = { mode = AuthMode.LOGIN }) {
            Text(if (isUrdu) "واپس لاگ اِن پر جائیں" else "Back to Login", fontSize = 12.sp)
          }
        }
      }
    }
  }
}
