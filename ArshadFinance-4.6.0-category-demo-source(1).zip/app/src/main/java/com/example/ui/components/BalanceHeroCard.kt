package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.ui.theme.NavyBlueDark
import com.example.ui.theme.NavyBlueLight
import com.example.ui.theme.NavyBluePrimary
import java.util.Locale

@Composable
fun BalanceHeroCard(
  totalBalance: Double,
  monthlyIncome: Double,
  monthlyExpense: Double,
  monthlyChangePercent: Double,
  currencySymbol: String = "$",
  appLanguage: AppLanguage = AppLanguage.URDU,
  modifier: Modifier = Modifier
) {
  val isUrdu = appLanguage == AppLanguage.URDU

  Box(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(32.dp))
      .background(
        Brush.linearGradient(
          colors = listOf(NavyBluePrimary, NavyBlueDark)
        )
      )
      .padding(24.dp)
      .testTag("hero_balance_card")
  ) {
    // Ambient blur glow circle
    Box(
      modifier = Modifier
        .size(120.dp)
        .offset(x = 180.dp, y = (-40).dp)
        .clip(CircleShape)
        .background(NavyBlueLight.copy(alpha = 0.25f))
    )

    Column(
      modifier = Modifier.fillMaxWidth()
    ) {
      Text(
        text = if (isUrdu) "کل بیلنس / دستیاب رقم" else "Total Balance",
        style = MaterialTheme.typography.bodyMedium.copy(
          color = Color.White.copy(alpha = 0.9f),
          fontWeight = FontWeight.Medium
        )
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = String.format(Locale.US, "%s%,.2f", currencySymbol, totalBalance),
        style = MaterialTheme.typography.displayLarge.copy(
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 34.sp
        ),
        modifier = Modifier.testTag("total_balance_text")
      )

      Spacer(modifier = Modifier.height(16.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Growth Chip
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.2f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("growth_percent_chip"),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.TrendingUp,
            contentDescription = "Growth",
            tint = Color.White,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.size(4.dp))
          Text(
            text = if (isUrdu) 
              String.format(Locale.US, "+ %.1f%% اس ماہ", monthlyChangePercent) 
            else 
              String.format(Locale.US, "+ %.1f%% this month", monthlyChangePercent),
            style = MaterialTheme.typography.labelSmall.copy(
              color = Color.White,
              fontWeight = FontWeight.SemiBold
            )
          )
        }

        // Quick mini-stats (Income & Expense)
        Row(
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.ArrowDownward,
              contentDescription = "Income",
              tint = Color(0xFFC8F6BC),
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.size(2.dp))
            Text(
              text = if (isUrdu) 
                String.format(Locale.US, "آمدنی: %s%,.0f", currencySymbol, monthlyIncome) 
              else 
                String.format(Locale.US, "%s%,.0f", currencySymbol, monthlyIncome),
              style = MaterialTheme.typography.bodySmall.copy(
                color = Color.White.copy(alpha = 0.9f),
                fontWeight = FontWeight.Medium
              )
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.ArrowUpward,
              contentDescription = "Expense",
              tint = Color(0xFFFFDAD6),
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.size(2.dp))
            Text(
              text = if (isUrdu) 
                String.format(Locale.US, "خرچ: %s%,.0f", currencySymbol, monthlyExpense) 
              else 
                String.format(Locale.US, "%s%,.0f", currencySymbol, monthlyExpense),
              style = MaterialTheme.typography.bodySmall.copy(
                color = Color.White.copy(alpha = 0.9f),
                fontWeight = FontWeight.Medium
              )
            )
          }
        }
      }
    }
  }
}
