package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.FilterCategory
import com.example.ui.FinanceUiState
import com.example.ui.components.BusinessCategoryItem
import com.example.ui.components.TransactionItemCard
import com.example.ui.components.SubscriptionAccessCard
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** New overview; the detailed original dashboard and all its actions remain reachable. */
@Composable
fun BusinessHomeScreen(
  uiState: FinanceUiState,
  onSendClick: () -> Unit,
  onReceiveClick: () -> Unit,
  onStockClick: () -> Unit,
  onBillsClick: () -> Unit,
  onBillingClick: () -> Unit = {},
  onServicesClick: () -> Unit = {},
  onFilterSelected: (FilterCategory) -> Unit,
  onSearchQueryChanged: (String) -> Unit,
  onTransactionClick: (Transaction) -> Unit,
  onAddNewClick: () -> Unit,
  onOpenFbrTaxReport: () -> Unit = {},
  onOpenTrialLock: () -> Unit = {},
  onSelectBusinessCategory: (BusinessCategoryItem) -> Unit = {},
  modifier: Modifier = Modifier,
  onPosClick: () -> Unit = {},
  onReportsClick: () -> Unit = {},
  onBusinessSetup: () -> Unit = {}
) {
  var detail by rememberSaveable { mutableStateOf(false) }
  val urdu = uiState.appLanguage == AppLanguage.URDU
  fun label(en: String, ur: String) = if (urdu) ur else en
  if (detail) {
    BackHandler { detail = false }
    Column(modifier.fillMaxSize()) {
      TextButton(onClick = { detail = false }, modifier = Modifier.padding(horizontal = 16.dp)) {
        Text(label("Back to overview", "خلاصہ پر واپس جائیں"))
      }
      HomeScreen(uiState, onSendClick, onReceiveClick, onStockClick, onBillsClick,
        onBillingClick, onServicesClick, onFilterSelected, onSearchQueryChanged, onTransactionClick,
        onAddNewClick, onOpenFbrTaxReport, onOpenTrialLock, onSelectBusinessCategory, Modifier.weight(1f))
    }
    return
  }
  val todayStart = remember {
    Calendar.getInstance().apply {
      set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
  }
  val todaySales = uiState.invoices.filter { it.dateMillis >= todayStart }.sumOf { it.netTotal() }
  val todayExpenses = uiState.transactions.filter { it.dateMillis >= todayStart && it.type == TransactionType.EXPENSE }.sumOf { it.amount }
  val lowStock = uiState.inventoryItems.count { it.currentStock <= it.lowStockThreshold }
  val personal = uiState.appMode == AppMode.PERSONAL_KHATA
  fun amount(value: Double) = String.format(Locale.US, "%s %,.2f", uiState.currencySymbol, value)
  LazyColumn(modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
    item {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
          Text(label("Welcome back", "خوش آمدید"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
          Text(SimpleDateFormat("EEE, d MMM yyyy", if (urdu) Locale("ur", "PK") else Locale.ENGLISH).format(Date()),
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        FilledTonalIconButton(onClick = onBusinessSetup) {
          Icon(Icons.Default.Tune, label("Business setup", "کاروبار کی ترتیب"))
        }
      }
    }
    item {
      SubscriptionAccessCard(
        state = uiState.subscriptionState,
        language = uiState.appLanguage,
        onPlans = onOpenTrialLock
      )
    }
    item {
      Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth().testTag("hero_balance_card")) {
        Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF043B2C), Color(0xFF087B56)))).padding(24.dp)) {
          Text(label("AVAILABLE BALANCE", "دستیاب بیلنس"), color = Color(0xFFC7E6D2), style = MaterialTheme.typography.labelLarge)
          Spacer(Modifier.height(10.dp))
          CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(amount(uiState.totalBalance), color = Color.White, style = MaterialTheme.typography.headlineLarge,
              fontWeight = FontWeight.Bold, modifier = Modifier.testTag("total_balance_text"))
          }
          Spacer(Modifier.height(20.dp))
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onReceiveClick, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
              modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
              Text(label("Receive", "وصول کریں"))
            }
            Button(onClick = onSendClick, enabled = uiState.features.expenses, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF043B2C)),
              modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
              Text(label("Pay / Expense", "ادائیگی / خرچ"))
            }
          }
        }
      }
    }
    item {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OverviewMetric(label("Today's sales", "آج کی فروخت"), amount(todaySales), Color(0xFFE4F4E8), Modifier.weight(1f))
        OverviewMetric(label("To collect", "وصول طلب"), amount(uiState.totalActiveUdhar), Color(0xFFFFEAD6), Modifier.weight(1f))
      }
    }
    item {
      Text(label("Everything your business needs", "کاروبار کے ضروری ٹولز"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      Spacer(Modifier.height(12.dp))
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!personal) {
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (uiState.features.pos) OverviewAction(label("New sale", "نئی فروخت"), label("POS & billing", "بل بنائیں"), Icons.Default.PointOfSale, Color(0xFFF7E2EF), onPosClick, Modifier.weight(1f))
            if (uiState.features.products) OverviewAction(label("Products", "پروڈکٹس"), label("$lowStock low stock", "$lowStock کا اسٹاک کم ہے"), Icons.Default.Inventory2, Color(0xFFE9E3FF), onStockClick, Modifier.weight(1f))
          }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          if (uiState.features.khata) OverviewAction(label("Khata", "کھاتہ"), label("Customers & invoices", "گاہک اور بل"), Icons.Default.ReceiptLong, Color(0xFFFFEAD6), onBillingClick, Modifier.weight(1f))
          if (uiState.features.reports) OverviewAction(label("Reports", "رپورٹس"), label("Review activity", "حساب کی تفصیل"), Icons.Default.Insights, Color(0xFFE0EFFA), onReportsClick, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          if (!personal && uiState.features.services) OverviewAction(label("Services", "سروسز"), label("Your service catalog", "آپ کی سروسز"), Icons.Default.Handyman, Color(0xFFDEF1E7), onServicesClick, Modifier.weight(1f))
          OverviewAction(label("Bills & budgets", "بل اور بجٹ"), label("Plan payments", "ادائیگی کی منصوبہ بندی"), Icons.Default.CalendarMonth, Color(0xFFFFF2CA), onBillsClick, Modifier.weight(1f))
        }
      }
    }
    item {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OverviewMetric(label("Today's expenses", "آج کے اخراجات"), amount(todayExpenses), MaterialTheme.colorScheme.surface, Modifier.weight(1f))
        OverviewMetric(label("Products in catalog", "کیٹلاگ کی پروڈکٹس"), uiState.inventoryItems.size.toString(), MaterialTheme.colorScheme.surface, Modifier.weight(1f))
      }
    }
    item {
      Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label("Recent activity", "حالیہ لین دین"), modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        TextButton(onClick = { detail = true }) { Text(label("View all", "سب دیکھیں")) }
      }
    }
    if (uiState.transactions.isEmpty()) {
      item {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(20.dp)) {
          Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.ReceiptLong, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(12.dp))
            Text(label("Your first entry starts here", "پہلا اندراج یہاں کریں"), style = MaterialTheme.typography.titleMedium)
            Text(label("Record a payment or expense to begin.", "ادائیگی یا خرچ درج کرکے شروع کریں۔"), style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = onAddNewClick) { Text(label("Add entry", "اندراج کریں")) }
          }
        }
      }
    } else {
      uiState.transactions.take(4).forEach { tx -> item(key = "tx-${tx.id}") {
        TransactionItemCard(tx, uiState.currencySymbol, { onTransactionClick(tx) })
      } }
    }
    item {
      OutlinedButton(onClick = { detail = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
        Text(label("Detailed dashboard & all tools", "تفصیلی ڈیش بورڈ اور تمام ٹولز"))
      }
    }
  }
}

@Composable
private fun OverviewMetric(title: String, value: String, color: Color, modifier: Modifier) {
  Card(modifier = modifier, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = color)) {
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Text(title, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF475569))
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF143E2D))
      }
    }
  }
}

@Composable
private fun OverviewAction(title: String, subtitle: String, icon: ImageVector, color: Color, click: () -> Unit, modifier: Modifier) {
  Card(onClick = click, modifier = modifier, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = color)) {
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Icon(icon, title, tint = Color(0xFF164B37), modifier = Modifier.size(28.dp))
      Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569))
    }
  }
}
