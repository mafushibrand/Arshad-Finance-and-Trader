package com.example.ui.dialogs

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.InventoryItem
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.util.BusinessProfile
import com.example.util.StockExportImportUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun StockExportDialog(
  items: List<InventoryItem>,
  currencySymbol: String,
  businessProfile: BusinessProfile,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val scrollState = rememberScrollState()

  val calendar = Calendar.getInstance()
  val dayName = SimpleDateFormat("EEEE", Locale.getDefault()).format(calendar.time)
  val yearStr = SimpleDateFormat("yyyy", Locale.getDefault()).format(calendar.time)
  val dateFormatted = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(calendar.time)

  val totalQuantity = items.sumOf { it.currentStock }
  val totalValuation = items.sumOf { it.currentStock * it.salePrice }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(24.dp))
        .testTag("stock_export_dialog"),
      color = Color.White
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(scrollState)
      ) {
        // Top Header with Close
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Color(0xFFE0F2FE)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Download,
                contentDescription = "Download Stock",
                tint = Color(0xFF13865F),
                modifier = Modifier.size(24.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Download Stock List",
                style = MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
              )
              Text(
                text = "اسٹاک لسٹ تمام فارمیٹس میں ڈاؤن لوڈ کریں",
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Report Top Header Preview Info Card
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = NavyBluePrimary)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "🏬 ${businessProfile.businessName}",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              )
              Text(
                text = "YEAR: $yearStr",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFFFBBF24)
                )
              )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = "📅 Date: $dateFormatted ($dayName) • ${items.size} Products",
              style = MaterialTheme.typography.bodySmall.copy(
                color = Color.White.copy(alpha = 0.85f)
              )
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text(
                  text = "Total Units",
                  style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.7f))
                )
                Text(
                  text = String.format("%,.0f Qty", totalQuantity),
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                )
              }

              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = "Stock Valuation",
                  style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.7f))
                )
                Text(
                  text = "$currencySymbol ${String.format("%,.0f", totalValuation)}",
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = IncomeGreen
                  )
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
          text = "Select Export Format (فارمیٹ منتخب کریں):",
          style = MaterialTheme.typography.titleSmall.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 1. PDF Document
        ExportOptionTile(
          icon = Icons.Default.Description,
          iconBg = Color(0xFFFEE2E2),
          iconTint = Color(0xFFDC2626),
          title = "PDF Report (.pdf)",
          subtitle = "Shop Header, Sr#, Qty, Cost & Sale Price, Developer Footer",
          badge = "PRINT READY",
          onClick = {
            StockExportImportUtils.exportStockToPdf(context, items, currencySymbol, businessProfile)
            onDismiss()
          }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 2. Excel (.csv / .xlsx)
        ExportOptionTile(
          icon = Icons.Default.TableChart,
          iconBg = Color(0xFFDCFCE7),
          iconTint = Color(0xFF16A34A),
          title = "Excel Spreadsheet (.csv / .xlsx)",
          subtitle = "Microsoft Excel & Google Sheets compatible with UTF-8",
          badge = "EXCEL / SHEETS",
          onClick = {
            StockExportImportUtils.exportStockToExcelCsv(context, items, currencySymbol, businessProfile, isTsv = false)
            onDismiss()
          }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 3. Image PNG
        ExportOptionTile(
          icon = Icons.Default.Image,
          iconBg = Color(0xFFFEF3C7),
          iconTint = Color(0xFFD97706),
          title = "Stock Report Image (.png)",
          subtitle = "High-definition photo graphic card for quick sharing",
          badge = "HQ IMAGE",
          onClick = {
            StockExportImportUtils.exportStockToImage(context, items, currencySymbol, businessProfile, Bitmap.CompressFormat.PNG)
            onDismiss()
          }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Image JPEG
        ExportOptionTile(
          icon = Icons.Default.Image,
          iconBg = Color(0xFFF3E8FF),
          iconTint = Color(0xFF9333EA),
          title = "Compressed Photo (.jpeg / .jpg)",
          subtitle = "Small file size image for fast messaging and saving",
          badge = "JPEG",
          onClick = {
            StockExportImportUtils.exportStockToImage(context, items, currencySymbol, businessProfile, Bitmap.CompressFormat.JPEG)
            onDismiss()
          }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 5. WhatsApp Formatted Text
        ExportOptionTile(
          icon = Icons.Default.Send,
          iconBg = Color(0xFFD1FAE5),
          iconTint = Color(0xFF059669),
          title = "WhatsApp Text Report",
          subtitle = "Directly send formatted stock list with emojis to WhatsApp",
          badge = "WHATSAPP",
          onClick = {
            StockExportImportUtils.exportStockToWhatsAppText(context, items, currencySymbol, businessProfile)
            onDismiss()
          }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 6. JSON Backup
        ExportOptionTile(
          icon = Icons.Default.Storage,
          iconBg = Color(0xFFE0E7FF),
          iconTint = Color(0xFF086B4D),
          title = "JSON Backup File (.json)",
          subtitle = "Full database backup file for restore on another mobile",
          badge = "BACKUP",
          onClick = {
            StockExportImportUtils.exportStockToJson(context, items, businessProfile)
            onDismiss()
          }
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Prominent Developer Footer in Dialog
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF7F9F3))
            .padding(12.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "🌟 Developed by Muhammad Arshad, 0302-7761415",
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = NavyBluePrimary,
                fontSize = 12.sp
              )
            )
            Text(
              text = "All export files include Sr#, Date, Day, Year, Cost, Sale and Shop header",
              style = MaterialTheme.typography.labelSmall.copy(
                color = TextTertiary,
                fontSize = 10.sp
              )
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ExportOptionTile(
  icon: ImageVector,
  iconBg: Color,
  iconTint: Color,
  title: String,
  subtitle: String,
  badge: String,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
      .clickable(onClick = onClick)
      .padding(14.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(46.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(iconBg),
      contentAlignment = Alignment.Center
    ) {
      Icon(imageVector = icon, contentDescription = title, tint = iconTint, modifier = Modifier.size(24.dp))
    }

    Spacer(modifier = Modifier.width(14.dp))

    Column(modifier = Modifier.weight(1f)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.bodyLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            fontSize = 15.sp
          )
        )

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFFF7F9F3))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = badge,
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              color = TextSecondary,
              fontSize = 9.sp
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(2.dp))

      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall.copy(
          color = TextSecondary,
          fontSize = 11.5.sp
        )
      )
    }
  }
}
