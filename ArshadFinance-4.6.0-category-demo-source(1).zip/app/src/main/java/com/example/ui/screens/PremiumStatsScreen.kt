package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun StatsScreen(
  uiState: FinanceUiState,
  onTransactionClick: (Transaction) -> Unit,
  modifier: Modifier = Modifier
) {
  var advanced by rememberSaveable { mutableStateOf(false) }
  if (advanced) {
    BackHandler { advanced = false }
    Column(modifier.fillMaxSize().background(Cream)) {
      TextButton(onClick = { advanced = false }, modifier = Modifier.padding(horizontal = 16.dp)) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(8.dp)); Text(uiState.word("Back to overview", "خلاصے پر واپس")) }
      LegacyStatsScreen(uiState = uiState, onTransactionClick = onTransactionClick, modifier = Modifier.weight(1f))
    }
    return
  }
  var days by rememberSaveable { mutableIntStateOf(0) }
  val start = if (days == 0) 0L else System.currentTimeMillis() - (if (days == 1) 7 else 30) * 86400000L
  val sales = uiState.invoices.filter { it.dateMillis >= start }
  val transactions = uiState.transactions.filter { it.dateMillis >= start }
  val income = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
  val expense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
  PremiumPage(uiState.word("Reports", "حساب اور رپورٹس"), uiState.word("Know how your business is doing", "اپنے کاروبار کا حساب دیکھیں"), Icons.Default.Insights, modifier) {
    item { FilterRow(listOf(uiState.word("All time", "شروع سے"), uiState.word("7 days", "۷ دن"), uiState.word("30 days", "۳۰ دن")), days) { days = it } }
    item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      Metric(uiState.word("Net sales", "خالص فروخت"), uiState.money(sales.sumOf { it.netTotal() }), Mint, Modifier.weight(1f))
      Metric(uiState.word("Receipts", "وصول شدہ"), uiState.money(income), Color(0xFFE7F2FC), Modifier.weight(1f))
    } }
    item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      Metric(uiState.word("Expenses", "اخراجات"), uiState.money(expense), Color(0xFFFFE7E5), Modifier.weight(1f))
      Metric(uiState.word("Net cash flow", "کیش کا خالص بہاؤ"), uiState.money(income - expense), Peach, Modifier.weight(1f))
    } }
    item { Surface(shape = RoundedCornerShape(22.dp), color = Color.White) { Column(Modifier.padding(18.dp)) {
      Text(uiState.word("Sales • last 7 days", "فروخت • گزشتہ ۷ دن"), fontWeight = FontWeight.SemiBold)
      Spacer(Modifier.height(18.dp))
      val buckets = (6 downTo 0).map { back ->
        val cal = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -back); set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }
        val value = uiState.invoices.filter { it.dateMillis >= cal.timeInMillis && it.dateMillis < cal.timeInMillis + 86400000L }.sumOf { it.netTotal() }
        SimpleDateFormat("EEE", Locale.ENGLISH).format(cal.time) to value
      }
      val max = buckets.maxOfOrNull { it.second }?.coerceAtLeast(1.0) ?: 1.0
      Row(Modifier.fillMaxWidth().height(145.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
        buckets.forEach { (day, value) -> Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
          Box(Modifier.fillMaxWidth().height((104 * value / max).toFloat().coerceAtLeast(3f).dp).background(if (value > 0) Forest else Mint, RoundedCornerShape(6.dp)))
          Spacer(Modifier.height(8.dp)); Text(day, fontSize = 10.sp)
        } }
      }
    } } }
    item { ListTile(uiState.word("Outstanding khata", "کھاتے کی بقایا رقم"), uiState.word("Customer receivables", "گاہکوں سے وصول طلب"), Icons.Default.PeopleAlt, uiState.money(uiState.totalActiveUdhar), Peach) }
    item { BusinessReportDetails(uiState,sales,start) }
    item { Text(uiState.word("Recent transactions", "حالیہ لین دین"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp)) }
    items(transactions.take(30), key = { it.id }) { tx -> ListTile(tx.title, "${tx.category} • ${tx.accountName}", if (tx.type == TransactionType.EXPENSE) Icons.Default.NorthEast else Icons.Default.SouthWest, uiState.money(tx.amount), click = { onTransactionClick(tx) }) }
    item { AdvancedButton(uiState) { advanced = true } }
  }
}
