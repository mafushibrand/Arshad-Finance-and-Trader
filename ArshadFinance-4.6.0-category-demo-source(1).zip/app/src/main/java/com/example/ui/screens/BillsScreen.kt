package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Bill
import com.example.data.model.Budget
import com.example.data.model.RecurringTransaction
import com.example.data.model.TransactionType
import com.example.ui.BudgetAlert
import com.example.ui.FinanceUiState
import com.example.ui.PlannerSubTab
import com.example.ui.theme.DeepNavyText
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ExpenseRedContainer
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IceBlueContainerLight
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.IncomeGreenContainer
import com.example.ui.theme.LightSurface
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.OnIceBlueContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BillsScreen(
  uiState: FinanceUiState,
  onSubTabSelected: (PlannerSubTab) -> Unit,
  onAddBillClick: () -> Unit,
  onToggleBillPaid: (Bill) -> Unit,
  onDeleteBill: (Bill) -> Unit,
  onAddBudgetClick: () -> Unit,
  onEditBudgetClick: (Budget) -> Unit,
  onDeleteBudget: (Budget) -> Unit,
  onAddRecurringClick: () -> Unit,
  onEditRecurringClick: (RecurringTransaction) -> Unit,
  onToggleRecurringActive: (RecurringTransaction) -> Unit,
  onExecuteRecurringNow: (RecurringTransaction) -> Unit,
  onDeleteRecurring: (RecurringTransaction) -> Unit,
  onProcessDueRecurring: () -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Header with Dynamic Action Button
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Budgets & Planner",
            style = MaterialTheme.typography.headlineSmall.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          Text(
            text = "Limits, recurring automations & bills",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
          )
        }

        val (btnText, btnAction, testTag) = when (uiState.plannerSubTab) {
          PlannerSubTab.BUDGETS -> Triple("Set Budget", onAddBudgetClick, "add_budget_button")
          PlannerSubTab.RECURRING -> Triple("Add Rule", onAddRecurringClick, "add_recurring_button")
          PlannerSubTab.BILLS -> Triple("Add Bill", onAddBillClick, "add_bill_button")
        }

        Button(
          onClick = btnAction,
          colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
          shape = RoundedCornerShape(20.dp),
          modifier = Modifier.testTag(testTag)
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = btnText,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(text = btnText)
        }
      }
    }

    // 2. Sub-Tabs Selector (Budgets / Recurring / Bills)
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(LightSurface)
          .padding(4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        PlannerTabChip(
          title = "Budgets (${uiState.budgets.size})",
          isSelected = uiState.plannerSubTab == PlannerSubTab.BUDGETS,
          onClick = { onSubTabSelected(PlannerSubTab.BUDGETS) },
          tag = "subtab_budgets"
        )
        PlannerTabChip(
          title = "Recurring (${uiState.recurringTransactions.size})",
          isSelected = uiState.plannerSubTab == PlannerSubTab.RECURRING,
          onClick = { onSubTabSelected(PlannerSubTab.RECURRING) },
          tag = "subtab_recurring"
        )
        PlannerTabChip(
          title = "Bills (${uiState.bills.size})",
          isSelected = uiState.plannerSubTab == PlannerSubTab.BILLS,
          onClick = { onSubTabSelected(PlannerSubTab.BILLS) },
          tag = "subtab_bills"
        )
      }
    }

    // 3. Render Selected SubTab Section
    when (uiState.plannerSubTab) {
      PlannerSubTab.BUDGETS -> {
        // --- BUDGETS SECTION ---

        // Overall Budget Health Summary Card
        item {
          val percent = if (uiState.totalBudgetLimit > 0) {
            (uiState.totalBudgetSpent / uiState.totalBudgetLimit) * 100.0
          } else 0.0

          val remaining = (uiState.totalBudgetLimit - uiState.totalBudgetSpent).coerceAtLeast(0.0)

          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(24.dp))
              .background(LightSurface)
              .padding(20.dp)
              .testTag("budget_summary_hero_card")
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "Monthly Spending Cap",
                  style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = String.format(Locale.US, "%s%,.2f spent of %s%,.2f", uiState.currencySymbol, uiState.totalBudgetSpent, uiState.currencySymbol, uiState.totalBudgetLimit),
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                  )
                )
              }

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (percent >= 100.0) ExpenseRedContainer else IceBlueContainer)
                  .padding(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text(
                  text = String.format(Locale.US, "%.0f%% Cap", percent),
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (percent >= 100.0) ExpenseRed else OnIceBlueContainer
                  )
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LinearProgressIndicator(
              progress = { (percent / 100.0).toFloat().coerceIn(0f, 1f) },
              modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp)),
              color = when {
                percent >= 100.0 -> ExpenseRed
                percent >= 80.0 -> WarningAmber
                else -> NavyBluePrimary
              },
              trackColor = Color(0xFFE2E2E6)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = String.format(Locale.US, "Remaining: %s%,.2f", uiState.currencySymbol, remaining),
                style = MaterialTheme.typography.bodySmall.copy(
                  color = if (remaining > 0) IncomeGreen else ExpenseRed,
                  fontWeight = FontWeight.SemiBold
                )
              )
              Text(
                text = "${uiState.budgetAlerts.size} Alerts",
                style = MaterialTheme.typography.bodySmall.copy(
                  color = if (uiState.budgetAlerts.isNotEmpty()) WarningAmber else TextSecondary,
                  fontWeight = FontWeight.Medium
                )
              )
            }
          }
        }

        // Budget Alerts Section (Approaching or Exceeded)
        if (uiState.budgetAlerts.isNotEmpty()) {
          item {
            Text(
              text = "⚠️ Budget Limit Alerts",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = ExpenseRed
              ),
              modifier = Modifier.padding(top = 4.dp)
            )
          }

          items(uiState.budgetAlerts, key = { it.budgetId }) { alert ->
            BudgetAlertCard(alert = alert, currencySymbol = uiState.currencySymbol)
          }
        }

        // Category Budgets Header
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Category Budget Targets",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            )
            Text(
              text = "Tap to edit",
              style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
            )
          }
        }

        if (uiState.budgets.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "No category budgets set. Tap 'Set Budget' to create one.",
                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
              )
            }
          }
        } else {
          items(uiState.budgets, key = { it.id }) { budget ->
            BudgetItemCard(
              budget = budget,
              currencySymbol = uiState.currencySymbol,
              onClick = { onEditBudgetClick(budget) },
              onDelete = { onDeleteBudget(budget) }
            )
          }
        }
      }

      PlannerSubTab.RECURRING -> {
        // --- RECURRING TRANSACTIONS SECTION ---

        // Automation Control Banner
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(24.dp))
              .background(LightSurface)
              .padding(16.dp)
              .testTag("recurring_automation_banner"),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Box(
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .background(IceBlueContainer),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Repeat,
                  contentDescription = "Recurring",
                  tint = DeepNavyText,
                  modifier = Modifier.size(24.dp)
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "Automated Rules Engine",
                  style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                  )
                )
                Text(
                  text = "${uiState.recurringTransactions.count { it.isActive }} active schedules",
                  style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
              }
            }

            OutlinedButton(
              onClick = onProcessDueRecurring,
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.testTag("process_due_recurring_button")
            ) {
              Icon(imageVector = Icons.Default.Bolt, contentDescription = "Sync", modifier = Modifier.size(16.dp), tint = NavyBluePrimary)
              Spacer(modifier = Modifier.width(4.dp))
              Text("Sync Due", style = MaterialTheme.typography.labelMedium.copy(color = NavyBluePrimary))
            }
          }
        }

        item {
          Text(
            text = "Scheduled Recurring Transactions",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            ),
            modifier = Modifier.padding(top = 4.dp)
          )
        }

        if (uiState.recurringTransactions.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "No recurring transactions set yet. Tap 'Add Rule' to configure payroll, subscriptions, or recurring transfers.",
                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
              )
            }
          }
        } else {
          items(uiState.recurringTransactions, key = { it.id }) { recurring ->
            RecurringItemCard(
              recurring = recurring,
              currencySymbol = uiState.currencySymbol,
              onToggleActive = { onToggleRecurringActive(recurring) },
              onExecuteNow = { onExecuteRecurringNow(recurring) },
              onEdit = { onEditRecurringClick(recurring) },
              onDelete = { onDeleteRecurring(recurring) }
            )
          }
        }
      }

      PlannerSubTab.BILLS -> {
        // --- BILLS SECTION ---
        val unpaidBillsTotal = uiState.bills.filter { !it.isPaid }.sumOf { it.amount }

        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(24.dp))
              .background(LightSurface)
              .padding(20.dp)
              .testTag("bills_due_summary_card"),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "Upcoming Invoices",
                style = MaterialTheme.typography.bodyMedium.copy(
                  color = TextSecondary,
                  fontWeight = FontWeight.Medium
                )
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = String.format(Locale.US, "%s%,.2f", uiState.currencySymbol, unpaidBillsTotal),
                style = MaterialTheme.typography.headlineMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = if (unpaidBillsTotal > 0) ExpenseRed else IncomeGreen
                )
              )
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (unpaidBillsTotal > 0) Color(0xFFFFDAD6) else IncomeGreenContainer)
                .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Text(
                text = "${uiState.bills.count { !it.isPaid }} Due",
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = if (unpaidBillsTotal > 0) ExpenseRed else IncomeGreen
                )
              )
            }
          }
        }

        item {
          Text(
            text = "Scheduled Bills",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            ),
            modifier = Modifier.padding(top = 4.dp)
          )
        }

        if (uiState.bills.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "No scheduled bills yet",
                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
              )
            }
          }
        } else {
          items(uiState.bills, key = { it.id }) { bill ->
            BillItemRow(
              bill = bill,
              currencySymbol = uiState.currencySymbol,
              onToggle = { onToggleBillPaid(bill) },
              onDelete = { onDeleteBill(bill) }
            )
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun PlannerTabChip(
  title: String,
  isSelected: Boolean,
  onClick: () -> Unit,
  tag: String
) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(12.dp))
      .background(if (isSelected) NavyBluePrimary else Color.Transparent)
      .clickable(onClick = onClick)
      .padding(horizontal = 16.dp, vertical = 8.dp)
      .testTag(tag),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.labelMedium.copy(
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        color = if (isSelected) Color.White else TextPrimary
      )
    )
  }
}

@Composable
fun BudgetAlertCard(alert: BudgetAlert, currencySymbol: String) {
  val isExceeded = alert.isExceeded
  val bgColor = if (isExceeded) ExpenseRedContainer else Color(0xFFFFF3CD)
  val textColor = if (isExceeded) ExpenseRed else Color(0xFF856404)
  val remainingOrOver = if (isExceeded) {
    "Over limit by " + String.format(Locale.US, "%s%,.2f", currencySymbol, alert.spentAmount - alert.limitAmount)
  } else {
    "Remaining: " + String.format(Locale.US, "%s%,.2f", currencySymbol, alert.limitAmount - alert.spentAmount)
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(18.dp))
      .testTag("budget_alert_${alert.budgetId}"),
    colors = CardDefaults.cardColors(containerColor = bgColor)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = if (isExceeded) Icons.Default.Warning else Icons.Default.NotificationsActive,
        contentDescription = "Alert",
        tint = textColor,
        modifier = Modifier.size(24.dp)
      )

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "${alert.icon} ${alert.category}",
            style = MaterialTheme.typography.titleSmall.copy(
              fontWeight = FontWeight.Bold,
              color = textColor
            )
          )
          Text(
            text = if (isExceeded) "🚨 EXCEEDED" else "⚠️ APPROACHING",
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.ExtraBold,
              color = textColor
            )
          )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = String.format(Locale.US, "%.1f%% spent (%s%,.2f / %s%,.2f) • %s",
            alert.percentSpent,
            currencySymbol, alert.spentAmount,
            currencySymbol, alert.limitAmount,
            remainingOrOver
          ),
          style = MaterialTheme.typography.bodySmall.copy(
            color = textColor,
            fontWeight = FontWeight.Medium
          )
        )
      }
    }
  }
}

@Composable
fun BudgetItemCard(
  budget: Budget,
  currencySymbol: String,
  onClick: () -> Unit,
  onDelete: () -> Unit
) {
  val percent = (budget.spentAmount / budget.limitAmount.coerceAtLeast(0.01)) * 100.0
  val isOverBudget = percent >= 100.0
  val isWarning = percent >= 80.0 && !isOverBudget
  val progressColor = when {
    isOverBudget -> ExpenseRed
    isWarning -> WarningAmber
    else -> NavyBluePrimary
  }
  val remaining = budget.limitAmount - budget.spentAmount

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .background(LightSurface)
      .clickable(onClick = onClick)
      .padding(16.dp)
      .testTag("budget_item_${budget.id}")
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text = budget.icon, fontSize = 22.sp)
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = budget.category,
            style = MaterialTheme.typography.titleSmall.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          Text(
            text = "${budget.period} limit",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
          )
        }
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        if (isOverBudget) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(ExpenseRedContainer)
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = "Over Cap",
              style = MaterialTheme.typography.labelSmall.copy(
                color = ExpenseRed,
                fontWeight = FontWeight.Bold
              )
            )
          }
        } else if (isWarning) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFFFF3CD))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = "Near Limit",
              style = MaterialTheme.typography.labelSmall.copy(
                color = Color(0xFF856404),
                fontWeight = FontWeight.Bold
              )
            )
          }
        }

        IconButton(
          onClick = onClick,
          modifier = Modifier.size(32.dp).padding(start = 4.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Edit,
            contentDescription = "Edit Budget",
            tint = TextSecondary,
            modifier = Modifier.size(16.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        text = String.format(Locale.US, "Spent: %s%,.2f (%.1f%%)", currencySymbol, budget.spentAmount, percent),
        style = MaterialTheme.typography.bodySmall.copy(
          color = TextSecondary,
          fontWeight = FontWeight.Medium
        )
      )
      Text(
        text = if (remaining >= 0) {
          String.format(Locale.US, "%s%,.2f left", currencySymbol, remaining)
        } else {
          String.format(Locale.US, "+%s%,.2f over", currencySymbol, -remaining)
        },
        style = MaterialTheme.typography.bodySmall.copy(
          color = if (remaining >= 0) IncomeGreen else ExpenseRed,
          fontWeight = FontWeight.Bold
        )
      )
    }

    Spacer(modifier = Modifier.height(8.dp))

    LinearProgressIndicator(
      progress = { (percent / 100.0).toFloat().coerceIn(0f, 1f) },
      modifier = Modifier
        .fillMaxWidth()
        .height(8.dp)
        .clip(RoundedCornerShape(4.dp)),
      color = progressColor,
      trackColor = Color(0xFFE2E2E6)
    )
  }
}

@Composable
fun RecurringItemCard(
  recurring: RecurringTransaction,
  currencySymbol: String,
  onToggleActive: () -> Unit,
  onExecuteNow: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit
) {
  val dateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
  val isIncome = recurring.type == TransactionType.INCOME
  val amountColor = if (isIncome) IncomeGreen else ExpenseRed
  val amountPrefix = if (isIncome) "+" else "-"

  val nextDateFormatted = dateFormat.format(Date(recurring.nextExecutionDateMillis))
  val startDateFormatted = dateFormat.format(Date(recurring.startDateMillis))
  val endDateFormatted = recurring.endDateMillis?.let { dateFormat.format(Date(it)) }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .background(LightSurface)
      .clickable(onClick = onEdit)
      .padding(16.dp)
      .testTag("recurring_item_${recurring.id}")
  ) {
    // Row 1: Icon, Title, Frequency Badge, and Amount
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(IceBlueContainerLight),
          contentAlignment = Alignment.Center
        ) {
          Text(text = recurring.icon, fontSize = 20.sp)
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
          Text(
            text = recurring.title,
            style = MaterialTheme.typography.titleSmall.copy(
              fontWeight = FontWeight.Bold,
              color = if (recurring.isActive) TextPrimary else TextSecondary
            )
          )

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(IceBlueContainer)
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = recurring.frequency.displayName,
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.SemiBold,
                  color = DeepNavyText,
                  fontSize = 10.sp
                )
              )
            }
            Text(
              text = "• ${recurring.accountName}",
              style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary, fontSize = 11.sp)
            )
          }
        }
      }

      Text(
        text = String.format(Locale.US, "%s%s%,.2f", amountPrefix, currencySymbol, recurring.amount),
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = if (recurring.isActive) amountColor else TextSecondary
        )
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Row 2: Date Details (Next run & Start / End dates)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        text = "Next: $nextDateFormatted",
        style = MaterialTheme.typography.bodySmall.copy(
          color = if (recurring.isActive) NavyBluePrimary else TextSecondary,
          fontWeight = FontWeight.SemiBold
        )
      )

      val dateRangeText = if (endDateFormatted != null) {
        "From $startDateFormatted to $endDateFormatted"
      } else {
        "Since $startDateFormatted (Ongoing)"
      }

      Text(
        text = dateRangeText,
        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary, fontSize = 11.sp)
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Row 3: Action Buttons (Pause/Resume, Trigger Now, Edit, Delete)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        // Toggle Active
        IconButton(
          onClick = onToggleActive,
          modifier = Modifier.size(32.dp).testTag("toggle_recurring_${recurring.id}")
        ) {
          Icon(
            imageVector = if (recurring.isActive) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
            contentDescription = if (recurring.isActive) "Pause" else "Resume",
            tint = if (recurring.isActive) NavyBluePrimary else IncomeGreen,
            modifier = Modifier.size(22.dp)
          )
        }

        // Trigger Now button
        OutlinedButton(
          onClick = onExecuteNow,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.height(30.dp).padding(start = 4.dp).testTag("trigger_recurring_${recurring.id}")
        ) {
          Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(14.dp), tint = NavyBluePrimary)
          Spacer(modifier = Modifier.width(4.dp))
          Text(text = "Post Now", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = NavyBluePrimary))
        }
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onEdit,
          modifier = Modifier.size(32.dp).testTag("edit_recurring_${recurring.id}")
        ) {
          Icon(
            imageVector = Icons.Default.Edit,
            contentDescription = "Edit",
            tint = TextSecondary,
            modifier = Modifier.size(16.dp)
          )
        }

        IconButton(
          onClick = onDelete,
          modifier = Modifier.size(32.dp).testTag("delete_recurring_${recurring.id}")
        ) {
          Icon(
            imageVector = Icons.Default.DeleteOutline,
            contentDescription = "Delete",
            tint = ExpenseRed,
            modifier = Modifier.size(16.dp)
          )
        }
      }
    }
  }
}

@Composable
fun BillItemRow(
  bill: Bill,
  currencySymbol: String,
  onToggle: () -> Unit,
  onDelete: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .background(LightSurface)
      .clickable(onClick = onToggle)
      .padding(16.dp)
      .testTag("bill_item_${bill.id}"),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = if (bill.isPaid) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
      contentDescription = if (bill.isPaid) "Paid" else "Unpaid",
      tint = if (bill.isPaid) IncomeGreen else NavyBluePrimary,
      modifier = Modifier.size(24.dp)
    )

    Spacer(modifier = Modifier.width(14.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = bill.title,
        style = MaterialTheme.typography.titleSmall.copy(
          fontWeight = FontWeight.Bold,
          color = if (bill.isPaid) TextSecondary else TextPrimary
        )
      )
      Text(
        text = "Due ${bill.dueDate} • ${bill.category}",
        style = MaterialTheme.typography.bodySmall.copy(
          color = TextTertiary,
          fontWeight = FontWeight.Medium
        )
      )
    }

    Text(
      text = String.format(Locale.US, "%s%,.2f", currencySymbol, bill.amount),
      style = MaterialTheme.typography.titleSmall.copy(
        fontWeight = FontWeight.Bold,
        color = if (bill.isPaid) TextSecondary else ExpenseRed
      )
    )

    IconButton(
      onClick = onDelete,
      modifier = Modifier
        .size(32.dp)
        .padding(start = 6.dp)
        .testTag("delete_bill_${bill.id}")
    ) {
      Icon(
        imageVector = Icons.Default.DeleteOutline,
        contentDescription = "Delete Bill",
        tint = TextSecondary,
        modifier = Modifier.size(18.dp)
      )
    }
  }
}
