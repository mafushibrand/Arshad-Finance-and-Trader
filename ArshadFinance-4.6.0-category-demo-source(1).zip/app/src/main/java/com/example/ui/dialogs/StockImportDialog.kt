package com.example.ui.dialogs

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.InventoryItem
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.util.BusinessProfile
import com.example.util.StockExportImportUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun StockImportDialog(
  currencySymbol: String,
  businessProfile: BusinessProfile,
  onDismiss: () -> Unit,
  onConfirmImport: (items: List<InventoryItem>, replaceExisting: Boolean) -> Unit
) {
  val context = LocalContext.current
  val clipboardManager = LocalClipboardManager.current

  var inputContent by remember { mutableStateOf("") }
  var replaceExisting by remember { mutableStateOf(false) }
  var parsedItems by remember { mutableStateOf<List<InventoryItem>>(emptyList()) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var selectedFileName by remember { mutableStateOf<String?>(null) }
  var showPasteInput by remember { mutableStateOf(false) }

  // File Picker Launcher
  val filePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      val text = StockExportImportUtils.readTextFromUri(context, uri)
      if (!text.isNullOrBlank()) {
        inputContent = text
        selectedFileName = uri.lastPathSegment ?: "Stock_Data_File"
        val result = StockExportImportUtils.parseStockFile(text)
        parsedItems = result.items
        errorMessage = result.errorMessage
      } else {
        Toast.makeText(context, "Could not read data from selected file", Toast.LENGTH_LONG).show()
      }
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(24.dp))
        .testTag("stock_import_dialog"),
      color = Color.White
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Top Bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Color(0xFFDCFCE7)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.CloudUpload,
                contentDescription = "Upload Stock",
                tint = Color(0xFF16A34A),
                modifier = Modifier.size(24.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Upload Stock List",
                style = MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
              )
              Text(
                text = "ایکسل، سی ایس وی یا فائل سے اسٹاک اپلوڈ کریں",
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Action 1: Upload File from Phone Button
        Button(
          onClick = {
            filePickerLauncher.launch("*/*")
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp),
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary)
        ) {
          Icon(Icons.Default.FileOpen, contentDescription = "Pick File", tint = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Select File from Device (فائل منتخب کریں)",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Action 2: Sample CSV Template / Paste Toggle
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = {
              val sample = StockExportImportUtils.getSampleCsvTemplate()
              inputContent = sample
              val result = StockExportImportUtils.parseStockFile(sample)
              parsedItems = result.items
              errorMessage = null
              selectedFileName = "Sample_Pakistani_Business_Stock.csv"
              Toast.makeText(context, "Sample template loaded for preview", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Download, contentDescription = "Sample", modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "Sample Template", fontSize = 12.sp)
          }

          OutlinedButton(
            onClick = { showPasteInput = !showPasteInput },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.ContentPaste, contentDescription = "Paste", modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = if (showPasteInput) "Hide Paste" else "Paste Text", fontSize = 12.sp)
          }
        }

        if (showPasteInput) {
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = inputContent,
            onValueChange = {
              inputContent = it
              val result = StockExportImportUtils.parseStockFile(it)
              parsedItems = result.items
              errorMessage = result.errorMessage
            },
            label = { Text("Paste CSV or Tab-separated stock data") },
            placeholder = { Text("Sr#, Item Name, Qty, Unit, Cost Price, Sale Price, Category...") },
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(min = 120.dp, max = 180.dp),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = Color(0xFFF5F7F2),
              unfocusedContainerColor = Color(0xFFF5F7F2)
            )
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Parsed Status Box
        if (parsedItems.isNotEmpty()) {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF86EFAC))
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = "Success",
                  tint = Color(0xFF16A34A),
                  modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "${parsedItems.size} Products Ready for Import",
                  style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF166534)
                  )
                )
              }

              Spacer(modifier = Modifier.height(4.dp))

              val totalVal = parsedItems.sumOf { it.currentStock * it.salePrice }
              val totalQty = parsedItems.sumOf { it.currentStock }
              Text(
                text = "Total Quantity: ${String.format("%,.0f", totalQty)} Units  •  Valuation: $currencySymbol ${String.format("%,.0f", totalVal)}",
                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF15803D))
              )

              Spacer(modifier = Modifier.height(10.dp))

              // Preview Table items (up to 5 items)
              Text(
                text = "Preview of detected products:",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF166534)
                )
              )

              Spacer(modifier = Modifier.height(6.dp))

              parsedItems.take(5).forEachIndexed { i, item ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "${i + 1}. ${item.name}",
                    style = MaterialTheme.typography.bodySmall.copy(
                      fontWeight = FontWeight.Medium,
                      color = TextPrimary
                    ),
                    modifier = Modifier.weight(1f)
                  )
                  Text(
                    text = "${String.format("%.0f", item.currentStock)} ${item.unit} @ $currencySymbol ${String.format("%,.0f", item.salePrice)}",
                    style = MaterialTheme.typography.bodySmall.copy(
                      color = TextSecondary,
                      fontSize = 11.sp
                    )
                  )
                }
              }

              if (parsedItems.size > 5) {
                Text(
                  text = "... and ${parsedItems.size - 5} more items",
                  style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary),
                  modifier = Modifier.padding(top = 4.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Import Strategy Options
          Text(
            text = "Import Option (اسٹاک درج کرنے کا طریقہ):",
            style = MaterialTheme.typography.titleSmall.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFFF5F7F2))
              .clickable { replaceExisting = false }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(
              selected = !replaceExisting,
              onClick = { replaceExisting = false },
              colors = RadioButtonDefaults.colors(selectedColor = NavyBluePrimary)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Column {
              Text(
                text = "Append to Existing Stock (موجودہ میں شامل کریں)",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
              )
              Text(
                text = "Keeps your current items and adds new items",
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFFF5F7F2))
              .clickable { replaceExisting = true }
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(
              selected = replaceExisting,
              onClick = { replaceExisting = true },
              colors = RadioButtonDefaults.colors(selectedColor = ExpenseRed)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Column {
              Text(
                text = "Replace All Stock (سارا پرانا ڈیٹا ختم کر کے نیا رکھیں)",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
              )
              Text(
                text = "Clears previous stock list and imports new fresh list",
                style = MaterialTheme.typography.bodySmall.copy(color = ExpenseRed)
              )
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Confirm Upload Button
          Button(
            onClick = {
              onConfirmImport(parsedItems, replaceExisting)
              Toast.makeText(context, "Successfully imported ${parsedItems.size} products!", Toast.LENGTH_LONG).show()
              onDismiss()
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = "Confirm", tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Confirm Import ${parsedItems.size} Products (درج کریں)",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }

        } else if (errorMessage != null) {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5))
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Error, contentDescription = "Error", tint = ExpenseRed)
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = errorMessage ?: "Failed to parse data",
                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF991B1B))
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Developer Footer
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF7F9F3))
            .padding(12.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "🌟 Developed by Muhammad Arshad, 0302-7761415",
            style = MaterialTheme.typography.bodySmall.copy(
              fontWeight = FontWeight.Bold,
              color = NavyBluePrimary,
              fontSize = 12.sp
            )
          )
        }
      }
    }
  }
}
