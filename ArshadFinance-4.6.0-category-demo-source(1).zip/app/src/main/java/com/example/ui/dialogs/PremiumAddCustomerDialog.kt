package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.example.data.model.*


@Composable
fun AddCustomerDialog(
  editingCustomer: Customer? = null,
  totalExistingCustomersCount: Int = 0,
  isBasicTierRestricted: Boolean = false,
  onSaveCustomer: (Customer) -> Unit,
  onDismiss: () -> Unit,
  appLanguage: AppLanguage = AppLanguage.ENGLISH
) {
  val urdu = appLanguage == AppLanguage.URDU
  fun label(en: String, ur: String) = if (urdu) ur else en
  var advanced by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf("") }
  if (advanced || (isBasicTierRestricted && editingCustomer == null && totalExistingCustomersCount >= 5)) {
    LegacyAddCustomerDialog(editingCustomer, totalExistingCustomersCount, isBasicTierRestricted, onSaveCustomer, onDismiss); return
  }
  var name by remember { mutableStateOf(editingCustomer?.name ?: "") }
  var phone by remember { mutableStateOf(editingCustomer?.phone ?: "") }
  var address by remember { mutableStateOf(editingCustomer?.address ?: "") }
  var type by remember { mutableStateOf(editingCustomer?.customerType ?: "Regular") }
  val metadata=remember {org.json.JSONObject(editingCustomer?.detailsJson ?: "{}")}
  var opening by remember {mutableStateOf(metadata.optDouble("openingBalance",0.0).toString())}
  var credit by remember {mutableStateOf(metadata.optDouble("creditLimit",0.0).toString())}
  var cnic by remember {mutableStateOf(metadata.optString("cnic"))}
  var ntn by remember {mutableStateOf(metadata.optString("ntn"))}
  var note by remember { mutableStateOf(editingCustomer?.note ?: "") }
  BusinessForm(if (editingCustomer == null) label("Add Customer", "نیا گاہک شامل کریں") else label("Edit Customer", "گاہک کی ترمیم"), label("Save Customer", "گاہک محفوظ کریں"), onDismiss, {
    if (name.isBlank()) error = label("Enter the customer name.", "گاہک کا نام درج کریں۔")
    else if(opening.toDoubleOrNull()?.isFinite()!=true || credit.toDoubleOrNull()?.let {it.isFinite()&&it>=0}!=true) error=label("Enter valid opening balance and credit limit.","ابتدائی بقایا اور ادھار کی حد درست درج کریں۔")
    else { metadata.put("openingBalance",opening.toDouble()).put("creditLimit",credit.toDouble()).put("cnic",cnic.trim()).put("ntn",ntn.trim());onSaveCustomer((editingCustomer ?: Customer(name = name.trim())).copy(name = name.trim(), phone = phone.trim(), address = address.trim(), customerType = type.trim(), note = note.trim(),detailsJson=metadata.toString())); onDismiss() }
  }) {
    Text(label("A clear khata for every customer", "ہر گاہک کے لیے صاف کھاتہ"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    BusinessField(name, label("Customer name", "گاہک کا نام")) { name = it }
    BusinessField(phone, label("Mobile number", "موبائل نمبر")) { phone = it }
    BusinessField(address, label("Address", "پتہ")) { address = it }
    BusinessField(type, label("Customer type", "گاہک کی قسم")) { type = it }
    BusinessField(opening,label("Opening balance (+ customer owes you)","ابتدائی بقایا (+ گاہک آپ کو ادا کرے گا)")) {opening=it}
    BusinessField(credit,label("Credit limit (0 = unlimited)","ادھار کی حد (0 = کوئی حد نہیں)")) {credit=it}
    BusinessField(cnic,label("CNIC (optional)","شناختی کارڈ (اختیاری)")) {cnic=it}
    BusinessField(ntn,label("NTN (optional)","این ٹی این (اختیاری)")) {ntn=it}
    BusinessField(note, label("Notes", "نوٹ")) { note = it }
    if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
    TextButton(onClick = { advanced = true }) { Text(label("More customer tools", "گاہک کے مزید ٹولز")) }
  }
}
