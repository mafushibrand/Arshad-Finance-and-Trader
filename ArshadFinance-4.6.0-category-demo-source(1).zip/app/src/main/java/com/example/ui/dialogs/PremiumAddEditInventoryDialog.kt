package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.example.data.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun BusinessForm(title: String, saveLabel: String, dismiss: () -> Unit, save: () -> Unit,
  body: @Composable ColumnScope.() -> Unit) {
  androidx.compose.ui.window.Dialog(onDismissRequest = dismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
    Scaffold(containerColor = androidx.compose.ui.graphics.Color(0xFFF7F8F2), topBar = { TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = dismiss) { Icon(Icons.Default.Close, title) } }) },
      bottomBar = { Surface { Button(onClick = save, modifier = Modifier.fillMaxWidth().padding(16.dp).height(54.dp), shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp)) { Icon(Icons.Default.Check, null); Spacer(Modifier.width(8.dp)); Text(saveLabel) } } }) { padding ->
      Column(Modifier.padding(padding).imePadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = body)
    }
  }
}

@Composable
internal fun BusinessField(value: String, label: String, numeric: Boolean = false, change: (String) -> Unit) {
  OutlinedTextField(value, change, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true,
    shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text))
}


@Composable
fun AddEditInventoryDialog(
  item: InventoryItem? = null,
  currencySymbol: String = "Rs",
  totalExistingProductsCount: Int = 0,
  isBasicTierRestricted: Boolean = false,
  onDismiss: () -> Unit,
  onSave: (
    id: Long,
    name: String,
    category: String,
    icon: String,
    costPrice: Double,
    salePrice: Double,
    currentStock: Double,
    unit: String,
    lowStockThreshold: Double,
    barcode: String,
    supplierName: String,
    note: String
  ) -> Unit,
  onDelete: ((InventoryItem) -> Unit)? = null,
  appLanguage: AppLanguage = AppLanguage.ENGLISH,
  templateId: String = "kiryana",
  onSaveFull: ((InventoryItem) -> Unit)? = null
) {
  val urdu = appLanguage == AppLanguage.URDU
  fun label(en: String, ur: String) = if (urdu) ur else en
  var advanced by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf("") }
  if (advanced || (isBasicTierRestricted && item == null && totalExistingProductsCount >= 5)) {
    LegacyAddEditInventoryDialog(item, currencySymbol, totalExistingProductsCount, isBasicTierRestricted, onDismiss, onSave, onDelete); return
  }
  val template = com.example.business.BusinessLibrary.find(templateId)
  var details by remember { mutableStateOf(com.example.business.BusinessLibrary.details(item?.detailsJson ?: "{}").toString()) }
  fun value(key: String) = com.example.business.BusinessLibrary.details(details).optString(key)
  fun change(key: String, value: String) { details = com.example.business.BusinessLibrary.details(details).put(key,value).toString() }
  var name by remember { mutableStateOf(item?.name ?: "") }
  var category by remember { mutableStateOf(item?.category ?: "General") }
  var cost by remember { mutableStateOf(item?.costPrice?.toString() ?: "0") }
  var price by remember { mutableStateOf(item?.salePrice?.toString() ?: "") }
  var stock by remember { mutableStateOf(item?.currentStock?.toString() ?: "0") }
  var unit by remember { mutableStateOf(item?.unit ?: template.unit) }
  var threshold by remember { mutableStateOf(item?.lowStockThreshold?.toString() ?: "5") }
  var barcode by remember { mutableStateOf(item?.barcode ?: "") }
  var supplier by remember { mutableStateOf(item?.supplierName ?: "") }
  var note by remember { mutableStateOf(item?.note ?: "") }
  var icon by remember { mutableStateOf(item?.icon ?: "📦") }
  var confirmDelete by remember { mutableStateOf(false) }
  BusinessForm(if (item == null) label("Add New Product", "نیا سامان شامل کریں") else label("Edit Product", "سامان کی ترمیم"), label("Save Product", "سامان محفوظ کریں"), onDismiss, {
    val values = listOf(cost, price, stock, threshold).map { it.toDoubleOrNull() }
    if (name.isBlank() || unit.isBlank() || values.any { it == null || !it.isFinite() || it < 0 } || (values[1] ?: 0.0) <= 0) error = label("Enter a name, unit and valid prices/stock.", "نام، یونٹ، قیمت اور اسٹاک درست درج کریں۔")
    else {
      val conversion = value("conversion").ifBlank { "1" }.toDoubleOrNull()
      if (conversion == null || !conversion.isFinite() || conversion <= 0) { error = label("Conversion must be positive", "یونٹ تبدیلی مثبت درج کریں") }
      else if (onSaveFull != null) onSaveFull((item ?: InventoryItem(name=name.trim())).copy(name=name.trim(),category=category.trim(),icon=icon,costPrice=values[0]!!,salePrice=values[1]!!,currentStock=values[2]!!,unit=unit.trim(),lowStockThreshold=values[3]!!,barcode=barcode.trim(),supplierName=supplier.trim(),note=note,detailsJson=details,lastUpdatedMillis=System.currentTimeMillis()))
      else { onSave(item?.id ?: 0L,name.trim(),category.trim(),icon,values[0]!!,values[1]!!,values[2]!!,unit.trim(),values[3]!!,barcode.trim(),supplier.trim(),note); onDismiss() }
    }
  }) {
    Text(label("Product details", "سامان کی تفصیل"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    BusinessChoice(value("itemType").ifBlank { "Product" }, label("Item type", "آئٹم کی قسم"), com.example.business.BusinessLibrary.itemTypes) { change("itemType",it) }
    BusinessField(name, label("Name English", "نام انگریزی")) { name = it }
    BusinessField(value("nameUrdu"),label("Name Urdu", "نام اردو")) { change("nameUrdu",it) }
    BusinessField(category, label("Category", "قسم")) { category = it }
    BusinessField(cost, label("Purchase price ($currencySymbol)", "خرید قیمت ($currencySymbol)"), true) { cost = it }
    BusinessField(price, label("Selling price ($currencySymbol)", "فروخت قیمت ($currencySymbol)"), true) { price = it }
    BusinessField(stock, label("Opening / available stock", "ابتدائی / دستیاب اسٹاک"), true) { stock = it }
    BusinessChoice(unit, label("Base / stock unit", "بنیادی / اسٹاک یونٹ"), com.example.business.BusinessLibrary.allUnits, allowCustom = true) { unit = it }
    BusinessChoice(value("purchaseUnit").ifBlank { unit },label("Purchase unit", "خرید یونٹ"),com.example.business.BusinessLibrary.allUnits, allowCustom = true) { change("purchaseUnit",it) }
    BusinessField(value("conversion").ifBlank { "1" },label("Base units per purchase unit", "ایک خرید یونٹ میں بنیادی مقدار"),true) { change("conversion",it) }
    Text(label("Example: 1 carton = 24 bottles; enter 24. Use base-unit quantities in POS and stock.", "مثال: ایک کارٹن میں ۲۴ بوتلیں، ۲۴ درج کریں۔ فروخت اور اسٹاک میں بنیادی یونٹ استعمال کریں۔"),style=MaterialTheme.typography.bodySmall)
    BusinessChoice(value("saleUnit").ifBlank { unit },label("Sale unit", "فروخت یونٹ"),com.example.business.BusinessLibrary.allUnits, allowCustom = true) { change("saleUnit",it) }
    BusinessField(value("saleConversion").ifBlank { "1" },label("Base units per sale unit", "ایک فروخت یونٹ میں بنیادی مقدار"),true) { change("saleConversion",it) }
    BusinessField(threshold, label("Low-stock alert at", "کم اسٹاک کی حد"), true) { threshold = it }
    BusinessField(barcode, label("Barcode / SKU", "بارکوڈ / کوڈ")) { barcode = it }
    BusinessField(supplier, label("Supplier", "سپلائر")) { supplier = it }
    BusinessField(value("subcategory"),label("Subcategory", "ذیلی قسم")) { change("subcategory",it) }
    BusinessField(value("warehouse"),label("Warehouse / rack", "گودام / ریک")) { change("warehouse",it) }
    BusinessField(value("wholesale"),label("Wholesale price", "ہول سیل قیمت"),true) { change("wholesale",it) }
    BusinessField(value("minimum"),label("Minimum price", "کم از کم قیمت"),true) { change("minimum",it) }
    template.fields.forEach { key ->
      val ur = mapOf("batch" to "بیچ","mfg" to "تیاری کی تاریخ","expiry" to "میعاد ختم ہونے کی تاریخ","serial" to "سیریل نمبر","imei" to "آئی ایم ای آئی","warranty" to "وارنٹی","size" to "سائز","color" to "رنگ","model" to "ماڈل","grade" to "گریڈ","purity" to "خالص پن","makingCharges" to "بنوائی چارجز","brand" to "برانڈ")[key] ?: key
      BusinessField(value(key),label(key.replaceFirstChar { it.uppercase() },ur)) { change(key,it) }
    }
    BusinessField(value("taxRate"),label("Tax rate % (optional)", "ٹیکس شرح % (اختیاری)"),true) { change("taxRate",it) }
    BusinessField(value("commission"),label("Commission (optional)", "کمیشن (اختیاری)"),true) { change("commission",it) }
    BusinessField(note, label("Notes", "نوٹ")) { note = it }
    BusinessField(icon, label("Product icon", "سامان کا آئیکن")) { icon = it }
    if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
    TextButton(onClick = { advanced = true }) { Text(label("More product tools", "سامان کے مزید ٹولز")) }
    if (item != null && onDelete != null) OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) { Text(label("Delete Product", "سامان حذف کریں")) }
  }
  if (confirmDelete && item != null) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text(label("Delete product?", "سامان حذف کریں؟")) }, text = { Text(item.name) }, confirmButton = { TextButton(onClick = { onDelete?.invoke(item); onDismiss() }) { Text(label("Delete", "حذف")) } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(label("Cancel", "منسوخ")) } })
}
