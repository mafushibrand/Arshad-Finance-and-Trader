package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.UserAccount
import com.example.ui.theme.InputFieldStyles

@Composable
fun LegacyLoginScreen(
  userAccount: UserAccount,
  appLanguage: AppLanguage,
  onToggleLanguage: () -> Unit,
  onLoginSuccess: (mobile: String, shopName: String, ownerName: String, city: String) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val isUrdu = appLanguage == AppLanguage.URDU

  var isSignUp by remember { mutableStateOf(false) }
  var mobileNumber by remember { mutableStateOf(userAccount.mobileNumber.ifBlank { "0302-7761415" }) }
  var password by remember { mutableStateOf("123456") }
  var isPasswordVisible by remember { mutableStateOf(false) }
  var shopName by remember { mutableStateOf(userAccount.shopName.ifBlank { "Arshad Finance & Traders" }) }
  var ownerName by remember { mutableStateOf(userAccount.ownerName.ifBlank { "Muhammad Arshad" }) }
  var cityRegion by remember { mutableStateOf(userAccount.cityRegion) }
  var showForgotPasswordDialog by remember { mutableStateOf(false) }
  var showOtpSimulationDialog by remember { mutableStateOf(false) }
  var otpInput by remember { mutableStateOf("") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  if (showForgotPasswordDialog) {
    androidx.compose.material3.AlertDialog(
      onDismissRequest = { showForgotPasswordDialog = false },
      title = {
        Text(if (isUrdu) "پاسورڈ بھول گئے؟" else "Forgot Password?", fontWeight = FontWeight.Bold)
      },
      text = {
        Column {
          Text(
            if (isUrdu)
              "آپ کے رجسٹرڈ موبائل نمبر $mobileNumber پر پاسورڈ بحالی کا کوڈ ایس ایم ایس اور واٹس ایپ کے ذریعے بھیج دیا گیا ہے۔"
            else
              "A password recovery code has been sent via SMS/WhatsApp to $mobileNumber."
          )
          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            color = Color(0xFFE5F3EA),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "Temporary Recovery PIN: 7861",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = Color(0xFF086B4D),
              modifier = Modifier.padding(10.dp),
              textAlign = TextAlign.Center
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showForgotPasswordDialog = false
            password = "PIN-7861-RESET"
            Toast.makeText(context, if (isUrdu) "پاسورڈ ری سیٹ ہو گیا" else "Password reset successful!", Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D))
        ) {
          Text(if (isUrdu) "لاگ ان کریں" else "Use PIN to Login")
        }
      },
      dismissButton = {
        TextButton(onClick = { showForgotPasswordDialog = false }) {
          Text(if (isUrdu) "منسوخ" else "Cancel")
        }
      }
    )
  }

  if (showOtpSimulationDialog) {
    androidx.compose.material3.AlertDialog(
      onDismissRequest = { showOtpSimulationDialog = false },
      title = {
        Text(if (isUrdu) "تصدیقی کوڈ درج کریں" else "Enter Verification OTP", fontWeight = FontWeight.Bold)
      },
      text = {
        Column {
          Text(
            if (isUrdu)
              "موبائل نمبر $mobileNumber کی تصدیق کیلئے کوڈ (OTP) بھیجا گیا ہے:"
            else
              "Verification OTP has been sent to $mobileNumber:"
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Auto-generated OTP: 7861",
            fontWeight = FontWeight.Bold,
            color = Color(0xFF059669),
            fontSize = 14.sp
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = otpInput,
            onValueChange = { otpInput = it },
            placeholder = { Text("7861") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (otpInput.trim() == "7861" || otpInput.trim().length >= 4) {
              showOtpSimulationDialog = false
              onLoginSuccess(mobileNumber, shopName, ownerName, cityRegion)
              Toast.makeText(context, if (isUrdu) "اکاؤنٹ کامیابی سے بن گیا!" else "Account created & verified!", Toast.LENGTH_LONG).show()
            } else {
              Toast.makeText(context, if (isUrdu) "غلط کوڈ، 7861 درج کریں" else "Invalid OTP, please enter 7861", Toast.LENGTH_SHORT).show()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
        ) {
          Text(if (isUrdu) "تصدیق و داخل ہوں" else "Verify & Continue")
        }
      },
      dismissButton = {
        TextButton(onClick = { showOtpSimulationDialog = false }) {
          Text(if (isUrdu) "منسوخ" else "Cancel")
        }
      }
    )
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
    ) {
      // 1. Lavish Top Curved Header
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                Color(0xFF006C45), // Deep Navy Indigo
                Color(0xFF086B4D), // Vibrant Blue
                Color(0xFF0F172A)  // Dark Background
              )
            )
          )
          .padding(top = 40.dp, bottom = 24.dp, start = 20.dp, end = 20.dp)
      ) {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Language Switcher Top Right
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
          ) {
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = Color.White.copy(alpha = 0.2f),
              modifier = Modifier.clickable { onToggleLanguage() }
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Language, contentDescription = "Language", tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isUrdu) "English" else "اردو",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Brand Logo Badge
          Surface(
            shape = CircleShape,
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier.size(76.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(text = "🏪", fontSize = 38.sp)
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = if (isUrdu) "ارشد فنانس و ٹریڈرز" else "Arshad Finance & Traders",
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            letterSpacing = 0.5.sp
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = if (isUrdu)
              "آل ان ون پی او ایس، بلنگ، کھاتہ اور لوکل/کلاؤڈ سنک"
            else
              "All-in-One POS, Dynamic Billing, Khata & Cloud Sync",
            fontSize = 12.sp,
            color = Color(0xFF99C9AB),
            textAlign = TextAlign.Center
          )
        }
      }

      // 2. Main Auth Card Container
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        shadowElevation = 12.dp
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
        ) {
          // Tab Toggle: [ Login ] | [ Sign Up ]
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFFF7F9F3),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
            ) {
              // Login Tab
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (!isSignUp) Color(0xFF086B4D) else Color.Transparent,
                modifier = Modifier
                  .weight(1f)
                  .clickable {
                    isSignUp = false
                    errorMessage = null
                  }
              ) {
                Text(
                  text = if (isUrdu) "🔐 لاگ ان (Login)" else "🔐 Login",
                  fontSize = 13.5.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (!isSignUp) Color.White else Color(0xFF64748B),
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(vertical = 10.dp)
                )
              }

              // Sign Up Tab
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isSignUp) Color(0xFF086B4D) else Color.Transparent,
                modifier = Modifier
                  .weight(1f)
                  .clickable {
                    isSignUp = true
                    errorMessage = null
                  }
              ) {
                Text(
                  text = if (isUrdu) "📝 نیا اکاؤنٹ (Sign Up)" else "📝 Sign Up",
                  fontSize = 13.5.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isSignUp) Color.White else Color(0xFF64748B),
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(vertical = 10.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(18.dp))

          // Error banner if any
          if (errorMessage != null) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFFFEE2E2),
              modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
              Text(
                text = errorMessage ?: "",
                color = Color(0xFFDC2626),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(10.dp)
              )
            }
          }

          // Mobile Number or Email Input (Primary Key)
          Text(
            text = if (isUrdu) "موبائل نمبر یا ای میل درج کریں:" else "Login with Mobile Number or Email:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1E293B)
          )
          Spacer(modifier = Modifier.height(6.dp))

          CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            OutlinedTextField(
              value = mobileNumber,
              onValueChange = { mobileNumber = it },
              placeholder = { 
                Text(
                  if (isUrdu) "0302-7761415 یا email@gmail.com" else "0302-7761415 or email@domain.com",
                  fontSize = 12.5.sp,
                  color = Color(0xFF94A3B8)
                ) 
              },
              leadingIcon = {
                Icon(
                  if (mobileNumber.contains("@")) Icons.Default.Email else Icons.Default.Phone,
                  contentDescription = null,
                  tint = Color(0xFF086B4D)
                )
              },
              keyboardOptions = KeyboardOptions(keyboardType = if (mobileNumber.contains("@")) KeyboardType.Email else KeyboardType.Text),
              textStyle = InputFieldStyles.textStyle,
              colors = InputFieldStyles.colors(),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("auth_mobile_input"),
              singleLine = true
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Password Input
          Text(
            text = if (isUrdu) "پاسورڈ درج کریں:" else "Password:",
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
          )
          Spacer(modifier = Modifier.height(4.dp))
          OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            placeholder = { Text("••••••••") },
            leadingIcon = {
              Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF086B4D))
            },
            trailingIcon = {
              IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                Icon(
                  imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                  contentDescription = "Toggle Password"
                )
              }
            },
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("auth_password_input"),
            singleLine = true
          )

          // Extra fields when Signing Up
          AnimatedVisibility(visible = isSignUp) {
            Column {
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = if (isUrdu) "دکان یا کاروبار کا نام:" else "Shop / Business / Usage Name:",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF334155)
              )
              Spacer(modifier = Modifier.height(4.dp))
              OutlinedTextField(
                value = shopName,
                onValueChange = { shopName = it },
                placeholder = { Text(if (isUrdu) "مثلاً ارشد ٹریڈرز یا ذاتی کھاتہ" else "e.g. Arshad Traders or Personal Khata") },
                leadingIcon = {
                  Icon(Icons.Default.Business, contentDescription = null, tint = Color(0xFF10B981))
                },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )

              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = if (isUrdu) "مالک / صارف کا نام:" else "Owner / User Name:",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF334155)
              )
              Spacer(modifier = Modifier.height(4.dp))
              OutlinedTextField(
                value = ownerName,
                onValueChange = { ownerName = it },
                placeholder = { Text(if (isUrdu) "مثلاً محمد ارشد" else "e.g. Muhammad Arshad") },
                leadingIcon = {
                  Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFF10B981))
                },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )

              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = if (isUrdu) "شہر و علاقہ:" else "City / Region:",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF334155)
              )
              Spacer(modifier = Modifier.height(4.dp))
              OutlinedTextField(
                value = cityRegion,
                onValueChange = { cityRegion = it },
                placeholder = { Text("Enter city / country") },
                leadingIcon = {
                  Icon(Icons.Default.Place, contentDescription = null, tint = Color(0xFF10B981))
                },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
            }
          }

          if (!isSignUp) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End
            ) {
              TextButton(onClick = { showForgotPasswordDialog = true }) {
                Text(
                  text = if (isUrdu) "پاسورڈ بھول گئے؟" else "Forgot Password?",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = Color(0xFF086B4D)
                )
              }
            }
          } else {
            Spacer(modifier = Modifier.height(16.dp))
          }

          // Main Action Button
          Button(
            onClick = {
              if (mobileNumber.isBlank()) {
                errorMessage = if (isUrdu) "برائے مہربانی موبائل نمبر یا ای میل درج کریں" else "Please enter your mobile number or email"
                return@Button
              }
              if (password.isBlank()) {
                errorMessage = if (isUrdu) "برائے مہربانی پاسورڈ درج کریں" else "Please enter your password"
                return@Button
              }

              if (isSignUp) {
                // Show simulated OTP for new registration
                showOtpSimulationDialog = true
              } else {
                onLoginSuccess(mobileNumber, shopName, ownerName, cityRegion)
                if (mobileNumber.contains("@")) {
                  Toast.makeText(
                    context,
                    if (isUrdu) "آپ کے ای میل ($mobileNumber) پر لاگ ان تصدیقی میسج بھیج دیا گیا ہے کہ آپ کا لاگ ان کامیاب ہو گیا ہے۔" 
                    else "Login confirmation sent to $mobileNumber!",
                    Toast.LENGTH_LONG
                  ).show()
                } else {
                  Toast.makeText(context, if (isUrdu) "خوش آمدید! لاگ ان کامیاب" else "Welcome back! Login successful", Toast.LENGTH_SHORT).show()
                }
              }
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isSignUp) Color(0xFF059669) else Color(0xFF086B4D)
            ),
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("btn_auth_submit")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (isSignUp) Icons.Default.Security else Icons.Default.Lock,
                contentDescription = null,
                tint = Color.White
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isSignUp) {
                  if (isUrdu) "اکاؤنٹ بنائیں اور کوڈ کی تصدیق کریں →" else "Register & Verify OTP →"
                } else {
                  if (isUrdu) "لاگ ان کریں اور کھاتہ کھولیں →" else "Secure Login →"
                },
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Quick 1-Tap Demo Login Button (Instant Access)
          androidx.compose.material3.OutlinedButton(
            onClick = {
              onLoginSuccess("0302-7761415", "Arshad Finance & Traders", "Muhammad Arshad", "")
              Toast.makeText(context, if (isUrdu) "ڈیمو لاگ ان کامیاب!" else "Instant Demo Login Successful!", Toast.LENGTH_SHORT).show()
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("btn_quick_demo_login")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text("⚡", fontSize = 16.sp)
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isUrdu) "براہ راست داخلہ (1-Tap Demo Login)" else "Instant Access (1-Tap Demo Login)",
                fontWeight = FontWeight.Bold,
                fontSize = 13.5.sp,
                color = Color(0xFF086B4D)
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Secure Cloud & Offline Badge
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFFF5F7F2),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isUrdu) "100% محفوظ کلاؤڈ بیک اپ و آف لائن کام کی سہولت" else "100% Secure Offline & Cloud Auto-Sync",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF334155)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
