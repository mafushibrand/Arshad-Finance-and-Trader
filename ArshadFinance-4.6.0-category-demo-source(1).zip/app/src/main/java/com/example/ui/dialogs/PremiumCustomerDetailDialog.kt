package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.util.BusinessProfile
import com.example.util.BusinessUtils

@Composable
fun CustomerDetailDialog(customer: Customer, invoices: List<Invoice>, businessProfile: BusinessProfile,
  currencySymbol: String = "Rs", onEditCustomer: (Customer) -> Unit = {}, onSelectInvoice: (Invoice) -> Unit = {},
  onNewBillForCustomer: (Customer) -> Unit, onDeleteCustomer: (Customer) -> Unit, onDismiss: () -> Unit,
  appLanguage: AppLanguage = AppLanguage.ENGLISH,
  onReceiveCash: (Double, String, (String?) -> Unit) -> Unit = { _, _, done -> done("Receipt action unavailable") }) {
  val urdu = appLanguage == AppLanguage.URDU
  fun label(en: String, ur: String) = if (urdu) ur else en
  fun money(value: Double) = String.format(java.util.Locale.US, "%s %,.2f", currencySymbol, value)
  val context = androidx.compose.ui.platform.LocalContext.current
  var billSearch by remember { mutableStateOf("") }
  var advanced by remember { mutableStateOf(false) }
  var receive by remember { mutableStateOf(false) }
  var amount by remember { mutableStateOf("") }
  var note by remember { mutableStateOf("") }
  var busy by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf("") }
  val bills = invoices.filter { it.customerId == customer.id }.sortedByDescending { it.dateMillis }
  if (advanced) { LegacyCustomerDetailDialog(customer, invoices, businessProfile, currencySymbol, onEditCustomer, onSelectInvoice, onNewBillForCustomer, onDeleteCustomer, onDismiss, onReceiveCash); return }
  BusinessForm(label("Customer Khata", "گاہک کا کھاتہ"), label("New Bill / Udhar", "نیا بل / ادھار"), onDismiss, { onNewBillForCustomer(customer) }) {
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
      FilledTonalIconButton(onClick = { onEditCustomer(customer) }) { Icon(Icons.Default.Person, null) }
      Spacer(Modifier.width(12.dp)); Column { Text(customer.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text(customer.phone) }
    }
    Surface(color = MaterialTheme.colorScheme.errorContainer, shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
      Column(Modifier.padding(22.dp), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(label("Due amount", "بقایا رقم")); Text(money(customer.currentBalance), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
      }
    }
    Button(onClick = { receive = true }, enabled = customer.currentBalance > 0, modifier = Modifier.fillMaxWidth().height(54.dp)) { Icon(Icons.Default.Add, null); Text(label("Cash Received", "پیسے وصول ہوئے")) }
    OutlinedButton(onClick = {
      val statement = businessProfile.businessName + "\n" + customer.name + "\n" + label("Due: ", "بقایا: ") + money(customer.currentBalance) + "\n" + bills.joinToString("\n") { it.invoiceNumber + " • " + money(it.grandTotal) + " • " + label("Due ", "بقایہ ") + money(it.remainingBalance) }
      BusinessUtils.shareWhatsAppMessage(context, customer.phone, statement)
    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text(label("Share Statement / WhatsApp", "تفصیل شیئر کریں / واٹس ایپ")) }
    Text(label("Bill history (${bills.size})", "بلوں کی تفصیل (${bills.size})"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    if (bills.isEmpty()) Text(label("No bills yet", "ابھی کوئی بل نہیں"))
    BusinessField(billSearch, label("Search bill number", "بل نمبر تلاش کریں")) { billSearch = it }
    bills.filter { it.invoiceNumber.contains(billSearch, true) }.forEach { bill -> Surface(onClick = { onSelectInvoice(bill) }, shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
      Column(Modifier.padding(16.dp)) {
        Row { Text(bill.invoiceNumber, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text(money(bill.netTotal())) }
        Text(java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.ENGLISH).format(java.util.Date(bill.dateMillis)), style = MaterialTheme.typography.bodySmall)
        Text(label("Received: ", "وصول شدہ: ") + money(bill.amountPaid) + " • " + label("Due: ", "بقایہ: ") + money(bill.remainingBalance), color = MaterialTheme.colorScheme.primary)
      }
    } }
    TextButton(onClick = { advanced = true }) { Text(label("More statement tools", "تفصیل کے مزید ٹولز")) }
  }
  if (receive) AlertDialog(onDismissRequest = { if (!busy) receive = false }, title = { Text(label("Receive cash", "کیش وصول کریں")) }, text = {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
      BusinessField(amount, label("Amount ($currencySymbol)", "رقم ($currencySymbol)"), true) { amount = it }
      BusinessField(note, label("Note", "نوٹ")) { note = it }
      Text(label("Applied to oldest unpaid bills and your cash account.", "پرانے بقایا بل اور کیش اکاؤنٹ میں محفوظ ہوگا۔"), style = MaterialTheme.typography.bodySmall)
      if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
      if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
    }
  }, confirmButton = { TextButton(onClick = {
    val received = amount.toDoubleOrNull()
    if (received == null || !received.isFinite() || received <= 0) error = label("Enter a valid amount", "درست رقم درج کریں")
    else { busy = true; onReceiveCash(received, note) { failure -> busy = false; if (failure == null) receive = false else error = failure } }
  }, enabled = !busy) { Text(label("Save Receipt", "وصولی محفوظ کریں")) } }, dismissButton = { TextButton(onClick = { receive = false }, enabled = !busy) { Text(label("Cancel", "منسوخ")) } })
}
