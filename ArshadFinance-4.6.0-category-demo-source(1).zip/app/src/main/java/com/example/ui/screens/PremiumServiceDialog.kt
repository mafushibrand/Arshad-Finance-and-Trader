package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.data.model.ServiceItem
import com.example.ui.dialogs.*
import com.example.business.BusinessLibrary

@Composable
fun AddEditServiceDialog(service: ServiceItem?,isUrdu:Boolean,currency:String,onDismiss:()->Unit,onSave:(ServiceItem)->Unit) {
  fun t(en:String,ur:String)=if(isUrdu)ur else en
  var name by remember{mutableStateOf(service?.name ?: "")};var ur by remember{mutableStateOf(service?.urduName ?: "")}
  var category by remember{mutableStateOf(service?.businessCategory ?: "GENERAL")};var type by remember{mutableStateOf(service?.serviceType ?: "")}
  var price by remember{mutableStateOf(service?.price?.toString() ?: "")};var discount by remember{mutableStateOf(service?.discountPrice?.toString() ?: "0")}
  var active by remember{mutableStateOf(service?.isDiscountActive ?: false)};var qty by remember{mutableStateOf(service?.quantity?.toString() ?: "1")}
  var slots by remember{mutableStateOf(service?.stockOrSlots?.toString() ?: "0")};var unit by remember{mutableStateOf(service?.unit ?: "service")}
  var icon by remember{mutableStateOf(service?.icon ?: "🛠️")};var description by remember{mutableStateOf(service?.description ?: "")};var error by remember{mutableStateOf("")}
  BusinessForm(t("Service details","سروس کی تفصیل"),t("Save service","سروس محفوظ کریں"),onDismiss,{
    val p=price.toDoubleOrNull();val d=discount.toDoubleOrNull();val q=qty.toDoubleOrNull();val s=slots.toDoubleOrNull()
    if(name.isBlank()||listOf(p,d,q,s).any{it==null||!it.isFinite()||it<0}||q==0.0||(active&&d!!>p!!))error=t("Enter a name and valid prices / quantities","نام، درست قیمت اور مقدار درج کریں")
    else {onSave((service ?: ServiceItem(name=name,businessCategory=category,serviceType=type,price=p!!)).copy(name=name.trim(),urduName=ur.trim(),businessCategory=category,serviceType=type,price=p!!,discountPrice=d!!,isDiscountActive=active,quantity=q!!,stockOrSlots=s!!,unit=unit,icon=icon,description=description));onDismiss()}
  }) {
    BusinessField(name,t("Name English","نام انگریزی")){name=it};BusinessField(ur,t("Name Urdu","نام اردو")){ur=it}
    BusinessField(category,t("Business category","کاروباری قسم")){category=it};BusinessField(type,t("Service type","سروس کی قسم")){type=it}
    BusinessChoice(unit,t("Billing unit","بلنگ یونٹ"),BusinessLibrary.allUnits,allowCustom=true){unit=it}
    BusinessField(price,t("Price ($currency)","قیمت ($currency)"),true){price=it}
    Row{Text(t("Offer discount","رعایت فعال کریں"),Modifier.weight(1f));Switch(active,{active=it})}
    if(active)BusinessField(discount,t("Discounted price","رعایتی قیمت"),true){discount=it}
    BusinessField(qty,t("Default quantity","پہلے سے مقرر مقدار"),true){qty=it};BusinessField(slots,t("Available slots (optional)","دستیاب سلاٹس (اختیاری)"),true){slots=it}
    BusinessField(icon,t("Icon","آئیکن")){icon=it};BusinessField(description,t("Description","تفصیل")){description=it}
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}
