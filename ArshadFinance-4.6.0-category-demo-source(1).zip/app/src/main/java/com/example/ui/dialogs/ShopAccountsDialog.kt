package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.InputFieldStyles
import com.example.util.BusinessProfile

@Composable
fun ShopAccountsDialog(
  currentProfile: BusinessProfile,
  onSave: (BusinessProfile) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current

  var bankName by remember { mutableStateOf(currentProfile.bankName) }
  var bankAccountTitle by remember { mutableStateOf(currentProfile.bankAccountTitle) }
  var bankAccountNumber by remember { mutableStateOf(currentProfile.bankAccountNumber) }
  var bankIban by remember { mutableStateOf(currentProfile.bankIban) }
  var jazzCashNumber by remember { mutableStateOf(currentProfile.jazzCashNumber) }
  var easyPaisaNumber by remember { mutableStateOf(currentProfile.easyPaisaNumber) }
  var sadaPayNumber by remember { mutableStateOf(currentProfile.sadaPayNumber) }
  var nayaPayNumber by remember { mutableStateOf(currentProfile.nayaPayNumber) }
  var raastId by remember { mutableStateOf(currentProfile.raastId) }

  val initialCustomSlots = remember {
    androidx.compose.runtime.mutableStateListOf<Pair<String, String>>().apply {
      if (currentProfile.customPaymentSlots.isNotBlank()) {
        currentProfile.customPaymentSlots.split(";;;").forEach { entry ->
          val parts = entry.split(":::")
          if (parts.size == 2) {
            add(Pair(parts[0], parts[1]))
          }
        }
      }
    }
  }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(24.dp))
        .testTag("shop_accounts_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFF086B4D).copy(alpha = 0.12f),
              modifier = Modifier.size(38.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.AccountBalance,
                  contentDescription = null,
                  tint = Color(0xFF086B4D),
                  modifier = Modifier.size(22.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Shop Payment Accounts",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
              )
              Text(
                text = "دکان کے بینک و والٹ کی تفصیلات",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = "یہ اکاؤنٹس بل، واٹس ایپ رسید اور پی ڈی ایف پر پرنٹ ہوں گے تا کہ گاہک براہ راست ادائیگی کر سکے۔",
          fontSize = 11.5.sp,
          color = Color(0xFF475569)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 1. Mobile Wallets (JazzCash & EasyPaisa)
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = Color(0xFFE11D48), modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "MOBILE WALLETS (جاز کیش و ایزی پیسہ):",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFE11D48),
            letterSpacing = 0.6.sp
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = jazzCashNumber,
          onValueChange = { jazzCashNumber = it },
          label = { Text("JazzCash Account Number") },
          placeholder = { Text("e.g. 0302-7761415") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = easyPaisaNumber,
          onValueChange = { easyPaisaNumber = it },
          label = { Text("Easypaisa Account Number") },
          placeholder = { Text("e.g. 0345-9876543") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = Color(0xFFF7F9F3))
        Spacer(modifier = Modifier.height(14.dp))

        // 2. Bank Details
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.AccountBalance, contentDescription = null, tint = Color(0xFF086B4D), modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "SHOP BANK ACCOUNT (بینک اکاؤنٹ کی تفصیل):",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF086B4D),
            letterSpacing = 0.6.sp
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = bankName,
          onValueChange = { bankName = it },
          label = { Text("Bank Name (بینک کا نام)") },
          placeholder = { Text("Meezan Bank Ltd / HBL / UBL") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = bankAccountTitle,
          onValueChange = { bankAccountTitle = it },
          label = { Text("Account Title (اکاؤنٹ ٹائٹل)") },
          placeholder = { Text("Arshad Finance & Traders") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = bankAccountNumber,
          onValueChange = { bankAccountNumber = it },
          label = { Text("Account Number") },
          placeholder = { Text("01020304050607") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = bankIban,
          onValueChange = { bankIban = it },
          label = { Text("IBAN (بین الاقوامی بینک نمبر)") },
          placeholder = { Text("PK89 MEZN 0001 0203 0405 0607") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = Color(0xFFF7F9F3))
        Spacer(modifier = Modifier.height(14.dp))

        // 3. Digital & Fintech Wallets (SadaPay, NayaPay, Raast)
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Payment, contentDescription = null, tint = Color(0xFF0D9488), modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "SADAPAY, NAYAPAY & RAAST (ڈیجیٹل والٹ و راست):",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0D9488),
            letterSpacing = 0.6.sp
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = sadaPayNumber,
          onValueChange = { sadaPayNumber = it },
          label = { Text("SadaPay Number / IBAN") },
          placeholder = { Text("0302-7761415") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = nayaPayNumber,
          onValueChange = { nayaPayNumber = it },
          label = { Text("NayaPay Number / Wallet ID") },
          placeholder = { Text("0302-7761415") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = raastId,
          onValueChange = { raastId = it },
          label = { Text("Raast Instant Pay ID") },
          placeholder = { Text("03027761415") },
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = Color(0xFFE2E8F0))
        Spacer(modifier = Modifier.height(10.dp))

        // Unlimited Dynamic Custom Payment Slots Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "Additional Payment Slots (مزید اکاؤنٹس)",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
            Text(
              text = "Add unlimited banks, wallets, or IBAN numbers",
              fontSize = 10.5.sp,
              color = Color(0xFF64748B)
            )
          }
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFE5F3EA),
            modifier = Modifier.clickable {
              initialCustomSlots.add(Pair("Custom Account", ""))
            }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF086B4D), modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("+ Add Slot", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF086B4D))
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        initialCustomSlots.forEachIndexed { index, slot ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedTextField(
              value = slot.first,
              onValueChange = { newTitle ->
                initialCustomSlots[index] = Pair(newTitle, slot.second)
              },
              label = { Text("Account Name") },
              placeholder = { Text("e.g. HBL / JazzCash 2") },
              textStyle = InputFieldStyles.textStyle,
              colors = InputFieldStyles.colors(),
              modifier = Modifier.weight(1f),
              singleLine = true
            )
            Spacer(modifier = Modifier.width(6.dp))
            OutlinedTextField(
              value = slot.second,
              onValueChange = { newVal ->
                initialCustomSlots[index] = Pair(slot.first, newVal)
              },
              label = { Text("Number / IBAN") },
              placeholder = { Text("03001234567") },
              textStyle = InputFieldStyles.textStyle,
              colors = InputFieldStyles.colors(),
              modifier = Modifier.weight(1.2f),
              singleLine = true
            )
            IconButton(onClick = { initialCustomSlots.removeAt(index) }) {
              Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(20.dp))
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Save Button
        Button(
          onClick = {
            val serializedCustom = initialCustomSlots
              .filter { it.first.isNotBlank() || it.second.isNotBlank() }
              .joinToString(";;;") { "${it.first}:::${it.second}" }

            val updated = currentProfile.copy(
              bankName = bankName,
              bankAccountTitle = bankAccountTitle,
              bankAccountNumber = bankAccountNumber,
              bankIban = bankIban,
              jazzCashNumber = jazzCashNumber,
              easyPaisaNumber = easyPaisaNumber,
              sadaPayNumber = sadaPayNumber,
              nayaPayNumber = nayaPayNumber,
              raastId = raastId,
              customPaymentSlots = serializedCustom
            )
            onSave(updated)
            Toast.makeText(context, "Shop Payment Accounts Updated! ✓", Toast.LENGTH_SHORT).show()
            onDismiss()
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF086B4D)),
          modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
          Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Save Shop Accounts (محفوظ کریں)", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
