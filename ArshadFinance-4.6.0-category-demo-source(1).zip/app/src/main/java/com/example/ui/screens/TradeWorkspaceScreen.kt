package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.business.*
import com.example.ui.*
import com.example.ui.dialogs.*
import com.example.data.model.*
import org.json.JSONObject

@Composable
fun TradeWorkspaceScreen(state:FinanceUiState,viewModel:FinanceViewModel,onBack:()->Unit) {
  var section by remember {mutableStateOf("PURCHASE_BILL")};var query by remember {mutableStateOf("")}
  var form by remember {mutableStateOf(false)};var selected by remember {mutableStateOf<BusinessRecord?>(null)}
  var source by remember {mutableStateOf<BusinessRecord?>(null)};var message by remember {mutableStateOf("")}
  val labels=linkedMapOf("PURCHASE_BILL" to state.word("Purchase bills","خرید بل"),"PURCHASE_ORDER" to state.word("Purchase orders","خرید آرڈر"),"GRN" to state.word("Goods received","سامان وصولی"),"QUOTATION" to state.word("Quotations","کوٹیشن"),"ORDER" to state.word("Sales orders","فروخت آرڈر"),"CHALLAN" to state.word("Delivery challans","ڈلیوری چالان"),"SALES_RETURN" to state.word("Sales returns","فروخت واپسی"),"COMPLAINT_RETURN" to state.word("Return complaints","واپسی کی شکایات"),"PURCHASE_RETURN" to state.word("Purchase returns","خرید واپسی"),"TRANSFER" to state.word("Transfers","منتقلی"),"STOCK_COUNT" to state.word("Stock counts","اسٹاک گنتی"),"LOCATIONS" to state.word("Warehouse stock","گودام اسٹاک"),"CUSTOMER_LEDGER" to state.word("Customer ledger","گاہک کھاتہ"))
  val owner=state.userRole==UserRole.OWNER
  fun done(error:String?) {message=error ?: state.word("Posted successfully","اندراج مکمل ہے");if(error==null){form=false;selected=null;source=null}}
  PremiumPage(state.word("Business documents","کاروباری دستاویزات"),state.word("Linked stock, payments and Khata","اسٹاک، ادائیگی اور کھاتہ ایک ساتھ"),Icons.Default.ReceiptLong,footer={if(owner&&section !in listOf("GRN","LOCATIONS","CUSTOMER_LEDGER"))PremiumButton(state.word("New document","نئی دستاویز"),{source=null;form=true})}) {
    item {TextButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Text(state.word("Business workspace","کاروباری مرکز"))}}
    item {Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){labels.forEach {(key,label)->FilterChip(section==key,{section=key;query=""},label={Text(label)})}}}
    item {SearchBox(query,state.word("Search reference or party","حوالہ یا گاہک تلاش کریں")){query=it}}
    if(message.isNotBlank())item {Text(message,color=MaterialTheme.colorScheme.primary)}
    if(section=="LOCATIONS") {
      val balances=state.stockMovements.groupBy {Triple(it.itemId,it.branchId,it.warehouseId)}
      items(balances.entries.filter {k->state.inventoryItems.find {it.id==k.key.first}?.name?.contains(query,true)==true},key={it.key.toString()}) {row->val item=state.inventoryItems.find {it.id==row.key.first};ListTile(item?.name ?: "#"+row.key.first,row.key.second+" / "+row.key.third,Icons.Default.Warehouse,trailing=row.value.sumOf {it.quantity}.toString()+" "+(item?.unit ?: ""))}
    } else if(section=="CUSTOMER_LEDGER") {
      items(state.customers.filter {it.name.contains(query,true)},key={it.id}) {customer->
        val entries=state.businessRecords.filter {it.party==customer.id.toString()&&it.kind in listOf("CUSTOMER_DEBIT","CUSTOMER_CREDIT")}
        ListTile(customer.name,state.word("Derived from ledger entries","کھاتے کے اندراج سے حساب"),Icons.Default.AccountBalanceWallet,trailing=state.money(entries.sumOf {if(it.kind=="CUSTOMER_DEBIT")it.amount else -it.amount}),click={selected=BusinessRecord(kind="LEDGER_VIEW",title=customer.name,party=customer.id.toString())})
      }
    } else {
      val rows=state.businessRecords.filter {it.kind==section&&!it.archived&&(it.title.contains(query,true)||it.party.contains(query,true))}
      if(rows.isEmpty())item {EmptyList(state.word("No documents yet","ابھی کوئی دستاویز نہیں"),state.word("Create a document to begin","پہلی دستاویز شامل کریں"),Icons.Default.Description)}
      items(rows,key={it.id}) {record->ListTile(record.title,record.party+" • "+record.status+" • "+record.branchId+"/"+record.warehouseId,Icons.Default.Description,trailing=state.money(record.amount),click={selected=record})}
    }
  }
  if(form&&owner)when(section) {
    "PURCHASE_BILL","PURCHASE_ORDER","QUOTATION","ORDER","CHALLAN" -> TradeDocumentForm(section,state,source,{form=false},submit={reference,party,customer,lines,paid,account,branch,warehouse->
      viewModel.tradeAction({if(section.startsWith("PURCHASE"))purchase(section,party,reference,lines,paid,account,branch,warehouse,source?.id ?: "") else salesDocument(section,reference,customer,lines,branch,warehouse)}){done(it)}
    })
    "SALES_RETURN","PURCHASE_RETURN" -> ReturnDocumentForm(section,state,{form=false}){id,quantities,account,restock->
      viewModel.tradeAction({if(section=="SALES_RETURN")returnSale(id.toLong(),quantities,account,restock) else returnPurchase(id,quantities,account)}){done(it)}
    }
    "COMPLAINT_RETURN" -> if(source==null) ComplaintReturnForm(state,{form=false}){invoiceId,reason->viewModel.tradeAction({complaintReturn(invoiceId,reason)}){done(it)}}
      else ReturnDocumentForm("SALES_RETURN",state.copy(invoices=state.invoices.filter {it.id==JSONObject(source!!.payload).optLong("invoiceId")}),{form=false}){_,quantities,account,restock->viewModel.tradeAction({settleComplaint(source!!.id,quantities,account,restock)}){done(it)}}
    "TRANSFER","STOCK_COUNT" -> StockLocationForm(section,state,{form=false}){id,qty,branch,warehouse,toBranch,toWarehouse->
      viewModel.tradeAction({if(section=="TRANSFER")transfer(id,qty,branch,warehouse,toBranch,toWarehouse) else stockCount(id,qty,branch,warehouse)}){done(it)}
    }
  }
  selected?.let {record->
    if(record.kind=="LEDGER_VIEW") {
      val entries=state.businessRecords.filter {it.party==record.party&&it.kind in listOf("CUSTOMER_DEBIT","CUSTOMER_CREDIT")}
      BusinessForm(record.title,state.word("Close","بند کریں"),{selected=null},{selected=null}){entries.forEach {Text(it.title+" • "+(if(it.kind=="CUSTOMER_DEBIT")"+" else "−")+state.money(it.amount))}}
    } else AlertDialog(onDismissRequest={selected=null},title={Text(record.title)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
      Text(record.party+"\n"+record.status+"\n"+state.money(record.amount))
      tradeLines(record.payload).forEach {line->val item=state.inventoryItems.find {it.id==line.itemId};Text((item?.name ?: "#"+line.itemId)+" • "+line.quantity+" "+(item?.unit ?: "")+" • "+state.money(line.quantity*line.price))}
      val data=JSONObject(record.payload)
      if(data.has("reason"))Text(data.optString("reason"))
      if(data.has("resolution"))Text(data.optString("resolution"))
      if(data.has("refund"))Text(state.word("Refund: ","واپسی ادائیگی: ")+state.money(data.optDouble("refund")))
      if(data.has("dueCredit"))Text(state.word("Khata adjustment: ","کھاتہ تبدیلی: ")+state.money(data.optDouble("dueCredit")))
    }},confirmButton={if(owner&&record.status=="OPEN") Column {
      if(record.kind=="COMPLAINT_RETURN") {
        TextButton(onClick={source=record;section="COMPLAINT_RETURN";selected=null;form=true}){Text(state.word("Return goods / refund","سامان واپس / رقم واپس"))}
        TextButton(onClick={viewModel.tradeAction({closeComplaint(record.id,"Resolved without refund")}){done(it)}}){Text(state.word("Resolve without refund","رقم واپسی کے بغیر حل"))}
      }
      if(record.kind=="PURCHASE_ORDER")TextButton(onClick={source=record;section="PURCHASE_BILL";selected=null;form=true}){Text(state.word("Receive goods / GRN","سامان وصول کریں"))}
      if(record.kind=="QUOTATION")TextButton(onClick={viewModel.tradeAction({convertSales(record.id,"ORDER")}){done(it)}}){Text(state.word("Convert to order","آرڈر بنائیں"))}
      if(record.kind=="ORDER")TextButton(onClick={viewModel.tradeAction({convertSales(record.id,"CHALLAN")}){done(it)}}){Text(state.word("Create delivery challan","ڈلیوری چالان بنائیں"))}
      if(record.kind in listOf("ORDER","CHALLAN"))TextButton(onClick={viewModel.tradeAction({convertSales(record.id,"INVOICE")}){done(it)}}){Text(state.word("Post invoice / Khata","بل / کھاتہ درج کریں"))}
    }},dismissButton={TextButton(onClick={selected=null}){Text(state.word("Close","بند کریں"))}})
  }
}

@Composable
internal fun LocationChoices(state:FinanceUiState,branch:String,warehouse:String,changeBranch:(String)->Unit,changeWarehouse:(String)->Unit) {
  BusinessChoice(branch,state.word("Branch","برانچ"),listOf("main")+state.businessRecords.filter {it.kind=="BRANCH"&&!it.archived}.map {it.title},onChange=changeBranch)
  BusinessChoice(warehouse,state.word("Warehouse","گودام"),listOf("main")+state.businessRecords.filter {it.kind=="WAREHOUSE"&&!it.archived}.map {it.title},onChange=changeWarehouse)
}
@Composable
internal fun AccountChoice(state:FinanceUiState,id:Long,change:(Long)->Unit) {
  BusinessChoice(state.accounts.find {it.id==id}?.name ?: "",state.word("Payment / refund account","ادائیگی / واپسی اکاؤنٹ"),state.accounts.map {it.name}){name->change(state.accounts.first {it.name==name}.id)}
}
@Composable
internal fun LineEditor(state:FinanceUiState,purchase:Boolean,lines:List<TradeLine>,change:(List<TradeLine>)->Unit) {
  var itemId by remember {mutableStateOf(state.inventoryItems.firstOrNull()?.id ?: 0L)};var quantity by remember {mutableStateOf("1")};var price by remember {mutableStateOf("")};var error by remember {mutableStateOf("")}
  val item=state.inventoryItems.find {it.id==itemId}
  BusinessChoice(item?.name ?: "",state.word("Item","سامان"),state.inventoryItems.filter {!BusinessLibrary.details(it.detailsJson).optBoolean("archived")}.map {it.name}){name->val i=state.inventoryItems.first {it.name==name};itemId=i.id;price=(if(purchase)i.costPrice else ItemRules.price(i)).toString()}
  BusinessField(quantity,state.word("Quantity in base unit","بنیادی یونٹ میں مقدار"),true){quantity=it}
  BusinessField(price.ifBlank {if(purchase)item?.costPrice?.toString() ?: "" else item?.salePrice?.toString() ?: ""},state.word("Price per base unit","بنیادی یونٹ کی قیمت"),true){price=it}
  Text((item?.unit ?: "")+" • "+state.word("Decimal quantities supported","اعشاریہ مقدار ممکن ہے"))
  Button(onClick={val q=quantity.toDoubleOrNull();val p=price.ifBlank {if(purchase)item?.costPrice?.toString() ?: "" else item?.salePrice?.toString() ?: ""}.toDoubleOrNull();if(item!=null&&q!=null&&p!=null&&q.isFinite()&&q>0&&p.isFinite()&&p>=0){change(lines+TradeLine(item.id,q,p));error=""}else error=state.word("Enter a valid quantity and price","مقدار اور قیمت درست درج کریں")}){Text(state.word("Add line","سامان شامل کریں"))}
  if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  lines.forEachIndexed {index,line->TextButton(onClick={change(lines.filterIndexed {i,_->i!=index})}){Text((state.inventoryItems.find {it.id==line.itemId}?.name ?: "")+" • "+line.quantity+" × "+line.price+" • "+state.word("Remove","حذف"))}}
}
@Composable
fun TradeDocumentForm(kind:String,state:FinanceUiState,source:BusinessRecord?=null,dismiss:()->Unit,submit:(String,String,Long,List<TradeLine>,Double,Long,String,String)->Unit) {
  var reference by remember {mutableStateOf(if(source!=null)"BILL-"+source.title else "")};var supplier by remember {mutableStateOf(source?.party ?: "")}
  var customer by remember {mutableStateOf(state.customers.firstOrNull()?.id ?: 0L)};var lines by remember {mutableStateOf(source?.let {tradeLines(it.payload)} ?: emptyList())}
  var paid by remember {mutableStateOf("0")};var account by remember {mutableStateOf(state.accounts.firstOrNull()?.id ?: 0L)}
  var branch by remember {mutableStateOf(source?.branchId ?: "main")};var warehouse by remember {mutableStateOf(source?.warehouseId ?: "main")};var error by remember {mutableStateOf("")}
  BusinessForm(state.word("New "+kind.replace('_',' '),"نئی کاروباری دستاویز"),state.word("Post document","دستاویز محفوظ کریں"),dismiss,{
    val p=paid.toDoubleOrNull();if(reference.isBlank()||lines.isEmpty()||p==null||!p.isFinite()||p<0)error=state.word("Reference, items and valid payment required","حوالہ، سامان اور درست رقم درج کریں")
    else submit(reference,supplier,customer,lines,if(kind=="PURCHASE_BILL")p else 0.0,account,branch,warehouse)
  }) {
    BusinessField(reference,state.word("Document reference","دستاویز کا حوالہ")){reference=it}
    if(kind.startsWith("PURCHASE"))BusinessField(supplier,state.word("Supplier","سپلائر")){supplier=it}
    else BusinessChoice(state.customers.find {it.id==customer}?.name ?: "",state.word("Customer","گاہک"),state.customers.map {it.name}){name->customer=state.customers.first {it.name==name}.id}
    if(source==null)LineEditor(state,kind.startsWith("PURCHASE"),lines){lines=it}
    else lines.forEach {Text((state.inventoryItems.find {i->i.id==it.itemId}?.name ?: "")+" • "+it.quantity+" × "+it.price)}
    Metric(state.word("Document total","کل رقم"),state.money(lines.sumOf {it.quantity*it.price}))
    if(kind=="PURCHASE_BILL") {BusinessField(paid,state.word("Paid now; balance goes to supplier Khata","اب ادائیگی؛ بقایا سپلائر کھاتے میں"),true){paid=it};AccountChoice(state,account){account=it}}
    LocationChoices(state,branch,warehouse,{branch=it},{warehouse=it})
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}
@Composable
fun ReturnDocumentForm(kind:String,state:FinanceUiState,dismiss:()->Unit,submit:(String,Map<Int,Double>,Long,Boolean)->Unit) {
  val sale=kind=="SALES_RETURN";val documents=if(sale)state.invoices.map {it.id.toString() to it.invoiceNumber} else state.businessRecords.filter {it.kind=="PURCHASE_BILL"}.map {it.id to it.title}
  var id by remember {mutableStateOf(documents.firstOrNull()?.first ?: "")};var quantities by remember {mutableStateOf(emptyMap<Int,String>())}
  var account by remember {mutableStateOf(state.accounts.firstOrNull()?.id ?: 0L)};var restock by remember {mutableStateOf(true)};var error by remember {mutableStateOf("")}
  val invoice=state.invoices.find {it.id.toString()==id};val purchase=state.businessRecords.find {it.id==id}
  val labels=if(sale)invoice?.parseItems()?.map {it.itemName+" • "+it.quantity+" "+it.unit} ?: emptyList() else purchase?.let {tradeLines(it.payload).map {line->(state.inventoryItems.find {it.id==line.itemId}?.name ?: "")+" • "+line.quantity}} ?: emptyList()
  BusinessForm(state.word("Linked return","متعلقہ بل کی واپسی"),state.word("Post return","واپسی محفوظ کریں"),dismiss,{
    val parsed=quantities.mapValues {it.value.toDoubleOrNull()};if(id.isBlank()||parsed.values.any {it==null||!it.isFinite()||it<0}||parsed.values.none {(it ?: 0.0)>0})error=state.word("Select a document and return quantity","بل اور واپسی مقدار منتخب کریں")
    else submit(id,parsed.filterValues {(it ?: 0.0)>0}.mapValues {it.value!!},account,restock)
  }) {
    BusinessChoice(documents.find {it.first==id}?.second ?: "",state.word("Original invoice / purchase","اصل بل / خریداری"),documents.map {it.second}){name->id=documents.first {it.second==name}.first;quantities=emptyMap()}
    labels.forEachIndexed {index,label->BusinessField(quantities[index] ?: "0",label,true){quantities=quantities+(index to it)}}
    AccountChoice(state,account){account=it}
    if(sale)Row {Text(state.word("Restock returned products","واپس سامان اسٹاک میں شامل کریں"),Modifier.weight(1f));Switch(restock,{restock=it})}
    Text(state.word("Unpaid amount is adjusted first; paid amount is refunded. Previously returned quantities cannot be returned again.","پہلے بقایا کم ہوگا؛ ادا شدہ رقم واپس ہوگی۔ پہلے واپس مقدار دوبارہ نہیں ہوگی۔"))
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}
@Composable
fun StockLocationForm(kind:String,state:FinanceUiState,dismiss:()->Unit,submit:(Long,Double,String,String,String,String)->Unit) {
  var id by remember {mutableStateOf(state.inventoryItems.firstOrNull()?.id ?: 0L)};var quantity by remember {mutableStateOf("")}
  var branch by remember {mutableStateOf("main")};var warehouse by remember {mutableStateOf("main")};var toBranch by remember {mutableStateOf("main")};var toWarehouse by remember {mutableStateOf("main")};var error by remember {mutableStateOf("")}
  BusinessForm(state.word(if(kind=="TRANSFER")"Transfer stock" else "Count stock",if(kind=="TRANSFER")"اسٹاک منتقل کریں" else "اسٹاک گنتی"),state.word("Post stock movement","اسٹاک تبدیلی محفوظ کریں"),dismiss,{
    val q=quantity.toDoubleOrNull();if(id<=0||q==null||!q.isFinite()||q<0)error=state.word("Enter a valid quantity","درست مقدار درج کریں") else submit(id,q,branch,warehouse,toBranch,toWarehouse)
  }) {
    BusinessChoice(state.inventoryItems.find {it.id==id}?.name ?: "",state.word("Product","سامان"),state.inventoryItems.map {it.name}){name->id=state.inventoryItems.first {it.name==name}.id}
    LocationChoices(state,branch,warehouse,{branch=it},{warehouse=it})
    Metric(state.word("Available at location","گودام میں دستیاب"),state.stockMovements.filter {it.itemId==id&&it.branchId==branch&&it.warehouseId==warehouse}.sumOf {it.quantity}.toString())
    BusinessField(quantity,state.word(if(kind=="TRANSFER")"Transfer quantity" else "Physical counted quantity",if(kind=="TRANSFER")"منتقلی مقدار" else "اصل گنتی مقدار"),true){quantity=it}
    if(kind=="TRANSFER"){Text(state.word("Destination","منزل"));LocationChoices(state,toBranch,toWarehouse,{toBranch=it},{toWarehouse=it})}
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}

@Composable
fun WorkBillingForm(work:BusinessRecord,state:FinanceUiState,dismiss:()->Unit,submit:(Long,List<TradeLine>,Double,String)->Unit) {
  var customer by remember {mutableStateOf(state.customers.firstOrNull()?.id ?: 0L)}
  var parts by remember {mutableStateOf(emptyList<TradeLine>())};var labour by remember {mutableStateOf(work.amount.toString())}
  var period by remember {mutableStateOf(java.text.SimpleDateFormat("yyyy-MM",java.util.Locale.US).apply {timeZone=java.util.TimeZone.getTimeZone("Asia/Karachi")}.format(java.util.Date()))};var error by remember {mutableStateOf("")}
  BusinessForm(work.title,state.word("Post invoice","بل محفوظ کریں"),dismiss,{
    val amount=labour.toDoubleOrNull();if(customer<=0||amount==null||!amount.isFinite()||amount<0)error=state.word("Select customer and valid labour amount","گاہک اور درست محنت رقم منتخب کریں") else submit(customer,parts,amount,period)
  }) {
    BusinessChoice(state.customers.find {it.id==customer}?.name ?: "",state.word("Customer","گاہک"),state.customers.map {it.name}){name->customer=state.customers.first {it.name==name}.id}
    BusinessField(labour,state.word("Labour / service fee","محنت / سروس رقم"),true){labour=it}
    if(work.kind=="SUBSCRIPTION")BusinessField(period,state.word("Billing month YYYY-MM","بل کا مہینہ سال-مہینہ")){period=it}
    else LineEditor(state,false,parts){parts=it}
    Metric(state.word("Invoice total","بل کی کل رقم"),state.money((labour.toDoubleOrNull() ?: 0.0)+parts.sumOf {it.quantity*it.price}))
    Text(state.word("Posts parts stock and customer Khata together. Use Khata to collect payment.","سامان کا اسٹاک اور گاہک کھاتہ ایک ساتھ درج ہوں گے۔ ادائیگی کھاتے میں وصول کریں۔"))
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}

@Composable
fun ComplaintReturnForm(state:FinanceUiState,dismiss:()->Unit,submit:(Long,String)->Unit) {
  var invoiceId by remember {mutableStateOf(state.invoices.firstOrNull()?.id ?: 0L)}
  var reason by remember {mutableStateOf("")};var error by remember {mutableStateOf("")}
  BusinessForm(state.word("Product return complaint","پروڈکٹ واپسی کی شکایت"),state.word("Save complaint","شکایت محفوظ کریں"),dismiss,{
    if(invoiceId==0L||reason.isBlank())error=state.word("Choose bill and enter complaint","بل منتخب کریں اور شکایت درج کریں") else submit(invoiceId,reason)
  }) {
    BusinessChoice(state.invoices.find {it.id==invoiceId}?.invoiceNumber ?: "",state.word("Original bill","اصل بل"),state.invoices.map {it.invoiceNumber}){value->invoiceId=state.invoices.first {it.invoiceNumber==value}.id}
    BusinessField(reason,state.word("Complaint / reason","شکایت / وجہ")){reason=it}
    Text(state.word("This records the complaint only. The owner can approve a linked return/refund later.","یہ صرف شکایت درج کرتا ہے۔ مالک بعد میں متعلقہ سامان اور رقم کی واپسی منظور کر سکتا ہے۔"))
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}
