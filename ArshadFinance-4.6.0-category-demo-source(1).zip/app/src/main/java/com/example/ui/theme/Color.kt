package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Modern Theme Palette: Forest Green (Primary), Emerald (Success), Warm Neutral
val IndigoPrimary = Color(0xFF086B4D)
val IndigoDark = Color(0xFF064D3A)
val IndigoDarker = Color(0xFF043B2C)
val IndigoLight = Color(0xFF2E9872)
val IndigoContainer = Color(0xFFE5F3EA)
val OnIndigoContainer = Color(0xFF164B37)

// Emerald Green (Success & Cash In)
val EmeraldSuccess = Color(0xFF10B981)
val EmeraldDark = Color(0xFF059669)
val EmeraldContainer = Color(0xFFD1FAE5)
val OnEmeraldContainer = Color(0xFF064E3B)

// Slate Gray & Dark Neutral
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF7F9F3)
val Slate50 = Color(0xFFF5F7F2)

// Functional & Semantic Colors
val NavyBluePrimary = IndigoPrimary
val NavyBlueDark = IndigoDark
val NavyBlueDarker = IndigoDarker
val NavyBlueLight = IndigoLight
val IceBlueContainer = IndigoContainer
val IceBlueContainerLight = Color(0xFFD6EADB)
val OnIceBlueContainer = OnIndigoContainer
val DeepNavyText = Slate900

val LightBackground = Slate50
val LightSurface = Color.White
val LightSurfaceVariant = Slate100
val LightOutline = Slate300
val LightOutlineVariant = Slate200

val TextPrimary = Slate900
val TextSecondary = Slate600
val TextTertiary = Slate400

val IncomeGreen = EmeraldDark
val IncomeGreenContainer = EmeraldContainer
val OnIncomeGreenContainer = OnEmeraldContainer

val ExpenseRed = Color(0xFFDC2626)
val ExpenseRedContainer = Color(0xFFFEE2E2)
val OnExpenseRedContainer = Color(0xFF991B1B)

val WarningAmber = Color(0xFFD97706)
val WarningAmberContainer = Color(0xFFFEF3C7)

val ChipBackground = Color(0x1F086B4D)
