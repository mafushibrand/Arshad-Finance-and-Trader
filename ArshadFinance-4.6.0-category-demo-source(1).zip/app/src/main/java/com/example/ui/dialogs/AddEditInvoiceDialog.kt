package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.InventoryItem
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItemEntry
import com.example.ui.theme.DeepNavyText
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IceBlueContainerLight
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.InputFieldStyles
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BusinessProfile
import com.example.util.InvoicePrintExportUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegacyAddEditInvoiceDialog(
  businessProfile: BusinessProfile,
  customers: List<Customer>,
  inventoryItems: List<InventoryItem>,
  editingInvoice: Invoice? = null,
  initialCustomer: Customer? = null,
  currencySymbol: String = "Rs",
  onOpenShopProfile: () -> Unit = {},
  onSaveInvoice: (Invoice, List<InvoiceItemEntry>, Boolean, (Invoice?) -> Unit) -> Unit,
  onAddNewProductToInventory: ((InventoryItem) -> Unit)? = null,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val isEditing = editingInvoice != null
  var savingInvoice by remember { mutableStateOf(false) }
  val dateNow = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())

  // Customer details
  var customerName by remember { mutableStateOf(editingInvoice?.customerName ?: initialCustomer?.name ?: "") }
  var customerPhone by remember { mutableStateOf(editingInvoice?.customerPhone ?: initialCustomer?.phone ?: "") }
  var customerAddress by remember { mutableStateOf(editingInvoice?.customerAddress ?: initialCustomer?.address ?: "") }
  var selectedCustomerId by remember { mutableStateOf(editingInvoice?.customerId ?: initialCustomer?.id ?: 0L) }
  var customerDropdownExpanded by remember { mutableStateOf(false) }

  // Invoice Items
  val billItems = remember {
    mutableStateListOf<InvoiceItemEntry>().apply {
      if (editingInvoice != null) {
        addAll(editingInvoice.parseItems())
      }
    }
  }

  // New / Editing Item addition fields
  var newItemName by remember { mutableStateOf("") }
  var newItemRateStr by remember { mutableStateOf("") }
  var newItemQtyStr by remember { mutableStateOf("1") }
  var newItemUnit by remember { mutableStateOf("Piece") }
  var newItemCategory by remember { mutableStateOf("General") }
  var selectedInventoryItem by remember { mutableStateOf<InventoryItem?>(null) }
  var itemDropdownExpanded by remember { mutableStateOf(false) }
  var showAddItemSection by remember { mutableStateOf(true) }
  var saveAsNewProductToInventory by remember { mutableStateOf(false) }
  var newProductCostPriceStr by remember { mutableStateOf("") }
  var newProductInitialStockStr by remember { mutableStateOf("10") }

  // Financial calculations
  var discountStr by remember { mutableStateOf(if (editingInvoice != null && editingInvoice.discountAmount > 0) editingInvoice.discountAmount.toInt().toString() else "0") }
  var extraChargesStr by remember { mutableStateOf(if (editingInvoice != null && editingInvoice.deliveryOrLabour > 0) editingInvoice.deliveryOrLabour.toInt().toString() else "0") }
  var paidAmountStr by remember { mutableStateOf(if (editingInvoice != null) editingInvoice.amountPaid.toInt().toString() else "") }
  var paymentMethod by remember { mutableStateOf(editingInvoice?.paymentMethod ?: "Cash") }
  var syncWithInventory by remember { mutableStateOf(editingInvoice?.syncWithInventory ?: true) }
  var note by remember { mutableStateOf(editingInvoice?.note ?: "") }

  val subtotal = billItems.sumOf { it.total }
  val discount = discountStr.toDoubleOrNull() ?: 0.0
  val extra = extraChargesStr.toDoubleOrNull() ?: 0.0
  val grandTotal = (subtotal - discount + extra).coerceAtLeast(0.0)

  // Auto-fill paid amount initially to grand total for new bill, or user entered
  var isPaidManuallyEdited by remember { mutableStateOf(editingInvoice != null) }
  val amountPaid = if (isPaidManuallyEdited) {
    paidAmountStr.toDoubleOrNull() ?: 0.0
  } else {
    grandTotal
  }
  val remainingBalance = (grandTotal - amountPaid).coerceAtLeast(0.0)
  val paymentStatus = if (remainingBalance <= 0.0) "Paid" else if (amountPaid > 0) "Partial" else "Unpaid"

  val paymentMethods = listOf("Cash", "EasyPaisa", "JazzCash", "Bank", "Udhar")

  fun buildInvoiceObject(): Invoice {
    val invoiceNumber = editingInvoice?.invoiceNumber ?: "${businessProfile.invoicePrefix.ifBlank { "AF" }}-${System.currentTimeMillis().toString()}"
    return Invoice(
      id = editingInvoice?.id ?: 0L,
      invoiceNumber = invoiceNumber,
      customerId = selectedCustomerId,
      customerName = customerName.trim(),
      customerPhone = customerPhone.trim(),
      customerAddress = customerAddress.trim(),
      dateMillis = editingInvoice?.dateMillis ?: System.currentTimeMillis(),
      itemsJson = InvoiceItemEntry.toJsonString(billItems),
      subtotal = subtotal,
      discountAmount = discount,
      taxAmount = 0.0,
      deliveryOrLabour = extra,
      grandTotal = grandTotal,
      amountPaid = amountPaid,
      remainingBalance = remainingBalance,
      paymentStatus = paymentStatus,
      paymentMethod = paymentMethod,
      businessName = businessProfile.businessName,
      businessPhone = businessProfile.phone,
      businessAddress = businessProfile.address,
      businessLogoEmoji = businessProfile.logoEmoji,
      shopType = businessProfile.shopType,
      note = note.trim(),
      syncWithInventory = syncWithInventory
    )
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .clip(RoundedCornerShape(24.dp))
        .testTag("add_edit_invoice_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        // 1. Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Color(0xFF0F172A)),
              contentAlignment = Alignment.Center
            ) {
              Text(text = businessProfile.logoEmoji.ifBlank { "🧾" }, fontSize = 22.sp)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (isEditing) "Edit Bill #${editingInvoice!!.invoiceNumber}" else "New Customer Bill (نیا بل بنائیں)",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = DeepNavyText
                )
              )
              Text(
                text = "$dateNow • ${businessProfile.businessName}",
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.5.sp)
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        // 1.5 Quick Shop Branding Edit Banner
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = Color(0xFFF7F9F3),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { onOpenShopProfile() }
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text("🏪", fontSize = 15.sp)
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Shop: ${businessProfile.businessName} (Ph: ${businessProfile.phone})",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1E293B),
                maxLines = 1
              )
            }
            Text(
              text = "Edit Logo & Info ➔",
              fontSize = 10.5.sp,
              fontWeight = FontWeight.Bold,
              color = NavyBluePrimary
            )
          }
        }

        HorizontalDivider(color = Color(0xFFE2E8F0))
        Spacer(modifier = Modifier.height(8.dp))

        // Scrollable Body
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
        ) {
          // Customer Selector Section
          item {
            Text(
              text = "👤 Customer / Client Details (گاہک کی تفصیل):",
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                color = NavyBluePrimary
              )
            )
            Spacer(modifier = Modifier.height(4.dp))

            // Pick Existing Customer Dropdown
            if (customers.isNotEmpty()) {
              ExposedDropdownMenuBox(
                expanded = customerDropdownExpanded,
                onExpandedChange = { customerDropdownExpanded = !customerDropdownExpanded }
              ) {
                OutlinedTextField(
                  value = if (selectedCustomerId > 0L) customerName else "Pick Saved Customer (or enter new below)...",
                  onValueChange = {},
                  readOnly = true,
                  label = { Text("Select Customer from Khata / Records") },
                  trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerDropdownExpanded) },
                  textStyle = InputFieldStyles.textStyle,
                  colors = InputFieldStyles.colors(),
                  modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
                )
                ExposedDropdownMenu(
                  expanded = customerDropdownExpanded,
                  onDismissRequest = { customerDropdownExpanded = false }
                ) {
                  DropdownMenuItem(
                    text = { Text("➕ New / Walk-in Customer", fontWeight = FontWeight.Bold, color = NavyBluePrimary) },
                    onClick = {
                      selectedCustomerId = 0L
                      customerName = ""
                      customerPhone = ""
                      customerAddress = ""
                      customerDropdownExpanded = false
                    }
                  )
                  customers.forEach { cust ->
                    DropdownMenuItem(
                      text = {
                        Column {
                          Text(cust.name, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                          Text(
                            "Ph: ${cust.phone.ifBlank { "N/A" }} • Bal: $currencySymbol ${"%,.0f".format(cust.currentBalance)}",
                            fontSize = 11.sp,
                            color = TextSecondary
                          )
                        }
                      },
                      onClick = {
                        selectedCustomerId = cust.id
                        customerName = cust.name
                        customerPhone = cust.phone
                        customerAddress = cust.address
                        customerDropdownExpanded = false
                      }
                    )
                  }
                }
              }
              Spacer(modifier = Modifier.height(8.dp))
            }

            // Customer Name & Phone Input
            Row(modifier = Modifier.fillMaxWidth()) {
              OutlinedTextField(
                value = customerName,
                onValueChange = {
                  customerName = it
                  if (selectedCustomerId > 0L) selectedCustomerId = 0L
                },
                label = { Text("Customer Name *") },
                placeholder = { Text("e.g. Ali Khan / Mrs. Fatima") },
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier
                  .weight(1.1f)
                  .testTag("invoice_customer_name"),
                singleLine = true
              )
              Spacer(modifier = Modifier.width(8.dp))
              OutlinedTextField(
                value = customerPhone,
                onValueChange = { customerPhone = it },
                label = { Text("WhatsApp / Phone") },
                placeholder = { Text("0300-1234567") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                textStyle = InputFieldStyles.textStyle,
                colors = InputFieldStyles.colors(),
                modifier = Modifier
                  .weight(0.9f)
                  .testTag("invoice_customer_phone"),
                singleLine = true
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
              value = customerAddress,
              onValueChange = { customerAddress = it },
              label = { Text("Address / City (Optional)") },
              placeholder = { Text("e.g. Commercial Market, Faisalabad") },
              textStyle = InputFieldStyles.textStyle,
              colors = InputFieldStyles.colors(),
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))
          }

          // 2. Items & Services Section
          item {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "🛍️ Items & Services (${billItems.size})",
                style = MaterialTheme.typography.labelLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = NavyBluePrimary
                )
              )
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFF7F9F3),
                modifier = Modifier.clickable { showAddItemSection = !showAddItemSection }
              ) {
                Text(
                  text = if (showAddItemSection) "▲ Hide Add Box" else "▼ + Add Item / Service",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = NavyBluePrimary,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }
            Spacer(modifier = Modifier.height(6.dp))
          }

          // Add / Edit Item Box
          if (showAddItemSection) {
            item {
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7F2)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  // Dropdown to pick from existing stock / services
                  if (inventoryItems.isNotEmpty()) {
                    ExposedDropdownMenuBox(
                      expanded = itemDropdownExpanded,
                      onExpandedChange = { itemDropdownExpanded = !itemDropdownExpanded }
                    ) {
                      OutlinedTextField(
                        value = selectedInventoryItem?.name ?: "Select from Stock / Service (or enter below)...",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Pick from Shop Inventory") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = itemDropdownExpanded) },
                        textStyle = InputFieldStyles.textStyle,
                        colors = InputFieldStyles.colors(),
                        modifier = Modifier
                          .menuAnchor()
                          .fillMaxWidth()
                      )
                      ExposedDropdownMenu(
                        expanded = itemDropdownExpanded,
                        onDismissRequest = { itemDropdownExpanded = false }
                      ) {
                        inventoryItems.forEach { invItem ->
                          DropdownMenuItem(
                            text = {
                              Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                              ) {
                                Text("${invItem.icon} ${invItem.name}", maxLines = 1, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                                Text("Rs ${invItem.salePrice.toInt()}", fontWeight = FontWeight.Bold, color = IncomeGreen)
                              }
                            },
                            onClick = {
                              selectedInventoryItem = invItem
                              newItemName = invItem.name
                              newItemRateStr = invItem.salePrice.toInt().toString()
                              newItemUnit = invItem.unit
                              newItemCategory = invItem.category
                              itemDropdownExpanded = false
                            }
                          )
                        }
                      }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                  }

                  // Item Name (can be typed manually)
                  OutlinedTextField(
                    value = newItemName,
                    onValueChange = {
                      newItemName = it
                      if (selectedInventoryItem != null && selectedInventoryItem?.name != it) {
                        selectedInventoryItem = null
                      }
                    },
                    label = { Text("Item Name / Service (چیز یا سروس کا نام) *") },
                    placeholder = { Text("e.g. Lawn Suit, Bridal Makeup, Panadol, Rice...") },
                    textStyle = InputFieldStyles.textStyle,
                    colors = InputFieldStyles.colors(),
                    modifier = Modifier
                      .fillMaxWidth()
                      .testTag("invoice_item_name_input"),
                    singleLine = true
                  )

                  Spacer(modifier = Modifier.height(8.dp))

                  // Qty, Unit, Rate
                  Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                      value = newItemQtyStr,
                      onValueChange = { newItemQtyStr = it },
                      label = { Text("Qty (تعداد)") },
                      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                      textStyle = InputFieldStyles.textStyle,
                      colors = InputFieldStyles.colors(),
                      modifier = Modifier.weight(0.8f),
                      singleLine = true
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    OutlinedTextField(
                      value = newItemUnit,
                      onValueChange = { newItemUnit = it },
                      label = { Text("Unit") },
                      placeholder = { Text("Piece/Kg") },
                      textStyle = InputFieldStyles.textStyle,
                      colors = InputFieldStyles.colors(),
                      modifier = Modifier.weight(0.9f),
                      singleLine = true
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    OutlinedTextField(
                      value = newItemRateStr,
                      onValueChange = { newItemRateStr = it },
                      label = { Text("Rate ($currencySymbol)") },
                      placeholder = { Text("500") },
                      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                      textStyle = InputFieldStyles.textStyle,
                      colors = InputFieldStyles.colors(),
                      modifier = Modifier.weight(1.3f),
                      singleLine = true
                    )
                  }

                  // Quick Weight & Quantity Fraction Selector (Daal, Sugar, Karyana, Meat, Medicines, Fast Food)
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = "Quick Weight / Qty (وزن یا مقدار منتخب کریں):",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF64748B)
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    listOf(
                      Triple("0.25", "Kg", "0.25 Kg (پاؤ)"),
                      Triple("0.5", "Kg", "0.5 Kg (آدھا کلو)"),
                      Triple("0.75", "Kg", "0.75 Kg (پونا کلو)"),
                      Triple("1", "Kg", "1 Kg (کلو)"),
                      Triple("2", "Kg", "2 Kg"),
                      Triple("5", "Kg", "5 Kg"),
                      Triple("1", "Piece", "1 Pc"),
                      Triple("1", "Box", "1 Box (ڈبہ)"),
                      Triple("10", "Tablet", "10 Tab (پتہ)"),
                      Triple("12", "Dozen", "1 Dozen (درجن)")
                    ).forEach { (q, u, lbl) ->
                      Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (newItemQtyStr == q && newItemUnit == u) Color(0xFF086B4D) else Color(0xFFF7F9F3),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (newItemQtyStr == q && newItemUnit == u) Color(0xFF086B4D) else Color(0xFFCBD5E1)),
                        modifier = Modifier.clickable {
                          newItemQtyStr = q
                          newItemUnit = u
                        }
                      ) {
                        Text(
                          text = lbl,
                          fontSize = 10.5.sp,
                          fontWeight = FontWeight.Bold,
                          color = if (newItemQtyStr == q && newItemUnit == u) Color.White else Color(0xFF0F172A),
                          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                      }
                    }
                  }

                  // Option to save as new product in shop inventory
                  if (selectedInventoryItem == null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (saveAsNewProductToInventory) Color(0xFFECFDF5) else Color.Transparent)
                        .clickable { saveAsNewProductToInventory = !saveAsNewProductToInventory }
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Checkbox(
                        checked = saveAsNewProductToInventory,
                        onCheckedChange = { saveAsNewProductToInventory = it },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF059669))
                      )
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = "📦 Save to Shop Stock (دکان کے اسٹاک میں بھی شامل کریں)",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (saveAsNewProductToInventory) Color(0xFF047857) else Color(0xFF0F172A)
                      )
                    }

                    if (saveAsNewProductToInventory) {
                      Spacer(modifier = Modifier.height(4.dp))
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                      ) {
                        OutlinedTextField(
                          value = newProductCostPriceStr,
                          onValueChange = { newProductCostPriceStr = it },
                          label = { Text("Cost / خرید ($currencySymbol)") },
                          placeholder = { Text("0") },
                          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                          textStyle = InputFieldStyles.textStyle,
                          colors = InputFieldStyles.colors(),
                          modifier = Modifier.weight(1f),
                          singleLine = true
                        )
                        OutlinedTextField(
                          value = newProductInitialStockStr,
                          onValueChange = { newProductInitialStockStr = it },
                          label = { Text("Store Stock") },
                          placeholder = { Text("10") },
                          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                          textStyle = InputFieldStyles.textStyle,
                          colors = InputFieldStyles.colors(),
                          modifier = Modifier.weight(1f),
                          singleLine = true
                        )
                      }
                    }
                  }

                  Spacer(modifier = Modifier.height(10.dp))

                  Button(
                    onClick = {
                      if (newItemName.isBlank()) {
                        Toast.makeText(context, "Please enter item or service name", Toast.LENGTH_SHORT).show()
                        return@Button
                      }
                      val qty = newItemQtyStr.toDoubleOrNull() ?: 1.0
                      val rate = newItemRateStr.toDoubleOrNull() ?: 0.0
                      if (rate <= 0.0) {
                        Toast.makeText(context, "Please enter item rate", Toast.LENGTH_SHORT).show()
                        return@Button
                      }

                      val isService = newItemUnit.equals("Service", ignoreCase = true) ||
                          newItemCategory.contains("Service", ignoreCase = true) ||
                          newItemName.contains("Facial", ignoreCase = true) ||
                          newItemName.contains("Makeup", ignoreCase = true) ||
                          newItemName.contains("Stitching", ignoreCase = true) ||
                          newItemName.contains("Repair", ignoreCase = true)

                      // If save to inventory is checked, persist to shop database
                      if (saveAsNewProductToInventory && selectedInventoryItem == null) {
                        val cost = newProductCostPriceStr.toDoubleOrNull() ?: (rate * 0.75)
                        val initialStock = (newProductInitialStockStr.toDoubleOrNull() ?: 10.0).coerceAtLeast(qty)
                        val newInv = InventoryItem(
                          id = 0L,
                          name = newItemName.trim(),
                          costPrice = cost,
                          salePrice = rate,
                          currentStock = initialStock,
                          unit = newItemUnit.trim().ifBlank { "Piece" },
                          category = newItemCategory.ifBlank { "General" },
                          icon = "📦",
                          lowStockThreshold = 3.0,
                          note = "Added via Arshad Finance Billing"
                        )
                        onAddNewProductToInventory?.invoke(newInv)
                        Toast.makeText(context, "Product saved to shop stock! ✓", Toast.LENGTH_SHORT).show()
                      }

                      billItems.add(
                        InvoiceItemEntry(
                          itemId = selectedInventoryItem?.id,
                          itemName = newItemName.trim(),
                          category = newItemCategory,
                          quantity = qty,
                          unit = newItemUnit.trim().ifBlank { "Piece" },
                          unitPrice = rate,
                          total = qty * rate,
                          isService = isService
                        )
                      )

                      // Clear fields for next item
                      newItemName = ""
                      newItemRateStr = ""
                      newItemQtyStr = "1"
                      newProductCostPriceStr = ""
                      newProductInitialStockStr = "10"
                      saveAsNewProductToInventory = false
                      selectedInventoryItem = null
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
                    modifier = Modifier
                      .fillMaxWidth()
                      .testTag("invoice_add_item_btn")
                  ) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add to Bill / بل میں شامل کریں", fontWeight = FontWeight.Bold)
                  }
                }
              }
              Spacer(modifier = Modifier.height(12.dp))
            }
          }

          // Added Items List with Edit & Delete Options
          if (billItems.isEmpty()) {
            item {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(Color(0xFFF7F9F3), RoundedCornerShape(12.dp))
                  .padding(20.dp),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "No items in this bill yet.\nAdd items or services using the box above.",
                  style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                  textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
              }
              Spacer(modifier = Modifier.height(12.dp))
            }
          } else {
            itemsIndexed(billItems) { index, item ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 3.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7F2)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                      modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(IceBlueContainerLight),
                      contentAlignment = Alignment.Center
                    ) {
                      Text(text = "${index + 1}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepNavyText)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                      Text(item.itemName, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, color = Color(0xFF0F172A))
                      val qStr = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else item.quantity.toString()
                      Text(
                        "$qStr ${item.unit} × $currencySymbol ${item.unitPrice.toInt()} = $currencySymbol ${"%,.0f".format(item.total)}",
                        fontSize = 11.sp,
                        color = Color(0xFF475569)
                      )
                    }
                  }

                  // Edit & Delete Item Buttons
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    // Edit Item Button
                    IconButton(
                      onClick = {
                        // Load item back to input box
                        newItemName = item.itemName
                        newItemQtyStr = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else item.quantity.toString()
                        newItemUnit = item.unit
                        newItemRateStr = item.unitPrice.toInt().toString()
                        newItemCategory = item.category
                        billItems.removeAt(index)
                        showAddItemSection = true
                        Toast.makeText(context, "Item loaded for editing", Toast.LENGTH_SHORT).show()
                      },
                      modifier = Modifier.size(32.dp)
                    ) {
                      Icon(Icons.Default.Edit, contentDescription = "Edit Item", tint = NavyBluePrimary, modifier = Modifier.size(16.dp))
                    }

                    // Delete Item Button
                    IconButton(
                      onClick = { billItems.removeAt(index) },
                      modifier = Modifier.size(32.dp)
                    ) {
                      Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ExpenseRed, modifier = Modifier.size(16.dp))
                    }
                  }
                }
              }
            }
            item { Spacer(modifier = Modifier.height(12.dp)) }
          }

          // 3. Totals, Discount, Extra, Paid Amount
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7F2)),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                // Subtotal
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text("Subtotal (آئٹمز ٹوٹل):", fontSize = 13.sp, color = Color(0xFF334155))
                  Text(
                    "$currencySymbol ${"%,.0f".format(subtotal)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF0F172A)
                  )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Discount & Delivery/Extra
                Row(modifier = Modifier.fillMaxWidth()) {
                  OutlinedTextField(
                    value = discountStr,
                    onValueChange = { discountStr = it },
                    label = { Text("Discount ($currencySymbol)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    textStyle = InputFieldStyles.textStyle,
                    colors = InputFieldStyles.colors(),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  OutlinedTextField(
                    value = extraChargesStr,
                    onValueChange = { extraChargesStr = it },
                    label = { Text("Delivery / Extra ($currencySymbol)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    textStyle = InputFieldStyles.textStyle,
                    colors = InputFieldStyles.colors(),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                  )
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = Color(0xFFE2E8F0))
                Spacer(modifier = Modifier.height(10.dp))

                // Grand Total Highlight
                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = Color(0xFFE5F3EA),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFC7D2FE)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text("GRAND TOTAL (کل رقم):", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E1B4B))
                    Text(
                      "$currencySymbol ${"%,.0f".format(grandTotal)}",
                      fontWeight = FontWeight.Bold,
                      fontSize = 17.sp,
                      color = NavyBluePrimary
                    )
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Amount Paid & Udhar / Balance
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                  OutlinedTextField(
                    value = if (isPaidManuallyEdited) paidAmountStr else grandTotal.toInt().toString(),
                    onValueChange = {
                      isPaidManuallyEdited = true
                      paidAmountStr = it
                    },
                    label = { Text("Amount Paid (وصول شدہ) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    textStyle = InputFieldStyles.boldTextStyle,
                    colors = InputFieldStyles.colors(),
                    modifier = Modifier
                      .weight(1.1f)
                      .testTag("invoice_paid_amount"),
                    singleLine = true
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(
                    modifier = Modifier.weight(0.9f),
                    horizontalAlignment = Alignment.End
                  ) {
                    Text("Remaining (بقایا / ادھار):", fontSize = 11.sp, color = TextSecondary)
                    Text(
                      text = "$currencySymbol ${"%,.0f".format(remainingBalance)}",
                      fontWeight = FontWeight.Bold,
                      fontSize = 15.sp,
                      color = if (remainingBalance > 0) ExpenseRed else IncomeGreen
                    )
                  }
                }

                // Quick Payment Buttons
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (remainingBalance <= 0) Color(0xFFDCFCE7) else Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF86EFAC)),
                    modifier = Modifier
                      .weight(1f)
                      .clickable {
                        isPaidManuallyEdited = true
                        paidAmountStr = grandTotal.toInt().toString()
                      }
                  ) {
                    Text("✓ Full Paid", modifier = Modifier.padding(vertical = 6.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IncomeGreen)
                  }

                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (amountPaid == 0.0) Color(0xFFFEE2E2) else Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier
                      .weight(1f)
                      .clickable {
                        isPaidManuallyEdited = true
                        paidAmountStr = "0"
                      }
                  ) {
                    Text("⚠️ Udhar (0 Paid)", modifier = Modifier.padding(vertical = 6.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ExpenseRed)
                  }

                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    modifier = Modifier
                      .weight(1f)
                      .clickable {
                        isPaidManuallyEdited = true
                        paidAmountStr = (grandTotal / 2).toInt().toString()
                      }
                  ) {
                    Text("½ Half Paid", modifier = Modifier.padding(vertical = 6.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Payment Method Selector
                Text("Payment Method (ادائیگی کا طریقہ):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                  horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  paymentMethods.forEach { method ->
                    val isSelected = paymentMethod == method
                    Surface(
                      shape = RoundedCornerShape(8.dp),
                      color = if (isSelected) NavyBluePrimary else Color.White,
                      border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) NavyBluePrimary else Color(0xFFCBD5E1)),
                      modifier = Modifier
                        .weight(1f)
                        .clickable { paymentMethod = method }
                    ) {
                      Text(
                        method,
                        modifier = Modifier.padding(vertical = 6.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else TextPrimary
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Sync with Inventory Checkbox
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable { syncWithInventory = !syncWithInventory }
                ) {
                  Checkbox(
                    checked = syncWithInventory,
                    onCheckedChange = { syncWithInventory = it },
                    colors = CheckboxDefaults.colors(checkedColor = NavyBluePrimary)
                  )
                  Text("Automatically deduct sold items from stock", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                  value = note,
                  onValueChange = { note = it },
                  label = { Text("Note / Instructions (Optional)") },
                  placeholder = { Text("e.g. Delivery by evening, bridal fitting") },
                  textStyle = InputFieldStyles.textStyle,
                  colors = InputFieldStyles.colors(),
                  modifier = Modifier.fillMaxWidth(),
                  singleLine = true
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Save & Share Action Buttons (WhatsApp, PDF, Image, Print, Save)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          // WhatsApp Share
          Button(
            onClick = {
              if (customerName.isBlank()) {
                Toast.makeText(context, "Please enter customer name", Toast.LENGTH_SHORT).show()
                return@Button
              }
              if (billItems.isEmpty()) {
                Toast.makeText(context, "Please add at least one item to bill", Toast.LENGTH_SHORT).show()
                return@Button
              }
              val inv = buildInvoiceObject()
              if (savingInvoice) return@Button
              savingInvoice = true
              onSaveInvoice(inv, billItems.toList(), syncWithInventory) { saved ->
                savingInvoice = false
                if (saved != null) {
                  InvoicePrintExportUtils.shareInvoiceViaWhatsApp(context, saved, businessProfile, currencySymbol)
                  onDismiss()
                }
              }
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Send, contentDescription = "WhatsApp", modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text("WhatsApp", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
          }

          // PDF Share
          Button(
            onClick = {
              if (customerName.isBlank()) {
                Toast.makeText(context, "Please enter customer name", Toast.LENGTH_SHORT).show()
                return@Button
              }
              if (billItems.isEmpty()) {
                Toast.makeText(context, "Please add at least one item to bill", Toast.LENGTH_SHORT).show()
                return@Button
              }
              val inv = buildInvoiceObject()
              if (savingInvoice) return@Button
              savingInvoice = true
              onSaveInvoice(inv, billItems.toList(), syncWithInventory) { saved ->
                savingInvoice = false
                if (saved != null) {
                  InvoicePrintExportUtils.generateAndShareInvoicePdf(context, saved, businessProfile, currencySymbol)
                  onDismiss()
                }
              }
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text("PDF Bill", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
          }

          // Image Share
          Button(
            onClick = {
              if (customerName.isBlank()) {
                Toast.makeText(context, "Please enter customer name", Toast.LENGTH_SHORT).show()
                return@Button
              }
              if (billItems.isEmpty()) {
                Toast.makeText(context, "Please add at least one item to bill", Toast.LENGTH_SHORT).show()
                return@Button
              }
              val inv = buildInvoiceObject()
              if (savingInvoice) return@Button
              savingInvoice = true
              onSaveInvoice(inv, billItems.toList(), syncWithInventory) { saved ->
                savingInvoice = false
                if (saved != null) {
                  InvoicePrintExportUtils.generateAndShareInvoiceImage(context, saved, businessProfile, currencySymbol)
                  onDismiss()
                }
              }
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Image, contentDescription = "Image", modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text("Image", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
          }

          // Save Only
          Button(
            onClick = {
              if (customerName.isBlank()) {
                Toast.makeText(context, "Please enter customer name", Toast.LENGTH_SHORT).show()
                return@Button
              }
              if (billItems.isEmpty()) {
                Toast.makeText(context, "Please add at least one item to bill", Toast.LENGTH_SHORT).show()
                return@Button
              }
              val inv = buildInvoiceObject()
              if (savingInvoice) return@Button
              savingInvoice = true
              onSaveInvoice(inv, billItems.toList(), syncWithInventory) { saved ->
                savingInvoice = false
                if (saved != null) {
                  Toast.makeText(context, if (isEditing) "Bill updated successfully!" else "Bill saved successfully!", Toast.LENGTH_SHORT).show()
                  onDismiss()
                }
              }
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
            modifier = Modifier.weight(1.1f)
          ) {
            Icon(Icons.Default.Save, contentDescription = "Save", modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (isEditing) "Update" else "Save Bill", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
