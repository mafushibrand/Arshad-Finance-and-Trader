package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.*
import com.example.ui.dialogs.ThermalSlipDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun ModeSelectionScreen(
  currentMode: AppMode,
  appLanguage: AppLanguage,
  onModeSelected: (AppMode) -> Unit,
  modifier: Modifier = Modifier
) {
  val urdu = appLanguage == AppLanguage.URDU
  fun label(en: String, ur: String) = if (urdu) ur else en
  var selected by rememberSaveable { mutableStateOf(currentMode) }
  Column(modifier.fillMaxSize().background(Cream).statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
    Text(label("What type of business do you run?", "آپ کس قسم کا کاروبار کرتے ہیں؟"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Text(label("Choose your workspace. Customize it anytime in Business Builder.", "اپنا کاروبار منتخب کریں۔ کاروبار کی ترتیب بعد میں بھی بدل سکتے ہیں۔"), modifier = Modifier.padding(vertical = 14.dp), style = MaterialTheme.typography.bodyMedium)
    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(16.dp)) {
      item { ListTile(label("Shop / Retail", "دکان / ریٹیل"), label("Products, stock & POS billing", "سامان، اسٹاک اور بلنگ"), Icons.Default.Storefront, if (selected == AppMode.BUSINESS_RETAIL) "✓" else "", Mint, { selected = AppMode.BUSINESS_RETAIL }) }
      item { ListTile(label("Services", "سروسز"), label("Salon, repair, consulting and more", "سیلون، مرمت، مشاورت اور دیگر"), Icons.Default.Handyman, if (selected == AppMode.SERVICE_BASED) "✓" else "", Color(0xFFECE8FF), { selected = AppMode.SERVICE_BASED }) }
      item { ListTile(label("Personal Khata", "ذاتی کھاتہ"), label("Cash, expenses and customer balances", "کیش، اخراجات اور بقایا حساب"), Icons.Default.ReceiptLong, if (selected == AppMode.PERSONAL_KHATA) "✓" else "", Peach, { selected = AppMode.PERSONAL_KHATA }) }
      item { Metric(label("Every business fits", "ہر کاروبار کے لیے"), label("Wholesale • Restaurant • Online store", "ہول سیل • ریسٹورنٹ • آن لائن اسٹور")) }
    }
    PremiumButton(label("Continue", "آگے بڑھیں"), { onModeSelected(selected) })
  }
}
