package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.business.BusinessLibrary

@Composable
fun QuickStockAdjustDialog(item: InventoryItem,currencySymbol: String,onDismiss: () -> Unit,onAddStock: (Double,Double?) -> Unit,onDeductStock: (Double,Boolean) -> Unit,appLanguage: AppLanguage=AppLanguage.ENGLISH) {
  val urdu=appLanguage==AppLanguage.URDU;fun t(en:String,ur:String)=if(urdu)ur else en
  val details=BusinessLibrary.details(item.detailsJson)
  var incoming by remember {mutableStateOf(true)};var qty by remember {mutableStateOf("1")};var cost by remember {mutableStateOf(item.costPrice.toString())};var error by remember {mutableStateOf("")}
  var unit by remember {mutableStateOf(item.unit)};var record by remember {mutableStateOf(true)}
  val purchaseUnit=details.optString("purchaseUnit").ifBlank {item.unit}
  val factor=if(unit==item.unit) 1.0 else details.optString("conversion","1").toDoubleOrNull() ?: 1.0
  BusinessForm(t("Adjust Stock","اسٹاک تبدیل کریں"),t("Save Stock","اسٹاک محفوظ کریں"),onDismiss,{
    val q=qty.toDoubleOrNull();val p=cost.toDoubleOrNull();val base=(q ?: 0.0)*factor
    if(q==null||!q.isFinite()||q<=0||!base.isFinite()||factor<=0||p==null||!p.isFinite()||p<0)error=t("Enter a valid positive quantity and price","درست مثبت مقدار اور قیمت درج کریں")
    else if(!incoming&&base>item.currentStock+0.000001)error=t("Insufficient stock","اسٹاک کم ہے")
    else if(incoming)onAddStock(base,p/factor) else onDeductStock(base,record)
  }) {
    Text(item.name,style=MaterialTheme.typography.titleLarge);Text(t("Available: ${item.currentStock} ${item.unit}","موجودہ اسٹاک: ${item.currentStock} ${item.unit}"))
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(incoming,{incoming=true},label={Text(t("Stock in","مال آیا"))});FilterChip(!incoming,{incoming=false;unit=item.unit},label={Text(t("Stock out","مال نکلا"))})}
    BusinessChoice(unit,t("Quantity unit","مقدار کا یونٹ"),if(incoming)listOf(item.unit,purchaseUnit).distinct() else listOf(item.unit)){unit=it}
    BusinessField(qty,t("Quantity","مقدار"),true){qty=it};Text(t("Base quantity: ${(qty.toDoubleOrNull() ?: 0.0)*factor} ${item.unit}","بنیادی مقدار: ${(qty.toDoubleOrNull() ?: 0.0)*factor} ${item.unit}"))
    if(incoming)BusinessField(cost,t("Cost per $unit ($currencySymbol)","فی $unit خرید قیمت ($currencySymbol)"),true){cost=it}
    else Row {Text(t("Record as sale","فروخت کے طور پر درج کریں"),Modifier.weight(1f));Switch(record,{record=it})}
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}
