package com.example.ui.dialogs

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage

@Composable
fun BackupDialog(language: AppLanguage, onExport: (android.net.Uri, String, (String) -> Unit) -> Unit,
  onRestore: (android.net.Uri, String, (String) -> Unit) -> Unit, onDismiss: () -> Unit) {
  val urdu = language == AppLanguage.URDU
  fun text(en: String, ur: String) = if (urdu) ur else en
  var password by remember { mutableStateOf("") }
  var busy by remember { mutableStateOf(false) }
  var message by remember { mutableStateOf("") }
  var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
  val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
    if (uri != null) { busy = true; onExport(uri, password) { message = it; busy = false } }
  }
  val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> restoreUri = uri }
  AlertDialog(onDismissRequest = { if (!busy) onDismiss() }, title = { Text(text("Backup & Data", "بیک اپ اور ڈیٹا")) }, text = {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
      Text(text("Save an encrypted backup of records, business settings and payment screenshots. Keep its password safely.", "ریکارڈ، کاروباری ترتیبات اور ادائیگی کی تصاویر کا پاسورڈ والا بیک اپ محفوظ کریں۔ پاسورڈ سنبھال کر رکھیں۔"))
      OutlinedTextField(password, { password = it }, label = { Text(text("Backup password • 8+ characters", "بیک اپ پاسورڈ • کم از کم ۸ حروف")) }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), enabled = !busy)
      Button(onClick = { export.launch("ArshadFinance-${System.currentTimeMillis()}.afbackup") }, enabled = !busy && password.length >= 8, modifier = Modifier.fillMaxWidth()) { Text(text("Save encrypted backup", "بیک اپ محفوظ کریں")) }
      OutlinedButton(onClick = { restore.launch(arrayOf("*/*")) }, enabled = !busy && password.length >= 8, modifier = Modifier.fillMaxWidth()) { Text(text("Restore from backup", "بیک اپ بحال کریں")) }
      if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
      if (message.isNotEmpty()) Text(message)
    }
  }, confirmButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text(text("Close", "بند کریں")) } })
  restoreUri?.let { uri -> AlertDialog(onDismissRequest = { restoreUri = null }, title = { Text(text("Replace current records?", "موجودہ ریکارڈ بدلیں؟")) }, text = { Text(text("Restoring replaces this workspace with the selected backup. A recovery copy is saved on this device before restoration.", "بحالی سے موجودہ ریکارڈ منتخب بیک اپ سے بدل جائے گا۔ پہلے اسی ڈیوائس پر موجودہ ریکارڈ کی محفوظ نقل بنے گی۔")) },
    confirmButton = { TextButton(onClick = { restoreUri = null; busy = true; onRestore(uri, password) { message = it; busy = false } }) { Text(text("Restore", "بحال کریں")) } }, dismissButton = { TextButton(onClick = { restoreUri = null }) { Text(text("Cancel", "منسوخ")) } }) }
}
