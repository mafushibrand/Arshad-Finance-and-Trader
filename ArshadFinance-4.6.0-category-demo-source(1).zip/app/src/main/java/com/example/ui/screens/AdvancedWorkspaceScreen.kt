package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDirection
import java.util.Calendar
import com.example.ui.*
import com.example.ui.dialogs.*
import com.example.business.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.Date

internal fun businessTime(value:Long):String=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).apply {timeZone=TimeZone.getTimeZone("Asia/Karachi")}.format(Date(value))
internal fun parseBusinessTime(value:String):Long {
  val format=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).apply {isLenient=false;timeZone=TimeZone.getTimeZone("Asia/Karachi")}
  val position=java.text.ParsePosition(0);val result=format.parse(value.trim(),position)
  require(result!=null&&position.index==value.trim().length){"Use YYYY-MM-DD HH:mm / تاریخ اور وقت درست درج کریں"};return result.time
}
internal fun workflowStatus(state:FinanceUiState,status:String)=when(status){
  "PLANNED"->state.word("Planned","منصوبہ شدہ");"WIP"->state.word("Work in progress","زیر تیاری");"COMPLETED"->state.word("Completed","مکمل");"CANCELLED"->state.word("Cancelled","منسوخ");"ACTIVE"->state.word("Issued","جاری");"CLOSED"->state.word("Returned","واپس");"BOOKED"->state.word("Booked","بک شدہ");"INVOICED"->state.word("Invoiced","بل بن گیا");else->status}

@Composable
fun AdvancedWorkspaceScreen(state:FinanceUiState,viewModel:FinanceViewModel,onBack:()->Unit) {
  var section by remember {mutableStateOf("PRODUCTION_ORDER")};var query by remember {mutableStateOf("")};var form by remember {mutableStateOf(false)};var selected by remember {mutableStateOf<BusinessRecord?>(null)};var action by remember {mutableStateOf("")};var message by remember {mutableStateOf("")};var billing by remember {mutableStateOf<BusinessRecord?>(null)}
  val owner=state.userRole==com.example.data.model.UserRole.OWNER
  fun done(error:String?) {message=error ?: state.word("Saved successfully","محفوظ ہو گیا");if(error==null){form=false;selected=null;action=""}}
  val labels=mapOf("PRODUCTION_ORDER" to state.word("Production","پیداوار"),"RENTAL_CONTRACT" to state.word("Rentals","کرایہ"),"APPOINTMENT" to state.word("Appointments","اپائنٹمنٹ"))
  val enabled=labels.filterKeys {when(it){"PRODUCTION_ORDER"->state.features.manufacturing;"RENTAL_CONTRACT"->state.features.rentals;else->state.features.appointments}}
  LaunchedEffect(enabled.keys) {if(section !in enabled)section=enabled.keys.firstOrNull() ?: ""}
  val rows=state.businessRecords.filter {it.kind==section&&!it.archived&&(it.title.contains(query,true)||it.party.contains(query,true))}.sortedWith(compareBy<BusinessRecord>{if(it.kind=="APPOINTMENT")JSONObject(it.payload).optLong("start",it.createdAt) else -it.createdAt})
  PremiumPage(state.word("Operations studio","کاروباری ورک فلو"),state.word("Plan, fulfil and settle with a complete history","منصوبہ، تکمیل اور تصفیہ کی مکمل تاریخ"),Icons.Default.Workspaces,footer={if(owner&&section.isNotBlank())PremiumButton(state.word("Create ${labels[section]}","نیا ریکارڈ بنائیں"),{form=true})}) {
    item {TextButton(onClick=onBack){Text(state.word("Back to workspace","کاروباری مرکز واپس"))}}
    item {Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){enabled.forEach {(key,label)->FilterChip(section==key,{section=key;query=""},label={Text(label)})}}}
    item {SearchBox(query,state.word("Search reference or customer","حوالہ یا گاہک تلاش کریں")){query=it}}
    item {when(section){"PRODUCTION_ORDER"->Metric(state.word("Work in progress value","زیر تیاری مال کی لاگت"),state.money(state.businessRecords.filter {it.kind==section&&it.status=="WIP"}.sumOf {it.amount}));"RENTAL_CONTRACT"->Metric(state.word("Refundable deposits held","قابل واپسی ڈپازٹ"),state.money(state.businessRecords.sumOf {when(it.kind){"RENTAL_DEPOSIT"->it.amount;"RENTAL_DEPOSIT_APPLIED","RENTAL_DEPOSIT_REFUND"->-it.amount;else->0.0}}));else->Metric(state.word("Upcoming bookings","آئندہ اپائنٹمنٹ"),rows.count {it.status=="BOOKED"&&JSONObject(it.payload).optLong("end")>=System.currentTimeMillis()}.toString())}}
    if(message.isNotBlank())item {Text(message,color=MaterialTheme.colorScheme.primary)}
    if(!owner)item {Text(state.word("Owner access is required to post changes","تبدیلی کے لیے مالک کی رسائی ضروری ہے"))}
    if(rows.isEmpty())item {EmptyList(state.word("Ready for your first workflow","پہلا ورک فلو شروع کریں"),state.word("Create an order, issue an asset or book a service","آرڈر، کرایہ یا سروس کی بکنگ بنائیں"),Icons.Default.EventAvailable)}
    items(rows,key={it.id}) {record->val data=JSONObject(record.payload);val detail=if(section=="APPOINTMENT"&&data.has("start"))"${businessTime(data.getLong("start"))} • ${data.optString("staff")}" else record.party
      ListTile(record.title,"$detail • ${workflowStatus(state,record.status)}",if(section=="APPOINTMENT")Icons.Default.Event else if(section=="RENTAL_CONTRACT")Icons.Default.Key else Icons.Default.Factory,click={selected=record;action=""},controls={if(record.amount>0)Text(state.money(record.amount))})}
  }
  if(form) AdvancedCreateForm(section,state,null,{form=false}){values->
    viewModel.advancedAction({when(section){"PRODUCTION_ORDER"->planProduction(values.getString("title"),values.getString("bomId"),values.getDouble("quantity"),values.getString("branch"),values.getString("warehouse"),values.getString("batch"));"RENTAL_CONTRACT"->issueRental(values.getString("title"),values.getLong("itemId"),values.getDouble("quantity"),values.getLong("customerId"),values.getLong("start"),values.getLong("end"),values.getDouble("rate"),values.getDouble("lateRate"),values.getDouble("deposit"),values.getLong("accountId"),values.getString("branch"),values.getString("warehouse"));else->bookAppointment(values.getString("title"),values.getLong("customerId"),values.getString("staff"),values.getLong("start"),values.getLong("end"),values.getDouble("fee"),values.getString("branch"),values.getString("notes"))}}){done(it)}
  }
  selected?.let {old->val record=state.businessRecords.find {it.id==old.id} ?: old
    if(action=="finish"||action=="return") AdvancedSettlementForm(record,state,{action=""}){quantity,waste,cost,account,time->viewModel.advancedAction({if(action=="finish")finishProduction(record.id,quantity,waste,cost,account) else returnRental(record.id,quantity,cost,account,time)}){done(it)}}
    else if(action=="reschedule")AdvancedCreateForm("APPOINTMENT",state,record,{action=""}){v->viewModel.advancedAction({bookAppointment(v.getString("title"),v.getLong("customerId"),v.getString("staff"),v.getLong("start"),v.getLong("end"),v.getDouble("fee"),v.getString("branch"),v.getString("notes"),record.id)}){done(it)}}
    else if(action=="cancel")AlertDialog(onDismissRequest={action=""},title={Text(state.word("Cancel this record?","یہ ریکارڈ منسوخ کریں؟"))},text={Text(state.word("Issued production materials will return to the original warehouse.","جاری خام مال اصل گودام میں واپس ہو گا۔"))},confirmButton={TextButton(onClick={viewModel.advancedAction({if(record.kind=="PRODUCTION_ORDER")cancelProduction(record.id) else cancelAppointment(record.id)}){done(it)}}){Text(state.word("Confirm cancellation","منسوخی کی تصدیق"))}},dismissButton={TextButton(onClick={action=""}){Text(state.word("Keep record","ریکارڈ برقرار رکھیں"))}})
    else AlertDialog(onDismissRequest={selected=null},title={Text(record.title)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("${record.party} • ${workflowStatus(state,record.status)}");Text(state.money(record.amount));val d=JSONObject(record.payload)
      if(record.kind=="PRODUCTION_ORDER"){Text("${state.word("Planned quantity","منصوبہ مقدار")}: ${d.optDouble("plannedQuantity")}");Text("${state.word("Batch","بیچ")}: ${d.optString("batch")}")}
      if(record.kind=="APPOINTMENT"&&d.has("start"))Text("${businessTime(d.getLong("start"))} → ${businessTime(d.getLong("end"))}\n${d.optString("staff")}")
      if(record.kind=="RENTAL_CONTRACT"){Text("${state.word("Quantity / deposit","مقدار / ڈپازٹ")}: ${d.optDouble("quantity")} / ${state.money(d.optDouble("deposit"))}");Text("${state.word("Due","واپسی وقت")}: ${businessTime(d.getLong("due"))}")}
      if(owner){when {record.kind=="PRODUCTION_ORDER"&&record.status=="PLANNED"->PremiumButton(state.word("Issue raw materials","خام مال جاری کریں"),{viewModel.advancedAction({issueProduction(record.id)}){done(it)}});record.kind=="PRODUCTION_ORDER"&&record.status=="WIP"->PremiumButton(state.word("Finish production","پیداوار مکمل کریں"),{action="finish"});record.kind=="RENTAL_CONTRACT"&&record.status=="ACTIVE"->PremiumButton(state.word("Return and settle","واپسی اور تصفیہ"),{action="return"});record.kind=="APPOINTMENT"&&record.status in listOf("OPEN","BOOKED")-> {PremiumButton(state.word("Reschedule","وقت تبدیل کریں"),{action="reschedule"});PremiumButton(state.word("Create service invoice","سروس کا بل بنائیں"),{selected=null;billing=record})}}
        if(record.kind=="PRODUCTION_ORDER"&&record.status in listOf("PLANNED","WIP")||record.kind=="APPOINTMENT"&&record.status in listOf("OPEN","BOOKED"))TextButton(onClick={action="cancel"}){Text(state.word("Cancel workflow","منسوخ کریں"))}}
    }},confirmButton={TextButton(onClick={selected=null}){Text(state.word("Close","بند"))}})
  }
  billing?.let {work->WorkBillingForm(work,state,{billing=null}){customer,parts,labour,period->viewModel.tradeAction({billWork(work.id,customer,parts,labour,period)}){if(it==null)billing=null;done(it)}}}
}

@Composable
fun AdvancedCreateForm(kind:String,state:FinanceUiState,record:BusinessRecord?,dismiss:()->Unit,save:(JSONObject)->Unit) {
  val old=record?.let {JSONObject(it.payload)} ?: JSONObject()
  var title by remember {mutableStateOf(record?.title ?: "")};var quantity by remember {mutableStateOf("1")};var customer by remember {mutableStateOf(old.optLong("customerId",state.customers.firstOrNull()?.id ?: 0L))};var staff by remember {mutableStateOf(old.optString("staff"))};var start by remember {mutableStateOf(businessTime(old.optLong("start",System.currentTimeMillis())))};var end by remember {mutableStateOf(businessTime(old.optLong("end",System.currentTimeMillis()+3600000)))}
  var fee by remember {mutableStateOf((record?.amount ?: 0.0).toString())};var notes by remember {mutableStateOf(old.optString("notes"))};var branch by remember {mutableStateOf(record?.branchId ?: "main")};var warehouse by remember {mutableStateOf("main")};var bom by remember {mutableStateOf(state.businessRecords.firstOrNull {it.kind=="BOM"&&!it.archived}?.id ?: "")};var batch by remember {mutableStateOf("")};var item by remember {mutableStateOf(state.inventoryItems.firstOrNull { !it.isServiceItem()}?.id ?: 0L)}
  var rate by remember {mutableStateOf("0")};var lateRate by remember {mutableStateOf("0")};var deposit by remember {mutableStateOf("0")};var account by remember {mutableStateOf(state.accounts.firstOrNull()?.id ?: 0L)};var error by remember {mutableStateOf("")}
  BusinessForm(state.word(if(kind=="PRODUCTION_ORDER")"Plan production" else if(kind=="RENTAL_CONTRACT")"Issue rental" else "Book appointment",if(kind=="PRODUCTION_ORDER")"پیداوار منصوبہ" else if(kind=="RENTAL_CONTRACT")"کرایہ جاری کریں" else "اپائنٹمنٹ بک کریں"),state.word("Save workflow","محفوظ کریں"),dismiss,{
    runCatching {val data=JSONObject().put("title",title).put("branch",branch).put("warehouse",warehouse).put("accountId",account).put("notes",notes)
      require(title.isNotBlank());if(kind=="PRODUCTION_ORDER")data.put("bomId",bom).put("quantity",quantity.toDouble()).put("batch",batch)
      else {data.put("customerId",customer).put("start",parseBusinessTime(start)).put("end",parseBusinessTime(end));if(kind=="APPOINTMENT")data.put("staff",staff).put("fee",fee.toDouble()) else data.put("itemId",item).put("quantity",quantity.toDouble()).put("rate",rate.toDouble()).put("lateRate",lateRate.toDouble()).put("deposit",deposit.toDouble())};save(data)
    }.onFailure {error=state.word("Check required fields and use YYYY-MM-DD HH:mm for dates","تمام فیلڈز درست درج کریں، تاریخ YYYY-MM-DD HH:mm میں لکھیں")}
  }) {
    BusinessField(title,state.word("Reference / service name","حوالہ / سروس نام")){title=it}
    if(kind=="PRODUCTION_ORDER") {val boms=state.businessRecords.filter {it.kind=="BOM"&&!it.archived};BusinessChoice(boms.find {it.id==bom}?.title ?: "",state.word("Recipe / BOM","ریسپی"),boms.map {it.title}){name->bom=boms.first {it.title==name}.id};BusinessField(quantity,state.word("Planned output including wastage","ضیاع سمیت منصوبہ پیداوار"),true){quantity=it};BusinessField(batch,state.word("Batch / lot reference","بیچ / لاٹ حوالہ")){batch=it};Text(state.word("Planning reserves no stock. Issue materials to start WIP.","منصوبہ اسٹاک کم نہیں کرتا۔ خام مال جاری کرنے سے تیاری شروع ہو گی۔"))}
    else {
      BusinessChoice(state.customers.find {it.id==customer}?.name ?: "",state.word("Customer","گاہک"),state.customers.map {it.name}){name->customer=state.customers.first {it.name==name}.id}
      OperationalDateField(start,state.word("Start • YYYY-MM-DD HH:mm","شروع • YYYY-MM-DD HH:mm")){start=it}
      OperationalDateField(end,state.word(if(kind=="RENTAL_CONTRACT")"Due • YYYY-MM-DD HH:mm" else "End • YYYY-MM-DD HH:mm","اختتام • YYYY-MM-DD HH:mm")){end=it}
      Text(if(kind=="RENTAL_CONTRACT")state.word("Times use Asia/Karachi. Rental days round up to whole 24-hour periods.","وقت پاکستان کا ہے۔ کرایہ کے دن مکمل 24 گھنٹے کی مدت میں شمار ہوں گے۔") else state.word("Times use Asia/Karachi. The same staff cannot have overlapping bookings.","وقت پاکستان کا ہے۔ ایک عملے کی بکنگ ایک ہی وقت میں نہیں ہو سکتی۔"))
      if(kind=="APPOINTMENT"){BusinessField(staff,state.word("Staff / resource","عملہ / وسیلہ")){staff=it};BusinessField(fee,state.word("Service fee estimate","سروس فیس تخمینہ"),true){fee=it};BusinessField(notes,state.word("Notes","نوٹ")){notes=it}}
      else {val products=state.inventoryItems.filter {!it.isServiceItem()};BusinessChoice(products.find {it.id==item}?.name ?: "",state.word("Rental asset","کرایہ کا سامان"),products.map {it.name}){name->item=products.first {it.name==name}.id};BusinessField(quantity,state.word("Quantity in base units","بنیادی یونٹ میں مقدار"),true){quantity=it};BusinessField(rate,state.word("Daily rate per unit","فی یونٹ روزانہ کرایہ"),true){rate=it};BusinessField(lateRate,state.word("Late day rate per unit","فی یونٹ تاخیر روزانہ کرایہ"),true){lateRate=it};BusinessField(deposit,state.word("Refundable deposit received","وصول شدہ قابل واپسی ڈپازٹ"),true){deposit=it};AccountChoice(state,account){account=it}}
    }
    LocationChoices(state,branch,warehouse,{branch=it},{warehouse=it})
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}

@Composable
fun AdvancedSettlementForm(record:BusinessRecord,state:FinanceUiState,dismiss:()->Unit,save:(Double,Double,Double,Long,Long)->Unit) {
  val production=record.kind=="PRODUCTION_ORDER";val data=JSONObject(record.payload)
  var quantity by remember {mutableStateOf(data.optDouble(if(production)"plannedQuantity" else "quantity",1.0).toString())};var waste by remember {mutableStateOf("0")};var cost by remember {mutableStateOf("0")};var account by remember {mutableStateOf(state.accounts.firstOrNull()?.id ?: 0L)};var time by remember {mutableStateOf(businessTime(System.currentTimeMillis()))};var error by remember {mutableStateOf("")}
  BusinessForm(state.word(if(production)"Finish production" else "Return rental",if(production)"پیداوار مکمل" else "کرایہ واپسی"),state.word("Post and settle","درج کریں اور تصفیہ کریں"),dismiss,{
    runCatching {save(quantity.toDouble(),waste.toDouble(),cost.toDouble(),account,if(production)System.currentTimeMillis() else parseBusinessTime(time))}.onFailure {error=state.word("Enter valid quantities, amounts and date","مقدار، رقم اور تاریخ درست درج کریں")}
  }) {
    Metric(record.title,record.party)
    BusinessField(quantity,state.word(if(production)"Good finished output" else "Usable quantity returned",if(production)"تیار پیداوار" else "قابل استعمال واپس مقدار"),true){quantity=it}
    if(production)BusinessField(waste,state.word("Wastage in output units","پیداوار یونٹ میں ضیاع"),true){waste=it} else OperationalDateField(time,state.word("Return time • YYYY-MM-DD HH:mm","واپسی وقت • YYYY-MM-DD HH:mm")){time=it}
    BusinessField(cost,state.word(if(production)"Labour / overhead paid now" else "Damage / loss charge",if(production)"اب ادا شدہ مزدوری / اضافی خرچ" else "نقصان کی رقم"),true){cost=it}
    AccountChoice(state,account){account=it}
    Text(state.word(if(production)"Unused materials return to the same warehouse. Production cost includes wastage and the additional payment." else "This closes the entire contract. Unreturned units are recorded as damaged/lost. Deposit pays the invoice first; surplus is refunded and unpaid fees enter Khata.",if(production)"غیر استعمال خام مال اسی گودام میں واپس ہو گا۔ لاگت میں ضیاع اور اضافی ادائیگی شامل ہیں۔" else "پورا معاہدہ بند ہو گا۔ باقی سامان نقصان میں درج ہو گا۔ ڈپازٹ پہلے بل میں لگے گا، اضافی رقم واپس اور بقایا کھاتہ میں درج ہو گا۔"))
    if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }
}

@Composable
private fun OperationalDateField(value:String,label:String,change:(String)->Unit) {
  val context=LocalContext.current
  OutlinedTextField(value,change,label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true,
    textStyle=LocalTextStyle.current.copy(textDirection=TextDirection.Ltr),shape=androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
    trailingIcon={IconButton(onClick={
      val calendar=Calendar.getInstance(TimeZone.getTimeZone("Asia/Karachi")).apply {timeInMillis=runCatching {parseBusinessTime(value)}.getOrDefault(System.currentTimeMillis())}
      android.app.DatePickerDialog(context,{_,year,month,day->
        calendar.set(Calendar.YEAR,year);calendar.set(Calendar.MONTH,month);calendar.set(Calendar.DAY_OF_MONTH,day)
        android.app.TimePickerDialog(context,{_,hour,minute->calendar.set(Calendar.HOUR_OF_DAY,hour);calendar.set(Calendar.MINUTE,minute);calendar.set(Calendar.SECOND,0);calendar.set(Calendar.MILLISECOND,0);change(businessTime(calendar.timeInMillis))},calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true).show()
      },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show()
    }){Icon(Icons.Default.CalendarMonth,label)}})
}
