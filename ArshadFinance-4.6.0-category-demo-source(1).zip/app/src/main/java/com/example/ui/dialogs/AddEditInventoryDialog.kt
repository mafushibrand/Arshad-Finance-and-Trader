package com.example.ui.dialogs

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.InventoryItem
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.InputFieldStyles

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegacyAddEditInventoryDialog(
  item: InventoryItem? = null,
  currencySymbol: String = "Rs",
  totalExistingProductsCount: Int = 0,
  isBasicTierRestricted: Boolean = false,
  onDismiss: () -> Unit,
  onSave: (
    id: Long,
    name: String,
    category: String,
    icon: String,
    costPrice: Double,
    salePrice: Double,
    currentStock: Double,
    unit: String,
    lowStockThreshold: Double,
    barcode: String,
    supplierName: String,
    note: String
  ) -> Unit,
  onDelete: ((InventoryItem) -> Unit)? = null
) {
  val context = LocalContext.current
  val isEditing = item != null

  // Basic tier boundary check
  if (!isEditing && isBasicTierRestricted && totalExistingProductsCount >= 5) {
    Dialog(onDismissRequest = onDismiss) {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.padding(16.dp)
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text("🔒 Basic Tier Limit Reached", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ExpenseRed)
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "You have reached the maximum of 5 products allowed in the Basic Tier. Please activate your subscription (PKR 300/mo or PKR 3000/yr) to add unlimited products.",
            fontSize = 12.sp,
            color = Color(0xFF475569)
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)) {
            Text("Got It")
          }
        }
      }
    }
    return
  }

  var name by remember { mutableStateOf(item?.name ?: "") }
  var category by remember { mutableStateOf(item?.category ?: "Grocery & Karyana") }
  var selectedIcon by remember { mutableStateOf(item?.icon ?: "📦") }
  var costPriceText by remember {
    mutableStateOf(item?.let { if (it.costPrice % 1.0 == 0.0) it.costPrice.toLong().toString() else it.costPrice.toString() } ?: "")
  }
  var salePriceText by remember {
    mutableStateOf(item?.let { if (it.salePrice % 1.0 == 0.0) it.salePrice.toLong().toString() else it.salePrice.toString() } ?: "")
  }
  var stockText by remember {
    mutableStateOf(item?.let { if (it.currentStock % 1.0 == 0.0) it.currentStock.toLong().toString() else it.currentStock.toString() } ?: "1")
  }
  var unit by remember { mutableStateOf(item?.unit ?: "Kg") }
  var thresholdText by remember {
    mutableStateOf(item?.let { if (it.lowStockThreshold % 1.0 == 0.0) it.lowStockThreshold.toLong().toString() else it.lowStockThreshold.toString() } ?: "2")
  }
  var barcode by remember { mutableStateOf(item?.barcode ?: "") }
  var supplierName by remember { mutableStateOf(item?.supplierName ?: "") }
  var productPhotoUri by remember { mutableStateOf<String?>(null) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  var categoryDropdownExpanded by remember { mutableStateOf(false) }
  var unitDropdownExpanded by remember { mutableStateOf(false) }

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri ->
    if (uri != null) {
      productPhotoUri = uri.toString()
      Toast.makeText(context, "Product photo attached with HD 1:1 frame!", Toast.LENGTH_SHORT).show()
    }
  }

  // Universal Business Categories
  val categoriesList = listOf(
    "Cash & Carry (کیش اینڈ کیری)",
    "General Store & Mart (جنرل سٹور و مارٹ)",
    "Grocery & Karyana (کریانہ: دال، چینی، گھی)",
    "Fast Food & Pizza (فاسٹ فوڈ و پیزا)",
    "Salon & Beauty Parlour (سیلون و بیوٹی پارلر)",
    "Gym & Fitness Club (جم و فٹنس)",
    "Pharmacy & Medical (ادویات و فارمیسی)",
    "Mobile Shop & Sales (موبائل شاپ)",
    "Mobile Repairing Lab (موبائل ریپیئرنگ)",
    "Laptop & Computer Repair (لیپ ٹاپ ریپیئرنگ)",
    "Mobile & Tech Accessories (موبائل سامان)",
    "Garments & Cloth Shop (کپڑے کی دکان)",
    "Shoes & Footwear (شوز و جوتے)",
    "Bakery & Sweets (بیکری و مٹھائی)",
    "Book & Stationery (بک و سٹیشنری)",
    "Gift & Toy Shop (گفٹ و ٹائے شاپ)",
    "Sanitary & Hardware (سینیٹری و ہارڈویئر)",
    "Farm & Dairy Distributors (فارم و ڈیری)",
    "Electronics & Electric (الیکٹرانکس)",
    "Distributor & Wholesale (ڈسٹری بیوٹر و تھوک)",
    "Crockery & Utensils Store (کراکری و برتن)",
    "Automobile & Showroom (شو روم و آٹو پارٹس)"
  )

  // Universal Units
  val unitsList = listOf(
    "Kg (کلوگرام)",
    "0.25 kg / پاؤ (250g)",
    "0.5 kg / آدھا کلو (500g)",
    "Maund / 40 kg (من)",
    "Bag / 50 kg (بوری)",
    "Gram (گرام)",
    "Liter (لیٹر)",
    "Ml (ملی لیٹر)",
    "Piece / Pcs (عدد)",
    "Box (ڈبہ)",
    "Packet (پیکٹ)",
    "Dozen (درجن)",
    "Meter (میٹر)",
    "Gaz (گز)",
    "Suit (سوٹ)",
    "Pair (جوڑا)",
    "Tablet (ٹیبلٹ)",
    "Strip (پتہ)",
    "Bottle (بوتل)",
    "Service (سروس)",
    "Hour (گھنٹہ)",
    "Session (سیشن)",
    "Deal (ڈیل)"
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(24.dp))
        .testTag("add_edit_inventory_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // 1. Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = if (isEditing) "Edit Product / آئٹم تبدیل کریں" else "+ Add New Product / نیا سامان",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A),
                fontSize = 17.sp
              )
            )
            Text(
              text = "Universal Business Setup (تمام اقسام کے کاروبار کیلئے)",
              style = MaterialTheme.typography.bodySmall.copy(
                color = Color(0xFF64748B),
                fontSize = 11.sp
              )
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 2. HD Image Framing (Locked 1:1 Aspect Ratio)
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(80.dp)
              .aspectRatio(1f)
              .clip(RoundedCornerShape(16.dp))
              .background(Color(0xFFF7F9F3))
              .border(1.5.dp, Color(0xFFCBD5E1), RoundedCornerShape(16.dp))
              .clickable { photoPickerLauncher.launch("image/*") },
            contentAlignment = Alignment.Center
          ) {
            if (productPhotoUri != null) {
              AsyncImage(
                model = productPhotoUri,
                contentDescription = "Product HD Frame",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(1f)
              )
            } else {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CameraAlt, contentDescription = "Add Photo", tint = IndigoPrimary, modifier = Modifier.size(24.dp))
                Text("HD Photo", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
              }
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = "Automatic HD Image Framing",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
            Text(
              text = "Auto-cropped to locked 1:1 square frame so layout never shifts or breaks.",
              fontSize = 10.sp,
              color = Color(0xFF64748B)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFE5F3EA),
              modifier = Modifier.clickable { photoPickerLauncher.launch("image/*") }
            ) {
              Text("Upload Image 📷", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3. Product Name Field
        OutlinedTextField(
          value = name,
          onValueChange = {
            name = it
            errorMessage = null
          },
          label = { Text("Product / Item Name (پراڈکٹ کا نام) *") },
          placeholder = { Text("e.g. Daal Chana, Sugar, Panadol, haircut...") },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth().testTag("product_name_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Category Selector (Universal Shop Types)
        ExposedDropdownMenuBox(
          expanded = categoryDropdownExpanded,
          onExpandedChange = { categoryDropdownExpanded = !categoryDropdownExpanded },
          modifier = Modifier.fillMaxWidth()
        ) {
          OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Business Category / زمرہ") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryDropdownExpanded) },
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.menuAnchor().fillMaxWidth().testTag("product_category_dropdown")
          )
          ExposedDropdownMenu(
            expanded = categoryDropdownExpanded,
            onDismissRequest = { categoryDropdownExpanded = false }
          ) {
            categoriesList.forEach { cat ->
              DropdownMenuItem(
                text = { Text(cat, fontSize = 12.5.sp) },
                onClick = {
                  category = cat.substringBefore(" (")
                  categoryDropdownExpanded = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 5. Unit Selector + Fractional Weight Quick Presets (Daal, Sugar, Liquid, Tablet)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          // Unit Dropdown
          ExposedDropdownMenuBox(
            expanded = unitDropdownExpanded,
            onExpandedChange = { unitDropdownExpanded = !unitDropdownExpanded },
            modifier = Modifier.weight(1f)
          ) {
            OutlinedTextField(
              value = unit,
              onValueChange = { unit = it },
              label = { Text("Unit (پیمائش)") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitDropdownExpanded) },
              shape = RoundedCornerShape(12.dp),
              textStyle = InputFieldStyles.textStyle,
              colors = InputFieldStyles.colors(),
              modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(
              expanded = unitDropdownExpanded,
              onDismissRequest = { unitDropdownExpanded = false }
            ) {
              unitsList.forEach { u ->
                DropdownMenuItem(
                  text = { Text(u, fontSize = 12.sp) },
                  onClick = {
                    unit = u.substringBefore(" (")
                    unitDropdownExpanded = false
                  }
                )
              }
            }
          }

          // Initial Stock Input
          OutlinedTextField(
            value = stockText,
            onValueChange = { stockText = it },
            label = { Text("Stock Qty (موجودہ)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.weight(1f).testTag("product_stock_input")
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Fractional Weight Chips (0.25 kg, 0.5 kg, 0.75 kg, 1 kg)
        Text(
          text = "⚡ Quick Fractional Presets (پاؤ • آدھا کلو • کلو):",
          fontSize = 10.5.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF64748B)
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          listOf("0.25", "0.50", "0.75", "1.0", "2.0", "5.0", "10.0", "40.0", "50.0").forEach { fraction ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (stockText == fraction) IndigoPrimary else Color(0xFFF7F9F3),
              modifier = Modifier.clickable { stockText = fraction }
            ) {
              Text(
                text = when (fraction) {
                  "0.25" -> "0.25 (پاؤ)"
                  "0.50" -> "0.5 (آدھا کلو)"
                  "0.75" -> "0.75 (3 پاؤ)"
                  "40.0" -> "40 kg (من)"
                  "50.0" -> "50 kg (بوری)"
                  else -> "$fraction $unit"
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (stockText == fraction) Color.White else Color(0xFF1E293B),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 6. Pricing Row: Cost Price & Sale Price
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = costPriceText,
            onValueChange = { costPriceText = it },
            label = { Text("Cost Price / لاگت ($currencySymbol)") },
            placeholder = { Text("150") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.weight(1f).testTag("product_cost_price")
          )

          OutlinedTextField(
            value = salePriceText,
            onValueChange = { salePriceText = it },
            label = { Text("Sale Price / فروخت *") },
            placeholder = { Text("200") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            textStyle = InputFieldStyles.textStyle,
            colors = InputFieldStyles.colors(),
            modifier = Modifier.weight(1f).testTag("product_sale_price")
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 7. Barcode Scanner field
        OutlinedTextField(
          value = barcode,
          onValueChange = { barcode = it },
          label = { Text("Barcode / بارکوڈ (Optional)") },
          placeholder = { Text("896400012345") },
          leadingIcon = {
            Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = IndigoPrimary)
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 8. Low Stock Alert Threshold
        OutlinedTextField(
          value = thresholdText,
          onValueChange = { thresholdText = it },
          label = { Text("Low Stock Alert / کم اسٹاک الرٹ") },
          placeholder = { Text("2") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          textStyle = InputFieldStyles.textStyle,
          colors = InputFieldStyles.colors(),
          modifier = Modifier.fillMaxWidth()
        )

        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = errorMessage ?: "",
            color = ExpenseRed,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 9. Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          if (isEditing && onDelete != null) {
            OutlinedButton(
              onClick = { item?.let { onDelete(it) } },
              colors = ButtonDefaults.outlinedButtonColors(contentColor = ExpenseRed),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f).height(48.dp)
            ) {
              Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Delete")
            }
          }

          Button(
            onClick = {
              if (name.isBlank()) {
                errorMessage = "براہ کرم پروڈکٹ کا نام درج کریں (Enter product name)"
                return@Button
              }
              val cost = costPriceText.toDoubleOrNull() ?: 0.0
              val sale = salePriceText.toDoubleOrNull() ?: 0.0
              val stock = stockText.toDoubleOrNull() ?: 0.0
              val threshold = thresholdText.toDoubleOrNull() ?: 0.0

              if (sale <= 0.0) {
                errorMessage = "براہ کرم درست فروخت کی قیمت درج کریں (Enter valid sale price)"
                return@Button
              }

              onSave(
                item?.id ?: 0L,
                name.trim(),
                category.trim(),
                selectedIcon,
                cost,
                sale,
                stock,
                unit.trim(),
                threshold,
                barcode.trim(),
                supplierName.trim(),
                ""
              )
              onDismiss()
            },
            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(2f).height(48.dp).testTag("save_product_btn")
          ) {
            Text(
              text = if (isEditing) "Update Product (تبدیل کریں)" else "+ Save Product (محفوظ کریں)",
              fontWeight = FontWeight.Bold,
              fontSize = 13.5.sp
            )
          }
        }
      }
    }
  }
}
