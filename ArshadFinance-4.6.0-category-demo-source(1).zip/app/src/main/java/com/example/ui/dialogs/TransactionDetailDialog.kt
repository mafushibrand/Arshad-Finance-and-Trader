package com.example.ui.dialogs

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IceBlueContainer
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.LightSurface
import com.example.ui.theme.NavyBluePrimary
import com.example.ui.theme.OnIceBlueContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.util.BusinessProfile
import com.example.util.BusinessUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TransactionDetailDialog(
  transaction: Transaction,
  currencySymbol: String,
  businessProfile: BusinessProfile = BusinessProfile(),
  onDismiss: () -> Unit,
  onDelete: () -> Unit
) {
  val context = LocalContext.current
  val isIncome = transaction.type == TransactionType.INCOME
  val amountPrefix = if (isIncome) "+" else "-"
  val amountColor = if (isIncome) IncomeGreen else ExpenseRed

  val fullDateFormat = SimpleDateFormat("MMMM d, yyyy 'at' h:mm a", Locale.getDefault())
  val formattedDate = fullDateFormat.format(Date(transaction.dateMillis))

  var isFullScreenImageOpen by remember { mutableStateOf(false) }
  var showReminderOptions by remember { mutableStateOf(false) }

  if (isFullScreenImageOpen && transaction.receiptImageUri.isNotBlank()) {
    Dialog(onDismissRequest = { isFullScreenImageOpen = false }) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.Black)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Payment Screenshot",
              style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
            )
            IconButton(onClick = { isFullScreenImageOpen = false }) {
              Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
            }
          }
          Spacer(modifier = Modifier.height(12.dp))
          AsyncImage(
            model = transaction.receiptImageUri,
            contentDescription = "Full screenshot",
            contentScale = ContentScale.Fit,
            modifier = Modifier
              .fillMaxWidth()
              .height(380.dp)
              .clip(RoundedCornerShape(16.dp))
          )
        }
      }
    }
  }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(28.dp))
        .testTag("transaction_detail_dialog"),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(22.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Title Bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Payment Slip / Receipt",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Icon Badge
        Box(
          modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(LightSurface),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = transaction.icon.ifBlank { if (isIncome) "💵" else "🛍️" },
            fontSize = 30.sp
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = transaction.title,
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )

        if (transaction.paymentMethod.isNotBlank()) {
          Box(
            modifier = Modifier
              .padding(top = 4.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(IceBlueContainer)
              .padding(horizontal = 12.dp, vertical = 4.dp)
          ) {
            Text(
              text = transaction.paymentMethod,
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = OnIceBlueContainer
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = String.format(Locale.US, "%s%s%,.2f", amountPrefix, currencySymbol, transaction.amount),
          style = MaterialTheme.typography.displaySmall.copy(
            fontWeight = FontWeight.Bold,
            color = amountColor,
            fontSize = 30.sp
          )
        )

        Spacer(modifier = Modifier.height(16.dp))

        HorizontalDivider(color = Color(0xFFE2E2E6))

        Spacer(modifier = Modifier.height(14.dp))

        DetailRow(label = "Date & Time", value = formattedDate)
        DetailRow(label = "Account", value = transaction.accountName)
        if (transaction.paymentMethod.isNotBlank()) {
          DetailRow(label = "Payment Source", value = transaction.paymentMethod)
        }
        if (transaction.recipientInfo.isNotBlank()) {
          DetailRow(label = "Recipient / Payee", value = transaction.recipientInfo)
        }
        if (transaction.transactionRef.isNotBlank()) {
          DetailRow(label = "Ref / Transaction ID", value = transaction.transactionRef)
        }
        DetailRow(label = "Category", value = transaction.category)
        if (transaction.note.isNotBlank()) {
          DetailRow(label = "Note", value = transaction.note)
        }

        // Receipt Screenshot Preview Card if attached
        if (transaction.receiptImageUri.isNotBlank()) {
          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = "Attached Screenshot / Proof",
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            ),
            modifier = Modifier.align(Alignment.Start)
          )
          Spacer(modifier = Modifier.height(6.dp))

          Card(
            modifier = Modifier
              .fillMaxWidth()
              .height(140.dp)
              .clip(RoundedCornerShape(16.dp))
              .border(1.dp, Color(0xFFE2E2E6), RoundedCornerShape(16.dp))
              .clickable { isFullScreenImageOpen = true },
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F3F7))
          ) {
            Box(modifier = Modifier.fillMaxSize()) {
              AsyncImage(
                model = transaction.receiptImageUri,
                contentDescription = "Receipt Screenshot",
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
              )
              Box(
                modifier = Modifier
                  .align(Alignment.BottomEnd)
                  .padding(8.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(Color.Black.copy(alpha = 0.65f))
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Fullscreen,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "Tap to view",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White)
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // WhatsApp Reminder Section
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0))
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "📲", fontSize = 18.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "WhatsApp Khata Share",
                  style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF166534)
                  )
                )
              }
              Text(
                text = "1-Click",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF15803D)
                )
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Button(
                onClick = {
                  val msg = BusinessUtils.buildReminderMessage(
                    customerName = transaction.recipientInfo.ifBlank { transaction.title },
                    amount = transaction.amount,
                    currency = currencySymbol,
                    businessProfile = businessProfile,
                    isUrdu = true
                  )
                  BusinessUtils.shareWhatsAppMessage(
                    context = context,
                    phoneNumber = transaction.recipientInfo,
                    message = msg
                  )
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                modifier = Modifier.weight(1f)
              ) {
                Text(text = "اردو میسج", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }

              OutlinedButton(
                onClick = {
                  val msg = BusinessUtils.buildReminderMessage(
                    customerName = transaction.recipientInfo.ifBlank { transaction.title },
                    amount = transaction.amount,
                    currency = currencySymbol,
                    businessProfile = businessProfile,
                    isUrdu = false
                  )
                  BusinessUtils.shareWhatsAppMessage(
                    context = context,
                    phoneNumber = transaction.recipientInfo,
                    message = msg
                  )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
              ) {
                Text(text = "English Notice", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // PDF Invoice & Standard Share
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = {
              BusinessUtils.generateAndShareReceiptPdf(
                context = context,
                transaction = transaction,
                currencySymbol = currencySymbol,
                businessProfile = businessProfile
              )
            },
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NavyBluePrimary),
            modifier = Modifier
              .weight(1f)
              .testTag("generate_pdf_button")
          ) {
            Icon(
              imageVector = Icons.Default.PictureAsPdf,
              contentDescription = "PDF Receipt",
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "PDF Receipt", fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = {
              shareTransactionReceipt(context, transaction, currencySymbol)
            },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("share_receipt_button")
          ) {
            Icon(
              imageVector = Icons.Default.Share,
              contentDescription = "Share",
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Share Slip", fontSize = 13.sp)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
          onClick = onDelete,
          colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed.copy(alpha = 0.9f)),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("delete_transaction_button")
        ) {
          Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "Delete",
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "Delete Transaction")
        }
      }
    }
  }
}

private fun shareTransactionReceipt(context: Context, transaction: Transaction, currencySymbol: String) {
  val isIncome = transaction.type == TransactionType.INCOME
  val sign = if (isIncome) "+" else "-"
  val dateFormat = SimpleDateFormat("MMM d, yyyy 'at' h:mm a", Locale.getDefault())
  val dateStr = dateFormat.format(Date(transaction.dateMillis))

  val slipText = buildString {
    appendLine("🧾 *PAYMENT RECEIPT / SLIP*")
    appendLine("━━━━━━━━━━━━━━━━━━━")
    appendLine("📌 *Title:* ${transaction.title}")
    appendLine("💰 *Amount:* $sign$currencySymbol${String.format(Locale.US, "%,.2f", transaction.amount)}")
    appendLine("📅 *Date:* $dateStr")
    if (transaction.paymentMethod.isNotBlank()) {
      appendLine("💳 *Payment Method:* ${transaction.paymentMethod}")
    }
    if (transaction.recipientInfo.isNotBlank()) {
      appendLine("👤 *Recipient/Payee:* ${transaction.recipientInfo}")
    }
    if (transaction.transactionRef.isNotBlank()) {
      appendLine("🔢 *Ref / TRX ID:* ${transaction.transactionRef}")
    }
    appendLine("🏦 *Account:* ${transaction.accountName}")
    if (transaction.note.isNotBlank()) {
      appendLine("📝 *Note:* ${transaction.note}")
    }
    appendLine("━━━━━━━━━━━━━━━━━━━")
    appendLine("Shared via Arshad Finance App")
  }

  val intent = Intent(Intent.ACTION_SEND).apply {
    type = "text/plain"
    putExtra(Intent.EXTRA_SUBJECT, "Payment Receipt: ${transaction.title}")
    putExtra(Intent.EXTRA_TEXT, slipText)
    if (transaction.receiptImageUri.isNotBlank()) {
      try {
        val imageUri = Uri.parse(transaction.receiptImageUri)
        putExtra(Intent.EXTRA_STREAM, imageUri)
        type = "image/*"
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      } catch (_: Exception) {
        // Fallback to text if URI parsing fails
      }
    }
  }

  context.startActivity(Intent.createChooser(intent, "Share Payment Slip / Receipt"))
}

@Composable
private fun DetailRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 5.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary, fontWeight = FontWeight.Medium)
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold)
    )
  }
}
