package com.example.data.model

data class ServiceItem(
  val id: Long = System.currentTimeMillis(),
  val name: String,
  val urduName: String = "",
  val businessCategory: String, // SALON, GYM, MOBILE_REPAIR, LAPTOP_REPAIR, CAR_SHOWROOM, TAILOR, FAST_FOOD, ELECTRONICS, CROCKERY, GENERAL
  val serviceType: String,
  val price: Double,
  val isDiscountActive: Boolean = false,
  val discountPrice: Double = 0.0,
  val quantity: Double = 1.0,
  val unit: String = "Service (سروس)",
  val stockOrSlots: Double = 50.0,
  val icon: String = "🛠️",
  val description: String = "",
  val isFeatured: Boolean = false
) {
  val effectivePrice: Double
    get() = if (isDiscountActive && discountPrice > 0.0) discountPrice else price

  val discountSaved: Double
    get() = if (isDiscountActive && discountPrice > 0.0) (price - discountPrice).coerceAtLeast(0.0) else 0.0
}

data class ShopBioData(
  val shopName: String = "ارشد فنانس و سروسز سینٹر",
  val ownerName: String = "محمد ارشد",
  val phone: String = "0302-7761415",
  val email: String = "muhammadarshad686@gmail.com",
  val address: String = "مین شاہراہ، بالمقابل جامع مسجد، نزد کچہری چوک",
  val city: String = "",
  val businessCategory: String = "تمام دکانیں و سروسز (All Shops & Services)",
  val bioDescription: String = "ہم تمام کاروبار جیسے سیلون، جم، موبائل و لیپ ٹاپ ریپئرنگ، گاڑی شو روم، درزی، فاسٹ فوڈ اور جنرل سروسز کیلئے جدید ترین سہولیات اور بلنگ فراہم کرتے ہیں۔",
  val openingHours: String = "9:00 AM - 10:00 PM (ہفتے کے 7 دن)"
)

object DefaultServicesProvider {
  fun getInitialDefaultServices(): List<ServiceItem> = listOf(
    // 1. Saloon & Barber (سیلون و حجام)
    ServiceItem(
      id = 101L,
      name = "Special Hair Cut & Styling",
      urduName = "اسپیشل ہیئر کٹنگ و ہیئر اسٹائلنگ",
      businessCategory = "SALON",
      serviceType = "Hair Cut / بال کٹنگ",
      price = 500.0,
      isDiscountActive = true,
      discountPrice = 400.0,
      quantity = 1.0,
      unit = "Session (سیشن)",
      stockOrSlots = 100.0,
      icon = "💇‍♂️",
      description = "شیمپو، ہیئر کٹنگ، بلو ڈرائی اور پرفیکٹ اسٹائلنگ",
      isFeatured = true
    ),
    ServiceItem(
      id = 102L,
      name = "Beard Styling & Steam Shave",
      urduName = "شیو، خط و داڑھی ڈیزائننگ مع سٹیم",
      businessCategory = "SALON",
      serviceType = "Beard / شیو",
      price = 350.0,
      isDiscountActive = false,
      discountPrice = 250.0,
      quantity = 1.0,
      unit = "Session (سیشن)",
      stockOrSlots = 80.0,
      icon = "🧔",
      description = "ہاٹ ٹاول مساج، فوم شیو اور آفٹر شیو لوشن",
      isFeatured = true
    ),
    ServiceItem(
      id = 103L,
      name = "Whitening Hydra Facial & Scrub",
      urduName = "ہائیڈرا فیشل و اسکن پالش وائٹننگ",
      businessCategory = "SALON",
      serviceType = "Facial / فیشل",
      price = 3500.0,
      isDiscountActive = true,
      discountPrice = 2800.0,
      quantity = 1.0,
      unit = "Session (سیشن)",
      stockOrSlots = 40.0,
      icon = "✨",
      description = "6 اسٹیپ اوریجنل ہائیڈرا فیشل مع بلیک ہیڈ ریموول",
      isFeatured = true
    ),
    ServiceItem(
      id = 104L,
      name = "Hair Keratin & Color Treatment",
      urduName = "کیراٹین ٹریٹمنٹ و ہیئر کلرنگ",
      businessCategory = "SALON",
      serviceType = "Treatment / ٹریٹمنٹ",
      price = 6000.0,
      isDiscountActive = true,
      discountPrice = 4800.0,
      quantity = 1.0,
      unit = "Session (سیشن)",
      stockOrSlots = 20.0,
      icon = "💆‍♂️",
      description = "سیف امونیا فری کیراٹین اور پروٹین تھراپی"
    ),

    // 2. Gym & Fitness (جم و فٹنس سنٹر)
    ServiceItem(
      id = 201L,
      name = "Monthly Gym Membership",
      urduName = "ماہانہ جم فیس (فل باڈی ورک آؤٹ)",
      businessCategory = "GYM",
      serviceType = "Membership / ممبرشپ",
      price = 3000.0,
      isDiscountActive = true,
      discountPrice = 2500.0,
      quantity = 1.0,
      unit = "Month (ماہانہ)",
      stockOrSlots = 200.0,
      icon = "🏋️‍♂️",
      description = "کارڈیو، ویٹ ٹریننگ، شاور اور لکر کی مکمل سہولت"
    ),
    ServiceItem(
      id = 202L,
      name = "Certified Personal Trainer Package",
      urduName = "پرسنل ٹرینر سیشنز (1 ماہ باڈی بلڈنگ)",
      businessCategory = "GYM",
      serviceType = "Personal Training / ٹرینر",
      price = 8000.0,
      isDiscountActive = false,
      discountPrice = 6500.0,
      quantity = 1.0,
      unit = "Package (پیکیج)",
      stockOrSlots = 15.0,
      icon = "💪",
      description = "ون آن ون ٹریننگ اور ڈیلی ورک آؤٹ گائیڈنس"
    ),
    ServiceItem(
      id = 203L,
      name = "Customized Diet Plan & Weight Loss",
      urduName = "ڈائیٹ پلان و وزن کم کرنے کا چارٹ",
      businessCategory = "GYM",
      serviceType = "Diet / ڈائیٹ",
      price = 2000.0,
      isDiscountActive = true,
      discountPrice = 1400.0,
      quantity = 1.0,
      unit = "Plan (پلان)",
      stockOrSlots = 50.0,
      icon = "🥗",
      description = "کیلوری گنتی اور دیسی گھریلو کھانوں پر مشتمل پلان"
    ),

    // 3. Mobile Repairing & Lab (موبائل شاپ و ریپئرنگ)
    ServiceItem(
      id = 301L,
      name = "Mobile Display / OCA Glass Change",
      urduName = "موبائل او سی اے گلاس و ایل سی ڈی چینج",
      businessCategory = "MOBILE_REPAIR",
      serviceType = "Screen / اسکرین",
      price = 3500.0,
      isDiscountActive = true,
      discountPrice = 2900.0,
      quantity = 1.0,
      unit = "Job (جاب)",
      stockOrSlots = 60.0,
      icon = "📱",
      description = "لیزر مشین سے بغیر ڈسپلے خراب کیے اوریجنل گلاس فٹنگ"
    ),
    ServiceItem(
      id = 302L,
      name = "Original Battery Replacement",
      urduName = "اوریجنل بیٹری فٹنگ مع 6 ماہ وارنٹی",
      businessCategory = "MOBILE_REPAIR",
      serviceType = "Battery / بیٹری",
      price = 2200.0,
      isDiscountActive = false,
      discountPrice = 1800.0,
      quantity = 1.0,
      unit = "Piece (عدد)",
      stockOrSlots = 45.0,
      icon = "🔋",
      description = "100% ہیلتھ اوریجنل بیٹری مع فری فٹنگ"
    ),
    ServiceItem(
      id = 303L,
      name = "Charging Port & Mic IC Repair",
      urduName = "چارجنگ جیک، مائیک و اسپیکر ریپئر",
      businessCategory = "MOBILE_REPAIR",
      serviceType = "Hardware / ہارڈویئر",
      price = 1200.0,
      isDiscountActive = true,
      discountPrice = 900.0,
      quantity = 1.0,
      unit = "Job (جاب)",
      stockOrSlots = 100.0,
      icon = "🔌",
      description = "مائیکرو سولڈرنگ اور اوریجنل فلیکس کیبل"
    ),
    ServiceItem(
      id = 304L,
      name = "Software Flashing & FRP / Pattern Unlock",
      urduName = "سافٹ ویئر فلیشنگ، ایف آر پی و لاگ ان لاک",
      businessCategory = "MOBILE_REPAIR",
      serviceType = "Software / سافٹ ویئر",
      price = 1500.0,
      isDiscountActive = false,
      discountPrice = 1100.0,
      quantity = 1.0,
      unit = "Device (ڈیوائس)",
      stockOrSlots = 80.0,
      icon = "💻",
      description = "لیٹسٹ اینڈرائیڈ و آئی او ایس فلیشنگ اور ان لاکنگ"
    ),

    // 4. Laptop & Computer Repair (لیپ ٹاپ شاپ و ریپیئرنگ)
    ServiceItem(
      id = 401L,
      name = "Windows 11 / 10 Pro Setup & Drivers",
      urduName = "ونڈوز 11 و 10 انسٹالیشن مع ڈرائیورز",
      businessCategory = "LAPTOP_REPAIR",
      serviceType = "Windows / ونڈوز",
      price = 1000.0,
      isDiscountActive = true,
      discountPrice = 800.0,
      quantity = 1.0,
      unit = "Setup (سیٹ اپ)",
      stockOrSlots = 90.0,
      icon = "🖥️",
      description = "لائف ٹائم ایکٹیویٹڈ ونڈوز مع ایم ایس آفس و اینٹی وائرس"
    ),
    ServiceItem(
      id = 402L,
      name = "NVMe / SSD 256GB / 512GB Upgrade",
      urduName = "ایس ایس ڈی اپگریڈ و ڈیٹا ٹرانسفر",
      businessCategory = "LAPTOP_REPAIR",
      serviceType = "SSD Upgrade / اسٹوریج",
      price = 4500.0,
      isDiscountActive = true,
      discountPrice = 3800.0,
      quantity = 1.0,
      unit = "Piece (عدد)",
      stockOrSlots = 30.0,
      icon = "⚡",
      description = "سسٹم اسپیڈ 10 گنا تیز، مع برانڈڈ وارنٹی"
    ),
    ServiceItem(
      id = 403L,
      name = "Motherboard Chip-Level & Power Repair",
      urduName = "مدر بورڈ چپ لیول ریپئرنگ و شارٹج فالٹ",
      businessCategory = "LAPTOP_REPAIR",
      serviceType = "Motherboard / بورڈ",
      price = 5000.0,
      isDiscountActive = false,
      discountPrice = 4200.0,
      quantity = 1.0,
      unit = "Job (جاب)",
      stockOrSlots = 25.0,
      icon = "🔬",
      description = "نو پاور، نو ڈسپلے اور چارجنگ آئی سی ٹریسنگ"
    ),

    // 5. Car Showroom & Detailing (گاڑی شو روم و آٹو کیئر)
    ServiceItem(
      id = 501L,
      name = "9H Ceramic Coating & Paint Sealant",
      urduName = "9H سیرامک کوٹنگ مع پینٹ پروٹیکشن",
      businessCategory = "CAR_SHOWROOM",
      serviceType = "Detailing / ڈیٹیلنگ",
      price = 35000.0,
      isDiscountActive = true,
      discountPrice = 28000.0,
      quantity = 1.0,
      unit = "Vehicle (گاڑی)",
      stockOrSlots = 10.0,
      icon = "🚗",
      description = "3 سال کی چمک اور اسکریچ پروٹیکشن وارنٹی"
    ),
    ServiceItem(
      id = 502L,
      name = "Engine Oil Change & Complete Tuning",
      urduName = "انجن آئل چینج و کمپیوٹرائزڈ ٹیوننگ",
      businessCategory = "CAR_SHOWROOM",
      serviceType = "Maintenance / ٹیوننگ",
      price = 6500.0,
      isDiscountActive = true,
      discountPrice = 5500.0,
      quantity = 1.0,
      unit = "Service (سروس)",
      stockOrSlots = 50.0,
      icon = "🛢️",
      description = "اوریجنل آئل، آئل فلٹر، ایئر فلٹر اور پلگ صفائی"
    ),
    ServiceItem(
      id = 503L,
      name = "Full Interior Deep Cleaning & Steam Wash",
      urduName = "انٹیریئر ڈیپ واش، سیٹس و چھت کلیننگ",
      businessCategory = "CAR_SHOWROOM",
      serviceType = "Cleaning / صفائی",
      price = 8000.0,
      isDiscountActive = false,
      discountPrice = 6500.0,
      quantity = 1.0,
      unit = "Vehicle (گاڑی)",
      stockOrSlots = 25.0,
      icon = "🧽",
      description = "سیٹ کورز، کارپٹ اور ڈیش بورڈ پالش"
    ),

    // 6. Tailor & Cloth (درزی و کپڑا سلائی)
    ServiceItem(
      id = 601L,
      name = "Men's Suit Tailoring (سوٹ سلائی نارمل)",
      urduName = "کرتا شلوار و مردانہ سوٹ بہترین سلائی",
      businessCategory = "TAILOR",
      serviceType = "Stitching / سلائی",
      price = 1200.0,
      isDiscountActive = false,
      discountPrice = 1000.0,
      quantity = 1.0,
      unit = "Suit (سوٹ)",
      stockOrSlots = 150.0,
      icon = "🧵",
      description = "بکرم، دھاگہ، بٹن اور پریسنگ مع پیکنگ"
    ),
    ServiceItem(
      id = 602L,
      name = "Urgent 24-Hour Suit Stitching",
      urduName = "ارجنٹ 24 گھنٹے میں سوٹ سلائی",
      businessCategory = "TAILOR",
      serviceType = "Urgent / ارجنٹ",
      price = 1800.0,
      isDiscountActive = true,
      discountPrice = 1500.0,
      quantity = 1.0,
      unit = "Suit (سوٹ)",
      stockOrSlots = 30.0,
      icon = "⚡",
      description = "شادی و ایمرجنسی کیلئے ایک دن میں فراہمی"
    ),

    // 7. Fast Food & Pizza (فاسٹ فوڈ و ریسٹورنٹ)
    ServiceItem(
      id = 701L,
      name = "Large Special Stuffed Crust Pizza",
      urduName = "لارج اسپیشل چکن تکہ کرسٹ پیزا",
      businessCategory = "FAST_FOOD",
      serviceType = "Pizza / پیزا",
      price = 1800.0,
      isDiscountActive = true,
      discountPrice = 1499.0,
      quantity = 1.0,
      unit = "Deal (ڈیل)",
      stockOrSlots = 100.0,
      icon = "🍕",
      description = "چیز لوڈڈ، چکن چنکس، مشروم اور سپریم ساس"
    ),
    ServiceItem(
      id = 702L,
      name = "Double Zinger Combo with Fries & Drink",
      urduName = "ڈبل زنگر برگر کومبو مع فرائز و کولڈ ڈرنک",
      businessCategory = "FAST_FOOD",
      serviceType = "Burger / برگر",
      price = 850.0,
      isDiscountActive = true,
      discountPrice = 699.0,
      quantity = 1.0,
      unit = "Deal (ڈیل)",
      stockOrSlots = 120.0,
      icon = "🍔",
      description = "کرسپی چکن فلٹ، ساس اور لارج کولڈ ڈرنک"
    ),

    // 8. AC & Electronics Repair (اے سی و الیکٹرانکس)
    ServiceItem(
      id = 801L,
      name = "Inverter AC Chemical Jet Service",
      urduName = "انوائیٹر اے سی مکمل کیمیکل جیٹ سروس",
      businessCategory = "ELECTRONICS",
      serviceType = "AC Service / اے سی",
      price = 2500.0,
      isDiscountActive = true,
      discountPrice = 1999.0,
      quantity = 1.0,
      unit = "Unit (یونٹ)",
      stockOrSlots = 40.0,
      icon = "❄️",
      description = "ان ڈور اور آؤٹ ڈور پریشر پمپ واش و گیس چیک"
    ),

    // 9. Crockery & Event Rentals (کراکری و رینٹل)
    ServiceItem(
      id = 901L,
      name = "100-Person Crockery & Buffet Cutlery",
      urduName = "100 افراد کیلئے کراکری و بوفے سیٹ رینٹ",
      businessCategory = "CROCKERY",
      serviceType = "Rental / رینٹل",
      price = 8000.0,
      isDiscountActive = true,
      discountPrice = 6500.0,
      quantity = 1.0,
      unit = "Event (تقریب)",
      stockOrSlots = 15.0,
      icon = "🍽️",
      description = "پلیٹس، ڈونگے، چمچ، گلاس اور سروینگ ٹرے"
    )
  )
}
