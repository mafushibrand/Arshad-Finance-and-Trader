package com.example.data.model

data class BusinessFeatures(
  val products: Boolean = true,
  val services: Boolean = true,
  val pos: Boolean = true,
  val khata: Boolean = true,
  val purchases: Boolean = true,
  val expenses: Boolean = true,
  val reports: Boolean = true,
  val onlinePayments: Boolean = true,
  val manufacturing: Boolean = true,
  val rentals: Boolean = true,
  val appointments: Boolean = true
)
