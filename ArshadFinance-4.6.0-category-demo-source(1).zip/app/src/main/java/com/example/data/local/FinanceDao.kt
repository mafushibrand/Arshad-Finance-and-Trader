package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Account
import com.example.data.model.Bill
import com.example.data.model.Budget
import com.example.data.model.Customer
import com.example.data.model.InventoryItem
import com.example.data.model.Invoice
import com.example.data.model.RecurringTransaction
import com.example.data.model.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface FinanceDao {
  // Inventory Items
  @Query("SELECT * FROM inventory_items ORDER BY name ASC")
  fun getAllInventoryItems(): Flow<List<InventoryItem>>

  @Query("SELECT * FROM inventory_items WHERE id = :id LIMIT 1")
  suspend fun getInventoryItemById(id: Long): InventoryItem?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInventoryItem(item: InventoryItem): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInventoryItems(items: List<InventoryItem>)

  @Update
  suspend fun updateInventoryItem(item: InventoryItem)

  @Delete
  suspend fun deleteInventoryItem(item: InventoryItem)

  @Query("UPDATE inventory_items SET currentStock = currentStock - :quantity, lastUpdatedMillis = :now WHERE id = :id")
  suspend fun deductInventoryStock(id: Long, quantity: Double, now: Long = System.currentTimeMillis())

  @Query("UPDATE inventory_items SET currentStock = currentStock + :quantity, lastUpdatedMillis = :now WHERE id = :id")
  suspend fun addInventoryStock(id: Long, quantity: Double, now: Long = System.currentTimeMillis())

  @Query("SELECT COUNT(*) FROM inventory_items")
  suspend fun getInventoryCount(): Int

  @Query("DELETE FROM inventory_items")
  suspend fun deleteAllInventoryItems()

  // Transactions
  @Query("SELECT * FROM transactions ORDER BY dateMillis DESC")
  fun getAllTransactions(): Flow<List<Transaction>>

  @Query("SELECT * FROM transactions WHERE category = :category ORDER BY dateMillis DESC")
  fun getTransactionsByCategory(category: String): Flow<List<Transaction>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTransaction(transaction: Transaction): Long

  @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
  suspend fun getTransactionById(id: Long): Transaction?

  @Query("SELECT * FROM transactions WHERE transactionRef = :reference")
  suspend fun getTransactionsByReference(reference: String): List<Transaction>

  @Query("SELECT * FROM transactions WHERE transactionRef = :reference OR transactionRef LIKE :collectionPrefix")
  suspend fun getInvoicePostings(reference: String, collectionPrefix: String): List<Transaction>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTransactions(transactions: List<Transaction>)

  @Update
  suspend fun updateTransaction(transaction: Transaction)

  @Delete
  suspend fun deleteTransaction(transaction: Transaction)

  // Accounts
  @Query("SELECT * FROM accounts ORDER BY id ASC")
  fun getAllAccounts(): Flow<List<Account>>

  @Query("SELECT * FROM accounts")
  suspend fun getAllAccountsList(): List<Account>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAccount(account: Account): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAccounts(accounts: List<Account>)

  @Update
  suspend fun updateAccount(account: Account)

  @Query("UPDATE accounts SET balance = balance + :delta WHERE id = :id")
  suspend fun changeAccountBalance(id: Long, delta: Double)

  @Delete
  suspend fun deleteAccount(account: Account)

  // Bills
  @Query("SELECT * FROM bills ORDER BY id ASC")
  fun getAllBills(): Flow<List<Bill>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBill(bill: Bill): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBills(bills: List<Bill>)

  @Update
  suspend fun updateBill(bill: Bill)

  @Delete
  suspend fun deleteBill(bill: Bill)

  // Budgets
  @Query("SELECT * FROM budgets ORDER BY id ASC")
  fun getAllBudgets(): Flow<List<Budget>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBudget(budget: Budget): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBudgets(budgets: List<Budget>)

  @Update
  suspend fun updateBudget(budget: Budget)

  @Delete
  suspend fun deleteBudget(budget: Budget)

  // Recurring Transactions
  @Query("SELECT * FROM recurring_transactions ORDER BY nextExecutionDateMillis ASC")
  fun getAllRecurringTransactions(): Flow<List<RecurringTransaction>>

  @Query("SELECT * FROM recurring_transactions WHERE isActive = 1")
  suspend fun getActiveRecurringTransactionsList(): List<RecurringTransaction>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRecurringTransaction(recurringTransaction: RecurringTransaction): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRecurringTransactions(recurringTransactions: List<RecurringTransaction>)

  @Update
  suspend fun updateRecurringTransaction(recurringTransaction: RecurringTransaction)

  @Delete
  suspend fun deleteRecurringTransaction(recurringTransaction: RecurringTransaction)

  @Query("SELECT COUNT(*) FROM accounts")
  suspend fun getAccountCount(): Int

  @Query("SELECT COUNT(*) FROM transactions")
  suspend fun getTransactionCount(): Int

  @Query("SELECT COUNT(*) FROM budgets")
  suspend fun getBudgetCount(): Int

  @Query("SELECT COUNT(*) FROM recurring_transactions")
  suspend fun getRecurringCount(): Int

  @Query("SELECT COUNT(*) FROM bills")
  suspend fun getBillCount(): Int

  @Query("DELETE FROM transactions")
  suspend fun deleteAllTransactions()

  @Query("DELETE FROM accounts")
  suspend fun deleteAllAccounts()

  @Query("DELETE FROM bills")
  suspend fun deleteAllBills()

  @Query("DELETE FROM budgets")
  suspend fun deleteAllBudgets()

  @Query("DELETE FROM recurring_transactions")
  suspend fun deleteAllRecurringTransactions()

  // Customers
  @Query("SELECT * FROM customers ORDER BY lastInteractionMillis DESC")
  fun getAllCustomers(): Flow<List<Customer>>

  @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
  suspend fun getCustomerById(id: Long): Customer?

  @Query("SELECT * FROM customers WHERE name = :name LIMIT 1")
  suspend fun getCustomerByName(name: String): Customer?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCustomer(customer: Customer): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCustomers(customers: List<Customer>)

  @Update
  suspend fun updateCustomer(customer: Customer)

  @Delete
  suspend fun deleteCustomer(customer: Customer)

  @Query("UPDATE customers SET totalBilled = totalBilled + :billedAmount, totalPaid = totalPaid + :paidAmount, currentBalance = currentBalance + :balanceDelta, lastInteractionMillis = :now WHERE id = :id")
  suspend fun updateCustomerFinancials(id: Long, billedAmount: Double, paidAmount: Double, balanceDelta: Double, now: Long = System.currentTimeMillis())

  @Query("SELECT COUNT(*) FROM customers")
  suspend fun getCustomerCount(): Int

  @Query("DELETE FROM customers")
  suspend fun deleteAllCustomers()

  // Invoices / Bills
  @Query("SELECT * FROM invoices ORDER BY dateMillis DESC")
  fun getAllInvoices(): Flow<List<Invoice>>

  @Query("SELECT * FROM invoices WHERE customerId = :customerId ORDER BY dateMillis DESC")
  fun getInvoicesForCustomer(customerId: Long): Flow<List<Invoice>>

  @Query("SELECT * FROM invoices WHERE customerName = :customerName ORDER BY dateMillis DESC")
  fun getInvoicesForCustomerName(customerName: String): Flow<List<Invoice>>

  @Query("SELECT * FROM invoices WHERE id = :id LIMIT 1")
  suspend fun getInvoiceById(id: Long): Invoice?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInvoice(invoice: Invoice): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInvoices(invoices: List<Invoice>)

  @Update
  suspend fun updateInvoice(invoice: Invoice)

  @Delete
  suspend fun deleteInvoice(invoice: Invoice)

  @Query("SELECT COUNT(*) FROM invoices")
  suspend fun getInvoiceCount(): Int

  @Query("DELETE FROM invoices")
  suspend fun deleteAllInvoices()
}
