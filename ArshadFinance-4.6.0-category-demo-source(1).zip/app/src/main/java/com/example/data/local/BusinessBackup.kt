package com.example.data.local

import android.content.Context
import androidx.room.withTransaction
import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.first
import java.io.File
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Portable encrypted snapshot. No raw copying of an open SQLite/WAL database. */
data class BusinessBackupData(
  val format: Int = 1, val schema: Int = 8,
  val transactions: List<Transaction>, val accounts: List<Account>, val bills: List<Bill>,
  val budgets: List<Budget>, val recurring: List<RecurringTransaction>, val products: List<InventoryItem>,
  val customers: List<Customer>, val invoices: List<Invoice>, val preferences: Map<String, String>,
  val receipts: Map<String, String> = emptyMap(),
  val businessRecords: List<com.example.business.BusinessRecord> = emptyList(),
  val stockMovements: List<com.example.business.StockMovement> = emptyList()
)

object BusinessBackup {
  private val json = Moshi.Builder().add(KotlinJsonAdapterFactory()).build().adapter(BusinessBackupData::class.java)
  private val magic = "ARSHAD-BACKUP-1\n".toByteArray()
  private fun key(password: CharArray, salt: ByteArray): SecretKeySpec {
    val spec = PBEKeySpec(password, salt, 120000, 256)
    try { return SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded, "AES") }
    finally { spec.clearPassword() }
  }
  fun encrypt(snapshot: BusinessBackupData, password: CharArray): ByteArray {
    require(password.size >= 8) { "Use at least 8 password characters / پاسورڈ کم از کم ۸ حروف کا ہو" }
    val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
    val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv)); cipher.updateAAD(magic)
    return magic + salt + iv + cipher.doFinal(json.toJson(snapshot).toByteArray(Charsets.UTF_8))
  }
  fun decrypt(bytes: ByteArray, password: CharArray): BusinessBackupData {
    require(bytes.size > magic.size + 44 && bytes.size <= 100 * 1024 * 1024) { "Invalid backup size" }
    require(bytes.take(magic.size).toByteArray().contentEquals(magic)) { "Not an Arshad Finance backup" }
    val salt = bytes.copyOfRange(magic.size, magic.size + 16)
    val iv = bytes.copyOfRange(magic.size + 16, magic.size + 28)
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv)); cipher.updateAAD(magic)
    val snapshot = json.fromJson(cipher.doFinal(bytes.copyOfRange(magic.size + 28, bytes.size)).toString(Charsets.UTF_8)) ?: error("Invalid backup")
    validate(snapshot)
    return snapshot
  }
  private fun validate(s: BusinessBackupData) {
    require(s.format == 1 && s.schema in 6..8) { "Unsupported backup version" }
    fun ids(values: List<Long>) { require(values.all { it > 0 } && values.distinct().size == values.size) { "Invalid duplicate record IDs" } }
    ids(s.accounts.map { it.id }); ids(s.products.map { it.id }); ids(s.customers.map { it.id }); ids(s.invoices.map { it.id }); ids(s.transactions.map { it.id }); ids(s.bills.map { it.id }); ids(s.budgets.map { it.id }); ids(s.recurring.map { it.id })
    require(s.accounts.all { it.balance.isFinite() } && s.products.all { it.currentStock.isFinite() && it.costPrice.isFinite() && it.salePrice.isFinite() })
    require(s.transactions.all { it.amount.isFinite() && it.amount >= 0 } && s.invoices.all { it.grandTotal.isFinite() && it.grandTotal >= 0 && it.amountPaid.isFinite() && it.amountPaid >= 0 && it.amountPaid <= it.grandTotal })
    require(s.invoices.all { it.customerId <= 0 || s.customers.any { c -> c.id == it.customerId } }) { "Missing customer records" }
    require(s.businessRecords.map { it.id }.distinct().size == s.businessRecords.size && s.businessRecords.all { it.amount.isFinite() && it.amount >= 0 })
    require(s.stockMovements.map { it.id }.distinct().size == s.stockMovements.size && s.stockMovements.all { it.quantity.isFinite() })
    s.businessRecords.forEach { org.json.JSONObject(it.payload) }
    s.products.forEach { org.json.JSONObject(it.detailsJson) }
    s.customers.forEach { org.json.JSONObject(it.detailsJson) }
    s.invoices.forEach { org.json.JSONObject(it.detailsJson) }
    val configuration = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    val expected = mapOf("profile" to com.example.util.BusinessProfile::class.java, "features" to BusinessFeatures::class.java,
      "language" to AppLanguage::class.java, "mode" to AppMode::class.java, "user" to UserAccount::class.java,
      "permissions" to EmployeePermissions::class.java, "subscription" to SubscriptionState::class.java, "bio" to ShopBioData::class.java,
      "currency" to String::class.java)
    expected.forEach { (key, type) -> s.preferences[key]?.let { require(configuration.adapter(type).fromJson(it) != null) { "Invalid setting: $key" } } }
    s.preferences["services"]?.let { require(configuration.adapter<List<ServiceItem>>(com.squareup.moshi.Types.newParameterizedType(List::class.java, ServiceItem::class.java)).fromJson(it) != null) }
    val raw = org.json.JSONObject()
    s.preferences.forEach { (k, v) -> require(k.length < 200); org.json.JSONTokener(v).nextValue(); raw.put(k, v) }
    require(s.receipts.keys.all { File(it).name == it && !it.contains("..") }) { "Invalid receipt path" }
    require(s.receipts.values.sumOf { it.length.toLong() } < 90 * 1024 * 1024) { "Receipts too large" }
  }
  suspend fun snapshot(context: Context, db: FinanceDatabase): BusinessBackupData = db.withTransaction {
    val dao = db.financeDao()
    val receiptDir = File(context.filesDir, "payment-receipts")
    val receipts = receiptDir.listFiles()?.filter { it.isFile }?.associate { file ->
      require(file.length() <= 10 * 1024 * 1024) { "Receipt too large" }
      file.name to android.util.Base64.encodeToString(file.readBytes(), android.util.Base64.NO_WRAP)
    } ?: emptyMap()
    BusinessBackupData(transactions = dao.getAllTransactions().first(), accounts = dao.getAllAccounts().first(), bills = dao.getAllBills().first(),
      budgets = dao.getAllBudgets().first(), recurring = dao.getAllRecurringTransactions().first(), products = dao.getAllInventoryItems().first(),
      customers = dao.getAllCustomers().first(), invoices = dao.getAllInvoices().first(), preferences = BusinessPreferences(context).exportRaw(), receipts = receipts, businessRecords = db.businessDao().allRecords(), stockMovements = db.businessDao().allMovements())
  }
  suspend fun restore(context: Context, db: FinanceDatabase, snapshot: BusinessBackupData) {
    validate(snapshot)
    val prefs = BusinessPreferences(context)
    val previous = prefs.exportRaw()
    val restored = snapshot.preferences.toMutableMap()
    val directory = File(context.filesDir, "payment-receipts").apply { mkdirs() }
    snapshot.receipts.forEach { (name, base64) ->
      val newFile = File(directory, "restored-${java.util.UUID.randomUUID()}-$name")
      newFile.writeBytes(android.util.Base64.decode(base64, android.util.Base64.NO_WRAP))
      restored.keys.toList().forEach { k -> if (k.startsWith("receipt/") && restored[k]?.contains(name) == true) restored[k] = org.json.JSONObject.quote(android.net.Uri.fromFile(newFile).toString()) }
    }
    try {
      db.withTransaction {
        val dao = db.financeDao()
        db.businessDao().context(com.example.business.StockContext())
        db.businessDao().clearRecords(); db.businessDao().clearMovements()
        dao.deleteAllInvoices(); dao.deleteAllTransactions(); dao.deleteAllInventoryItems(); dao.deleteAllCustomers()
        dao.deleteAllAccounts(); dao.deleteAllBills(); dao.deleteAllBudgets(); dao.deleteAllRecurringTransactions()
        dao.insertAccounts(snapshot.accounts); dao.insertInventoryItems(snapshot.products); dao.insertCustomers(snapshot.customers)
        dao.insertInvoices(snapshot.invoices); dao.insertTransactions(snapshot.transactions); dao.insertBills(snapshot.bills)
        dao.insertBudgets(snapshot.budgets); dao.insertRecurringTransactions(snapshot.recurring)
        db.businessDao().insertRecords(snapshot.businessRecords)
        if (snapshot.stockMovements.isNotEmpty()) { db.businessDao().clearMovements(); db.businessDao().insertMovements(snapshot.stockMovements) }
        if(snapshot.schema<8) snapshot.customers.forEach {customer ->
          val existing=com.example.business.CustomerLedger.balance(db,customer.id)
          com.example.business.CustomerLedger.post(db,customer.id,customer.currentBalance-existing,"Restored opening balance","restore")
        }
        prefs.replaceRaw(restored)
      }
    } catch (error: Exception) { prefs.replaceRaw(previous); throw error }
  }
}
