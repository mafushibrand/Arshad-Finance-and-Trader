package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "inventory_items")
data class InventoryItem(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,
  val name: String,
  val category: String = "General",
  val icon: String = "📦",
  val costPrice: Double = 0.0,      // Purchase / Khareed price
  val salePrice: Double = 0.0,      // Selling / Farokht price
  val currentStock: Double = 0.0,   // Available quantity
  val unit: String = "Piece",       // Piece, Kg, Packet, Box, Liter, Meter
  val lowStockThreshold: Double = 5.0, // Alert threshold
  val barcode: String = "",         // Barcode / SKU
  val supplierName: String = "",    // Supplier / Company
  val lastUpdatedMillis: Long = System.currentTimeMillis(),
  val note: String = "",
  @androidx.room.ColumnInfo(defaultValue = "'{}'") val detailsJson: String = "{}"
)
