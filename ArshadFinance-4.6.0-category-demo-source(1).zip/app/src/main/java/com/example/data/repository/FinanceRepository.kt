package com.example.data.repository

import androidx.room.withTransaction

import com.example.data.local.FinanceDao
import com.example.data.model.Account
import com.example.data.model.Bill
import com.example.data.model.Budget
import com.example.data.model.Customer
import com.example.data.model.InventoryItem
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItemEntry
import com.example.data.model.RecurringTransaction
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class FinanceRepository(private val dao: FinanceDao, private val database: com.example.data.local.FinanceDatabase) {
  val allTransactions: Flow<List<Transaction>> = dao.getAllTransactions()
  val allAccounts: Flow<List<Account>> = dao.getAllAccounts()
  val allBills: Flow<List<Bill>> = dao.getAllBills()
  val allBudgets: Flow<List<Budget>> = dao.getAllBudgets()
  val allRecurringTransactions: Flow<List<RecurringTransaction>> = dao.getAllRecurringTransactions()
  val allInventoryItems: Flow<List<InventoryItem>> = dao.getAllInventoryItems()
  val allCustomers: Flow<List<Customer>> = dao.getAllCustomers()
  val allInvoices: Flow<List<Invoice>> = dao.getAllInvoices()

  suspend fun saveCustomerAtomically(customer:Customer):Customer=database.withTransaction {
    require(customer.name.isNotBlank()) {"Enter a customer name / گاہک کا نام درج کریں"}
    val metadata=org.json.JSONObject(customer.detailsJson);val credit=metadata.optDouble("creditLimit",0.0)
    require(credit.isFinite()&&credit>=0) {"Invalid credit limit / ادھار کی حد درست درج کریں"}
    val existing=dao.getAllCustomers().first()
    require(existing.none {it.id!=customer.id && (it.name.trim().equals(customer.name.trim(),true) || customer.phone.isNotBlank()&&it.phone.filter(Char::isDigit)==customer.phone.filter(Char::isDigit))}) {"Customer name or phone already exists / نام یا نمبر پہلے موجود ہے"}
    val previous=if(customer.id>0) dao.getCustomerById(customer.id) ?: error("Customer missing") else null
    val opening=metadata.optDouble("openingBalance",0.0);val oldOpening=previous?.let {org.json.JSONObject(it.detailsJson).optDouble("openingBalance",0.0)} ?: 0.0
    require(opening.isFinite()) {"Invalid opening balance / ابتدائی بقایا درست درج کریں"}
    val delta=opening-oldOpening
    val updated=customer.copy(name=customer.name.trim(),totalBilled=previous?.totalBilled ?: 0.0,totalPaid=previous?.totalPaid ?: 0.0,currentBalance=(previous?.currentBalance ?: 0.0)+delta,lastInteractionMillis=System.currentTimeMillis())
    val id=if(previous==null) dao.insertCustomer(updated) else {dao.updateCustomer(updated);updated.id}
    com.example.business.CustomerLedger.post(database,id,delta,"Opening balance adjustment")
    database.businessDao().insert(com.example.business.BusinessRecord(kind="AUDIT",title="CUSTOMER_SAVED",party=id.toString(),status="POSTED"))
    updated.copy(id=id)
  }

  suspend fun receiveCustomerCashAtomically(customerId: Long, amount: Double, note: String): Customer = database.withTransaction {
    require(amount.isFinite() && amount > 0) { "Enter a positive amount / درست رقم درج کریں" }
    val customer = dao.getCustomerById(customerId) ?: error("Customer no longer exists / گاہک موجود نہیں")
    require(amount <= customer.currentBalance + 0.000001) { "Amount exceeds customer balance / رقم بقایا سے زیادہ ہے" }
    val invoices = dao.getAllInvoices().first().filter { it.customerId == customerId && it.remainingBalance > 0 && it.paymentStatus != "PENDING_APPROVAL" }.sortedBy { it.dateMillis }
    require(dao.getAllInvoices().first().none { it.customerId==customerId && it.paymentStatus=="PENDING_APPROVAL" }) { "Review pending payment receipts first / پہلے زیر التوا رسید کی تصدیق کریں" }
    val account = dao.getAllAccountsList().firstOrNull { it.accountType.contains("Cash", true) }
      ?: dao.getAllAccountsList().firstOrNull() ?: error("Create a cash account first")
    var remaining = amount
    val now = System.currentTimeMillis()
    invoices.forEach { invoice ->
      if (remaining > 0.000001) {
        val received = minOf(remaining, invoice.remainingBalance)
        val allocations = if (invoice.paymentMethod.startsWith("Split [")) invoice.paymentMethod.substringAfter('[').substringBefore(']').split(';').mapNotNull { part ->
          val pair = part.split('=', limit = 2); if (pair.size == 2) pair[1].toDoubleOrNull()?.let { pair[0] to it } else null
        }.toMap().toMutableMap() else mutableMapOf(invoice.paymentMethod.substringBefore(" (") to invoice.amountPaid)
        allocations["Cash"] = (allocations["Cash"] ?: 0.0) + received
        val paid = invoice.amountPaid + received
        val balance = (invoice.grandTotal - org.json.JSONObject(invoice.detailsJson).optDouble("returnedTotal",0.0) - paid).coerceAtLeast(0.0)
        dao.updateInvoice(invoice.copy(amountPaid = paid, remainingBalance = balance, paymentStatus = if (balance <= 0.000001) "PAID" else "PARTIAL",
          paymentMethod = "Split [" + allocations.filterValues { it > 0.0 }.entries.joinToString(";") { "${it.key}=${it.value}" } + "]"))
        dao.insertTransaction(Transaction(title = "Khata receipt: ${customer.name}", amount = received, type = TransactionType.INCOME,
          category = "Khata Receipt", icon = "💵", accountName = account.name, dateMillis = now, note = note,
          transactionRef = "COLLECT/BILL/${invoice.id}/${java.util.UUID.randomUUID()}"))
        remaining -= received
      }
    }
    if(remaining>0.000001) dao.insertTransaction(Transaction(title="Opening balance receipt: ${customer.name}",amount=remaining,type=TransactionType.INCOME,category="Khata Receipt",icon="💵",accountName=account.name,note=note,transactionRef="DOC/OPENING/${java.util.UUID.randomUUID()}"))
    com.example.business.CustomerLedger.post(database,customerId,-amount,"Khata collection")
    dao.changeAccountBalance(account.id, amount)
    dao.updateCustomerFinancials(customerId, 0.0, amount, -amount)
    dao.getCustomerById(customerId) ?: error("Customer update failed")
  }

  suspend fun purchaseStockAtomically(itemId: Long, quantity: Double, costPrice: Double?) = database.withTransaction {
    require(quantity.isFinite() && quantity > 0) { "Enter a positive quantity / درست مقدار درج کریں" }
    require(costPrice == null || (costPrice.isFinite() && costPrice >= 0)) { "Invalid purchase price / خرید قیمت درست نہیں" }
    val item = dao.getInventoryItemById(itemId) ?: error("Product no longer exists / سامان موجود نہیں")
    val cost = costPrice ?: item.costPrice
    val total = if (costPrice != null) cost * quantity else 0.0
    require(total.isFinite() && (item.currentStock+quantity).isFinite()) { "Quantity or total is too large / مقدار یا رقم بہت زیادہ ہے" }
    val averageCost = if(costPrice!=null && item.currentStock+quantity>0) (item.currentStock*item.costPrice+quantity*cost)/(item.currentStock+quantity) else item.costPrice
    require(averageCost.isFinite())
    val account = if (total > 0) dao.getAllAccountsList().firstOrNull { it.accountType.contains("Cash", true) }
      ?: dao.getAllAccountsList().firstOrNull() ?: error("Create a cash account first / پہلے کیش اکاؤنٹ بنائیں") else null
    dao.updateInventoryItem(item.copy(currentStock = item.currentStock + quantity, costPrice = averageCost, lastUpdatedMillis = System.currentTimeMillis()))
    if (account != null) {
      dao.changeAccountBalance(account.id, -total)
      dao.insertTransaction(Transaction(title = "Stock Purchase: ${item.name}", amount = total, type = TransactionType.EXPENSE,
        category = "Inventory / Stock", icon = item.icon, accountName = account.name, dateMillis = System.currentTimeMillis(),
        note = "$quantity ${item.unit} @ $cost", transactionRef = "PURCHASE/${System.currentTimeMillis()}/$itemId"))
    }
  }

  fun getInvoicesForCustomer(customerId: Long): Flow<List<Invoice>> {
    return dao.getInvoicesForCustomer(customerId)
  }

  /** Invoice, stock, customer khata and wallet posting succeed or roll back together. */
  suspend fun saveInvoiceAtomically(invoice: Invoice, items: List<InvoiceItemEntry>, syncStock: Boolean, pendingCash: Double = 0.0, existingRentalDepositId: String = ""): Invoice = database.withTransaction {
    require(items.isNotEmpty()) { "Add a product or service / پروڈکٹ یا سروس شامل کریں" }
    require(listOf(invoice.grandTotal, invoice.amountPaid, invoice.discountAmount, invoice.taxAmount).all { it.isFinite() && it >= 0.0 }) {
      "Invalid bill amount / بل کی رقم درست نہیں"
    }
    require(invoice.amountPaid <= invoice.grandTotal) { "Payment exceeds bill total / ادائیگی بل سے زیادہ ہے" }
    require(items.all { it.quantity.isFinite() && it.quantity > 0.0 && it.unitPrice.isFinite() && it.unitPrice >= 0.0 }) {
      "Invalid quantity or price / مقدار یا قیمت درست نہیں"
    }
    val old = if (invoice.id > 0L) dao.getInvoiceById(invoice.id) else null
    require(invoice.id == 0L || old != null) { "Bill no longer exists / بل موجود نہیں" }
    require(database.businessDao().allRecords().none { it.kind=="SALES_RETURN" && org.json.JSONObject(it.payload).optLong("invoiceId")==invoice.id && invoice.id>0 }) { "A returned invoice cannot be edited; issue a new invoice / واپسی والے بل کو تبدیل نہ کریں" }
    require(old == null || org.json.JSONObject(old.detailsJson).optString("rentalId").isBlank()) { "Rental settlement invoices are immutable / کرایہ تصفیہ کا بل تبدیل نہیں ہو سکتا" }
    if (existingRentalDepositId.isNotBlank()) {
      val rental=database.businessDao().record(existingRentalDepositId) ?: error("Rental deposit missing")
      val data=org.json.JSONObject(rental.payload)
      require(old==null && rental.kind=="RENTAL_CONTRACT" && rental.status=="ACTIVE" && data.getLong("customerId")==invoice.customerId && invoice.paymentStatus!="PENDING_APPROVAL" && invoice.amountPaid<=data.getDouble("deposit") && org.json.JSONObject(invoice.detailsJson).optString("rentalId")==rental.id)
      require(database.businessDao().allRecords().none {it.kind=="RENTAL_DEPOSIT_APPLIED"&&it.party==rental.id}) { "Deposit already settled / ڈپازٹ پہلے استعمال ہو چکا ہے" }
    } else require(org.json.JSONObject(invoice.detailsJson).optString("rentalId").isBlank()) { "Use the rental return workflow / کرایہ واپسی کا طریقہ استعمال کریں" }
    if (old != null) {
      com.example.business.CustomerLedger.post(database,old.customerId,-old.remainingBalance,"Invoice edit reversal: ${old.invoiceNumber}")
      restoreInvoiceStock(old)
      if (old.customerId > 0L) dao.updateCustomerFinancials(old.customerId, -old.grandTotal, -old.amountPaid, -old.remainingBalance)
      removeInvoicePostings(old)
    }
    val metadata=org.json.JSONObject(invoice.detailsJson)
    val branch=metadata.optString("branch","main").ifBlank {"main"};val warehouse=metadata.optString("warehouse","main").ifBlank {"main"}
    val stockItems = items.filter { !it.isService && it.itemId != null }.groupBy { it.itemId!! }
    if (syncStock) stockItems.forEach { (id, entries) ->
      val item = dao.getInventoryItemById(id) ?: error("Product was removed / پروڈکٹ موجود نہیں")
      com.example.business.ItemRules.validateSale(item,entries.sumOf {it.quantity})
      val location = database.businessDao().allMovements()
      val available = if(location.isEmpty())item.currentStock else database.businessDao().locationStock(id,branch,warehouse)
      require(item.currentStock + 0.000001 >= entries.sumOf { it.quantity } && available + 0.000001 >= entries.sumOf {it.quantity}) {
        "Insufficient stock: ${item.name} / اسٹاک ناکافی ہے"
      }
    }
    val now = System.currentTimeMillis()
    var customerId = invoice.customerId
    if (customerId > 0L) require(dao.getCustomerById(customerId) != null) { "Customer no longer exists / گاہک موجود نہیں" }
    if (customerId <= 0L && invoice.customerName.isNotBlank()) {
      customerId = dao.getCustomerByName(invoice.customerName.trim())?.id ?: dao.insertCustomer(Customer(
        name = invoice.customerName.trim(), phone = invoice.customerPhone.trim(), address = invoice.customerAddress.trim(),
        createdDateMillis = now, lastInteractionMillis = now
      ))
    }
    val lineCosts=org.json.JSONArray()
    for(line in items)lineCosts.put(if(line.isService)0.0 else line.itemId?.let {dao.getInventoryItemById(it)?.costPrice} ?: 0.0)
    val capturedMetadata=org.json.JSONObject(invoice.detailsJson).put("lineCosts",lineCosts).toString()
    val pending = invoice.paymentStatus == "PENDING_APPROVAL"
    val paid = if (pending) pendingCash else invoice.amountPaid
    require(paid.isFinite() && paid >= 0.0 && paid <= invoice.grandTotal) { "Invalid confirmed payment" }
    val remaining = invoice.grandTotal - paid
    var saved = invoice.copy(customerId = customerId, itemsJson = InvoiceItemEntry.toJsonString(items),
      detailsJson=capturedMetadata, syncWithInventory = syncStock, amountPaid = paid, remainingBalance = remaining,
      paymentStatus = if (pending) "PENDING_APPROVAL" else if (remaining <= 0.0) "PAID" else if (paid > 0.0) "PARTIAL" else "UNPAID / UDHAR")
    if (old == null) saved = saved.copy(id = dao.insertInvoice(saved)) else dao.updateInvoice(saved)
    if (customerId > 0L) {
      val customer=dao.getCustomerById(customerId)!!
      val limit=org.json.JSONObject(customer.detailsJson).optDouble("creditLimit",0.0)
      require(limit<=0 || customer.currentBalance+remaining<=limit+0.000001) { "Customer credit limit exceeded / گاہک کی کریڈٹ حد سے زیادہ ہے" }
      dao.updateCustomerFinancials(customerId, saved.grandTotal, paid, remaining)
      com.example.business.CustomerLedger.post(database,customerId,saved.grandTotal,"Invoice: ${saved.invoiceNumber}")
      com.example.business.CustomerLedger.post(database,customerId,-paid,"Invoice payment: ${saved.invoiceNumber}")
    }
    database.businessDao().insert(com.example.business.BusinessRecord(kind="AUDIT",title=if(old==null)"INVOICE_CREATED" else "INVOICE_UPDATED",party=saved.invoiceNumber,status="RECORDED"))
    if (syncStock) {
      val context=database.businessDao().context() ?: com.example.business.StockContext()
      database.businessDao().context(com.example.business.StockContext(reason="SALE",documentId=saved.id.toString(),createdBy="owner",branchId=branch,warehouseId=warehouse))
      try {stockItems.forEach { (id, entries) -> dao.deductInventoryStock(id, entries.sumOf { it.quantity }) }} finally {database.businessDao().context(context)}
    }
    if(existingRentalDepositId.isBlank()) postInvoicePayment(saved) else database.businessDao().insert(com.example.business.BusinessRecord(kind="RENTAL_DEPOSIT_APPLIED",title=saved.invoiceNumber,party=existingRentalDepositId,amount=paid,status="POSTED"))
    saved
  }

  suspend fun deleteInvoiceAtomically(id: Long) = database.withTransaction {
    val invoice = dao.getInvoiceById(id) ?: return@withTransaction
    require(org.json.JSONObject(invoice.detailsJson).optString("rentalId").isBlank()) { "Rental settlement invoices must remain for audit / کرایہ تصفیہ کا بل محفوظ رہے گا" }
    require(database.businessDao().allRecords().none {it.kind=="SALES_RETURN" && org.json.JSONObject(it.payload).optLong("invoiceId")==id}) { "Returned invoices must remain for audit / واپسی والا بل محفوظ رہے گا" }
    com.example.business.CustomerLedger.post(database,invoice.customerId,-invoice.remainingBalance,"Invoice deletion reversal: ${invoice.invoiceNumber}")
    restoreInvoiceStock(invoice)
    removeInvoicePostings(invoice)
    if (invoice.customerId > 0L) dao.updateCustomerFinancials(invoice.customerId, -invoice.grandTotal, -invoice.amountPaid, -invoice.remainingBalance)
    dao.deleteInvoice(invoice)
  }

  suspend fun decidePendingPayment(id: Long, approved: Boolean, claimedPaid: Double? = null): Invoice? = database.withTransaction {
    val invoice = dao.getInvoiceById(id) ?: return@withTransaction null
    if (invoice.paymentStatus != "PENDING_APPROVAL") return@withTransaction invoice
    removeInvoicePostings(invoice)
    val paid = if (approved) (claimedPaid ?: invoice.grandTotal) else invoice.amountPaid
    require(paid.isFinite() && paid >= invoice.amountPaid && paid <= invoice.grandTotal) { "Invalid receipt amount" }
    val remaining = invoice.grandTotal - paid
    val updated = invoice.copy(amountPaid = paid, remainingBalance = remaining,
      paymentStatus = if (remaining <= 0.0) "PAID" else if (paid > 0.0) "PARTIAL" else "UNPAID / UDHAR")
    dao.updateInvoice(updated)
    if (invoice.customerId > 0L) dao.updateCustomerFinancials(invoice.customerId, 0.0, paid - invoice.amountPaid, remaining - invoice.remainingBalance)
    com.example.business.CustomerLedger.post(database,invoice.customerId,-(paid-invoice.amountPaid),"Receipt review: ${invoice.invoiceNumber}")
    postInvoicePayment(updated)
    updated
  }

  private suspend fun restoreInvoiceStock(invoice: Invoice) {
    if (invoice.syncWithInventory) {
      val data=org.json.JSONObject(invoice.detailsJson);val context=database.businessDao().context() ?: com.example.business.StockContext()
      database.businessDao().context(com.example.business.StockContext(reason="INVOICE_REVERSAL",documentId=invoice.id.toString(),branchId=data.optString("branch","main"),warehouseId=data.optString("warehouse","main")))
      try {invoice.parseItems().filter { !it.isService }.forEach { entry -> entry.itemId?.let { dao.addInventoryStock(it, entry.quantity) } }}finally{database.businessDao().context(context)}
    }
  }

  private suspend fun removeInvoicePostings(invoice: Invoice) {
    dao.getInvoicePostings("BILL/${invoice.id}", "COLLECT/BILL/${invoice.id}/%").forEach { tx ->
      dao.getAllAccountsList().find { it.name == tx.accountName }?.let { dao.changeAccountBalance(it.id, -tx.amount) }
      dao.deleteTransaction(tx)
    }
    // Earlier builds recorded a sale transaction without changing the wallet.
    dao.getTransactionsByReference(invoice.invoiceNumber).filter { it.category == "Customer Bill / Sale" }.forEach { dao.deleteTransaction(it) }
  }

  private suspend fun postInvoicePayment(invoice: Invoice) {
    if (invoice.amountPaid <= 0.0) return
    ensurePakistaniAccounts()
    val parts = if (invoice.paymentMethod.startsWith("Split [")) {
      invoice.paymentMethod.substringAfter("[").substringBefore("]").split(";").mapNotNull {
        val pair = it.split("=", limit = 2)
        if (pair.size == 2) pair[1].toDoubleOrNull()?.let { amount -> pair[0] to amount } else null
      }
    } else listOf(invoice.paymentMethod.substringBefore(" (").trim() to invoice.amountPaid)
    var unallocated = invoice.amountPaid
    for ((method, claimed) in parts) {
      val amount = minOf(claimed, unallocated)
      if (amount <= 0.0) continue
      val accounts = dao.getAllAccountsList()
      val cash = method.equals("Cash", ignoreCase = true)
      var account = accounts.find { it.name.equals(method, ignoreCase = true) || it.name.contains(method, ignoreCase = true) }
        ?: if (cash) accounts.find { it.accountType.contains("Cash", ignoreCase = true) } else null
      if (account == null) {
        val id = dao.insertAccount(Account(name = method.ifBlank { "Online Payment" },
          accountType = if (cash) "Cash In Hand" else "Online Wallet", balance = 0.0,
          accountNumber = "LOCAL-${java.util.UUID.randomUUID()}"))
        account = dao.getAllAccountsList().first { it.id == id }
      }
      dao.insertTransaction(Transaction(title = "Customer Bill: ${invoice.invoiceNumber} (${invoice.customerName})",
        amount = amount, type = TransactionType.INCOME, category = "Customer Bill / Sale", icon = "🧾",
        accountName = account.name, paymentMethod = method, recipientInfo = invoice.customerName,
        transactionRef = "BILL/${invoice.id}", dateMillis = invoice.dateMillis))
      dao.changeAccountBalance(account.id, amount)
      unallocated -= amount
    }
    require(unallocated < 0.01) { "Payment allocation does not match bill / ادائیگی کی تقسیم درست نہیں" }
  }

  suspend fun recordTransactionAtomically(transaction: Transaction): Long = database.withTransaction {
    require(transaction.amount.isFinite() && transaction.amount > 0.0) { "Enter a valid amount / درست رقم درج کریں" }
    val accounts = dao.getAllAccountsList()
    val source = accounts.find { it.name == transaction.accountName } ?: error("Choose an account / اکاؤنٹ منتخب کریں")
    val delta = if (transaction.type == TransactionType.INCOME) transaction.amount else -transaction.amount
    if (transaction.type == TransactionType.TRANSFER) {
      val destination = accounts.find { it.name == transaction.recipientInfo } ?: error("Choose the destination account / دوسرا اکاؤنٹ منتخب کریں")
      require(source.id != destination.id) { "Choose different accounts / مختلف اکاؤنٹ منتخب کریں" }
      dao.changeAccountBalance(destination.id, transaction.amount)
    }
    dao.changeAccountBalance(source.id, delta)
    val id=dao.insertTransaction(transaction.copy(updatedAt=System.currentTimeMillis()))
    database.businessDao().insert(com.example.business.BusinessRecord(kind="AUDIT",title="TRANSACTION_CREATED",party=id.toString(),amount=transaction.amount,status="RECORDED"))
    id
  }

  suspend fun deleteTransactionAtomically(id: Long) = database.withTransaction {
    val transaction = dao.getTransactionById(id) ?: return@withTransaction
    require(!(transaction.transactionRef.startsWith("BILL/") || transaction.transactionRef.startsWith("COLLECT/BILL/") || transaction.transactionRef.startsWith("DOC/") || transaction.transactionRef.startsWith("SUPPLIER/"))) { "Edit or delete the bill instead / متعلقہ بل میں تبدیلی کریں" }
    val accounts = dao.getAllAccountsList()
    accounts.find { it.name == transaction.accountName }?.let {
      dao.changeAccountBalance(it.id, if (transaction.type == TransactionType.INCOME) -transaction.amount else transaction.amount)
    }
    if (transaction.type == TransactionType.TRANSFER) accounts.find { it.name == transaction.recipientInfo }?.let {
      dao.changeAccountBalance(it.id, -transaction.amount)
    }
    dao.deleteTransaction(transaction)
  }

  suspend fun insertCustomer(customer: Customer): Long {
    return dao.insertCustomer(customer)
  }

  suspend fun updateCustomer(customer: Customer) {
    dao.updateCustomer(customer)
  }

  suspend fun deleteCustomer(customer: Customer) = database.withTransaction {
    require(database.businessDao().allRecords().none {it.kind in listOf("RENTAL_CONTRACT","APPOINTMENT")&&it.status in listOf("ACTIVE","BOOKED")&&org.json.JSONObject(it.payload).optLong("customerId")==customer.id}) {"Customer has an active rental or booking / گاہک کا کرایہ یا بکنگ جاری ہے"}
    dao.deleteCustomer(customer)
  }

  suspend fun getCustomerById(id: Long): Customer? {
    return dao.getCustomerById(id)
  }

  suspend fun getCustomerByName(name: String): Customer? {
    return dao.getCustomerByName(name)
  }

  suspend fun insertInvoice(invoice: Invoice): Long {
    return dao.insertInvoice(invoice)
  }

  suspend fun updateInvoice(invoice: Invoice) {
    dao.updateInvoice(invoice)
  }

  suspend fun deleteInvoice(invoice: Invoice) {
    dao.deleteInvoice(invoice)
  }

  suspend fun getInvoiceById(id: Long): Invoice? {
    return dao.getInvoiceById(id)
  }

  suspend fun updateCustomerFinancials(id: Long, billed: Double, paid: Double, balanceDelta: Double) {
    dao.updateCustomerFinancials(id, billed, paid, balanceDelta)
  }

  suspend fun insertInventoryItem(item: InventoryItem): Long {
    return dao.insertInventoryItem(item)
  }

  suspend fun insertInventoryItems(items: List<InventoryItem>) {
    dao.insertInventoryItems(items)
  }

  suspend fun deleteAllInventoryItems() {
    dao.deleteAllInventoryItems()
  }

  suspend fun updateInventoryItem(item: InventoryItem) {
    dao.updateInventoryItem(item)
  }

  suspend fun deleteInventoryItem(item: InventoryItem) = database.withTransaction {
    require(database.businessDao().allRecords().none {r->val d=org.json.JSONObject(r.payload);(r.kind=="RENTAL_CONTRACT"&&r.status=="ACTIVE"&&d.optLong("itemId")==item.id)||(r.kind=="PRODUCTION_ORDER"&&r.status in listOf("PLANNED","WIP")&&(d.optLong("outputId")==item.id||(d.optJSONArray("ingredients")?.let {a->(0 until a.length()).any {a.getJSONObject(it).optLong("itemId")==item.id}} ?: false)))}) {"Item belongs to an active production order or rental / سامان جاری پیداوار یا کرایہ میں ہے"}
    dao.deleteInventoryItem(item)
  }

  suspend fun deductStock(id: Long, quantity: Double) {
    dao.deductInventoryStock(id, quantity)
  }

  suspend fun addStock(id: Long, quantity: Double) {
    dao.addInventoryStock(id, quantity)
  }

  suspend fun getInventoryItemById(id: Long): InventoryItem? {
    return dao.getInventoryItemById(id)
  }

  suspend fun insertTransaction(transaction: Transaction): Long {
    return dao.insertTransaction(transaction)
  }

  suspend fun deleteTransaction(transaction: Transaction) {
    dao.deleteTransaction(transaction)
  }

  suspend fun insertAccount(account: Account): Long {
    return dao.insertAccount(account)
  }

  suspend fun updateAccount(account: Account) {
    dao.updateAccount(account)
  }

  suspend fun deleteAccount(account: Account) {
    dao.deleteAccount(account)
  }

  suspend fun insertBill(bill: Bill): Long {
    return dao.insertBill(bill)
  }

  suspend fun updateBill(bill: Bill) {
    dao.updateBill(bill)
  }

  suspend fun deleteBill(bill: Bill) {
    dao.deleteBill(bill)
  }

  suspend fun insertBudget(budget: Budget): Long {
    return dao.insertBudget(budget)
  }

  suspend fun updateBudget(budget: Budget) {
    dao.updateBudget(budget)
  }

  suspend fun deleteBudget(budget: Budget) {
    dao.deleteBudget(budget)
  }

  suspend fun insertRecurringTransaction(recurring: RecurringTransaction): Long {
    return dao.insertRecurringTransaction(recurring)
  }

  suspend fun updateRecurringTransaction(recurring: RecurringTransaction) {
    dao.updateRecurringTransaction(recurring)
  }

  suspend fun deleteRecurringTransaction(recurring: RecurringTransaction) {
    dao.deleteRecurringTransaction(recurring)
  }

  suspend fun getActiveRecurringTransactions(): List<RecurringTransaction> {
    return dao.getActiveRecurringTransactionsList()
  }

  suspend fun ensurePakistaniAccounts() = database.withTransaction {
    if (dao.getAccountCount() == 0) {
      dao.insertAccount(Account(
        name = "Cash Counter (گلہ / کیش)", accountType = "Cash In Hand",
        balance = 0.0, accountNumber = "CASH-PKR", cardHolder = "",
        expiryDate = "N/A", colorHex = 0xFF10B981
      ))
    }
  }

  suspend fun clearAllData() = database.withTransaction {
    dao.deleteAllTransactions()
    dao.deleteAllAccounts()
    dao.deleteAllBills()
    dao.deleteAllBudgets()
    dao.deleteAllRecurringTransactions()
    dao.deleteAllInventoryItems()
    dao.deleteAllCustomers()
    dao.deleteAllInvoices()
  }

  suspend fun loadPakistaniBusinessDemoData(): Boolean = database.withTransaction {
    val hasRecords = dao.getTransactionCount() > 0 || dao.getInventoryCount() > 0 ||
      dao.getCustomerCount() > 0 || dao.getInvoiceCount() > 0 || dao.getBillCount() > 0 ||
      dao.getBudgetCount() > 0 || dao.getRecurringCount() > 0
    val accounts = dao.getAllAccountsList()
    val onlyEmptyDefaultCash = accounts.isEmpty() || (accounts.size == 1 &&
      accounts.single().name == "Cash Counter (گلہ / کیش)" && accounts.single().balance == 0.0)
    if (hasRecords || !onlyEmptyDefaultCash) false else {
      seedDemoData()
      true
    }
  }

  private suspend fun seedDemoData() {
    clearAllData()
    val now = System.currentTimeMillis()
    val oneDay = 86400_000L

    // 0. Pakistani Store Inventory & Stock Demo Data
    val inventory = listOf(
      InventoryItem(
        id = 1L,
        name = "Super Basmati Rice (سپر باسمتی چاول)",
        category = "Grocery / اناج",
        icon = "🌾",
        costPrice = 320.0,
        salePrice = 380.0,
        currentStock = 120.0,
        unit = "Kg",
        lowStockThreshold = 25.0,
        barcode = "RICE-BAS-01",
        supplierName = "Al-Rehman Rice Mills",
        note = "Premium export quality 50kg bags"
      ),
      InventoryItem(
        id = 2L,
        name = "Dal Chana Special (دال چنا)",
        category = "Grocery / اناج",
        icon = "🍲",
        costPrice = 240.0,
        salePrice = 280.0,
        currentStock = 85.0,
        unit = "Kg",
        lowStockThreshold = 15.0,
        barcode = "DAL-CHANA-02",
        supplierName = "Ghalla Mandi Wholesaler",
        note = "Cleaned and sorted"
      ),
      InventoryItem(
        id = 3L,
        name = "Cooking Oil 5 Litre (کوکنگ آئل)",
        category = "Oils & Ghee",
        icon = "🛢️",
        costPrice = 2450.0,
        salePrice = 2750.0,
        currentStock = 35.0,
        unit = "Bottle",
        lowStockThreshold = 10.0,
        barcode = "OIL-5L-CAN",
        supplierName = "Habib Oil Mills",
        note = "High demand item"
      ),
      InventoryItem(
        id = 4L,
        name = "Sugar White (چینی دیسی)",
        category = "Grocery / اناج",
        icon = "🧂",
        costPrice = 140.0,
        salePrice = 155.0,
        currentStock = 4.0, // Low Stock Demo
        unit = "Kg",
        lowStockThreshold = 20.0,
        barcode = "SUGAR-50K",
        supplierName = "Pattoki Sugar Mills",
        note = "Stock low! Need urgent reorder"
      ),
      InventoryItem(
        id = 5L,
        name = "Tapal Danedar Tea 900g (چائے پتی)",
        category = "Tea & Beverages",
        icon = "☕",
        costPrice = 1650.0,
        salePrice = 1850.0,
        currentStock = 28.0,
        unit = "Packet",
        lowStockThreshold = 8.0,
        barcode = "TAPAL-900G",
        supplierName = "Tapal Tea Distribution",
        note = "Family pack"
      ),
      InventoryItem(
        id = 6L,
        name = "Olper's Milk 1 Litre (دودھ ڈبہ)",
        category = "Dairy",
        icon = "🥛",
        costPrice = 275.0,
        salePrice = 300.0,
        currentStock = 3.0, // Low stock demo
        unit = "Box",
        lowStockThreshold = 12.0,
        barcode = "OLPERS-1L",
        supplierName = "Engro Foods",
        note = "Fast moving daily product"
      )
    )
    dao.insertInventoryItems(inventory)

    // 1. Business Accounts
    val accounts = listOf(
      Account(
        id = 1L,
        name = "Cash Counter (گلہ / کیش)",
        accountType = "Cash In Hand",
        balance = 85400.0,
        accountNumber = "CASH-PKR",
        cardHolder = "Muhammad Arshad",
        expiryDate = "N/A",
        colorHex = 0xFF10B981 // Emerald Green
      ),
      Account(
        id = 2L,
        name = "JazzCash Business",
        accountType = "Mobile Wallet",
        balance = 42350.0,
        accountNumber = "0300-1234567",
        cardHolder = "Arshad Traders",
        expiryDate = "N/A",
        colorHex = 0xFFE11D48 // Jazz Red
      ),
      Account(
        id = 3L,
        name = "Easypaisa Merchant",
        accountType = "Mobile Wallet",
        balance = 28900.0,
        accountNumber = "0345-9876543",
        cardHolder = "Arshad Traders",
        expiryDate = "N/A",
        colorHex = 0xFF059669 // Easypaisa Green
      ),
      Account(
        id = 4L,
        name = "Meezan Islamic Bank",
        accountType = "Current Account",
        balance = 245000.0,
        accountNumber = "•••• 9021",
        cardHolder = "Arshad Finance",
        expiryDate = "12/28",
        colorHex = 0xFF0A2540 // Navy Blue
      )
    )
    dao.insertAccounts(accounts)

    // 2. Realistic Pakistani Business Transactions
    val transactions = listOf(
      Transaction(
        id = 0L,
        title = "Daily Shop Counter Sale (نقد فروخت)",
        amount = 38500.0,
        type = com.example.data.model.TransactionType.INCOME,
        category = "Sales",
        icon = "🛒",
        accountName = "Cash Counter (گلہ / کیش)",
        dateMillis = now - (2 * 3600_000L),
        note = "Cash sales from walk-in customers",
        recipientInfo = "Walk-in Customers",
        paymentMethod = "Cash",
        receiptImageUri = "",
        transactionRef = "INV-8901"
      ),
      Transaction(
        id = 0L,
        title = "Malik Traders - Khata Wasooli (ادھار وصول)",
        amount = 25000.0,
        type = com.example.data.model.TransactionType.INCOME,
        category = "Khata Recovery",
        icon = "🤝",
        accountName = "Meezan Islamic Bank",
        dateMillis = now - (6 * 3600_000L),
        note = "Received via Online Bank Transfer for Invoice #412",
        recipientInfo = "Malik Aslam (+92 301 5551234)",
        paymentMethod = "Bank Transfer",
        receiptImageUri = "",
        transactionRef = "INV-7723"
      ),
      Transaction(
        id = 0L,
        title = "Al-Rehman Rice Mills (اسٹاک خریداری)",
        amount = 45000.0,
        type = com.example.data.model.TransactionType.EXPENSE,
        category = "Inventory / Stock",
        icon = "📦",
        accountName = "Meezan Islamic Bank",
        dateMillis = now - (1 * oneDay),
        note = "Purchased 20 Bags Basmati Super Kernel Rice",
        recipientInfo = "Rehman Mills Gujranwala",
        paymentMethod = "Cheque",
        receiptImageUri = "",
        transactionRef = "BILL-908"
      ),
      Transaction(
        id = 0L,
        title = "Chaudhry Bilal - Online Order Payment",
        amount = 12400.0,
        type = com.example.data.model.TransactionType.INCOME,
        category = "Online Sales",
        icon = "📱",
        accountName = "JazzCash Business",
        dateMillis = now - (1 * oneDay + 4 * 3600_000L),
        note = "Goods delivered via Courier TCS",
        recipientInfo = "Chaudhry Bilal (+92 321 4447890)",
        paymentMethod = "JazzCash",
        receiptImageUri = "",
        transactionRef = "TCS-3341"
      ),
      Transaction(
        id = 0L,
        title = "Shop Rent (دکان کا کرایہ)",
        amount = 35000.0,
        type = com.example.data.model.TransactionType.EXPENSE,
        category = "Rent",
        icon = "🏬",
        accountName = "Cash Counter (گلہ / کیش)",
        dateMillis = now - (2 * oneDay),
        note = "Monthly rent for Shop #14 Commercial Market",
        recipientInfo = "Haji Abdul Ghafoor (Landlord)",
        paymentMethod = "Cash",
        receiptImageUri = "",
        transactionRef = "RENT-AUG"
      ),
      Transaction(
        id = 0L,
        title = "LESCO Commercial Electricity Bill (بجلی بل)",
        amount = 18600.0,
        type = com.example.data.model.TransactionType.EXPENSE,
        category = "Bills & Utilities",
        icon = "⚡",
        accountName = "Easypaisa Merchant",
        dateMillis = now - (3 * oneDay),
        note = "Commercial 3-Phase meter consumer #24115",
        recipientInfo = "LESCO / WAPDA",
        paymentMethod = "Easypaisa",
        receiptImageUri = "",
        transactionRef = "WAPDA-991"
      ),
      Transaction(
        id = 0L,
        title = "Tariq Electronics - Udhaar Payment Received",
        amount = 15000.0,
        type = com.example.data.model.TransactionType.INCOME,
        category = "Khata Recovery",
        icon = "💵",
        accountName = "Cash Counter (گلہ / کیش)",
        dateMillis = now - (4 * oneDay),
        note = "Partial clearance of previous ledger balance",
        recipientInfo = "Tariq Mehmood (+92 333 7771122)",
        paymentMethod = "Cash",
        receiptImageUri = "",
        transactionRef = "INV-6510"
      ),
      Transaction(
        id = 0L,
        title = "Staff Salaries - 2 Workers (اسٹاف تنخواہ)",
        amount = 50000.0,
        type = com.example.data.model.TransactionType.EXPENSE,
        category = "Salary",
        icon = "👥",
        accountName = "Cash Counter (گلہ / کیش)",
        dateMillis = now - (5 * oneDay),
        note = "Monthly salary paid to Kashif & Noman",
        recipientInfo = "Shop Staff Members",
        paymentMethod = "Cash",
        receiptImageUri = "",
        transactionRef = "SAL-AUG"
      )
    )
    dao.insertTransactions(transactions)

    // 3. Budgets for Business
    val budgets = listOf(
      Budget(
        id = 1L,
        category = "Inventory / Stock",
        limitAmount = 150000.0,
        spentAmount = 45000.0,
        icon = "📦",
        period = "Monthly"
      ),
      Budget(
        id = 2L,
        category = "Salary",
        limitAmount = 60000.0,
        spentAmount = 50000.0,
        icon = "👥",
        period = "Monthly"
      ),
      Budget(
        id = 3L,
        category = "Rent",
        limitAmount = 35000.0,
        spentAmount = 35000.0,
        icon = "🏬",
        period = "Monthly"
      ),
      Budget(
        id = 4L,
        category = "Bills & Utilities",
        limitAmount = 25000.0,
        spentAmount = 18600.0,
        icon = "⚡",
        period = "Monthly"
      )
    )
    dao.insertBudgets(budgets)

    // 4. Commercial Bills
    val bills = listOf(
      Bill(
        id = 1L,
        title = "LESCO Commercial Bill",
        amount = 18600.0,
        dueDate = "28 Aug 2026",
        category = "Electricity",
        icon = "⚡",
        isPaid = true
      ),
      Bill(
        id = 2L,
        title = "Shop Rent - Shop #14",
        amount = 35000.0,
        dueDate = "01 Sep 2026",
        category = "Rent",
        icon = "🏬",
        isPaid = true
      ),
      Bill(
        id = 3L,
        title = "PTCL Corporate Fiber Net",
        amount = 4500.0,
        dueDate = "05 Sep 2026",
        category = "Internet",
        icon = "🌐",
        isPaid = false
      ),
      Bill(
        id = 4L,
        title = "Supplier Oil Payment (Al-Madina)",
        amount = 62000.0,
        dueDate = "10 Sep 2026",
        category = "Supplier Dues",
        icon = "🛢️",
        isPaid = false
      )
    )
    dao.insertBills(bills)

    // 5. Recurring Business Payments
    val recurring = listOf(
      RecurringTransaction(
        id = 1L,
        title = "Monthly Shop Staff Payroll",
        amount = 50000.0,
        type = com.example.data.model.TransactionType.EXPENSE,
        category = "Salary",
        icon = "👥",
        accountName = "Cash Counter (گلہ / کیش)",
        frequency = com.example.data.model.RecurringFrequency.MONTHLY,
        startDateMillis = now - (30 * oneDay),
        endDateMillis = null,
        nextExecutionDateMillis = now + (25 * oneDay),
        lastExecutedDateMillis = now - (5 * oneDay),
        isActive = true,
        note = "Fixed staff salary for Kashif & Noman"
      ),
      RecurringTransaction(
        id = 2L,
        title = "Commercial Shop Rent",
        amount = 35000.0,
        type = com.example.data.model.TransactionType.EXPENSE,
        category = "Rent",
        icon = "🏬",
        accountName = "Cash Counter (گلہ / کیش)",
        frequency = com.example.data.model.RecurringFrequency.MONTHLY,
        startDateMillis = now - (60 * oneDay),
        endDateMillis = null,
        nextExecutionDateMillis = now + (6 * oneDay),
        lastExecutedDateMillis = now - (24 * oneDay),
        isActive = true,
        note = "Pay to Landlord Haji Abdul Ghafoor"
      ),
      RecurringTransaction(
        id = 3L,
        title = "PTCL Flash Fiber Internet",
        amount = 4500.0,
        type = com.example.data.model.TransactionType.EXPENSE,
        category = "Bills & Utilities",
        icon = "🌐",
        accountName = "Easypaisa Merchant",
        frequency = com.example.data.model.RecurringFrequency.MONTHLY,
        startDateMillis = now - (90 * oneDay),
        endDateMillis = null,
        nextExecutionDateMillis = now + (10 * oneDay),
        lastExecutedDateMillis = now - (20 * oneDay),
        isActive = true,
        note = "Broadband account #042-358900"
      )
    )
    dao.insertRecurringTransactions(recurring)
  }

  suspend fun prepopulateIfEmpty() {
    val accCount = dao.getAccountCount()
    val now = System.currentTimeMillis()
    val oneHour = 3600_000L
    val oneDay = 86400_000L

    if (accCount == 0) {
      val accounts = listOf(
        Account(
          id = 1L,
          name = "Cash Counter (گلہ / کیش)",
          accountType = "Cash In Hand",
          balance = 85400.0,
          accountNumber = "CASH-PKR",
          cardHolder = "Muhammad Arshad",
          expiryDate = "N/A",
          colorHex = 0xFF10B981 // Emerald Green
        ),
        Account(
          id = 2L,
          name = "JazzCash Business",
          accountType = "Mobile Wallet",
          balance = 42350.0,
          accountNumber = "0302-7761415",
          cardHolder = "Muhammad Arshad",
          expiryDate = "N/A",
          colorHex = 0xFFE11D48 // Jazz Red
        ),
        Account(
          id = 3L,
          name = "Easypaisa Merchant",
          accountType = "Mobile Wallet",
          balance = 28900.0,
          accountNumber = "0345-9876543",
          cardHolder = "Muhammad Arshad",
          expiryDate = "N/A",
          colorHex = 0xFF059669 // Easypaisa Green
        ),
        Account(
          id = 4L,
          name = "Meezan Islamic Bank",
          accountType = "Current Account",
          balance = 245000.0,
          accountNumber = "PK89 MEZN 0001 0203 0405 0607",
          cardHolder = "Arshad Finance & Traders",
          expiryDate = "12/29",
          colorHex = 0xFF0A2540 // Navy Blue
        ),
        Account(
          id = 5L,
          name = "SadaPay Business",
          accountType = "Digital Wallet",
          balance = 35000.0,
          accountNumber = "PK12 SADA 0000 1234 5678 90",
          cardHolder = "Arshad Finance",
          expiryDate = "06/29",
          colorHex = 0xFF0D9488 // Teal / Coral
        ),
        Account(
          id = 6L,
          name = "NayaPay Wallet",
          accountType = "Digital Wallet",
          balance = 18500.0,
          accountNumber = "0302-7761415",
          cardHolder = "Muhammad Arshad",
          expiryDate = "08/29",
          colorHex = 0xFF7C3AED // Violet
        )
      )
      dao.insertAccounts(accounts)
    }

    if (dao.getTransactionCount() == 0) {
      val initialTransactions = listOf(
        Transaction(
          id = 1L,
          title = "Supermarket",
          amount = 84.20,
          type = com.example.data.model.TransactionType.EXPENSE,
          category = "Shopping",
          icon = "🛍️",
          accountName = "Main Checking",
          dateMillis = now - (2 * oneHour),
          note = "Groceries & household essentials"
        ),
        Transaction(
          id = 2L,
          title = "Salary Deposit",
          amount = 4200.00,
          type = com.example.data.model.TransactionType.INCOME,
          category = "Salary",
          icon = "💼",
          accountName = "Main Checking",
          dateMillis = now - oneDay,
          note = "Monthly payroll - Astute Solutions"
        ),
        Transaction(
          id = 3L,
          title = "Coffee Shop",
          amount = 4.50,
          type = com.example.data.model.TransactionType.EXPENSE,
          category = "Food & Dining",
          icon = "☕",
          accountName = "Main Checking",
          dateMillis = now - oneDay - (3 * oneHour),
          note = "Morning espresso"
        ),
        Transaction(
          id = 4L,
          title = "Electricity Utility",
          amount = 125.00,
          type = com.example.data.model.TransactionType.EXPENSE,
          category = "Bills & Utilities",
          icon = "⚡",
          accountName = "Main Checking",
          dateMillis = now - (2 * oneDay),
          note = "City Power monthly invoice"
        ),
        Transaction(
          id = 5L,
          title = "Freelance Consulting",
          amount = 850.00,
          type = com.example.data.model.TransactionType.INCOME,
          category = "Investments & Extra",
          icon = "💻",
          accountName = "High-Yield Savings",
          dateMillis = now - (3 * oneDay),
          note = "Architecture review milestone"
        ),
        Transaction(
          id = 6L,
          title = "Metro Transit Pass",
          amount = 45.00,
          type = com.example.data.model.TransactionType.EXPENSE,
          category = "Transportation",
          icon = "🚕",
          accountName = "Main Checking",
          dateMillis = now - (4 * oneDay),
          note = "Monthly commuter top-up"
        ),
        Transaction(
          id = 7L,
          title = "Online Pharmacy",
          amount = 32.80,
          type = com.example.data.model.TransactionType.EXPENSE,
          category = "Health & Wellness",
          icon = "💊",
          accountName = "Main Checking",
          dateMillis = now - (5 * oneDay),
          note = "Vitamins & prescriptions"
        )
      )
      dao.insertTransactions(initialTransactions)
    }

    if (dao.getBillCount() == 0) {
      val initialBills = listOf(
        Bill(
          id = 1L,
          title = "Cloud Server Hosting",
          amount = 49.99,
          dueDate = "Aug 24, 2026",
          category = "Tech & Work",
          icon = "☁️",
          isPaid = false
        ),
        Bill(
          id = 2L,
          title = "High-Speed Fiber Internet",
          amount = 79.00,
          dueDate = "Aug 28, 2026",
          category = "Utilities",
          icon = "🌐",
          isPaid = false
        ),
        Bill(
          id = 3L,
          title = "Fitness Gym Membership",
          amount = 65.00,
          dueDate = "Aug 30, 2026",
          category = "Health",
          icon = "🏋️",
          isPaid = true
        )
      )
      dao.insertBills(initialBills)
    }

    if (dao.getBudgetCount() == 0) {
      val initialBudgets = listOf(
        Budget(
          id = 1L,
          category = "Food & Dining",
          limitAmount = 400.0,
          spentAmount = 345.50,
          icon = "🍔",
          period = "Monthly"
        ),
        Budget(
          id = 2L,
          category = "Shopping",
          limitAmount = 250.0,
          spentAmount = 284.20,
          icon = "🛍️",
          period = "Monthly"
        ),
        Budget(
          id = 3L,
          category = "Bills & Utilities",
          limitAmount = 300.0,
          spentAmount = 255.00,
          icon = "⚡",
          period = "Monthly"
        ),
        Budget(
          id = 4L,
          category = "Transportation",
          limitAmount = 200.0,
          spentAmount = 45.00,
          icon = "🚕",
          period = "Monthly"
        ),
        Budget(
          id = 5L,
          category = "Health & Wellness",
          limitAmount = 150.0,
          spentAmount = 32.80,
          icon = "💊",
          period = "Monthly"
        )
      )
      dao.insertBudgets(initialBudgets)
    }

    if (dao.getRecurringCount() == 0) {
      val initialRecurring = listOf(
        RecurringTransaction(
          id = 1L,
          title = "Monthly Astute Payroll",
          amount = 4200.00,
          type = com.example.data.model.TransactionType.INCOME,
          category = "Salary",
          icon = "💼",
          accountName = "Main Checking",
          frequency = com.example.data.model.RecurringFrequency.MONTHLY,
          startDateMillis = now - (30 * oneDay),
          endDateMillis = null,
          nextExecutionDateMillis = now + (10 * oneDay),
          lastExecutedDateMillis = now - oneDay,
          isActive = true,
          note = "Regular employee direct deposit"
        ),
        RecurringTransaction(
          id = 2L,
          title = "Netflix 4K Ultra",
          amount = 19.99,
          type = com.example.data.model.TransactionType.EXPENSE,
          category = "Subscriptions",
          icon = "📺",
          accountName = "Sapphire Credit",
          frequency = com.example.data.model.RecurringFrequency.MONTHLY,
          startDateMillis = now - (60 * oneDay),
          endDateMillis = null,
          nextExecutionDateMillis = now + (3 * oneDay),
          lastExecutedDateMillis = now - (27 * oneDay),
          isActive = true,
          note = "Family stream plan"
        ),
        RecurringTransaction(
          id = 3L,
          title = "Weekly Grocery Budget Transfer",
          amount = 120.00,
          type = com.example.data.model.TransactionType.EXPENSE,
          category = "Shopping",
          icon = "🛒",
          accountName = "Main Checking",
          frequency = com.example.data.model.RecurringFrequency.WEEKLY,
          startDateMillis = now - (14 * oneDay),
          endDateMillis = null,
          nextExecutionDateMillis = now + (2 * oneDay),
          lastExecutedDateMillis = now - (5 * oneDay),
          isActive = true,
          note = "Food market allowance"
        ),
        RecurringTransaction(
          id = 4L,
          title = "Annual Amazon Prime",
          amount = 139.00,
          type = com.example.data.model.TransactionType.EXPENSE,
          category = "Subscriptions",
          icon = "📦",
          accountName = "Sapphire Credit",
          frequency = com.example.data.model.RecurringFrequency.YEARLY,
          startDateMillis = now - (180 * oneDay),
          endDateMillis = null,
          nextExecutionDateMillis = now + (185 * oneDay),
          lastExecutedDateMillis = now - (180 * oneDay),
          isActive = true,
          note = "Fast delivery & video subscription"
        )
      )
      dao.insertRecurringTransactions(initialRecurring)
    }

    if (dao.getInventoryCount() == 0) {
      val initialInventory = listOf(
        InventoryItem(
          id = 1L,
          name = "Super Basmati Rice (سپر باسمتی چاول)",
          category = "Grocery / اناج",
          icon = "🌾",
          costPrice = 320.0,
          salePrice = 380.0,
          currentStock = 120.0,
          unit = "Kg",
          lowStockThreshold = 25.0,
          barcode = "RICE-BAS-01",
          supplierName = "Al-Rehman Rice Mills",
          note = "Premium export quality 50kg bags"
        ),
        InventoryItem(
          id = 2L,
          name = "Dal Chana Special (دال چنا)",
          category = "Grocery / اناج",
          icon = "🍲",
          costPrice = 240.0,
          salePrice = 280.0,
          currentStock = 85.0,
          unit = "Kg",
          lowStockThreshold = 15.0,
          barcode = "DAL-CHANA-02",
          supplierName = "Ghalla Mandi Wholesaler",
          note = "Cleaned and sorted"
        ),
        InventoryItem(
          id = 3L,
          name = "Cooking Oil 5 Litre (کوکنگ آئل)",
          category = "Oils & Ghee",
          icon = "🛢️",
          costPrice = 2450.0,
          salePrice = 2750.0,
          currentStock = 45.0,
          unit = "Can",
          lowStockThreshold = 10.0,
          barcode = "OIL-5L-CAN",
          supplierName = "Habib Oil Mills",
          note = "5 Litre tin container"
        ),
        InventoryItem(
          id = 4L,
          name = "Sugar Premium White (چینی)",
          category = "Grocery / اناج",
          icon = "🧂",
          costPrice = 135.0,
          salePrice = 155.0,
          currentStock = 350.0,
          unit = "Kg",
          lowStockThreshold = 50.0,
          barcode = "SUGAR-WHITE-1KG",
          supplierName = "JDW Sugar Mills",
          note = "Grade-A refined white sugar"
        ),
        InventoryItem(
          id = 5L,
          name = "Tapal Danedar Tea 900g (چائے پتی)",
          category = "Beverages",
          icon = "☕",
          costPrice = 1650.0,
          salePrice = 1850.0,
          currentStock = 28.0,
          unit = "Packet",
          lowStockThreshold = 8.0,
          barcode = "TAPAL-900G",
          supplierName = "Tapal Tea Distribution",
          note = "Family pack"
        ),
        InventoryItem(
          id = 6L,
          name = "Olper's Milk 1 Litre (دودھ ڈبہ)",
          category = "Dairy",
          icon = "🥛",
          costPrice = 275.0,
          salePrice = 300.0,
          currentStock = 3.0,
          unit = "Box",
          lowStockThreshold = 12.0,
          barcode = "OLPERS-1L",
          supplierName = "Engro Foods",
          note = "Fast moving daily product"
        )
      )
      dao.insertInventoryItems(initialInventory)
    }
  }
}
