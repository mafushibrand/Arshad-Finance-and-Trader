package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "accounts")
data class Account(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,
  val name: String,
  val accountType: String, // "Checking", "Savings", "Credit Card", "Investment"
  val balance: Double,
  val accountNumber: String,
  val cardHolder: String = "Arshad",
  val expiryDate: String = "12/29",
  val colorHex: Long = 0xFF0061A4
)
