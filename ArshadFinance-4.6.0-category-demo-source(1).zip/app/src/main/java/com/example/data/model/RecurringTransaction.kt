package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Calendar

enum class RecurringFrequency(val displayName: String) {
  DAILY("Daily"),
  WEEKLY("Weekly"),
  BIWEEKLY("Bi-weekly"),
  MONTHLY("Monthly"),
  YEARLY("Yearly");

  fun getNextDate(fromMillis: Long): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = fromMillis
    }
    when (this) {
      DAILY -> cal.add(Calendar.DAY_OF_YEAR, 1)
      WEEKLY -> cal.add(Calendar.WEEK_OF_YEAR, 1)
      BIWEEKLY -> cal.add(Calendar.WEEK_OF_YEAR, 2)
      MONTHLY -> cal.add(Calendar.MONTH, 1)
      YEARLY -> cal.add(Calendar.YEAR, 1)
    }
    return cal.timeInMillis
  }
}

@Entity(tableName = "recurring_transactions")
data class RecurringTransaction(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,
  val title: String,
  val amount: Double,
  val type: TransactionType,
  val category: String,
  val icon: String = "🔄",
  val accountName: String = "Main Checking",
  val frequency: RecurringFrequency = RecurringFrequency.MONTHLY,
  val startDateMillis: Long = System.currentTimeMillis(),
  val endDateMillis: Long? = null,
  val nextExecutionDateMillis: Long = System.currentTimeMillis(),
  val lastExecutedDateMillis: Long? = null,
  val isActive: Boolean = true,
  val note: String = ""
)
