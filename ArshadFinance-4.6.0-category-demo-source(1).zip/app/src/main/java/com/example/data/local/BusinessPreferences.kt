package com.example.data.local

import android.content.Context
import com.example.data.model.ServiceItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

/** Local configuration only. Financial records remain in Room. */
class BusinessPreferences(context: Context) {
  private val prefs = context.applicationContext.getSharedPreferences("business_config", Context.MODE_PRIVATE)
  @PublishedApi internal val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

  @PublishedApi internal fun stored(key: String): String? = prefs.getString(key, null)

  @PublishedApi internal fun save(key: String, value: String) {
    check(prefs.edit().putString(key, value).commit()) { "Could not save business configuration" }
  }

  inline fun <reified T : Any> read(key: String, fallback: T): T {
    val json = stored(key) ?: return fallback
    // Keep malformed bytes for recovery; do not replace them with defaults on read.
    return moshi.adapter(T::class.java).fromJson(json)
      ?: error("Saved configuration is invalid: $key")
  }

  inline fun <reified T : Any> write(key: String, value: T) {
    save(key, moshi.adapter(T::class.java).toJson(value))
  }

  private val servicesAdapter = moshi.adapter<List<ServiceItem>>(
    Types.newParameterizedType(List::class.java, ServiceItem::class.java)
  )

  fun readServices(fallback: List<ServiceItem>): List<ServiceItem> =
    stored("services")?.let { servicesAdapter.fromJson(it) ?: error("Invalid saved services") } ?: fallback

  fun writeServices(services: List<ServiceItem>) = save("services", servicesAdapter.toJson(services))

  private val featuredAdapter = moshi.adapter<List<Long>>(
    Types.newParameterizedType(List::class.java, Long::class.javaObjectType)
  )

  fun readFeatured(fallback: Set<Long>): Set<Long> = stored("featured")?.let {
    featuredAdapter.fromJson(it)?.toSet() ?: error("Invalid saved featured services")
  } ?: fallback

  fun writeFeatured(ids: Set<Long>) = save("featured", featuredAdapter.toJson(ids.toList()))

  fun exportRaw(): Map<String, String> = prefs.all.mapValues { (_, value) -> value as? String ?: error("Unsupported saved preference") }
  fun replaceRaw(values: Map<String, String>) {
    val editor = prefs.edit().clear()
    values.forEach { (key, value) -> editor.putString(key, value) }
    check(editor.commit()) { "Could not save restored configuration" }
  }
}
