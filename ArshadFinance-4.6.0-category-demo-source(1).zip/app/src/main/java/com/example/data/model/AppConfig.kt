package com.example.data.model

enum class UserRole {
  OWNER,
  EMPLOYEE
}

data class EmployeePermissions(
  val canAddProducts: Boolean = true,
  val canUploadStock: Boolean = true,
  val canGenerateInvoice: Boolean = true,
  val canGenerateDailyWeeklyReport: Boolean = true,
  val canGenerateMonthlyReport: Boolean = false,
  val canGiveDiscounts: Boolean = false,
  val canViewProfits: Boolean = false,
  val canAccessDebts: Boolean = false
)

enum class AppMode {
  BUSINESS_RETAIL, // Retail POS, Stock & Barcode
  SERVICE_BASED,   // Services, Hourly & Labor Billing
  PERSONAL_KHATA   // Personal Income/Expense & Friend Udhar
}

enum class AppLanguage {
  URDU,
  ENGLISH
}

data class UserAccount(
  val mobileNumber: String = "",
  val shopName: String = "Arshad Finance & Traders",
  val ownerName: String = "",
  val email: String = "",
  val cityRegion: String = "",
  val isLoggedIn: Boolean = false,
  val hasSelectedMode: Boolean = false,
  val registeredDateMillis: Long = System.currentTimeMillis(),
  val lastLoginRegion: String = "",
  val lastLoginTimeMillis: Long = System.currentTimeMillis()
)

data class FbrTaxSummary(
  val dailyTax: Double = 0.0,
  val weeklyTax: Double = 0.0,
  val monthlyTax: Double = 0.0,
  val yearlyTax: Double = 0.0,
  val totalSalesTaxCollected: Double = 0.0,
  val totalTaxPayable: Double = 0.0,
  val ntnNumber: String = "NTN-892341-PK",
  val fbrPosId: String = "POS-98421"
)

data class SubscriptionState(
  val installDateMillis: Long = System.currentTimeMillis(),
  val trialDurationDays: Int = 30,
  val isActivated: Boolean = false,
  val isSimulatedLocked: Boolean = false,
  val activationCode: String = "",
  val expiryDateMillis: Long = 0L,
  val monthlyPricePkr: Int = 300,
  val yearlyPricePkr: Int = 3000,
  val jazzCashNumber: String = "",
  val ownerContactName: String = "",
  val policyVersion: Int = 2,
  val trialStartedMillis: Long = 0L,
  val lastSeenMillis: Long = 0L,
  val deviceId: String = "",
  val plan: String = "",
  val clockBlocked: Boolean = false,
  val merchantConfig: String = "",
  val hasPaidBefore: Boolean = false
) {
  val remainingDays: Long
    get() = com.example.business.SubscriptionPolicy.remainingDays(this, System.currentTimeMillis())
  val hasBusinessAccess: Boolean
    get() = com.example.business.SubscriptionPolicy.allowed(this, System.currentTimeMillis())
  val isTrialExpired: Boolean get() = !hasBusinessAccess
  val isBasicTierRestricted: Boolean get() = !hasBusinessAccess
}
