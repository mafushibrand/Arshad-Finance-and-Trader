package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,
  val name: String,
  val phone: String = "",
  val address: String = "",
  val customerType: String = "Regular", // Regular, VIP, Wholesale, Client
  val totalBilled: Double = 0.0,
  val totalPaid: Double = 0.0,
  val currentBalance: Double = 0.0, // Remaining Udhar / Receivable
  val createdDateMillis: Long = System.currentTimeMillis(),
  val lastInteractionMillis: Long = System.currentTimeMillis(),
  val note: String = "",
  @androidx.room.ColumnInfo(defaultValue = "'{}'") val detailsJson: String = "{}"
)
