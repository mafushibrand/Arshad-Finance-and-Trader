package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.Account
import com.example.data.model.Bill
import com.example.data.model.Budget
import com.example.data.model.Customer
import com.example.data.model.InventoryItem
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItemEntry
import com.example.data.model.RecurringFrequency
import com.example.data.model.RecurringTransaction
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [Transaction::class, Account::class, Bill::class, Budget::class, RecurringTransaction::class, InventoryItem::class, Customer::class, Invoice::class, com.example.business.BusinessRecord::class, com.example.business.StockMovement::class, com.example.business.StockContext::class],
  version = 8,
  exportSchema = false
)
abstract class FinanceDatabase : RoomDatabase() {
  abstract fun financeDao(): FinanceDao
  abstract fun businessDao(): com.example.business.BusinessDao

  companion object {
    @Volatile
    private var INSTANCE: FinanceDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): FinanceDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          FinanceDatabase::class.java,
          "arshad_finance_db"
        )
          // Keep schema v6; an unknown older schema must fail instead of deleting data.
          // Seed examples only through the explicit, protected demo action.
          .addMigrations(com.example.business.BusinessSchema.migration, com.example.business.WorkflowSchema.migration)
          .addCallback(com.example.business.BusinessSchema.callback)
          .build()
        INSTANCE = instance
        instance
      }
    }
  }

  private class FinanceDatabaseCallback(
    private val scope: CoroutineScope
  ) : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
      super.onCreate(db)
      INSTANCE?.let { database ->
        scope.launch(Dispatchers.IO) {
          populateDatabase(database.financeDao())
        }
      }
    }

    suspend fun populateDatabase(dao: FinanceDao) {
      val now = System.currentTimeMillis()
      val oneHour = 3600_000L
      val oneDay = 86400_000L

      // Initial Pakistani Accounts & Wallets
      val accounts = listOf(
        Account(
          id = 1L,
          name = "Cash Counter (گلہ / کیش)",
          accountType = "Cash In Hand",
          balance = 85400.0,
          accountNumber = "CASH-PKR",
          cardHolder = "Muhammad Arshad",
          expiryDate = "N/A",
          colorHex = 0xFF10B981 // Emerald Green
        ),
        Account(
          id = 2L,
          name = "JazzCash Business",
          accountType = "Mobile Wallet",
          balance = 42350.0,
          accountNumber = "0302-7761415",
          cardHolder = "Muhammad Arshad",
          expiryDate = "N/A",
          colorHex = 0xFFE11D48 // Jazz Red
        ),
        Account(
          id = 3L,
          name = "Easypaisa Merchant",
          accountType = "Mobile Wallet",
          balance = 28900.0,
          accountNumber = "0345-9876543",
          cardHolder = "Muhammad Arshad",
          expiryDate = "N/A",
          colorHex = 0xFF059669 // Easypaisa Green
        ),
        Account(
          id = 4L,
          name = "Meezan Islamic Bank",
          accountType = "Current Account",
          balance = 245000.0,
          accountNumber = "PK89 MEZN 0001 0203 0405 0607",
          cardHolder = "Arshad Finance & Traders",
          expiryDate = "12/29",
          colorHex = 0xFF0A2540 // Navy Blue
        ),
        Account(
          id = 5L,
          name = "SadaPay Business",
          accountType = "Digital Wallet",
          balance = 35000.0,
          accountNumber = "PK12 SADA 0000 1234 5678 90",
          cardHolder = "Arshad Finance",
          expiryDate = "06/29",
          colorHex = 0xFF0D9488 // Teal / Coral
        ),
        Account(
          id = 6L,
          name = "NayaPay Wallet",
          accountType = "Digital Wallet",
          balance = 18500.0,
          accountNumber = "0302-7761415",
          cardHolder = "Muhammad Arshad",
          expiryDate = "08/29",
          colorHex = 0xFF7C3AED // Violet
        )
      )
      dao.insertAccounts(accounts)

      // Initial Transactions
      val initialTransactions = listOf(
        Transaction(
          id = 1L,
          title = "Supermarket",
          amount = 84.20,
          type = TransactionType.EXPENSE,
          category = "Shopping",
          icon = "🛍️",
          accountName = "Main Checking",
          dateMillis = now - (2 * oneHour),
          note = "Groceries & household essentials"
        ),
        Transaction(
          id = 2L,
          title = "Salary Deposit",
          amount = 4200.00,
          type = TransactionType.INCOME,
          category = "Salary",
          icon = "💼",
          accountName = "Main Checking",
          dateMillis = now - oneDay,
          note = "Monthly payroll - Astute Solutions"
        ),
        Transaction(
          id = 3L,
          title = "Coffee Shop",
          amount = 4.50,
          type = TransactionType.EXPENSE,
          category = "Food & Dining",
          icon = "☕",
          accountName = "Main Checking",
          dateMillis = now - oneDay - (3 * oneHour),
          note = "Morning espresso"
        ),
        Transaction(
          id = 4L,
          title = "Electricity Utility",
          amount = 125.00,
          type = TransactionType.EXPENSE,
          category = "Bills & Utilities",
          icon = "⚡",
          accountName = "Main Checking",
          dateMillis = now - (2 * oneDay),
          note = "City Power monthly invoice"
        ),
        Transaction(
          id = 5L,
          title = "Freelance Consulting",
          amount = 850.00,
          type = TransactionType.INCOME,
          category = "Investments & Extra",
          icon = "💻",
          accountName = "High-Yield Savings",
          dateMillis = now - (3 * oneDay),
          note = "Architecture review milestone"
        ),
        Transaction(
          id = 6L,
          title = "Metro Transit Pass",
          amount = 45.00,
          type = TransactionType.EXPENSE,
          category = "Transportation",
          icon = "🚕",
          accountName = "Main Checking",
          dateMillis = now - (4 * oneDay),
          note = "Monthly commuter top-up"
        ),
        Transaction(
          id = 7L,
          title = "Online Pharmacy",
          amount = 32.80,
          type = TransactionType.EXPENSE,
          category = "Health & Wellness",
          icon = "💊",
          accountName = "Main Checking",
          dateMillis = now - (5 * oneDay),
          note = "Vitamins & prescriptions"
        )
      )
      dao.insertTransactions(initialTransactions)

      // Initial Bills
      val initialBills = listOf(
        Bill(
          id = 1L,
          title = "Cloud Server Hosting",
          amount = 49.99,
          dueDate = "Aug 24, 2026",
          category = "Tech & Work",
          icon = "☁️",
          isPaid = false
        ),
        Bill(
          id = 2L,
          title = "High-Speed Fiber Internet",
          amount = 79.00,
          dueDate = "Aug 28, 2026",
          category = "Utilities",
          icon = "🌐",
          isPaid = false
        ),
        Bill(
          id = 3L,
          title = "Fitness Gym Membership",
          amount = 65.00,
          dueDate = "Aug 30, 2026",
          category = "Health",
          icon = "🏋️",
          isPaid = true
        )
      )
      dao.insertBills(initialBills)

      // Initial Budgets
      val initialBudgets = listOf(
        Budget(
          id = 1L,
          category = "Food & Dining",
          limitAmount = 400.0,
          spentAmount = 345.50,
          icon = "🍔",
          period = "Monthly"
        ),
        Budget(
          id = 2L,
          category = "Shopping",
          limitAmount = 250.0,
          spentAmount = 284.20, // Over budget demo for alert
          icon = "🛍️",
          period = "Monthly"
        ),
        Budget(
          id = 3L,
          category = "Bills & Utilities",
          limitAmount = 300.0,
          spentAmount = 255.00, // Approaching warning demo
          icon = "⚡",
          period = "Monthly"
        ),
        Budget(
          id = 4L,
          category = "Transportation",
          limitAmount = 200.0,
          spentAmount = 45.00, // Safe
          icon = "🚕",
          period = "Monthly"
        ),
        Budget(
          id = 5L,
          category = "Health & Wellness",
          limitAmount = 150.0,
          spentAmount = 32.80, // Safe
          icon = "💊",
          period = "Monthly"
        )
      )
      dao.insertBudgets(initialBudgets)

      // Initial Recurring Transactions
      val initialRecurring = listOf(
        RecurringTransaction(
          id = 1L,
          title = "Monthly Astute Payroll",
          amount = 4200.00,
          type = TransactionType.INCOME,
          category = "Salary",
          icon = "💼",
          accountName = "Main Checking",
          frequency = RecurringFrequency.MONTHLY,
          startDateMillis = now - (30 * oneDay),
          endDateMillis = null,
          nextExecutionDateMillis = now + (10 * oneDay),
          lastExecutedDateMillis = now - oneDay,
          isActive = true,
          note = "Regular employee direct deposit"
        ),
        RecurringTransaction(
          id = 2L,
          title = "Netflix 4K Ultra",
          amount = 19.99,
          type = TransactionType.EXPENSE,
          category = "Subscriptions",
          icon = "📺",
          accountName = "Sapphire Credit",
          frequency = RecurringFrequency.MONTHLY,
          startDateMillis = now - (60 * oneDay),
          endDateMillis = null,
          nextExecutionDateMillis = now + (3 * oneDay),
          lastExecutedDateMillis = now - (27 * oneDay),
          isActive = true,
          note = "Family stream plan"
        ),
        RecurringTransaction(
          id = 3L,
          title = "Weekly Grocery Budget Transfer",
          amount = 120.00,
          type = TransactionType.EXPENSE,
          category = "Shopping",
          icon = "🛒",
          accountName = "Main Checking",
          frequency = RecurringFrequency.WEEKLY,
          startDateMillis = now - (14 * oneDay),
          endDateMillis = null,
          nextExecutionDateMillis = now + (2 * oneDay),
          lastExecutedDateMillis = now - (5 * oneDay),
          isActive = true,
          note = "Food market allowance"
        ),
        RecurringTransaction(
          id = 4L,
          title = "Annual Amazon Prime",
          amount = 139.00,
          type = TransactionType.EXPENSE,
          category = "Subscriptions",
          icon = "📦",
          accountName = "Sapphire Credit",
          frequency = RecurringFrequency.YEARLY,
          startDateMillis = now - (180 * oneDay),
          endDateMillis = null,
          nextExecutionDateMillis = now + (185 * oneDay),
          lastExecutedDateMillis = now - (180 * oneDay),
          isActive = true,
          note = "Fast delivery & video subscription"
        )
      )
      dao.insertRecurringTransactions(initialRecurring)

      // Initial Inventory Items
      val initialInventory = listOf(
        InventoryItem(
          id = 1L,
          name = "Super Basmati Rice (سپر باسمتی چاول)",
          category = "Grocery / اناج",
          icon = "🌾",
          costPrice = 320.0,
          salePrice = 380.0,
          currentStock = 120.0,
          unit = "Kg",
          lowStockThreshold = 25.0,
          barcode = "RICE-BAS-01",
          supplierName = "Al-Rehman Rice Mills",
          note = "Premium export quality 50kg bags"
        ),
        InventoryItem(
          id = 2L,
          name = "Dal Chana Special (دال چنا)",
          category = "Grocery / اناج",
          icon = "🍲",
          costPrice = 240.0,
          salePrice = 280.0,
          currentStock = 85.0,
          unit = "Kg",
          lowStockThreshold = 15.0,
          barcode = "DAL-CHANA-02",
          supplierName = "Ghalla Mandi Wholesaler",
          note = "Cleaned and sorted"
        ),
        InventoryItem(
          id = 3L,
          name = "Cooking Oil 5 Litre (کوکنگ آئل)",
          category = "Oils & Ghee",
          icon = "🛢️",
          costPrice = 2450.0,
          salePrice = 2750.0,
          currentStock = 45.0,
          unit = "Can",
          lowStockThreshold = 10.0,
          barcode = "OIL-5L-CAN",
          supplierName = "Habib Oil Mills",
          note = "5 Litre tin container"
        ),
        InventoryItem(
          id = 4L,
          name = "Sugar Premium White (چینی)",
          category = "Grocery / اناج",
          icon = "🧂",
          costPrice = 135.0,
          salePrice = 155.0,
          currentStock = 350.0,
          unit = "Kg",
          lowStockThreshold = 50.0,
          barcode = "SUGAR-WHITE-1KG",
          supplierName = "JDW Sugar Mills",
          note = "Grade-A refined white sugar"
        ),
        InventoryItem(
          id = 5L,
          name = "Tapal Danedar Tea 900g (چائے پتی)",
          category = "Beverages",
          icon = "☕",
          costPrice = 1650.0,
          salePrice = 1850.0,
          currentStock = 28.0,
          unit = "Packet",
          lowStockThreshold = 8.0,
          barcode = "TAPAL-900G",
          supplierName = "Tapal Tea Distribution",
          note = "Family pack"
        ),
        InventoryItem(
          id = 6L,
          name = "Olper's Milk 1 Litre (دودھ ڈبہ)",
          category = "Dairy",
          icon = "🥛",
          costPrice = 275.0,
          salePrice = 300.0,
          currentStock = 3.0,
          unit = "Box",
          lowStockThreshold = 12.0,
          barcode = "OLPERS-1L",
          supplierName = "Engro Foods",
          note = "Fast moving daily product"
        ),
        // Beauty Parlour Items
        InventoryItem(
          id = 7L,
          name = "Bridal Makeup Package (برائیڈل میک اپ)",
          category = "Beauty Parlour / سیلون",
          icon = "👰",
          costPrice = 8000.0,
          salePrice = 25000.0,
          currentStock = 50.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "PARL-BRIDAL",
          supplierName = "In-House Salon Service",
          note = "HD makeup, hairstyle, lashes and dupatta setting"
        ),
        InventoryItem(
          id = 8L,
          name = "Whitening Hydra Facial (ہائیڈرا فیشل)",
          category = "Beauty Parlour / سیلون",
          icon = "✨",
          costPrice = 1200.0,
          salePrice = 4500.0,
          currentStock = 80.0,
          unit = "Service",
          lowStockThreshold = 10.0,
          barcode = "PARL-HYDRA",
          supplierName = "Imported Salon Kit",
          note = "Pore cleansing and radiant serum glow"
        ),
        InventoryItem(
          id = 9L,
          name = "Hair Cut & Blow Dry (ہیر کٹ)",
          category = "Beauty Parlour / سیلون",
          icon = "✂️",
          costPrice = 200.0,
          salePrice = 1200.0,
          currentStock = 100.0,
          unit = "Service",
          lowStockThreshold = 10.0,
          barcode = "PARL-CUT",
          supplierName = "Salon Tools",
          note = "Professional styling & blow dry"
        ),
        // Cloth Shop & Boutique Items
        InventoryItem(
          id = 10L,
          name = "Lawn 3-Piece Designer Suit (لان تھری پیس سوٹ)",
          category = "Cloth & Fabric / کپڑے",
          icon = "👗",
          costPrice = 2800.0,
          salePrice = 3800.0,
          currentStock = 45.0,
          unit = "Suit",
          lowStockThreshold = 10.0,
          barcode = "CLOTH-LAWN-3PC",
          supplierName = "Sapphire Wholesale",
          note = "Printed lawn shirt, trouser and dupatta"
        ),
        InventoryItem(
          id = 11L,
          name = "Ladies Suit Stitching (سلائی چارجز لیڈیز)",
          category = "Tailoring / سلائی",
          icon = "🧵",
          costPrice = 700.0,
          salePrice = 1800.0,
          currentStock = 999.0,
          unit = "Service",
          lowStockThreshold = 5.0,
          barcode = "TAILOR-LADIES",
          supplierName = "Master Tailor Unit",
          note = "Custom designer neck and pipen lace work"
        ),
        InventoryItem(
          id = 12L,
          name = "Gents Cotton Unstitched (جنٹس کاٹن سوٹ)",
          category = "Cloth & Fabric / کپڑے",
          icon = "👔",
          costPrice = 1900.0,
          salePrice = 2900.0,
          currentStock = 55.0,
          unit = "Suit",
          lowStockThreshold = 10.0,
          barcode = "CLOTH-GENTS-COT",
          supplierName = "Grace Fabrics",
          note = "4.5 Metres soft wash-and-wear gents fabric"
        ),
        // Medical Store & Pharmacy Items
        InventoryItem(
          id = 13L,
          name = "Panadol 500mg (Box of 200 Tabs) (پیناڈول)",
          category = "Medicines / ادویات",
          icon = "💊",
          costPrice = 580.0,
          salePrice = 680.0,
          currentStock = 50.0,
          unit = "Box",
          lowStockThreshold = 10.0,
          barcode = "MED-PANADOL",
          supplierName = "GSK Distribution",
          note = "Paracetamol 500mg fever and ache relief"
        ),
        InventoryItem(
          id = 14L,
          name = "Digital Blood Pressure Monitor (بی پی مانیٹر)",
          category = "Medical Devices / آلات",
          icon = "🩺",
          costPrice = 3300.0,
          salePrice = 4200.0,
          currentStock = 12.0,
          unit = "Piece",
          lowStockThreshold = 3.0,
          barcode = "MED-BP-MONITOR",
          supplierName = "Certeza Medical",
          note = "Upper arm automatic BP machine"
        ),
        // Mobile & Electronics Items
        InventoryItem(
          id = 15L,
          name = "9D Curved Screen Protector (گلاس پروٹیکٹر)",
          category = "Accessories / موبائل اشیاء",
          icon = "📱",
          costPrice = 120.0,
          salePrice = 350.0,
          currentStock = 120.0,
          unit = "Piece",
          lowStockThreshold = 25.0,
          barcode = "MOB-GLASS-9D",
          supplierName = "Hafeez Centre Wholesaler",
          note = "Edge to edge unbreakable screen guard"
        ),
        InventoryItem(
          id = 16L,
          name = "Fast USB Type-C Charger 33W (فاسٹ چارجر)",
          category = "Accessories / موبائل اشیاء",
          icon = "🔌",
          costPrice = 750.0,
          salePrice = 1250.0,
          currentStock = 35.0,
          unit = "Piece",
          lowStockThreshold = 8.0,
          barcode = "MOB-CHARGER-33W",
          supplierName = "Ronin Distribution",
          note = "Super fast 33W charging adapter"
        )
      )
      dao.insertInventoryItems(initialInventory)

      // Initial Customers
      val initialCustomers = listOf(
        Customer(
          id = 1L,
          name = "Chaudhry Tariq (Wholesale Client)",
          phone = "0300-9876543",
          address = "Shop 14, Commercial Market, Rawalpindi",
          customerType = "Wholesale Client",
          totalBilled = 48500.0,
          totalPaid = 35000.0,
          currentBalance = 13500.0,
          createdDateMillis = now - (15 * oneDay),
          lastInteractionMillis = now - oneDay,
          note = "Regular bulk buyer, payment via Bank/Cash"
        ),
        Customer(
          id = 2L,
          name = "Mrs. Ayesha Khan (Boutique & Salon Client)",
          phone = "0321-5551234",
          address = "House 42, Street 7, F-7/2 Islamabad",
          customerType = "VIP Client",
          totalBilled = 31300.0,
          totalPaid = 31300.0,
          currentBalance = 0.0,
          createdDateMillis = now - (20 * oneDay),
          lastInteractionMillis = now - (2 * oneDay),
          note = "Bridal packages & designer suits customer"
        ),
        Customer(
          id = 3L,
          name = "Haji Muhammad Aslam",
          phone = "0333-8889900",
          address = "Main Bazar, Taxila",
          customerType = "Regular",
          totalBilled = 14200.0,
          totalPaid = 10000.0,
          currentBalance = 4200.0,
          createdDateMillis = now - (10 * oneDay),
          lastInteractionMillis = now - (3 * oneDay),
          note = "Weekly general supplies customer"
        )
      )
      dao.insertCustomers(initialCustomers)

      // Initial Invoices
      val invoice1Items = listOf(
        InvoiceItemEntry(
          itemId = 7L,
          itemName = "Bridal Makeup Package",
          category = "Beauty Parlour / سیلون",
          quantity = 1.0,
          unit = "Service",
          unitPrice = 25000.0,
          total = 25000.0,
          isService = true
        ),
        InvoiceItemEntry(
          itemId = 8L,
          itemName = "Whitening Hydra Facial",
          category = "Beauty Parlour / سیلون",
          quantity = 1.0,
          unit = "Service",
          unitPrice = 4500.0,
          total = 4500.0,
          isService = true
        ),
        InvoiceItemEntry(
          itemId = 11L,
          itemName = "Ladies Suit Stitching (Tailoring)",
          category = "Tailoring / سلائی",
          quantity = 1.0,
          unit = "Service",
          unitPrice = 1800.0,
          total = 1800.0,
          isService = true
        )
      )
      val invoice1ItemsJson = InvoiceItemEntry.toJsonString(invoice1Items)

      val invoice2Items = listOf(
        InvoiceItemEntry(
          itemId = 1L,
          itemName = "Super Basmati Rice 50Kg",
          category = "Grocery / اناج",
          quantity = 50.0,
          unit = "Kg",
          unitPrice = 380.0,
          total = 19000.0,
          isService = false
        ),
        InvoiceItemEntry(
          itemId = 3L,
          itemName = "Cooking Oil 5 Litre Can",
          category = "Oils & Ghee",
          quantity = 4.0,
          unit = "Can",
          unitPrice = 2750.0,
          total = 11000.0,
          isService = false
        ),
        InvoiceItemEntry(
          itemId = 4L,
          itemName = "Sugar White",
          category = "Grocery / اناج",
          quantity = 50.0,
          unit = "Kg",
          unitPrice = 155.0,
          total = 7750.0,
          isService = false
        )
      )
      val invoice2ItemsJson = InvoiceItemEntry.toJsonString(invoice2Items)

      val initialInvoices = listOf(
        Invoice(
          id = 1L,
          invoiceNumber = "INV-1001",
          customerId = 2L,
          customerName = "Mrs. Ayesha Khan (Boutique & Salon Client)",
          customerPhone = "0321-5551234",
          customerAddress = "House 42, F-7/2 Islamabad",
          dateMillis = now - (2 * oneDay),
          itemsJson = invoice1ItemsJson,
          subtotal = 31300.0,
          discountAmount = 0.0,
          taxAmount = 0.0,
          deliveryOrLabour = 0.0,
          grandTotal = 31300.0,
          amountPaid = 31300.0,
          remainingBalance = 0.0,
          paymentStatus = "PAID",
          paymentMethod = "Cash / Bank Transfer",
          businessName = "Arshad Traders & Finance",
          businessPhone = "+92 300 1234567",
          businessAddress = "Main Bazar, Commercial Market",
          businessLogoEmoji = "🏪",
          shopType = "Boutique & Salon",
          note = "Special Bridal & Tailoring Booking"
        ),
        Invoice(
          id = 2L,
          invoiceNumber = "INV-1002",
          customerId = 1L,
          customerName = "Chaudhry Tariq (Wholesale Client)",
          customerPhone = "0300-9876543",
          customerAddress = "Commercial Market, Rawalpindi",
          dateMillis = now - oneDay,
          itemsJson = invoice2ItemsJson,
          subtotal = 37750.0,
          discountAmount = 750.0,
          taxAmount = 0.0,
          deliveryOrLabour = 500.0,
          grandTotal = 37500.0,
          amountPaid = 24000.0,
          remainingBalance = 13500.0,
          paymentStatus = "UNPAID / UDHAR",
          paymentMethod = "Cash + Credit Khata",
          businessName = "Arshad Traders & Finance",
          businessPhone = "+92 300 1234567",
          businessAddress = "Main Bazar, Commercial Market",
          businessLogoEmoji = "🏪",
          shopType = "Wholesale & Retail",
          note = "Remaining Rs. 13,500 due in 10 days"
        )
      )
      dao.insertInvoices(initialInvoices)
    }
  }
}
