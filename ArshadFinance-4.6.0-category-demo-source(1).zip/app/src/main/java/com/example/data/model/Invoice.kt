package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "invoices")
data class Invoice(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,
  val invoiceNumber: String,
  val customerId: Long = 0L,
  val customerName: String,
  val customerPhone: String = "",
  val customerAddress: String = "",
  val dateMillis: Long = System.currentTimeMillis(),
  val itemsJson: String = "[]",
  val subtotal: Double = 0.0,
  val discountAmount: Double = 0.0,
  val taxAmount: Double = 0.0,
  val deliveryOrLabour: Double = 0.0,
  val grandTotal: Double = 0.0,
  val amountPaid: Double = 0.0,
  val remainingBalance: Double = 0.0,
  val paymentStatus: String = "PAID", // "PAID", "PARTIAL", "UNPAID / UDHAR"
  val paymentMethod: String = "Cash", // "Cash", "EasyPaisa", "JazzCash", "Bank Transfer", "Udhar"
  val businessName: String = "",
  val businessPhone: String = "",
  val businessAddress: String = "",
  val businessLogoEmoji: String = "🏪",
  val shopType: String = "General Store",
  val note: String = "",
  val syncWithInventory: Boolean = true,
  @androidx.room.ColumnInfo(defaultValue = "'{}'") val detailsJson: String = "{}"
) {
  fun netTotal():Double=(grandTotal-JSONObject(detailsJson).optDouble("returnedTotal",0.0)).coerceAtLeast(0.0)
  fun parseItems(): List<InvoiceItemEntry> {
    return InvoiceItemEntry.fromJsonString(itemsJson)
  }
}

data class InvoiceItemEntry(
  val itemId: Long? = null,
  val itemName: String,
  val category: String = "General",
  val quantity: Double = 1.0,
  val unit: String = "Piece",
  val unitPrice: Double = 0.0,
  val total: Double = 0.0,
  val isService: Boolean = false
) {
  fun toJson(): JSONObject {
    return JSONObject().apply {
      put("itemId", itemId ?: -1L)
      put("itemName", itemName)
      put("category", category)
      put("quantity", quantity)
      put("unit", unit)
      put("unitPrice", unitPrice)
      put("total", total)
      put("isService", isService)
    }
  }

  companion object {
    fun fromJson(obj: JSONObject): InvoiceItemEntry {
      val rawId = obj.optLong("itemId", -1L)
      return InvoiceItemEntry(
        itemId = if (rawId > 0) rawId else null,
        itemName = obj.optString("itemName", "Item"),
        category = obj.optString("category", "General"),
        quantity = obj.optDouble("quantity", 1.0),
        unit = obj.optString("unit", "Piece"),
        unitPrice = obj.optDouble("unitPrice", 0.0),
        total = obj.optDouble("total", 0.0),
        isService = obj.optBoolean("isService", false)
      )
    }

    fun toJsonString(items: List<InvoiceItemEntry>): String {
      val array = JSONArray()
      items.forEach { array.put(it.toJson()) }
      return array.toString()
    }

    fun fromJsonString(jsonString: String): List<InvoiceItemEntry> {
      val result = mutableListOf<InvoiceItemEntry>()
      try {
        if (jsonString.isNotBlank()) {
          val array = JSONArray(jsonString)
          for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            result.add(fromJson(obj))
          }
        }
      } catch (e: Exception) {
        e.printStackTrace()
      }
      return result
    }
  }
}
