package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bills")
data class Bill(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,
  val title: String,
  val amount: Double,
  val dueDate: String,
  val category: String,
  val icon: String = "📄",
  val isPaid: Boolean = false,
  val isRecurring: Boolean = true
)
