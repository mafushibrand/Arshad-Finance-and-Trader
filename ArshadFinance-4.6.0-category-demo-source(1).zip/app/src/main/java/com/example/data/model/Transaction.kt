package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
  EXPENSE,
  INCOME,
  TRANSFER
}

@Entity(tableName = "transactions")
data class Transaction(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,
  val title: String,
  val amount: Double,
  val type: TransactionType,
  val category: String,
  val icon: String,
  val accountName: String,
  val dateMillis: Long = System.currentTimeMillis(),
  val note: String = "",
  val recipientInfo: String = "",
  val paymentMethod: String = "",
  val receiptImageUri: String = "",
  val transactionRef: String = "",
  @androidx.room.ColumnInfo(defaultValue = "0") val updatedAt: Long = 0L,
  @androidx.room.ColumnInfo(defaultValue = "'local'") val createdBy: String = "local",
  @androidx.room.ColumnInfo(defaultValue = "'main'") val branchId: String = "main"
)
