package com.example

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.business.*
import com.example.data.local.FinanceDatabase
import com.example.data.repository.FinanceRepository
import com.example.data.model.*
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
class TradeEngineTest {
  private fun database()=Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(),FinanceDatabase::class.java).addCallback(BusinessSchema.callback).build()
  @Test fun creditPurchaseGrnAndReturnReconcile()=runBlocking {
    val db=database();try {
      val dao=db.financeDao();val e=TradeEngine(db);val cash=dao.insertAccount(Account(name="Cash",accountType="Cash",balance=1000.0,accountNumber="C"))
      val item=dao.insertInventoryItem(InventoryItem(name="Rice",currentStock=0.0,costPrice=5.0))
      val order=e.purchase("PURCHASE_ORDER","Supplier","PO-1",listOf(TradeLine(item,10.0,10.0)),0.0,0L)
      assertEquals(0.0,dao.getInventoryItemById(item)!!.currentStock,0.0)
      val bill=e.purchase("PURCHASE_BILL","Supplier","BILL-1",tradeLines(order.payload),40.0,cash,sourceId=order.id)
      assertEquals("RECEIVED",db.businessDao().record(order.id)!!.status)
      assertTrue(db.businessDao().allRecords().any {it.kind=="GRN"})
      assertEquals(960.0,dao.getAllAccountsList().single().balance,0.0)
      e.returnPurchase(bill.id,mapOf(0 to 8.0),cash)
      assertEquals(2.0,dao.getInventoryItemById(item)!!.currentStock,0.0)
      assertEquals(980.0,dao.getAllAccountsList().single().balance,0.0)
      val balance=db.businessDao().allRecords().filter {it.party=="Supplier"}.sumOf {if(it.kind=="SUPPLIER_DEBIT")it.amount else if(it.kind=="SUPPLIER_CREDIT")-it.amount else 0.0}
      assertEquals(0.0,balance,0.0)
      val count=db.businessDao().allRecords().size
      assertTrue(runCatching {e.returnPurchase(bill.id,mapOf(0 to 3.0),cash)}.isFailure)
      assertEquals(count,db.businessDao().allRecords().size)
    }finally{db.close()}
  }
  @Test fun partialSaleReturnOffsetsDueBeforeCashAndCannotRepeat()=runBlocking {
    val db=database();try {
      val dao=db.financeDao();val repository=FinanceRepository(dao,db);val e=TradeEngine(db)
      val cash=dao.insertAccount(Account(name="Cash",accountType="Cash",balance=0.0,accountNumber="C"))
      val item=dao.insertInventoryItem(InventoryItem(name="Item",currentStock=10.0,salePrice=10.0))
      val invoice=repository.saveInvoiceAtomically(Invoice(invoiceNumber="R1",customerName="Customer",grandTotal=100.0,subtotal=100.0,amountPaid=40.0),listOf(InvoiceItemEntry(itemId=item,itemName="Item",quantity=10.0,unitPrice=10.0,total=100.0)),true)
      e.returnSale(invoice.id,mapOf(0 to 8.0),cash)
      val saved=dao.getInvoiceById(invoice.id)!!
      assertEquals(20.0,saved.netTotal(),0.0)
      assertEquals(0.0,saved.remainingBalance,0.0);assertEquals(20.0,saved.amountPaid,0.0)
      assertEquals(8.0,dao.getInventoryItemById(item)!!.currentStock,0.0)
      assertEquals(20.0,dao.getAllAccountsList().first {it.id==cash}.balance,0.0)
      assertEquals(0.0,CustomerLedger.balance(db,invoice.customerId),0.0)
      assertTrue(runCatching {e.returnSale(invoice.id,mapOf(0 to 3.0),cash)}.isFailure)
      assertTrue(runCatching {repository.deleteInvoiceAtomically(invoice.id)}.isFailure)
    }finally{db.close()}
  }
  @Test fun warehouseTransfersAndLocationOversellAreAtomic()=runBlocking {
    val db=database();try {
      val dao=db.financeDao();val e=TradeEngine(db);val core=BusinessCore(db);core.create("WAREHOUSE","Secondary","",0.0)
      val item=dao.insertInventoryItem(InventoryItem(name="Item",currentStock=10.0))
      e.transfer(item,7.0,"main","main","main","Secondary")
      assertEquals(10.0,dao.getInventoryItemById(item)!!.currentStock,0.0)
      assertEquals(3.0,db.businessDao().locationStock(item,"main","main"),0.0)
      assertEquals(7.0,db.businessDao().locationStock(item,"main","Secondary"),0.0)
      val repository=FinanceRepository(dao,db)
      val invoice=Invoice(invoiceNumber="W1",customerName="Customer",grandTotal=40.0,amountPaid=0.0)
      assertTrue(runCatching {repository.saveInvoiceAtomically(invoice,listOf(InvoiceItemEntry(itemId=item,itemName="Item",quantity=4.0,unitPrice=10.0,total=40.0)),true)}.isFailure)
      assertEquals(0,dao.getInvoiceCount())
      e.stockCount(item,5.0,"main","Secondary")
      assertEquals(8.0,dao.getInventoryItemById(item)!!.currentStock,0.0)
      assertEquals(8.0,db.businessDao().derivedStock(item),0.0)
    }finally{db.close()}
  }
  @Test fun quotationOrderInvoiceConversionOnlyPostsOnce()=runBlocking {
    val db=database();try {
      val dao=db.financeDao();val e=TradeEngine(db);val customer=dao.insertCustomer(Customer(name="Customer"));val item=dao.insertInventoryItem(InventoryItem(name="Item",currentStock=5.0))
      val quote=e.salesDocument("QUOTATION","Q1",customer,listOf(TradeLine(item,2.0,30.0)),"main","main")
      e.convertSales(quote.id,"ORDER")
      val order=db.businessDao().allRecords().single {it.kind=="ORDER"};e.convertSales(order.id,"INVOICE")
      assertEquals(1,dao.getInvoiceCount());assertEquals(3.0,dao.getInventoryItemById(item)!!.currentStock,0.0)
      assertEquals(60.0,CustomerLedger.balance(db,customer),0.0)
      assertTrue(runCatching {e.convertSales(order.id,"INVOICE")}.isFailure)
    }finally{db.close()}
  }
  @Test fun expiryAndSerialValidationRejectUnsafeStock() {
    assertTrue(runCatching {ItemRules.validateSale(InventoryItem(name="Expired",detailsJson=JSONObject().put("expiry","2000-01-01").toString()),1.0)}.isFailure)
    assertTrue(runCatching {ItemRules.validateSale(InventoryItem(name="Serial",currentStock=2.0,detailsJson=JSONObject().put("imei","123").toString()),2.0)}.isFailure)
    assertEquals(12.35,moneyRound(12.345),0.0)
  }
  @Test fun openingBalanceCreditLimitAndJobBillingAreAtomic()=runBlocking {
    val db=database();try {
      val dao=db.financeDao();val repo=FinanceRepository(dao,db);val e=TradeEngine(db)
      val customer=repo.saveCustomerAtomically(Customer(name="Customer",detailsJson=JSONObject().put("openingBalance",100.0).put("creditLimit",200.0).toString()))
      assertEquals(100.0,CustomerLedger.balance(db,customer.id),0.0)
      assertEquals(100.0,dao.getCustomerById(customer.id)!!.currentBalance,0.0)
      assertTrue(runCatching {repo.saveCustomerAtomically(Customer(name="customer"))}.isFailure)
      val item=dao.insertInventoryItem(InventoryItem(name="Part",currentStock=5.0,salePrice=10.0))
      val job=BusinessCore(db).create("JOB","Repair","Customer",30.0)
      e.billWork(job.id,customer.id,listOf(TradeLine(item,2.0,10.0)),30.0)
      assertEquals(3.0,dao.getInventoryItemById(item)!!.currentStock,0.0)
      assertEquals(150.0,CustomerLedger.balance(db,customer.id),0.0)
      assertTrue(runCatching {e.billWork(job.id,customer.id,emptyList(),30.0)}.isFailure)
      val second=BusinessCore(db).create("JOB","Second","Customer",100.0)
      assertTrue(runCatching {e.billWork(second.id,customer.id,listOf(TradeLine(item,1.0,10.0)),100.0)}.isFailure)
      assertEquals(3.0,dao.getInventoryItemById(item)!!.currentStock,0.0)
      assertEquals("OPEN",db.businessDao().record(second.id)!!.status)
    }finally{db.close()}
  }
  @Test fun recurringDuesCannotBePostedTwiceForSameMonth()=runBlocking {
    val db=database();try {
      val dao=db.financeDao();val customer=dao.insertCustomer(Customer(name="Student"));val work=BusinessCore(db).create("SUBSCRIPTION","Monthly fee","Student",100.0)
      val e=TradeEngine(db);e.billWork(work.id,customer,emptyList(),100.0,"2026-10")
      assertTrue(runCatching {e.billWork(work.id,customer,emptyList(),100.0,"2026-10")}.isFailure)
      e.billWork(work.id,customer,emptyList(),100.0,"2026-11")
      assertEquals(2,dao.getInvoiceCount());assertEquals(200.0,CustomerLedger.balance(db,customer),0.0)
    }finally{db.close()}
  }
  @Test fun supplierPaymentSkipsReturnedBillAndDuplicateLinesCannotOverReturn()=runBlocking {
    val db=database();try {
      val dao=db.financeDao();val e=TradeEngine(db);val cash=dao.insertAccount(Account(name="Cash",accountType="Cash",balance=1000.0,accountNumber="C"))
      val item=dao.insertInventoryItem(InventoryItem(name="Part",currentStock=0.0))
      val a=e.purchase("PURCHASE_BILL","S","A",listOf(TradeLine(item,5.0,10.0),TradeLine(item,5.0,10.0)),0.0,cash)
      e.returnPurchase(a.id,mapOf(0 to 5.0,1 to 5.0),cash)
      val b=e.purchase("PURCHASE_BILL","S","B",listOf(TradeLine(item,10.0,10.0)),0.0,cash)
      BusinessCore(db).supplierEntry("S",50.0,true,"Payment","owner")
      assertEquals(0.0,JSONObject(db.businessDao().record(a.id)!!.payload).optDouble("paid"),0.0)
      assertEquals(50.0,JSONObject(db.businessDao().record(b.id)!!.payload).optDouble("paid"),0.0)
      val c=e.purchase("PURCHASE_BILL","S","C",listOf(TradeLine(item,5.0,10.0),TradeLine(item,5.0,10.0)),0.0,cash)
      e.stockCount(item,7.0,"main","main")
      val before=db.businessDao().allRecords().size
      assertTrue(runCatching {e.returnPurchase(c.id,mapOf(0 to 5.0,1 to 5.0),cash)}.isFailure)
      assertEquals(7.0,dao.getInventoryItemById(item)!!.currentStock,0.0);assertEquals(before,db.businessDao().allRecords().size)
    }finally{db.close()}
  }

  @Test fun schemaSevenUpgradePreservesStockAndCustomerOpeningBalance() {
    val context=ApplicationProvider.getApplicationContext<android.content.Context>()
    val helper=androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context).callback(object:androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(7) {
      override fun onCreate(db:androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE inventory_items(id INTEGER PRIMARY KEY,currentStock REAL NOT NULL,lastUpdatedMillis INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY,currentBalance REAL NOT NULL,createdDateMillis INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY,customerId INTEGER NOT NULL,grandTotal REAL NOT NULL,amountPaid REAL NOT NULL,dateMillis INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY)")
        BusinessSchema.install(db)
        db.execSQL("INSERT INTO inventory_items VALUES(1,7.5,1234)")
        db.execSQL("INSERT INTO customers VALUES(1,150,1234)")
        db.execSQL("INSERT INTO invoices VALUES(1,1,100,40,1234)")
      }
      override fun onUpgrade(db:androidx.sqlite.db.SupportSQLiteDatabase,a:Int,b:Int) {}
    }).build())
    try {
      val sql=helper.writableDatabase;WorkflowSchema.migration.migrate(sql)
      sql.query("SELECT SUM(CASE WHEN kind='CUSTOMER_DEBIT' THEN amount ELSE -amount END) FROM business_records WHERE kind IN ('CUSTOMER_DEBIT','CUSTOMER_CREDIT')").use {assertTrue(it.moveToFirst());assertEquals(150.0,it.getDouble(0),0.0)}
      sql.execSQL("UPDATE stock_context SET reason='SALE',documentId='42',warehouseId='warehouse-b' WHERE id=1")
      sql.execSQL("UPDATE inventory_items SET currentStock=6.25 WHERE id=1")
      sql.query("SELECT quantity,documentId,warehouseId FROM stock_movements ORDER BY rowid DESC LIMIT 1").use {assertTrue(it.moveToFirst());assertEquals(-1.25,it.getDouble(0),0.0);assertEquals("42",it.getString(1));assertEquals("warehouse-b",it.getString(2))}
      sql.query("SELECT SUM(quantity) FROM stock_movements").use {assertTrue(it.moveToFirst());assertEquals(6.25,it.getDouble(0),0.0)}
    }finally {helper.close()}
  }

}
