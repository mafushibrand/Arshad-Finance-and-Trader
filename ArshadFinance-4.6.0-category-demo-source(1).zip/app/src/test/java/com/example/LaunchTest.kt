package com.example

import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class LaunchTest {
  @Test fun mainActivityCanStart() {
    val controller = Robolectric.buildActivity(MainActivity::class.java)
    try {
      controller.setup()
      assertFalse(controller.get().isFinishing)
    } finally { controller.pause().stop().destroy() }
  }
}
