package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.LayoutDirection
import com.example.data.model.AppLanguage
import com.example.ui.FinanceUiState
import com.example.ui.screens.BusinessHomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [35])
class BusinessDesignTest {
  @get:Rule val compose = createComposeRule()

  private fun dashboard(language: AppLanguage) {
    var received = false
    var setup = false
    compose.setContent {
      MyApplicationTheme {
        CompositionLocalProvider(LocalLayoutDirection provides
          if (language == AppLanguage.URDU) LayoutDirection.Rtl else LayoutDirection.Ltr) {
          BusinessHomeScreen(
            uiState = FinanceUiState(appLanguage = language),
            onSendClick = {}, onReceiveClick = { received = true },
            onStockClick = {}, onBillsClick = {}, onFilterSelected = {},
            onSearchQueryChanged = {}, onTransactionClick = {}, onAddNewClick = {},
            onBusinessSetup = { setup = true }
          )
        }
      }
    }
    val urdu = language == AppLanguage.URDU
    compose.onNodeWithText(if (urdu) "وصول کریں" else "Receive").performClick()
    compose.onNodeWithContentDescription(if (urdu) "کاروبار کی ترتیب" else "Business setup").performClick()
    assertTrue("Receive action must remain connected", received)
    assertTrue("Business setup action must remain connected", setup)
    File("build/design-previews").mkdirs()
    compose.onRoot().captureRoboImage(filePath = "build/design-previews/dashboard-${language.name}.png")
  }

  @Test fun englishDashboardRendersAndActionsWork() = dashboard(AppLanguage.ENGLISH)
  @Test fun urduDashboardRendersAndActionsWork() = dashboard(AppLanguage.URDU)
}
