package com.example

import androidx.test.core.app.ApplicationProvider
import android.content.Context
import android.graphics.BitmapFactory
import com.example.data.model.*
import com.example.util.*
import org.junit.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*
import java.io.File
import org.json.JSONArray

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk=[35])
class ReceiptImageTest {
 private fun bill(count:Int=2)=Invoice(id=12,invoiceNumber="INV/001",customerId=1,customerName="Customer / گاہک",
   itemsJson=JSONArray().apply {repeat(count){put(InvoiceItemEntry(itemName="Long item name / لمبا نام "+"wrapped description ".repeat(4),quantity=1.5,unit="kg",unitPrice=100.0,total=150.0).toJson())}}.toString(),subtotal=300.0,taxAmount=54.0,grandTotal=354.0,amountPaid=100.0,remainingBalance=254.0,paymentStatus="PARTIAL")
 @Test fun receiptUsesActualAmountsAndNoInventedTaxToken() {
   val s=ThermalReceiptImage.text(bill(),BusinessProfile(businessName="My shop"),"Rs")
   Assert.assertTrue(s.contains("354.00"));Assert.assertTrue(s.contains("254.00"));Assert.assertTrue(s.contains("INV/001"));Assert.assertFalse(s.contains("FBR-PK"));Assert.assertTrue(s.contains("لمبا نام"))
 }
 @Test fun wrappedLongReceiptHasMeasuredHeightAndPersistsValidPng() {
   val ctx=ApplicationProvider.getApplicationContext<Context>();val profile=BusinessProfile(businessName="My shop")
   val short=ThermalReceiptImage.bitmap(bill(1),profile,"Rs");val long=ThermalReceiptImage.bitmap(bill(30),profile,"Rs")
   Assert.assertTrue(long.height>short.height*2);short.recycle();long.recycle()
   val file=ThermalReceiptImage.file(ctx,bill(),profile,"Rs");Assert.assertTrue(file.path.startsWith(ctx.filesDir.path));Assert.assertFalse(file.name.contains("/001"))
   val decoded=BitmapFactory.decodeFile(file.path);Assert.assertNotNull(decoded);Assert.assertEquals(720,decoded.width);decoded.recycle()
   val preview=File("build/design-previews/thermal-saved-image.png");preview.parentFile!!.mkdirs();file.copyTo(preview,overwrite=true)
 }
 @Test fun whatsappAssetIsTheThermalReceiptAsJpeg() {
   val ctx=ApplicationProvider.getApplicationContext<Context>()
   val image=ThermalReceiptImage.whatsappImageFile(ctx,bill(4),BusinessProfile(businessName="My shop"),"Rs")
   Assert.assertTrue(image.name.endsWith(".jpg"))
   val header=image.inputStream().use { input -> byteArrayOf(input.read().toByte(),input.read().toByte()) }
   Assert.assertArrayEquals(byteArrayOf(0xFF.toByte(),0xD8.toByte()),header)
   val decoded=BitmapFactory.decodeFile(image.path)
   Assert.assertNotNull(decoded)
   Assert.assertEquals(720,decoded.width)
   decoded.recycle()
 }

}
