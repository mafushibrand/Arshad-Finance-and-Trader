package com.example

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.business.*
import com.example.data.local.FinanceDatabase
import com.example.data.model.*
import com.example.data.repository.FinanceRepository
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
class AdvancedWorkflowTest {
  private fun database()=Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(),FinanceDatabase::class.java).addCallback(BusinessSchema.callback).build()
  @Test fun productionIssueWipFinishReturnsUnusedAndCostsWastage()=runBlocking {
    val db=database();try {val dao=db.financeDao();val raw=dao.insertInventoryItem(InventoryItem(name="Flour",currentStock=100.0,costPrice=10.0));val out=dao.insertInventoryItem(InventoryItem(name="Bread",currentStock=0.0));val cash=dao.insertAccount(Account(name="Cash",accountType="Cash",balance=1000.0,accountNumber="C"))
      val bom=BusinessCore(db).create("BOM","Bread recipe","",0.0,JSONObject().put("outputId",out).put("ingredients",JSONArray().put(JSONObject().put("itemId",raw).put("quantity",2.0))).toString())
      val e=AdvancedWorkflowEngine(db);val order=e.planProduction("P1",bom.id,10.0)
      assertEquals(100.0,dao.getInventoryItemById(raw)!!.currentStock,0.0)
      e.issueProduction(order.id);assertEquals("WIP",db.businessDao().record(order.id)!!.status);assertEquals(80.0,dao.getInventoryItemById(raw)!!.currentStock,0.0)
      assertTrue(runCatching {e.issueProduction(order.id)}.isFailure)
      e.finishProduction(order.id,8.0,1.0,20.0,cash)
      assertEquals(82.0,dao.getInventoryItemById(raw)!!.currentStock,0.0);assertEquals(8.0,dao.getInventoryItemById(out)!!.currentStock,0.0);assertEquals(25.0,dao.getInventoryItemById(out)!!.costPrice,0.0)
      assertEquals(980.0,dao.getAllAccountsList().single().balance,0.0);assertEquals("COMPLETED",db.businessDao().record(order.id)!!.status)
      assertTrue(runCatching {e.finishProduction(order.id,1.0,0.0)}.isFailure)
      assertEquals(82.0,db.businessDao().derivedStock(raw),0.0)
    }finally{db.close()}
  }
  @Test fun issueFailureAndCancelPreserveEveryStockPosting()=runBlocking {
    val db=database();try {val d=db.financeDao();val a=d.insertInventoryItem(InventoryItem(name="A",currentStock=10.0,costPrice=2.0));val b=d.insertInventoryItem(InventoryItem(name="B",currentStock=1.0,costPrice=3.0));val out=d.insertInventoryItem(InventoryItem(name="Output"));val bom=BusinessCore(db).create("BOM","Recipe","",0.0,JSONObject().put("outputId",out).put("ingredients",JSONArray().put(JSONObject().put("itemId",a).put("quantity",1.0)).put(JSONObject().put("itemId",b).put("quantity",1.0))).toString());val e=AdvancedWorkflowEngine(db);val order=e.planProduction("Fail",bom.id,2.0)
      val count=db.businessDao().allMovements().size;assertTrue(runCatching {e.issueProduction(order.id)}.isFailure);assertEquals(count,db.businessDao().allMovements().size);assertEquals(10.0,d.getInventoryItemById(a)!!.currentStock,0.0)
      val next=e.planProduction("Cancel",bom.id,1.0);e.issueProduction(next.id);e.cancelProduction(next.id);assertEquals(10.0,d.getInventoryItemById(a)!!.currentStock,0.0);assertEquals(1.0,d.getInventoryItemById(b)!!.currentStock,0.0);assertTrue(runCatching {e.cancelProduction(next.id)}.isFailure)
    }finally{db.close()}
  }
  @Test fun missingOverheadAccountRollsBackOutputAndWip()=runBlocking {
    val db=database();try {val d=db.financeDao();val raw=d.insertInventoryItem(InventoryItem(name="Raw",currentStock=10.0,costPrice=2.0));val out=d.insertInventoryItem(InventoryItem(name="Output"));val bom=BusinessCore(db).create("BOM","Recipe","",0.0,JSONObject().put("outputId",out).put("ingredients",JSONArray().put(JSONObject().put("itemId",raw).put("quantity",1.0))).toString());val e=AdvancedWorkflowEngine(db);val order=e.planProduction("P",bom.id,5.0);e.issueProduction(order.id)
      assertTrue(runCatching {e.finishProduction(order.id,4.0,0.0,10.0,999)}.isFailure);assertEquals("WIP",db.businessDao().record(order.id)!!.status);assertEquals(5.0,d.getInventoryItemById(raw)!!.currentStock,0.0);assertEquals(0.0,d.getInventoryItemById(out)!!.currentStock,0.0)
    }finally{db.close()}
  }
  @Test fun appointmentsRejectOverlapButAllowAdjacentAndRescheduling()=runBlocking {
    val db=database();try {val customer=db.financeDao().insertCustomer(Customer(name="Client"));val e=AdvancedWorkflowEngine(db);val start=1800000000000L
      val a=e.bookAppointment("Consultation",customer,"Staff",start,start+3600000,50.0)
      assertTrue(runCatching {e.bookAppointment("Conflict",customer,"staff",start+1000,start+7200000,50.0)}.isFailure)
      e.bookAppointment("Next",customer,"Staff",start+3600000,start+7200000,50.0)
      e.bookAppointment("Other",customer,"Other Staff",start,start+3600000,50.0)
      e.bookAppointment("Moved",customer,"Staff",start-3600000,start,50.0,id=a.id);assertEquals("Moved",db.businessDao().record(a.id)!!.title)
      e.cancelAppointment(a.id);assertTrue(runCatching {e.bookAppointment("Invalid",customer,"Staff",start,start,0.0)}.isFailure)
    }finally{db.close()}
  }
  @Test fun rentalDepositRefundDoesNotDoubleCountCashOrSales()=runBlocking {
    val db=database();try {val d=db.financeDao();val customer=d.insertCustomer(Customer(name="Client"));val item=d.insertInventoryItem(InventoryItem(name="Asset",currentStock=3.0));val cash=d.insertAccount(Account(name="Cash",accountType="Cash",balance=100.0,accountNumber="C"));val e=AdvancedWorkflowEngine(db);val start=1800000000000L
      val rental=e.issueRental("R1",item,1.0,customer,start,start+86400000,50.0,20.0,100.0,cash)
      assertEquals(200.0,d.getAllAccountsList().single().balance,0.0);assertEquals(2.0,d.getInventoryItemById(item)!!.currentStock,0.0);assertEquals(0,d.getInvoiceCount())
      e.returnRental(rental.id,1.0,0.0,cash,start+86400000)
      assertEquals(150.0,d.getAllAccountsList().single().balance,0.0);assertEquals(3.0,d.getInventoryItemById(item)!!.currentStock,0.0);assertEquals(0.0,CustomerLedger.balance(db,customer),0.0)
      val invoice=d.getInvoiceById(JSONObject(db.businessDao().record(rental.id)!!.payload).getLong("invoiceId"))!!;assertEquals(50.0,invoice.grandTotal,0.0);assertEquals(50.0,invoice.amountPaid,0.0)
      assertTrue(runCatching {e.returnRental(rental.id,1.0,0.0,cash,start+86400000)}.isFailure);assertTrue(runCatching {FinanceRepository(d,db).deleteInvoiceAtomically(invoice.id)}.isFailure)
      val liability=db.businessDao().allRecords().sumOf {when(it.kind){"RENTAL_DEPOSIT"->it.amount;"RENTAL_DEPOSIT_APPLIED","RENTAL_DEPOSIT_REFUND"->-it.amount;else->0.0}};assertEquals(0.0,liability,0.0)
    }finally{db.close()}
  }
  @Test fun lateRentalDamageAndCreditLimitFailureRollBackReturn()=runBlocking {
    val db=database();try {val d=db.financeDao();val customer=FinanceRepository(d,db).saveCustomerAtomically(Customer(name="Client",detailsJson=JSONObject().put("creditLimit",10.0).toString()));val item=d.insertInventoryItem(InventoryItem(name="Asset",currentStock=3.0));val cash=d.insertAccount(Account(name="Cash",accountType="Cash",balance=0.0,accountNumber="C"));val e=AdvancedWorkflowEngine(db);val start=1800000000000L;val r=e.issueRental("R",item,2.0,customer.id,start,start+86400000,50.0,20.0,100.0,cash)
      assertTrue(runCatching {e.returnRental(r.id,1.0,10.0,cash,start+86400001)}.isFailure);assertEquals("ACTIVE",db.businessDao().record(r.id)!!.status);assertEquals(1.0,d.getInventoryItemById(item)!!.currentStock,0.0);assertEquals(0,d.getInvoiceCount());assertEquals(100.0,d.getAllAccountsList().single().balance,0.0)
      FinanceRepository(d,db).saveCustomerAtomically(customer.copy(detailsJson=JSONObject().put("creditLimit",1000.0).toString()));e.returnRental(r.id,1.0,10.0,cash,start+86400001);assertEquals(50.0,CustomerLedger.balance(db,customer.id),0.0);assertEquals(2.0,d.getInventoryItemById(item)!!.currentStock,0.0)
    }finally{db.close()}
  }
  @Test fun cancellationRestoresOriginalIssueCostAfterNewPurchases()=runBlocking {
    val db=database();try {val d=db.financeDao();val raw=d.insertInventoryItem(InventoryItem(name="Raw",currentStock=10.0,costPrice=10.0));val out=d.insertInventoryItem(InventoryItem(name="Output"));val bom=BusinessCore(db).create("BOM","Recipe","",0.0,JSONObject().put("outputId",out).put("ingredients",JSONArray().put(JSONObject().put("itemId",raw).put("quantity",1.0))).toString());val e=AdvancedWorkflowEngine(db);val order=e.planProduction("P",bom.id,5.0);e.issueProduction(order.id)
      d.updateInventoryItem(d.getInventoryItemById(raw)!!.copy(currentStock=10.0,costPrice=20.0));e.cancelProduction(order.id)
      assertEquals(15.0,d.getInventoryItemById(raw)!!.currentStock,0.0);assertEquals(250.0/15.0,d.getInventoryItemById(raw)!!.costPrice,0.000001)
    }finally{db.close()}
  }
  @Test fun sixDemoTemplatesHaveExecutableWorkflowRecords()=runBlocking {
    for(template in listOf("kiryana","pharmacy","garments","workshop","restaurant","food_factory")) {
      val db=database();try {db.financeDao().insertInventoryItems(DemoLibrary.items(template));DemoLibrary.workflows(db,template)
        val records=db.businessDao().allRecords();assertTrue(records.any {it.kind=="SUPPLIER"})
        when(template){"restaurant","food_factory"->{val order=records.single {it.kind=="PRODUCTION_ORDER"};AdvancedWorkflowEngine(db).issueProduction(order.id);AdvancedWorkflowEngine(db).finishProduction(order.id,9.0,1.0)};"workshop"->assertTrue(records.any {it.kind=="JOB"});else->assertTrue(records.any {it.kind=="QUOTATION"})}
      }finally{db.close()}
    }
  }
  @Test fun encryptedBackupRestoresActiveWipAndDepositLiability()=runBlocking {
    val db=database();try {val d=db.financeDao();val customer=d.insertCustomer(Customer(name="Client"));val cash=d.insertAccount(Account(name="Cash",accountType="Cash",balance=0.0,accountNumber="C"));val raw=d.insertInventoryItem(InventoryItem(name="Raw",currentStock=10.0,costPrice=10.0));val out=d.insertInventoryItem(InventoryItem(name="Output"));val asset=d.insertInventoryItem(InventoryItem(name="Rental",currentStock=2.0));val bom=BusinessCore(db).create("BOM","Recipe","",0.0,JSONObject().put("outputId",out).put("ingredients",JSONArray().put(JSONObject().put("itemId",raw).put("quantity",1.0))).toString());val e=AdvancedWorkflowEngine(db);val order=e.planProduction("P",bom.id,2.0);e.issueProduction(order.id);val r=e.issueRental("R",asset,1.0,customer,1800000000000,1800086400000,20.0,10.0,50.0,cash)
      val context=ApplicationProvider.getApplicationContext<android.content.Context>();val data=com.example.data.local.BusinessBackup.snapshot(context,db);val bytes=com.example.data.local.BusinessBackup.encrypt(data,"testing123".toCharArray());com.example.data.local.BusinessBackup.restore(context,db,com.example.data.local.BusinessBackup.decrypt(bytes,"testing123".toCharArray()))
      assertEquals("WIP",db.businessDao().record(order.id)!!.status);assertEquals("ACTIVE",db.businessDao().record(r.id)!!.status);assertEquals(50.0,d.getAllAccountsList().single().balance,0.0);assertEquals(8.0,d.getInventoryItemById(raw)!!.currentStock,0.0);assertEquals(1.0,db.businessDao().locationStock(asset,"main","main"),0.0)
      e.cancelProduction(order.id);e.returnRental(r.id,1.0,0.0,cash,1800086400000);assertEquals(20.0,d.getAllAccountsList().single().balance,0.0)
    }finally{db.close()}
  }
  @Test fun activeWorkflowItemsAndCustomersCannotBeDeleted()=runBlocking {
    val db=database();try {val d=db.financeDao();val c=d.insertCustomer(Customer(name="Client"));val item=d.insertInventoryItem(InventoryItem(name="Asset",currentStock=2.0));val e=AdvancedWorkflowEngine(db);e.issueRental("R",item,1.0,c,1800000000000,1800086400000,0.0,0.0,0.0,0)
      val repo=FinanceRepository(d,db);assertTrue(runCatching {repo.deleteInventoryItem(d.getInventoryItemById(item)!!)}.isFailure);assertTrue(runCatching {repo.deleteCustomer(d.getCustomerById(c)!!)}.isFailure)
    }finally{db.close()}
  }

  @Test fun itemReturnsUseExactLineAndHistoricalCost()=runBlocking {
    val db=database();try {val d=db.financeDao();val a=d.insertInventoryItem(InventoryItem(name="A",currentStock=10.0,costPrice=5.0));val b=d.insertInventoryItem(InventoryItem(name="B",currentStock=10.0,costPrice=10.0));val repo=FinanceRepository(d,db)
      val invoice=repo.saveInvoiceAtomically(Invoice(invoiceNumber="R",customerName="Client",grandTotal=100.0),listOf(InvoiceItemEntry(itemId=a,itemName="A",quantity=2.0,unitPrice=10.0,total=20.0),InvoiceItemEntry(itemId=b,itemName="B",quantity=4.0,unitPrice=20.0,total=80.0)),true)
      d.updateInventoryItem(d.getInventoryItemById(a)!!.copy(costPrice=50.0));TradeEngine(db).returnSale(invoice.id,mapOf(0 to 2.0),0)
      val saved=d.getInvoiceById(invoice.id)!!;val lines=netInvoiceLines(saved,db.businessDao().allRecords()){999.0}
      assertEquals(0.0,lines[0].revenue,0.0);assertEquals(80.0,lines[1].revenue,0.0);assertEquals(40.0,lines[1].cost,0.0);assertEquals(0.0,lines[0].cost,0.0)
      assertEquals(41.0,d.getInventoryItemById(a)!!.costPrice,0.000001)
    }finally{db.close()}
  }

}
