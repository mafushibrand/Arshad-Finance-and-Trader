package com.example

import com.example.business.*
import com.example.data.model.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
class SubscriptionPolicyTest {
  private val now=1800000000000L
  private fun token(name:String)=javaClass.classLoader!!.getResourceAsStream("entitlements/$name.aflicense")!!.bufferedReader().readText()
  @Test fun trialStartsOnceAndExpiresAtExactThirtyDays() {
    val initial=SubscriptionState(deviceId="test-device")
    assertFalse(SubscriptionPolicy.allowed(initial,now))
    val started=initial.copy(trialStartedMillis=now,lastSeenMillis=now)
    assertTrue(SubscriptionPolicy.allowed(started,now));assertEquals(30L,SubscriptionPolicy.remainingDays(started,now))
    assertTrue(SubscriptionPolicy.allowed(started,now+30*SubscriptionPolicy.DAY-1))
    assertFalse(SubscriptionPolicy.allowed(started,now+30*SubscriptionPolicy.DAY));assertEquals(0L,SubscriptionPolicy.remainingDays(started,now+30*SubscriptionPolicy.DAY))
  }
  @Test fun legacyUnlockedDefaultsCannotActivateBusiness() {
    val legacy=SubscriptionState(isActivated=true,activationCode="ARSHAD-PRO-LIFETIME",expiryDateMillis=now+365*SubscriptionPolicy.DAY)
    val refreshed=SubscriptionPolicy.refresh(legacy,now)
    assertFalse(refreshed.isActivated);assertFalse(SubscriptionPolicy.allowed(refreshed,now))
    listOf("ARSHAD-anything","LIFETIME-PRO","PAK-KHATA-2026","anything=").forEach {assertTrue(runCatching {SubscriptionPolicy.activate(legacy,it,now)}.isFailure)}
  }
  @Test fun monthlyAndYearlySignedLicensesUnlockCorrectPhone() {
    listOf("monthly" to "MONTHLY","yearly" to "YEARLY").forEach {(fixture,plan)->
      val active=SubscriptionPolicy.activate(SubscriptionState(deviceId="test-device"),token(fixture),now)
      assertTrue(SubscriptionPolicy.allowed(active,now));assertEquals(plan,active.plan)
      assertFalse(SubscriptionPolicy.allowed(active,active.expiryDateMillis))
      assertFalse(SubscriptionPolicy.allowed(SubscriptionPolicy.refresh(active,active.expiryDateMillis),active.expiryDateMillis))
    }
  }
  @Test fun wrongDeviceTamperedAndExpiredActivationAreRejected() {
    val valid=token("monthly")
    assertTrue(runCatching {SubscriptionPolicy.activate(SubscriptionState(deviceId="another-device"),valid,now)}.isFailure)
    val parts=valid.split('.');val sig=parts[2];val bad=parts[0]+"."+parts[1]+"."+(if(sig[0]=='A')"B" else "A")+sig.drop(1)
    assertTrue(runCatching {SubscriptionPolicy.activate(SubscriptionState(deviceId="test-device"),bad,now)}.isFailure)
    assertTrue(runCatching {SubscriptionPolicy.activate(SubscriptionState(deviceId="test-device"),valid,now+40*SubscriptionPolicy.DAY)}.isFailure)
  }
  @Test fun clockRollbackBlocksTrialAndPaidAccess() {
    val trial=SubscriptionState(trialStartedMillis=now,lastSeenMillis=now+SubscriptionPolicy.DAY)
    assertFalse(SubscriptionPolicy.allowed(trial,now));assertTrue(SubscriptionPolicy.refresh(trial,now).clockBlocked)
    val paid=SubscriptionPolicy.activate(SubscriptionState(deviceId="test-device"),token("monthly"),now)
    assertFalse(SubscriptionPolicy.allowed(paid.copy(lastSeenMillis=now+SubscriptionPolicy.DAY),now))
  }
  @Test fun correctingClockRestoresExistingSignedPaidToken() {
    val paid=SubscriptionPolicy.activate(SubscriptionState(deviceId="test-device"),token("monthly"),now)
    val blocked=SubscriptionPolicy.refresh(paid.copy(lastSeenMillis=now+SubscriptionPolicy.DAY),now)
    assertFalse(SubscriptionPolicy.allowed(blocked,now))
    val restored=SubscriptionPolicy.refresh(blocked,now+SubscriptionPolicy.DAY)
    assertTrue(SubscriptionPolicy.allowed(restored,now+SubscriptionPolicy.DAY))
  }
  @Test fun expiredPaidPeriodNeverFallsBackToOldTrial() {
    val state=SubscriptionState(trialStartedMillis=now,hasPaidBefore=true)
    assertFalse(SubscriptionPolicy.allowed(state,now+SubscriptionPolicy.DAY));assertEquals(0L,SubscriptionPolicy.remainingDays(state,now))
  }
  @Test fun signedMerchantSetupAndPricingAreVerified() {
    assertEquals("merchant",SubscriptionPolicy.merchant(token("merchant")).getString("type"))
    assertTrue(runCatching {SubscriptionPolicy.merchant(token("monthly"))}.isFailure)
    assertEquals(600,SubscriptionPolicy.MONTHLY*12-SubscriptionPolicy.YEARLY)
    assertEquals("16.67%",SubscriptionPolicy.YEAR_DISCOUNT)
  }
}
