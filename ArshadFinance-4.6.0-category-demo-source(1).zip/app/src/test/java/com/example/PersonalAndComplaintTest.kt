package com.example

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.business.*
import com.example.data.local.FinanceDatabase
import com.example.data.model.*
import com.example.data.repository.FinanceRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
class PersonalAndComplaintTest {
  private fun database()=Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(),FinanceDatabase::class.java).addCallback(BusinessSchema.callback).build()
  @Test fun personalLedgerDoesNotTouchShopStockInvoicesOrCash()=runBlocking {
    val db=database();try {
      val d=db.financeDao();d.insertAccount(Account(name="Cash",accountType="Cash",balance=500.0,accountNumber="C"));val item=d.insertInventoryItem(InventoryItem(name="Shop item",currentStock=12.0))
      val e=PersonalKhataEngine(db);val contact=e.contact("Friend","");e.entry(contact.id,100.0,"GAVE","");e.entry(contact.id,40.0,"RECEIVED","")
      assertEquals(60.0,PersonalKhataEngine.balance(db.businessDao().allRecords(),contact.id),0.0)
      assertEquals(12.0,d.getInventoryItemById(item)!!.currentStock,0.0);assertEquals(500.0,d.getAllAccountsList().single().balance,0.0);assertEquals(0,d.getInvoiceCount())
      assertTrue(runCatching {e.contact("friend","")}.isFailure)
      assertTrue(runCatching {e.entry(contact.id,Double.NaN,"GAVE","")}.isFailure)
      assertTrue(runCatching {e.entry("missing",20.0,"GAVE","")}.isFailure)
    }finally{db.close()}
  }
  @Test fun complaintIntakeHasNoFinancialEffectAndRefundPostsOnce()=runBlocking {
    val db=database();try {
      val d=db.financeDao();val cash=d.insertAccount(Account(name="Cash",accountType="Cash",balance=0.0,accountNumber="C"));val item=d.insertInventoryItem(InventoryItem(name="Item",currentStock=10.0))
      val invoice=FinanceRepository(d,db).saveInvoiceAtomically(Invoice(invoiceNumber="C1",customerName="Customer",grandTotal=100.0,subtotal=100.0,amountPaid=100.0),listOf(InvoiceItemEntry(itemId=item,itemName="Item",quantity=10.0,unitPrice=10.0,total=100.0)),true)
      val e=TradeEngine(db);val complaint=e.complaintReturn(invoice.id,"Damaged product")
      assertEquals(0.0,d.getInventoryItemById(item)!!.currentStock,0.0);assertEquals(100.0,d.getAllAccountsList().single().balance,0.0)
      assertTrue(runCatching {e.settleComplaint(complaint.id,mapOf(0 to 11.0),cash,false)}.isFailure);assertEquals("OPEN",db.businessDao().record(complaint.id)!!.status)
      e.settleComplaint(complaint.id,mapOf(0 to 10.0),cash,false)
      assertEquals("REFUNDED",db.businessDao().record(complaint.id)!!.status);assertEquals(0.0,d.getAllAccountsList().single().balance,0.0);assertEquals(0.0,d.getInventoryItemById(item)!!.currentStock,0.0)
      assertTrue(runCatching {e.settleComplaint(complaint.id,mapOf(0 to 1.0),cash,true)}.isFailure)
    }finally{db.close()}
  }
  @Test fun complaintCanCloseWithoutRefund()=runBlocking {
    val db=database();try {
      val invoice=FinanceRepository(db.financeDao(),db).saveInvoiceAtomically(Invoice(invoiceNumber="C2",customerName="Customer",grandTotal=10.0),listOf(InvoiceItemEntry(itemName="Service",quantity=1.0,unitPrice=10.0,total=10.0,isService=true)),false)
      val e=TradeEngine(db);val c=e.complaintReturn(invoice.id,"Question about service");e.closeComplaint(c.id,"Explained to customer")
      assertEquals("RESOLVED_NO_REFUND",db.businessDao().record(c.id)!!.status);assertTrue(db.businessDao().allRecords().none {it.kind=="SALES_RETURN"})
    }finally{db.close()}
  }
}
