package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.room.Room
import com.example.data.local.*
import com.example.data.model.*
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.flow.first
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class BackupTest {
  @Test fun encryptedBackupRoundTripPreservesRecords() = runTest {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, FinanceDatabase::class.java).allowMainThreadQueries().build()
    try {
      db.financeDao().insertAccount(Account(id = 1, name = "Cash", accountType = "Cash", balance = 300.0, accountNumber = "CASH"))
      db.financeDao().insertInventoryItem(InventoryItem(id = 1, name = "چاول", currentStock = 50.0))
      BusinessPreferences(context).write("features", BusinessFeatures(services = false))
      val data = BusinessBackup.snapshot(context, db)
      val encrypted = BusinessBackup.encrypt(data, "testing123".toCharArray())
      assertFalse(encrypted.toString(Charsets.UTF_8).contains("چاول"))
      db.financeDao().deleteAllInventoryItems()
      BusinessBackup.restore(context, db, BusinessBackup.decrypt(encrypted, "testing123".toCharArray()))
      assertEquals("چاول", db.financeDao().getAllInventoryItems().first().single().name)
      assertEquals(300.0, db.financeDao().getAllAccountsList().single().balance, 0.001)
      assertFalse(BusinessPreferences(context).read("features", BusinessFeatures()).services)
    } finally { db.close() }
  }
  @Test fun wrongPasswordAndTamperingAreRejected() = runTest {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, FinanceDatabase::class.java).allowMainThreadQueries().build()
    try {
      val encrypted = BusinessBackup.encrypt(BusinessBackup.snapshot(context, db), "testing123".toCharArray())
      try { BusinessBackup.decrypt(encrypted, "wrongpass".toCharArray()); fail("Wrong password accepted") } catch (_: Exception) { }
      encrypted[encrypted.lastIndex] = (encrypted.last().toInt() xor 1).toByte()
      try { BusinessBackup.decrypt(encrypted, "testing123".toCharArray()); fail("Tampered backup accepted") } catch (_: Exception) { }
      assertEquals(0, db.financeDao().getInventoryCount())
    } finally { db.close() }
  }
}
