package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.LayoutDirection
import com.example.data.model.*
import com.example.ui.FinanceUiState
import com.example.ui.dialogs.*
import com.example.ui.screens.*
import com.example.business.*
import com.example.ui.theme.MyApplicationTheme
import com.example.util.BusinessProfile
import com.github.takahirom.roborazzi.captureRoboImage
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*
import java.io.File

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers=RobolectricDeviceQualifiers.Pixel8,sdk=[35])
class ExpandedDesignTest {
  @get:Rule val compose=createComposeRule()
  private fun screen(route:String,urdu:Boolean) {
    val language=if(urdu)AppLanguage.URDU else AppLanguage.ENGLISH
    val item=InventoryItem(id=1,name="Rice",currentStock=40.0,salePrice=200.0,costPrice=150.0,unit="kg")
    compose.setContent {MyApplicationTheme {CompositionLocalProvider(LocalLayoutDirection provides if(urdu)LayoutDirection.Rtl else LayoutDirection.Ltr) {
      val state=FinanceUiState(appLanguage=language,inventoryItems=listOf(item),customers=listOf(Customer(id=1,name="Customer")),accounts=listOf(Account(id=1,name="Cash",accountType="Cash",balance=0.0,accountNumber="C")))
      when(route) {
        "purchase-document" -> TradeDocumentForm("PURCHASE_BILL",state,dismiss={},submit={_,_,_,_,_,_,_,_->})
        "complaint-return" -> ComplaintReturnForm(state,{}, {_,_->})
        "return-document" -> ReturnDocumentForm("SALES_RETURN",state,{}, {_,_,_,_->})
        "transfer-document" -> StockLocationForm("TRANSFER",state,{}, {_,_,_,_,_,_->})
        "work-billing" -> WorkBillingForm(BusinessRecord(kind="JOB",title="Repair job",amount=500.0),state,{}, {_,_,_,_->})
        "product-form" -> AddEditInventoryDialog(appLanguage=language,templateId="pharmacy",onDismiss={},onSave={_,_,_,_,_,_,_,_,_,_,_,_->})
        "customer-form" -> AddCustomerDialog(onSaveCustomer={},onDismiss={},appLanguage=language)
        "expense-form" -> AddTransactionDialog(TransactionType.EXPENSE,listOf(Account(name="Cash",accountType="Cash",balance=0.0,accountNumber="CASH")),"Rs",{}, {_,_,_,_,_,_,_,_,_,_,_->},language)
        "service-form" -> AddEditServiceDialog(null,urdu,"Rs",{}, {})
        "profile-form" -> ShopProfileDialog(BusinessProfile(businessName="My Business"),{}, {},language)
        "stock-form" -> QuickStockAdjustDialog(item,"Rs",{}, {_,_->}, {_,_->},language)
        "invoice-form" -> AddEditInvoiceDialog(BusinessProfile(businessName="My Business"),emptyList(),listOf(item),onSaveInvoice={_,_,_,_->},onDismiss={},appLanguage=language)
        "production-plan" -> AdvancedCreateForm("PRODUCTION_ORDER",state,null,{}, {})
        "rental-issue" -> AdvancedCreateForm("RENTAL_CONTRACT",state,null,{}, {})
        "appointment-book" -> AdvancedCreateForm("APPOINTMENT",state,null,{}, {})
        "production-finish" -> AdvancedSettlementForm(BusinessRecord(kind="PRODUCTION_ORDER",title="Production",payload="{\"plannedQuantity\":10}"),state,{}, {_,_,_,_,_->})
        "rental-return" -> AdvancedSettlementForm(BusinessRecord(kind="RENTAL_CONTRACT",title="Rental",payload="{\"quantity\":1}"),state,{}, {_,_,_,_,_->})
        "builder" -> BusinessBuilderDialog(FinanceUiState(appLanguage=language,businessProfile=BusinessProfile(businessName="My Business")),onSave={_,_,_->},onDismiss={})
      }
    }}}
    compose.waitForIdle()
    val dir=File("build/design-previews").apply{mkdirs()}
    compose.onRoot().captureRoboImage(filePath=File(dir,"$route-${if(urdu)"URDU" else "ENGLISH"}.png").absolutePath)
  }
  @Test fun productEn()=screen("product-form",false)
  @Test fun productUr()=screen("product-form",true)
  @Test fun customerEn()=screen("customer-form",false)
  @Test fun customerUr()=screen("customer-form",true)
  @Test fun expenseEn()=screen("expense-form",false)
  @Test fun expenseUr()=screen("expense-form",true)
  @Test fun serviceEn()=screen("service-form",false)
  @Test fun serviceUr()=screen("service-form",true)
  @Test fun profileEn()=screen("profile-form",false)
  @Test fun profileUr()=screen("profile-form",true)
  @Test fun stockEn()=screen("stock-form",false)
  @Test fun stockUr()=screen("stock-form",true)
  @Test fun invoiceEn()=screen("invoice-form",false)
  @Test fun invoiceUr()=screen("invoice-form",true)
  @Test fun builderEn()=screen("builder",false)
  @Test fun builderUr()=screen("builder",true)
  @Test fun purchaseEn()=screen("purchase-document",false)
  @Test fun purchaseUr()=screen("purchase-document",true)
  @Test fun complaintEn()=screen("complaint-return",false)
  @Test fun complaintUr()=screen("complaint-return",true)
  @Test fun returnEn()=screen("return-document",false)
  @Test fun returnUr()=screen("return-document",true)
  @Test fun transferEn()=screen("transfer-document",false)
  @Test fun transferUr()=screen("transfer-document",true)
  @Test fun billingEn()=screen("work-billing",false)
  @Test fun billingUr()=screen("work-billing",true)

  @Test fun productionPlanEn()=screen("production-plan",false)
  @Test fun productionPlanUr()=screen("production-plan",true)
  @Test fun rentalIssueEn()=screen("rental-issue",false)
  @Test fun rentalIssueUr()=screen("rental-issue",true)
  @Test fun appointmentBookEn()=screen("appointment-book",false)
  @Test fun appointmentBookUr()=screen("appointment-book",true)
  @Test fun productionFinishEn()=screen("production-finish",false)
  @Test fun productionFinishUr()=screen("production-finish",true)
  @Test fun rentalReturnEn()=screen("rental-return",false)
  @Test fun rentalReturnUr()=screen("rental-return",true)
}
