package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.LayoutDirection
import com.example.data.model.*
import com.example.ui.FinanceUiState
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*
import java.io.File

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [35])
class InternalDesignTest {
  @get:Rule val compose = createComposeRule()
  private fun screen(route: String, urdu: Boolean) {
    var added = false
    val state = FinanceUiState(appLanguage = if (urdu) AppLanguage.URDU else AppLanguage.ENGLISH,
      inventoryItems = listOf(InventoryItem(id = 1, name = "Rice / چاول", category = "Grocery", salePrice = 180.0, costPrice = 150.0, currentStock = 50.0, unit = "Kg")),
      services = listOf(ServiceItem(id = 1, name = "Hair cutting", urduName = "ہیئر کٹنگ", businessCategory = "SALON", serviceType = "Hair", price = 500.0)),
      customers = listOf(Customer(id = 1, name = "Ahmed Khan", phone = "03001234567", currentBalance = 12500.0)),
      accounts = listOf(Account(id = 1, name = "Cash", accountType = "Cash", balance = 2000.0, accountNumber = "CASH")))
    compose.setContent { MyApplicationTheme { CompositionLocalProvider(LocalLayoutDirection provides if (urdu) LayoutDirection.Rtl else LayoutDirection.Ltr) {
      when (route) {
        "products" -> InventoryScreen(state, { added = true }, {}, {}, {}, {})
        "services" -> ServicesScreen(state, {}, {}, { _, _, _ -> }, {}, {}, {}, {})
        "khata" -> BillingScreen(state, {}, {}, {}, {}, {}, {}, {}, {}, {}, {})
        "cash" -> CardsScreen(state, {}, {})
        "reports" -> StatsScreen(state, {})
        "settings" -> SettingsScreen(state, {}, {}, onOpenIndustryCatalog = {}, onLoadDemoData = {}, onResetData = {})
        "pos" -> PosCounterScreen(state, { _, _, _, _ -> }, {})
        "welcome" -> LoginScreen(UserAccount(), state.appLanguage, {}, { _, _, _, _ -> })
        "types" -> ModeSelectionScreen(AppMode.BUSINESS_RETAIL, state.appLanguage, {})
        "purchases" -> PurchasesScreen(state, {})
      }
    } } }
    compose.waitForIdle()
    val directory = File("build/design-previews").apply { mkdirs() }
    compose.onRoot().captureRoboImage(filePath = File(directory, "$route-${if (urdu) "URDU" else "ENGLISH"}.png").absolutePath)
    if (route == "products") { compose.onNodeWithText(if (urdu) "نیا سامان شامل کریں" else "Add New Product").performClick(); assertTrue(added) }
  }
  @Test fun productsEnglish() = screen("products", false)
  @Test fun productsUrdu() = screen("products", true)
  @Test fun servicesEnglish() = screen("services", false)
  @Test fun servicesUrdu() = screen("services", true)
  @Test fun khataEnglish() = screen("khata", false)
  @Test fun khataUrdu() = screen("khata", true)
  @Test fun cashEnglish() = screen("cash", false)
  @Test fun cashUrdu() = screen("cash", true)
  @Test fun reportsEnglish() = screen("reports", false)
  @Test fun reportsUrdu() = screen("reports", true)
  @Test fun settingsEnglish() = screen("settings", false)
  @Test fun settingsUrdu() = screen("settings", true)
  @Test fun posEnglish() = screen("pos", false)
  @Test fun posUrdu() = screen("pos", true)
  @Test fun welcomeEnglish() = screen("welcome", false)
  @Test fun welcomeUrdu() = screen("welcome", true)
  @Test fun businessTypeEnglish() = screen("types", false)
  @Test fun businessTypeUrdu() = screen("types", true)
  @Test fun purchasesEnglish() = screen("purchases", false)
  @Test fun purchasesUrdu() = screen("purchases", true)
}
