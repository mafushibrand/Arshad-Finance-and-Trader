package com.example

import com.example.business.BusinessLibrary
import com.example.business.DemoLibrary
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DemoLibraryCoverageTest {
  @Test fun everyBusinessTemplateHasCategoryMatchedVisualSamples() {
    BusinessLibrary.templates.forEach { template ->
      val samples = DemoLibrary.items(template.id)
      assertTrue("${template.id} should have at least three demo records", samples.size >= 3)
      samples.forEach { item ->
        val details = JSONObject(item.detailsJson)
        assertTrue("${template.id}: ${item.name} needs a visual sample icon",
          details.optString("demoImageEmoji").isNotBlank())
        assertTrue("${template.id}: ${item.name} must be marked as sample",
          details.optBoolean("demoSample"))
      }
    }
  }

  @Test fun serviceBusinessesReceiveTheirOwnServiceMenu() {
    listOf("salon", "mobile_repair", "clinic", "school", "travel", "gym", "solar", "software").forEach { id ->
      assertFalse("$id should have category-specific services", DemoLibrary.services(id).isEmpty())
    }
  }
}
