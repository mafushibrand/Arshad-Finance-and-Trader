package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Budget
import com.example.data.model.RecurringFrequency
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Arshad Finance", appName)
  }

  @Test
  fun `recurring frequency calculations are accurate`() {
    val cal = Calendar.getInstance().apply {
      set(2026, Calendar.AUGUST, 1, 12, 0, 0)
    }
    val startMillis = cal.timeInMillis

    val nextWeekly = RecurringFrequency.WEEKLY.getNextDate(startMillis)
    val nextCal = Calendar.getInstance().apply { timeInMillis = nextWeekly }
    assertEquals(8, nextCal.get(Calendar.DAY_OF_MONTH))

    val nextMonthly = RecurringFrequency.MONTHLY.getNextDate(startMillis)
    val monthlyCal = Calendar.getInstance().apply { timeInMillis = nextMonthly }
    assertEquals(Calendar.SEPTEMBER, monthlyCal.get(Calendar.MONTH))
  }

  @Test
  fun `budget calculations detect over-limit and warning states`() {
    val safeBudget = Budget(category = "Transport", limitAmount = 100.0, spentAmount = 50.0)
    val safePercent = (safeBudget.spentAmount / safeBudget.limitAmount) * 100.0
    assertTrue(safePercent < 80.0)

    val warningBudget = Budget(category = "Dining", limitAmount = 200.0, spentAmount = 170.0)
    val warnPercent = (warningBudget.spentAmount / warningBudget.limitAmount) * 100.0
    assertTrue(warnPercent in 80.0..99.9)

    val overBudget = Budget(category = "Shopping", limitAmount = 300.0, spentAmount = 350.0)
    val overPercent = (overBudget.spentAmount / overBudget.limitAmount) * 100.0
    assertTrue(overPercent >= 100.0)
  }
}
