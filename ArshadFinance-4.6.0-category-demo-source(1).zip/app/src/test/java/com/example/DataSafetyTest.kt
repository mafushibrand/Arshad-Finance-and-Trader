package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.BusinessPreferences
import com.example.data.local.FinanceDatabase
import com.example.data.model.Account
import com.example.data.model.AppLanguage
import com.example.data.model.ServiceItem
import com.example.data.model.InventoryItem
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItemEntry
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import com.example.data.repository.FinanceRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class DataSafetyTest {
  private val context: Context = ApplicationProvider.getApplicationContext()

  @Test fun startupKeepsCustomAccountsAndBalances() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(context, FinanceDatabase::class.java).build()
    try {
      val dao = db.financeDao()
      dao.insertAccount(Account(name = "My custom bank", accountType = "Bank", balance = 125.50, accountNumber = "CUSTOM"))
      val repo = FinanceRepository(dao, db)
      repo.ensurePakistaniAccounts()
      assertEquals(1, dao.getAccountCount())
      assertEquals(125.50, dao.getAllAccountsList().single().balance, 0.001)
      assertFalse(repo.loadPakistaniBusinessDemoData())
      assertEquals("My custom bank", dao.getAllAccountsList().single().name)
      assertEquals(0, dao.getTransactionCount())
    } finally { db.close() }
  }

  @Test fun freshBusinessStartsAtZeroAndDemoCannotOverwriteItLater() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(context, FinanceDatabase::class.java).build()
    try {
      val dao = db.financeDao()
      val repo = FinanceRepository(dao, db)
      repo.ensurePakistaniAccounts()
      repo.ensurePakistaniAccounts()
      assertEquals(1, dao.getAccountCount())
      assertEquals(0.0, dao.getAllAccountsList().single().balance, 0.0)
      assertEquals(0, dao.getTransactionCount())
      assertTrue(repo.loadPakistaniBusinessDemoData())
      val count = dao.getTransactionCount()
      assertTrue(count > 0)
      assertFalse(repo.loadPakistaniBusinessDemoData())
      assertEquals(count, dao.getTransactionCount())
    } finally { db.close() }
  }

  @Test fun configurationAndDeletedServicesSurviveStoreRecreation() {
    context.getSharedPreferences("business_config", Context.MODE_PRIVATE).edit().clear().commit()
    val store = BusinessPreferences(context)
    store.write("language", AppLanguage.ENGLISH)
    val service = ServiceItem(id = 99L, name = "Consultation", urduName = "مشاورت",
      businessCategory = "CUSTOM", serviceType = "Hourly", price = 1500.0)
    store.writeServices(listOf(service))
    val reopened = BusinessPreferences(context)
    assertEquals(AppLanguage.ENGLISH, reopened.read("language", AppLanguage.URDU))
    assertEquals(service, reopened.readServices(emptyList()).single())
    reopened.writeServices(emptyList())
    assertTrue(BusinessPreferences(context).readServices(listOf(service)).isEmpty())
  }

  @Test fun saleEditAndDeleteKeepStockKhataAndCashConsistent() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(context, FinanceDatabase::class.java).build()
    try {
      val dao = db.financeDao()
      val repo = FinanceRepository(dao, db)
      val product = dao.insertInventoryItem(InventoryItem(name = "Rice", category = "Grocery", icon = "🌾",
        costPrice = 5.0, salePrice = 10.0, currentStock = 10.0))
      fun entries(qty: Double) = listOf(InvoiceItemEntry(itemId = product, itemName = "Rice", quantity = qty, unitPrice = 10.0, total = qty * 10.0))
      val saved = repo.saveInvoiceAtomically(Invoice(invoiceNumber = "TEST-1", customerName = "Ali", grandTotal = 20.0,
        amountPaid = 10.0, remainingBalance = 10.0), entries(2.0), true)
      assertEquals(8.0, dao.getInventoryItemById(product)!!.currentStock, 0.0)
      assertEquals(10.0, dao.getCustomerById(saved.customerId)!!.currentBalance, 0.0)
      assertEquals(10.0, dao.getAllAccountsList().single().balance, 0.0)
      val edited = repo.saveInvoiceAtomically(saved.copy(grandTotal = 30.0, amountPaid = 20.0), entries(3.0), true)
      assertEquals(7.0, dao.getInventoryItemById(product)!!.currentStock, 0.0)
      assertEquals(20.0, dao.getAllAccountsList().single().balance, 0.0)
      assertEquals(1, dao.getTransactionCount())
      repo.deleteInvoiceAtomically(edited.id)
      repo.deleteInvoiceAtomically(edited.id)
      assertEquals(10.0, dao.getInventoryItemById(product)!!.currentStock, 0.0)
      assertEquals(0.0, dao.getCustomerById(saved.customerId)!!.currentBalance, 0.0)
      assertEquals(0.0, dao.getAllAccountsList().single().balance, 0.0)
      assertEquals(0, dao.getTransactionCount())
    } finally { db.close() }
  }

  @Test fun insufficientStockRollsBackEntireSale() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(context, FinanceDatabase::class.java).build()
    try {
      val dao = db.financeDao()
      val repo = FinanceRepository(dao, db)
      val product = dao.insertInventoryItem(InventoryItem(name = "Rice", category = "Grocery", icon = "🌾",
        costPrice = 5.0, salePrice = 10.0, currentStock = 1.0))
      try {
        repo.saveInvoiceAtomically(Invoice(invoiceNumber = "FAIL", customerName = "Ali", grandTotal = 20.0, amountPaid = 20.0),
          listOf(InvoiceItemEntry(itemId = product, itemName = "Rice", quantity = 2.0, unitPrice = 10.0)), true)
        fail("Overselling must be rejected")
      } catch (_: IllegalArgumentException) { }
      assertEquals(1.0, dao.getInventoryItemById(product)!!.currentStock, 0.0)
      assertEquals(0, dao.getInvoiceCount())
      assertEquals(0, dao.getCustomerCount())
      assertEquals(0, dao.getTransactionCount())
    } finally { db.close() }
  }

  @Test fun pendingApprovalPostsCashOnlyOnce() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(context, FinanceDatabase::class.java).build()
    try {
      val dao = db.financeDao()
      val repo = FinanceRepository(dao, db)
      val invoice = repo.saveInvoiceAtomically(Invoice(invoiceNumber = "ONLINE", customerName = "Ali", grandTotal = 100.0,
        amountPaid = 100.0, paymentStatus = "PENDING_APPROVAL"),
        listOf(InvoiceItemEntry(itemName = "Consultation", isService = true, unitPrice = 100.0)), false)
      assertEquals(0, dao.getTransactionCount())
      assertEquals(100.0, dao.getCustomerById(invoice.customerId)!!.currentBalance, 0.0)
      repo.decidePendingPayment(invoice.id, true)
      repo.decidePendingPayment(invoice.id, true)
      repo.decidePendingPayment(invoice.id, false)
      assertEquals(1, dao.getTransactionCount())
      assertEquals(100.0, dao.getAllAccountsList().single().balance, 0.0)
      assertEquals(0.0, dao.getCustomerById(invoice.customerId)!!.currentBalance, 0.0)
    } finally { db.close() }
  }

  @Test fun transfersAndRepeatedDeletionPreserveMoney() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(context, FinanceDatabase::class.java).build()
    try {
      val dao = db.financeDao()
      val repo = FinanceRepository(dao, db)
      dao.insertAccount(Account(name = "Cash", accountType = "Cash", balance = 100.0, accountNumber = "1"))
      dao.insertAccount(Account(name = "Bank", accountType = "Bank", balance = 20.0, accountNumber = "2"))
      val id = repo.recordTransactionAtomically(Transaction(title = "Transfer", amount = 30.0, type = TransactionType.TRANSFER,
        category = "Transfer", icon = "↔", accountName = "Cash", recipientInfo = "Bank"))
      assertEquals(listOf(70.0, 50.0), dao.getAllAccountsList().map { it.balance })
      repo.deleteTransactionAtomically(id)
      repo.deleteTransactionAtomically(id)
      assertEquals(listOf(100.0, 20.0), dao.getAllAccountsList().map { it.balance })
    } finally { db.close() }
  }

  @Test fun khataCashCollectionAndInvoiceDeletionStayConsistent() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(context, FinanceDatabase::class.java).build()
    try {
      val dao = db.financeDao(); val repo = FinanceRepository(dao, db)
      repo.ensurePakistaniAccounts()
      val id = dao.insertInventoryItem(InventoryItem(name = "Rice", salePrice = 100.0, currentStock = 10.0))
      val entries = listOf(InvoiceItemEntry(itemId = id, itemName = "Rice", quantity = 1.0, unitPrice = 100.0, total = 100.0))
      val invoice = repo.saveInvoiceAtomically(Invoice(invoiceNumber = "KHATA-1", customerName = "Ali", grandTotal = 100.0, amountPaid = 0.0, paymentMethod = "Udhar"), entries, true)
      val customer = repo.receiveCustomerCashAtomically(invoice.customerId, 40.0, "Received cash")
      assertEquals(60.0, customer.currentBalance, 0.001)
      assertEquals(40.0, dao.getAllAccountsList().sumOf { it.balance }, 0.001)
      assertEquals(9.0, dao.getInventoryItemById(id)!!.currentStock, 0.001)
      assertEquals(40.0, dao.getInvoiceById(invoice.id)!!.amountPaid, 0.001)
      try { repo.receiveCustomerCashAtomically(invoice.customerId, 70.0, "Overpayment"); fail("Overpayment accepted") } catch (_: IllegalArgumentException) { }
      assertEquals(40.0, dao.getAllAccountsList().sumOf { it.balance }, 0.001)
      repo.deleteInvoiceAtomically(invoice.id)
      assertEquals(0.0, dao.getAllAccountsList().sumOf { it.balance }, 0.001)
      assertEquals(0.0, dao.getCustomerById(invoice.customerId)!!.currentBalance, 0.001)
      assertEquals(10.0, dao.getInventoryItemById(id)!!.currentStock, 0.001)
    } finally { db.close() }
  }
}
