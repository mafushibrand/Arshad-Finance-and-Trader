package com.example

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import android.content.Context
import com.example.business.*
import com.example.data.local.FinanceDatabase
import com.example.data.model.*
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
class BusinessCoreTest {
  private val context: Context=ApplicationProvider.getApplicationContext()
  private fun db()=Room.inMemoryDatabaseBuilder(context,FinanceDatabase::class.java).addCallback(BusinessSchema.callback).build()
  @Test fun decimalUnitsAndTemplateCoverage() {
    assertEquals("48",BusinessLibrary.convert("2","24").toPlainString())
    assertEquals("1.250",BusinessLibrary.convert("0.025","50").toPlainString())
    assertTrue(BusinessLibrary.templates.size>=50)
    assertEquals(BusinessLibrary.templates.size,BusinessLibrary.templates.map {it.id}.distinct().size)
    listOf("tola","ratti","room-night","GB","shift","maund","cft").forEach {assertTrue(BusinessLibrary.allUnits.contains(it))}
    assertTrue(runCatching {BusinessLibrary.convert("2","0")}.isFailure)
    assertTrue(runCatching {BusinessLibrary.convert("-1","12")}.isFailure)
  }
  @Test fun stockHistoryReconcilesInsertUpdateReplaceAndDelete()=runBlocking {
    val db=db();try {
      val dao=db.financeDao();val id=dao.insertInventoryItem(InventoryItem(name="Rice",currentStock=10.0))
      dao.deductInventoryStock(id,1.25);assertEquals(8.75,db.businessDao().derivedStock(id),0.000001)
      dao.insertInventoryItem(InventoryItem(id=id,name="Rice",currentStock=12.0));assertEquals(12.0,db.businessDao().derivedStock(id),0.000001)
      dao.deleteInventoryItem(dao.getInventoryItemById(id)!!);assertEquals(0.0,db.businessDao().derivedStock(id),0.000001)
    }finally{db.close()}
  }
  @Test fun manufacturingConsumesIngredientsAndRejectsShortageAtomically()=runBlocking {
    val db=db();try {
      val dao=db.financeDao();val core=BusinessCore(db)
      val raw=dao.insertInventoryItem(InventoryItem(name="Raw",currentStock=20.0,costPrice=5.0))
      val output=dao.insertInventoryItem(InventoryItem(name="Finished",currentStock=0.0))
      val payload=JSONObject().put("outputId",output).put("ingredients",JSONArray().put(JSONObject().put("itemId",raw).put("quantity",2.0))).toString()
      val bom=core.create("BOM","Recipe","",0.0,payload)
      core.produce(bom.id,3.0,0.5,"owner")
      assertEquals(13.0,dao.getInventoryItemById(raw)!!.currentStock,0.000001)
      assertEquals(3.0,dao.getInventoryItemById(output)!!.currentStock,0.000001)
      assertEquals(35.0/3,dao.getInventoryItemById(output)!!.costPrice,0.000001)
      val count=db.businessDao().allRecords().size
      assertTrue(runCatching {core.produce(bom.id,20.0,0.0,"owner")}.isFailure)
      assertEquals(13.0,dao.getInventoryItemById(raw)!!.currentStock,0.000001)
      assertEquals(count,db.businessDao().allRecords().size)
      assertEquals(3.0,db.businessDao().derivedStock(output),0.000001)
    }finally{db.close()}
  }
  @Test fun supplierPartialPaymentPostsCashAndCannotOverpay()=runBlocking {
    val db=db();try {
      val core=BusinessCore(db);val dao=db.financeDao()
      dao.insertAccount(Account(name="Cash",accountType="Cash",balance=1000.0,accountNumber="CASH"))
      core.create("SUPPLIER","Supplier A","",0.0)
      core.supplierEntry("Supplier A",500.0,false,"Opening","owner")
      core.supplierEntry("Supplier A",200.0,true,"Partial payment","owner")
      assertEquals(800.0,dao.getAllAccountsList().single().balance,0.000001)
      val count=db.businessDao().allRecords().size
      assertTrue(runCatching {core.supplierEntry("Supplier A",400.0,true,"Overpay","owner")}.isFailure)
      assertEquals(count,db.businessDao().allRecords().size)
      assertEquals(800.0,dao.getAllAccountsList().single().balance,0.000001)
      assertEquals(1,dao.getTransactionCount())
    }finally{db.close()}
  }
  @Test fun duplicateRecordCannotCreateSecondJobAndCompletionKeepsId()=runBlocking {
    val db=db();try {
      val core=BusinessCore(db);val job=core.create("JOB","Repair 1","Customer",500.0)
      assertTrue(runCatching {core.create("JOB","repair 1","customer",500.0)}.isFailure)
      core.complete(job.id,"owner")
      assertEquals("COMPLETED",db.businessDao().record(job.id)!!.status)
      assertTrue(runCatching {core.complete(job.id,"owner")}.isFailure)
    }finally{db.close()}
  }
  @Test fun migrationKeepsOldStockAndAddsOpeningMovement() {
    val helper=androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context).callback(object: androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(6) {
      override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE inventory_items(id INTEGER PRIMARY KEY,name TEXT,currentStock REAL,lastUpdatedMillis INTEGER)")
        db.execSQL("INSERT INTO inventory_items VALUES(42,'Existing',7.5,1234)")
      }
      override fun onUpgrade(db: androidx.sqlite.db.SupportSQLiteDatabase,oldVersion:Int,newVersion:Int) {}
    }).build())
    try {
      val sql=helper.writableDatabase
      BusinessSchema.migration.migrate(sql)
      sql.query("SELECT currentStock,detailsJson FROM inventory_items WHERE id=42").use {assertTrue(it.moveToFirst());assertEquals(7.5,it.getDouble(0),0.0);assertEquals("{}",it.getString(1))}
      sql.query("SELECT SUM(quantity) FROM stock_movements WHERE itemId=42").use {assertTrue(it.moveToFirst());assertEquals(7.5,it.getDouble(0),0.0)}
    }finally{helper.close()}
  }
}
