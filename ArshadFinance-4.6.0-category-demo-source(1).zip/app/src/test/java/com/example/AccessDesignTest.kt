package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.LayoutDirection
import com.example.data.model.*
import com.example.ui.FinanceUiState
import com.example.ui.dialogs.SubscriptionDialog
import com.example.ui.dialogs.InvoiceDetailDialog
import com.example.ui.screens.PersonalKhataScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.BusinessProfile
import com.github.takahirom.roborazzi.captureRoboImage
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import org.junit.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*
import java.io.File

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers=RobolectricDeviceQualifiers.Pixel8,sdk=[35])
class AccessDesignTest {
 @get:Rule val compose=createComposeRule()
 private fun screen(personal:Boolean,urdu:Boolean) {
   val language=if(urdu)AppLanguage.URDU else AppLanguage.ENGLISH
   compose.setContent {MyApplicationTheme {CompositionLocalProvider(LocalLayoutDirection provides if(urdu)LayoutDirection.Rtl else LayoutDirection.Ltr) {
     if(personal)PersonalKhataScreen(FinanceUiState(appLanguage=language,appMode=AppMode.PERSONAL_KHATA),{},{},{},{_,_,_->},{_,_,_,_,_->})
     else SubscriptionDialog(SubscriptionState(deviceId="Phone-ID"),language,{}, {_,_->})
   }}}
   compose.waitForIdle()
   if(personal){compose.onNodeWithText("Products").assertDoesNotExist();compose.onNodeWithText("Services").assertDoesNotExist();compose.onNodeWithText("POS").assertDoesNotExist();compose.onNodeWithTag("personal_add_contact").assertExists()}
   val dir=File("build/design-previews").apply{mkdirs()}
   compose.onRoot().captureRoboImage(filePath=File(dir,"${if(personal)"personal-free" else "subscription-pricing"}-${if(urdu)"URDU" else "ENGLISH"}.png").absolutePath)
 }
 @Test fun personalEnglish()=screen(true,false)
 @Test fun personalUrdu()=screen(true,true)
 @Test fun pricingEnglish()=screen(false,false)
 @Test fun pricingUrdu()=screen(false,true)
 private fun headerPlans(urdu:Boolean) {
   var opened=false
   val lang=if(urdu)AppLanguage.URDU else AppLanguage.ENGLISH
   compose.setContent {MyApplicationTheme {CompositionLocalProvider(LocalLayoutDirection provides if(urdu)LayoutDirection.Rtl else LayoutDirection.Ltr) {
     com.example.ui.components.HeaderBar(onProfileClick={},appLanguage=lang,
       subscriptionState=SubscriptionState(trialStartedMillis=System.currentTimeMillis()-86_400_000L),onTrialAlertClick={opened=true})
   }}}
   compose.onNodeWithTag("subscription_access_card").assertIsDisplayed().performClick()
   Assert.assertTrue(opened)
   compose.onNodeWithText(if(urdu)"مفت ٹرائل" else "Free trial",substring=true).assertExists()
   compose.onRoot().captureRoboImage(filePath=File("build/design-previews/header-trial-${if(urdu)"URDU" else "ENGLISH"}.png").absolutePath)
 }
 @Test fun trialHeaderEnglishOpensPlans()=headerPlans(false)
 @Test fun trialHeaderUrduOpensPlans()=headerPlans(true)
 @Test fun plansVisibleAtTopOfSettings() {
   var opened=false
   compose.setContent {MyApplicationTheme {com.example.ui.screens.SettingsScreen(FinanceUiState(appLanguage=AppLanguage.ENGLISH),
     onOpenShopProfile={},onOpenShopAccounts={},onOpenIndustryCatalog={},onLoadDemoData={},onResetData={},onOpenTrialActivation={opened=true})}}
   compose.onNodeWithTag("subscription_access_card").assertIsDisplayed().performClick()
   Assert.assertTrue(opened)
 }
 private fun expiredPersonal(urdu:Boolean) {
   val lang=if(urdu)AppLanguage.URDU else AppLanguage.ENGLISH
   compose.setContent {MyApplicationTheme {CompositionLocalProvider(LocalLayoutDirection provides if(urdu)LayoutDirection.Rtl else LayoutDirection.Ltr) {
     PersonalKhataScreen(FinanceUiState(appLanguage=lang,appMode=AppMode.BUSINESS_RETAIL,
       subscriptionState=SubscriptionState(trialStartedMillis=System.currentTimeMillis()-31*86_400_000L)),{},{},{},{_,_,_->},{_,_,_,_,_->})
   }}}
   compose.onNodeWithText(if(urdu)"کاروباری رسائی ختم ہو گئی" else "Business access expired").assertIsDisplayed()
   compose.onNodeWithTag("personal_business_upgrade").assertIsDisplayed()
   compose.onNodeWithText("Products").assertDoesNotExist();compose.onNodeWithText("POS").assertDoesNotExist()
   compose.onRoot().captureRoboImage(filePath=File("build/design-previews/expired-personal-${if(urdu)"URDU" else "ENGLISH"}.png").absolutePath)
 }
 @Test fun expiredTrialEnglishShowsPersonalOnly()=expiredPersonal(false)
 @Test fun expiredTrialUrduShowsPersonalOnly()=expiredPersonal(true)
 @Test fun employeeBillingOverviewHasNoEditAction() {
   compose.setContent {MyApplicationTheme {com.example.ui.screens.BillingScreen(
     FinanceUiState(appLanguage=AppLanguage.ENGLISH,userRole=UserRole.EMPLOYEE,invoices=listOf(Invoice(id=1,invoiceNumber="B1",customerName="Customer",grandTotal=10.0))),
     onOpenAddInvoice={},onOpenEditInvoice={},onSelectInvoice={},onOpenAddCustomer={},onEditCustomer={},onSelectCustomer={},onOpenEditProfile={},onOpenShopProfile={},onOpenIndustryCatalog={},onDeleteInvoice={})}}
   compose.onNodeWithText("All bills").performClick()
   compose.onNodeWithText("Customer").assertExists()
   compose.onNodeWithText("Edit").assertDoesNotExist()
 }
 @Test fun employeeBillDetailHasNoEditAction() {
   compose.setContent {MyApplicationTheme {InvoiceDetailDialog(Invoice(invoiceNumber="B1",customerName="Customer",grandTotal=10.0),BusinessProfile(),onEditInvoice={},onDeleteInvoice={},onDismiss={},canEdit=false)}}
   compose.onNodeWithText("Edit / Update Bill (تبدیل کریں)").assertDoesNotExist()
   compose.onNodeWithTag("save_bill_image").assertExists()
 }
}
