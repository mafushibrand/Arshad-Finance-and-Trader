package com.example

import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun financialCalculations_areAccurate() {
    val transactions = listOf(
      Transaction(
        id = 1L,
        title = "Salary Deposit",
        amount = 4200.00,
        type = TransactionType.INCOME,
        category = "Salary",
        icon = "💼",
        accountName = "Main Checking"
      ),
      Transaction(
        id = 2L,
        title = "Supermarket",
        amount = 84.20,
        type = TransactionType.EXPENSE,
        category = "Shopping",
        icon = "🛍️",
        accountName = "Main Checking"
      ),
      Transaction(
        id = 3L,
        title = "Coffee Shop",
        amount = 4.50,
        type = TransactionType.EXPENSE,
        category = "Food & Dining",
        icon = "☕",
        accountName = "Main Checking"
      )
    )

    val totalIncome = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    val totalExpense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
    val netSavings = totalIncome - totalExpense

    assertEquals(4200.00, totalIncome, 0.001)
    assertEquals(88.70, totalExpense, 0.001)
    assertEquals(4111.30, netSavings, 0.001)
  }
}
