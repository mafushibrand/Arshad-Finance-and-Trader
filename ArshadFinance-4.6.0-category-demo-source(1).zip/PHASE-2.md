# Redesign source checkpoint — NOT an APK release

The supplied English/Urdu green business-management mockup was inspected and used for this direction. Native Compose changes include a green/warm-neutral palette across existing screens and dialogs, a new business overview with real data, large action cards, readable summary hierarchy, a business-name header with comfortable controls, and five-item navigation with Catalog/More sheets. Existing business screens and the detailed HomeScreen remain reachable. Reports and the existing bills/budget/recurring planner are now explicit destinations. No stock, invoice, service, ledger or transaction posting algorithms were replaced by the redesign.

Both English and Urdu are implemented in the new overview/header/navigation. Older screens still contain mixed-language/hardcoded labels and have not undergone a complete translation/layout audit. The final all-screen redesign is not complete. No emulator render or device UX check was possible.

A dedicated `testing` build type uses the existing application ID plus `.testing`. It is intended to install beside the older app so testers do not uninstall or overwrite their original records. The manifest has no added country restriction. Device/region installation must still be tested.

The missing hardcoded debug-keystore dependency was made conditional. Testing uses the supplied debug key if present, otherwise AGP's generated debug key. This is for testing only and is not production signing or an upgrade guarantee. Release build still uses debug signing from the original project; do not distribute it as a production release.

Testing build commands (in a provisioned Android/Gradle environment):

- Windows: `powershell -ExecutionPolicy Bypass -File scripts/build-testing.ps1`
- Linux/macOS: `bash scripts/build-testing.sh`
- Android Studio: open project, restore official Gradle wrapper if needed, install SDK required by compileSdk, select `testing` variant and build APK.

Scripts run the Phase 1 data-safety tests, testing lint and APK assembly, and only copy the generated APK when successful. Expected output: `dist/ArshadFinance-v4.0-testing.apk`. THIS OUTPUT HAS NOT BEEN GENERATED HERE.

Remaining build blockers: no Android SDK, Gradle, wrapper files, emulator or adb available here. Direct downloads from official Google SDK, Gradle and Maven endpoints timed out. Testing build configuration, Kotlin compilation, lint and tests were not run. Latest-Kotlin modernization remains pending compatible toolchain validation. Do not rename old APKs as the new design.

Remaining functional work: custom business builder/feature enforcement, atomic posting, purchase/return operations, actual screenshot attachment/review, account/khata reconciliation, correct financial report definitions, complete backup/restore and real owner security. This checkpoint does not claim those are complete.
