# Arshad Finance 4.6.0 — source update

This source tree remains pinned to Android `versionCode 45` / `versionName 4.6.0-plans`.

## Changes in this update
- Added category-specific demo catalogues for all 54 `BusinessLibrary` templates.
- Demo products/services carry bilingual English/Urdu names and a category-specific emoji thumbnail stored in `detailsJson`.
- Added category-specific service menu entries for service templates.
- Business Builder saves now seed the selected category's sample catalogue.
- Demo import merges only missing sample product names; it does not clear or replace existing inventory, transactions, customers, invoices, or business records.
- Workflow examples are created only when the workspace is genuinely new, avoiding duplicate sample jobs, quotations, suppliers, and production orders.
- Demo workspace list now includes every business template.
- Inventory cards display the sample category thumbnail.
- Removed the duplicate trial/pricing banner from the detailed Home screen. Trial and plan/payment access remains on the business overview and settings, rather than every screen.
- Preserved the post-login mode selection flow: Shop/Retail, Services, and Personal Khata.
- Preserved the earlier thermal-receipt JPEG/WhatsApp URI-sharing source change.

## Validation performed
- Static source checks confirm all 54 business template IDs have matching demo catalogues and each catalogue has at least three sample entries.
- Static checks confirm login-to-mode selection, overview-only trial card placement, and thermal JPEG MIME/WhatsApp URI sharing code are present.
- Added `DemoLibraryCoverageTest` for catalogue coverage and service menus.

## Build and device-test status
This environment does not have Gradle installed, the project is missing `gradle/wrapper/gradle-wrapper.jar`, and no Android SDK/ADB is configured. Therefore Gradle compilation, APK generation, automated Android tests, and physical WhatsApp/device verification could not be run here. This ZIP is an updated source project, **not a newly built APK**. Do not install or label the previous APK as containing these changes.
