# Arshad Finance 4.6.0 source checkpoint — modified, NOT an APK release

Base project: supplied `ArshadFinance-GitHub-build (6).zip`
Android version identity preserved:
- applicationId: `com.aistudio.arshadfinance.v2stock`
- preview applicationId suffix: `.design02`
- versionCode: `45`
- versionName: `4.6.0-plans`
- preview versionName suffix: `-testing`

## Changes in this checkpoint

1. Thermal WhatsApp share:
   - Creates a JPEG from the same thermal receipt bitmap/layout.
   - Uses a FileProvider content URI.
   - Adds read permission and ClipData.
   - Sends a single `image/jpeg` payload (no mixed EXTRA_TEXT payload).
   - Tries WhatsApp, then WhatsApp Business, then Android's normal share sheet.
   - Keeps the existing PNG save/export path intact.
   - Adds a Robolectric test for JPEG signature and decoded receipt dimensions.

2. Trial banner placement:
   - Removes the subscription/trial card from the global HeaderBar, where it appeared on every screen.
   - Places the subscription card on the business dashboard instead.
   - Existing plans/payment entry remains reachable through that card and settings.

## Build and verification status

This checkpoint is source code only. No APK was generated.
The project has no `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`; this runtime also has no Gradle installation, Android SDK, or `adb`.
Running `scripts/build-testing.sh` stops with:
`Gradle 9.3.1 or a restored Gradle wrapper is required. Open this project in Android Studio first.`

The new test and full project test suite have NOT been executed here. WhatsApp sending still requires testing on a real Android device with WhatsApp/WhatsApp Business installed. The full all-screen Urdu/English audit and category-by-category demo product photography/auto-seeding are also not complete in this checkpoint. Existing category templates and service catalog remain in the source. Do not distribute this source checkpoint as a tested APK.
