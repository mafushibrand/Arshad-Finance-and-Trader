$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $ProjectRoot
try {
  if (Test-Path '.\gradlew.bat') { $BuildCommand = '.\gradlew.bat' }
  elseif (Get-Command gradle -ErrorAction SilentlyContinue) { $BuildCommand = 'gradle' }
  else { throw 'Gradle 9.3.1 or a restored Gradle wrapper is required. Open this project in Android Studio first.' }
  & $BuildCommand ':app:testDebugUnitTest' '--tests' 'com.example.DataSafetyTest' ':app:lintPreview' ':app:assemblePreview'
  if ($LASTEXITCODE -ne 0) { throw "Android build failed (exit $LASTEXITCODE). No APK is ready." }
  New-Item -ItemType Directory -Path 'dist' -Force | Out-Null
  Copy-Item 'app\build\outputs\apk\testing\app-testing.apk' 'dist\ArshadFinance-v4.0-testing.apk' -Force
  Write-Output "Built: $ProjectRoot\dist\ArshadFinance-v4.0-testing.apk"
} finally { Pop-Location }
