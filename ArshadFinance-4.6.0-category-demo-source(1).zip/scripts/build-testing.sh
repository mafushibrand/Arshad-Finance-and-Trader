#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_root"
if [[ -x ./gradlew ]]; then
  build_command=(./gradlew)
elif command -v gradle >/dev/null 2>&1; then
  build_command=(gradle)
else
  printf '%s\n' 'Gradle 9.3.1 or a restored Gradle wrapper is required. Open this project in Android Studio first.' >&2
  exit 1
fi
"${build_command[@]}" :app:testDebugUnitTest --tests com.example.DataSafetyTest :app:lintPreview :app:assemblePreview
mkdir -p dist
cp app/build/outputs/apk/preview/app-preview.apk dist/ArshadFinance-v4.0-testing.apk
printf '%s\n' "Built: $project_root/dist/ArshadFinance-v4.0-testing.apk"
