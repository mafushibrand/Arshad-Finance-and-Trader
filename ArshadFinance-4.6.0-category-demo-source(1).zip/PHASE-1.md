# Phase 1 — Data safety source checkpoint

Source version: 4.0.0-alpha01 (37). Not a production release.

See ArshadFinance-Audit.md for the complete initial audit and outstanding phases.

Implemented: no demo on login, no automatic sample seeding, existing account preservation, zero cash initialization, protected transactional demo import, transactional database reset, no destructive migration fallback, durable local configuration/services, zero initial summary values.

Preserved: original application ID, Room v6 entities/tables, all pre-existing Kotlin screen/dialog/component sources, explicit demo UI, stock imports/exports, invoice receipts, recurring/budget/bill features.

Tests added: DataSafetyTest (three Robolectric behavior tests). Not run.

Build blockers: missing gradlew/gradlew.bat/wrapper JAR, missing debug.keystore referenced by build script, no Android SDK/Gradle/emulator here; Gradle download timed out. Do not rename an included older APK and present it as this checkpoint.

To verify in a provisioned Android build environment: restore the official Gradle wrapper, install the declared SDK and compatible compiler/plugins, supply the correct existing signing key; run :app:testDebugUnitTest --tests com.example.DataSafetyTest, :app:lintDebug and :app:assembleRelease. Then verify the APK certificate and test fresh install and update on a device. No successful result is claimed here.

Unknown older database schemas require real migrations before upgrade. Configuration JSON corruption currently fails instead of silently overwriting saved data; a recovery UI is still needed. Full reset is not yet a full configuration reset. SharedPreferences configuration writes are separate from Room financial writes. Secure auth and staff permissions remain pending.

Only source is included in this checkpoint; binaries from the original ZIP have been omitted to prevent mistaking them for newly built artifacts. Original ZIP remains available unchanged.
