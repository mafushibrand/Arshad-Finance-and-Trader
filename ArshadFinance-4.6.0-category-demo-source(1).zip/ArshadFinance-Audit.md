# Arshad Finance — Project audit and implementation plan

Date: 5 October 2026. Input: `arshad-finance (3).zip`.

## Read this first / پہلے یہ پڑھیں

The uploaded app is already a native Kotlin / Jetpack Compose Android project. It is not a web app that needs to be rewritten. There are 72 Kotlin files, about 31,865 lines, 11 screen files, 27 dialog files and eight Room entities. This is a static source audit, not a claim that every feature was executed on a phone. No physical device or Android emulator was available.

ایپ پہلے سے Kotlin میں ہے۔ اصل فیچرز برقرار رکھ کر مرحلہ وار درست کیے جائیں گے۔ ZIP میں database بنانے کا code موجود ہے، مگر آپ کے اصل کاروباری records کی database file شامل نہیں ہے۔

The source contains substantial existing functionality, but several controls are demonstrations rather than completed business operations. Existing APKs are supplied binaries, not proof that the current source compiles or matches them. Original uploaded ZIP remains unchanged.

## Architecture and storage

- `MainActivity.kt`: activity, login/mode gates, screen dispatch and dialog callbacks.
- `ui/FinanceViewModel.kt`: navigation, business configuration, cart, transactions, customer balances, invoice creation, inventory and recurring processing. About 1,750 lines; substantial responsibility concentrated here.
- `data/repository/FinanceRepository.kt`: Room DAO forwarding, account initialization and demo population.
- `data/local/FinanceDatabase.kt`: Room version **6**, database name `arshad_finance_db`. No exported migration schemas or explicit migration path included.
- `data/local/FinanceDao.kt`: CRUD and stock/customer increments.
- Room tables: `transactions`, `accounts`, `bills`, `budgets`, `recurring_transactions`, `inventory_items`, `customers`, `invoices`.
- Invoice lines are stored as JSON in `Invoice.itemsJson`; no separate line table. Relationships are IDs without declared foreign keys in the reviewed models.
- Services, selected services, shop bio, language, mode, profile, permissions and user/session configuration use in-memory StateFlows. No durable configuration storage found before this work.
- No verified cloud backup/restore implementation. Firestore/Auth dependencies are commented out; cloud UI calls local demo loading.

## Navigation map

Login → mode selection → `Scaffold` → selected enum tab → dialogs.

| Tab | Screen | Main function |
| --- | --- | --- |
| HOME | HomeScreen | Summary, actions, activity, business categories |
| STOCK (alias PRODUCTS) | InventoryScreen | Products, quantities, search, import/export |
| SERVICES | ServicesScreen | Service catalog, pricing, shop bio, add to cart |
| POS | PosCounterScreen | Shared cart, checkout, receipt preview |
| LEDGERS (alias BILLING) | BillingScreen | Customers, invoices, khata |
| ACCOUNTS | CardsScreen | Cash/bank/mobile wallets |
| SETTINGS | SettingsScreen | Profile, mode, permissions, demo/reset, imports |

`FinanceTab.STATS` is an alias of HOME. `StatsScreen` and `BillsScreen` exist but are not dispatched as separate destinations in the current `when` block. This limits discoverability of the older report/planner screens; keep their code and reconnect deliberately. Personal mode exposes fewer tabs. Android back-stack handling and selected-tab restoration need explicit device tests.

## Feature coverage

“Present” means code exists; it does not mean runtime verification passed.

| Requested area | Existing coverage | Remaining work |
| --- | --- | --- |
| Custom Business Builder | Three modes, category showcase, industry import, editable profile | Durable custom categories, units, workflow/feature choices, onboarding preview; business scoping if multiple businesses are required |
| Products | Room model and CRUD dialogs/screens | Validation, barcode/device behavior, soft archive, historical price protection |
| Services | Rich CRUD/discount/featured interface | Durable storage; remove invented cost assumption; clarify slots vs stock |
| Stock | Quantity adjustments, low-stock UI, import/export | Movement ledger, oversell protection, atomic writes, rollback, audited imports |
| POS/Billing | Cart, invoice lines, discounts, payments, receipt preview/export | Atomic commit, success acknowledgment before clearing cart, unique numbering, correct edit/delete reversals |
| Cash/Wallets | Account models and transaction forms | Atomic balances, transfer destination, settlement/reversal reconciliation |
| Online screenshot | Approval dialog; transaction form has image picker | Actual POS file picker, durable receipt storage, pending state, settlement once only |
| Udhar/Khata | Customer balances, invoices, reminders and detail UI | Payment allocations, recoveries, invoice/customer reconciliation and supplier payable separation |
| Purchases | Stock-in expense path; POS mode selector | Purchase documents, supplier bills/payables, actual purchase-mode execution |
| Returns | POS mode selector | Original sale linkage, stock refund and cash/khata reversal; current selector does not change posting behavior |
| Expenses | Transactions, bills, budget and recurring code | Correct delete/reversal, durable operation boundaries, report classification |
| Reports | Dashboard summaries, tax dialog, StatsScreen, exports | Accurate date windows, profit/COGS, accounts reconciliation and dedicated reports navigation |
| Settings | Many dialogs and switches | Durable values, coherent settings hierarchy and genuine backup/restore |
| Feature toggles | Mode and employee-permission controls | Durable individual business feature switches, enforcement in actions and navigation, preserve hidden data |
| English + Urdu | Language enum and RTL provider; many bilingual strings | Central resource translations, all screens/dialogs, Urdu wrapping, numeric LTR islands, exports and accessibility QA |
| Data safety | Room persistence and Android backup placeholders | Non-destructive migrations, user-controlled full backup/restore, integrity checks, protected receipts and atomic operations |

## Findings ranked by priority

### Critical: login can erase real business records

Evidence: `FinanceViewModel.loginUser()` calls `loadPakistaniBusinessDemo()`; repository `loadPakistaniBusinessDemoData()` begins with `clearAllData()`. That function deletes all eight business tables. This is not cloud restore. Repeated local login can wipe records and replace them with sample data. Remove automatic demo load and make explicit demo import refuse a non-empty business.

### Critical: upgrades can silently delete the database

Evidence: `FinanceDatabase.getDatabase()` calls `.fallbackToDestructiveMigration()` with schema version 6 and no migrations. Missing migration paths can recreate tables destructively. Preserve current v6 schema; fail safely for unknown older schemas until their real schema/export is available. Do not invent migrations or change application ID to bypass upgrade issues.

### High: startup can replace user accounts or seed fake balances

Evidence: `ensurePakistaniAccounts()` deletes all accounts when names do not match its expected list. `prepopulateIfEmpty()` and database creation callback seed example balances and transactions. A user-created account is not invalid just because it has a different name. Fresh real businesses must start at zero, and existing accounts must stay untouched.

### High: invoice posting is not atomic

Evidence: `createInvoice()` sequentially updates invoice, customer, stock and income transaction without a database transaction. A failure can leave half a sale. Stock deduction query has no availability condition; checkout should validate and deduct atomically. POS clears the cart before the asynchronous save result is known (`PosCounterScreen` around lines 669–670).

### High: screenshot payment is simulated and can corrupt khata

Evidence: POS `hasAttachedScreenshot` is a Boolean toggled by a button, not a file upload. Invoice has no receipt URI field. Approval only sets invoice paid; it does not settle customer balances or post wallet income. Rejection adds the full grand total to customer balance and can do so repeatedly. `pendingScreenshotInvoices` includes payment-method matches even when already paid. Required fix: real receipt attachment, explicit pending status, transactional and idempotent review, payment allocation and durable receipt bytes.

### High: services/settings disappear after process restart

Evidence: `_services`, `_businessProfile`, `_shopBioData`, `_appLanguage`, `_appMode`, `_userAccount`, permissions and subscription state are initialized in ViewModel only. Service edits and settings need durable local storage. Existing default service templates can remain available as templates, but should not be presented as the user’s actual business records.

### High: purchase/return modes do not post purchase/return transactions

Evidence: `activeMode` is changed only by the selector and used for styling; checkout still invokes the same sale callback. These require distinct stock and accounting operations. Do not claim purchase and return functionality is complete because buttons exist.

### High: cash and invoice reversals are inconsistent

Evidence: new invoice income uses hardcoded account name `Main Checking`, rather than selected payment account. Invoice edit reverses customer totals but does not reconcile corresponding stock/account/income changes. Invoice delete adjusts customer totals only. Transaction delete does not undo account balance; transfers only deduct a source. Fix using an auditable posting/reversal service within Room transactions.

### High: local login is not authenticated cloud access

Evidence: role dialog accepts an empty owner PIN and hardcodes `1234`. Auth login does not verify the entered password; recovery UI displays a PIN-sent toast without a transport call. Subscription accepts broad string patterns. Retain useful UI but distinguish local profile access from actual authentication; secure owner verification and action-level permissions before real staff deployment.

### High: reports use inaccurate financial definitions

Evidence: HomeScreen uses remaining inventory cost as `totalPurchase`, subtracts it from sales for `netProfitMonth`, and month-named totals are not filtered to a month. `netEarnings` clamps losses to zero. Inventory valuation is not purchases, sales are not cash receipts, and profit requires cost of goods sold and applicable expenses. Implement explicit periods and definitions backed by source transactions.

### Medium: receipt access and backup are incomplete

Evidence: transaction picker uses `GetContent` and stores the URI only. That URI may not remain accessible; use persisted document access or internal copies with validated type/size. Backup XML files are templates; no complete user export/restore UI was found. Stock export is not a full application backup. Back up database, preferences and receipt bytes together, validate before restoring, and keep a recovery snapshot.

### Medium: UI and bilingual polish require a full pass

Source evidence: custom screens use many hardcoded colors, English/bilingual inline labels, fixed widths/heights and 10–12sp text. Language switching does not translate every label. This is a source-based design assessment, not a screenshot-based accessibility audit. Use a consistent token system, 14–16sp body text, comfortable touch areas, restrained shadows, proper Urdu line height, scalable cards and shorter navigation. Verify actual layouts at small/large font sizes in both directions.

### Medium: tax output contains simulated identifiers

Evidence: POS generates a random FBR token; export helpers use a fixed token string. No genuine FBR submission/verification was found. Label calculations as local tax estimates and remove claims of official submission until a real integration exists. This audit does not determine applicable tax rates or provide tax advice.

## Build/install audit

- Current source: `applicationId=com.aistudio.arshadfinance.v2stock`, versionCode **36**, versionName **3.5.0**, minSdk **24** (Android 7+), targetSdk **34**.
- Catalog: Kotlin Compose plugin **2.2.10**, AGP **9.1.1**, KSP **2.3.5**, Room **2.7.0**, Compose BOM **2024.09.00**. AGP uses built-in Kotlin; compiler and Compose plugin versions must be compatible.
- Wrapper properties reference Gradle **9.3.1**, but `gradlew`, `gradlew.bat` and wrapper JAR are missing.
- Release signs using `rootDir/debug.keystore`; that file is not included. No production signing key was supplied.
- Existing root APKs include v3.4, v3.5, unversioned and Release. Unversioned APK is byte-identical to v3.5. Do not rename any old APK as a redesigned release.
- APK ZIPs have no v1 signature entries; that does not establish that they are unsigned, since APK v2/v3 signatures are outside those entries. Proper `apksigner verify` remains required.
- This workspace has Java 17, but no Android SDK, Gradle installation, emulator or adb was found in the standard paths checked. Attempt to reach the Gradle distribution timed out. Compilation/install tests are blocked here.
- A future APK must retain the application ID, use a higher versionCode and the same signing certificate to update an existing installation without uninstalling. If the old signing key is unavailable, seamless update cannot be promised.
- Proposed final release name: **ArshadFinance-v4.0.apk**, versionName **4.0.0**, versionCode at least **37**. This is a plan, not an APK delivered in this phase.
- Official Kotlin release documentation currently lists **2.4.20**. Updating to it must include compatible AGP/Kotlin/Compose/KSP verification; changing one version string is not a verified modernization.

## Design direction

Retain the existing native Compose app and its green/indigo/slate visual vocabulary; refine with a consistent premium interface. Home should show the current business name, real date, cash, receivable/payable, sales and quick actions. Primary navigation: Home, POS, Khata, Catalog, More; retain all current features behind clear secondary destinations. The builder should ask business name/type, products/services/both, units, cash/online/credit preferences, feature switches and invoice branding.

Use English and Urdu versions of every resource, deliberate RTL placement, LTR phone/amount/reference fields, unclipped Urdu text and clear empty/error/success states. Images from the previously discussed mockups may be reused after their actual files are retrieved; they are not present in this project ZIP. The only included assets outside resources are older APKs. Do not claim the mockups were visually inspected during this source audit.

## Phase-by-phase implementation and acceptance

| Phase | Scope | Exit criteria |
| --- | --- | --- |
| 0 — audit | Feature map, data risks, build audit, preservation plan | This report; original ZIP retained |
| 1 — safety foundation | Stop login/startup data replacement, persist config/services, block destructive demo import, preserve schema | Existing records survive login/restart; empty real business starts at zero; targeted tests |
| 2 — business builder and design | Custom categories, units, toggles, navigation, design tokens, complete translations | Retail, services and personal modes usable in both languages; all old features reachable |
| 3 — posting correctness | Atomic sale/purchase/return, stock ledger, wallet posting, customer recovery, invoice edit/void | No partial sale, negative stock or duplicate posting; reconciliation and rollback tests |
| 4 — screenshot and reports | Real attachments, pending review, split settlement, report periods/profit, exports | Review changes balances once; receipts survive restart; reports reconcile to postings |
| 5 — backup/security | Full export/validated restore, safe reset/import, owner PIN and permissions | Corrupt restore changes nothing; valid round-trip preserves records/settings/receipts |
| 6 — release | Compatible current Kotlin toolchain, signing, APK build, install/update, device QA | APK signature validated; fresh install and same-key upgrade; English/Urdu, offline/restart and workflow tests |

No working feature should be removed. Keep the existing Room tables and data identity. Add schemas/entities and migrations only with fixtures and integrity tests. Preserve transaction, recurring, budget, bills, stock import/export and all receipt/share functionality during navigation changes. Feature switches hide entry points and guard operations, never delete records.

## Required release tests

1. Seed representative v6 data; login/logout and restart without changing records.
2. Cash sale, online payment, screenshot pending/approve/reject, split payment and credit sale; reconcile stock, accounts, customer totals and invoices.
3. Repeated approve/reject cannot duplicate settlement; rejected receipt remains attached and recoverable.
4. Insufficient stock and injected write failure leave cart and all data unchanged.
5. Purchase, supplier payable, supplier payment, customer recovery and partial return reconcile independently.
6. Invoice edit/void and transaction reversal update all linked effects exactly once.
7. Backup/export/restore with Urdu text and receipts; malformed or incomplete backup is rejected before any deletion.
8. Owner/employee action enforcement; blank/wrong PIN rejected.
9. Both languages, large fonts, small screens, keyboard, rotation and process death.
10. Real APK install, offline launch, same-certificate upgrade and minSdk compatibility.

## Outcome

The app has a useful native foundation worth preserving. The first priority is protecting existing records and making configuration durable; a cosmetic-only redesign would leave substantial business errors. A finished premium app and a verified installable APK are not delivered by this audit. Build and device verification are prerequisites to claiming installation readiness.

## Phase 1 source checkpoint delivered after audit

Status: source changes made; Kotlin/Android compilation and the three added Robolectric tests **not executed** because the build toolchain is unavailable. This is an alpha source checkpoint, not a finished or install-tested app.

- Login no longer calls demo import.
- Startup no longer calls the sample prepopulation method or registers the sample-data callback.
- Startup preserves custom accounts and creates only one zero-balance cash account if no accounts exist.
- Explicit demo import remains available, but it refuses existing business records or custom/funded accounts. Demo import and full database reset now use Room transactions.
- Destructive migration fallback removed; schema remains version 6. Older unknown schemas now need an explicit migration rather than being erased. This safeguard can prevent launch for older unsupported databases; it does not substitute for migration tests.
- Added local JSON configuration persistence using the already-declared Moshi Kotlin dependency: profile, language, mode, user/session, permissions, subscription, currency, services, featured services, bio and relevant switches. Malformed saved configuration currently fails rather than silently discarding records; recovery UI is pending. Services remain outside Room for this checkpoint.
- Initial summary placeholders now start at zero.
- Source version is 4.0.0-alpha01 / code 37. Kotlin toolchain upgrade remains pending compatible build verification.
- Added three behavior tests for custom-account preservation, protected demo loading and configuration/service persistence. Source invariants were checked separately; these do not prove Android runtime behavior.

All existing Kotlin sources remain, with localized fixes in the database builder, repository, ViewModel and build version. Existing working UI screens/dialogs were not redesigned or replaced in Phase 1. Full bilingual redesign, custom builder, posting corrections, screenshot implementation, reports, backup/security and final APK remain pending phases 2–6.
